#include <bits/stdc++.h>
using namespace std;

const int MAXN = 26;

int t, n, p[MAXN], total;

int main() {
    cin >> t;
    for (int i = 1; i <= t; i++) {
        cin >> n;
        total = 0;
        priority_queue<pair<int, char>> pq;
        for (int j = 0; j < n; j++) {
            cin >> p[j];
            pq.push({p[j], 'A' + j});
            total += p[j];
        }
        cout << "Case #" << i << ": ";
        while (total > 0) {
            auto [f1, c1] = pq.top();
            pq.pop();
            total--;
            if (total == 0 || f1 > total / 2) {
                cout << c1 << " ";
            } else {
                auto [f2, c2] = pq.top();
                pq.pop();
                total--;
                cout << c1 << c2 << " ";
                if (f2 > 1) {
                    pq.push({f2 - 1, c2});
                    total++;
                }
            }
            if (f1 > 1) {
                pq.push({f1 - 1, c1});
                total++;
            }
        }
        cout << "\n";
    }
    return 0;
}
