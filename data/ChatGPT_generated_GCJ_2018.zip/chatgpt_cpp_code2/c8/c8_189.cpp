#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void print_vector(const vector<string>& vec) {
    for (const string& s : vec) {
        cout << s << " ";
    }
    cout << endl;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<pair<int, char>> parties;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            parties.push_back({P, 'A' + i});
        }

        vector<string> plan;
        while (true) {
            sort(parties.rbegin(), parties.rend());

            if (parties[0].first == 0) {
                break;
            }

            if (parties[0].first > parties[1].first || (parties[0].first == parties[1].first && N == 2)) {
                plan.push_back(string(1, parties[0].second));
                parties[0].first--;
            } else {
                plan.push_back(string(1, parties[0].second) + string(1, parties[1].second));
                parties[0].first--;
                parties[1].first--;
            }
        }

        cout << "Case #" << t << ": ";
        print_vector(plan);
    }

    return 0;
}
