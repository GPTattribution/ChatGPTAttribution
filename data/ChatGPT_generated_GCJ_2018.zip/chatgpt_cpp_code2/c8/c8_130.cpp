#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> pq;
        int sum = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            pq.push({p, 'A' + j});
            sum += p;
        }
        string ans;
        while (!pq.empty()) {
            char a = pq.top().second;
            pq.pop();
            sum--;
            ans += a;
            if (!pq.empty() && pq.top().first * 2 > sum) {
                char b = pq.top().second;
                pq.pop();
                sum--;
                ans += b;
                pq.push({--pq.top().first, pq.top().second});
            }
            if (!pq.empty() && pq.top().first * 2 > sum) {
                char b = pq.top().second;
                pq.pop();
                sum--;
                ans += b;
                pq.push({--pq.top().first, pq.top().second});
            }
            if (pq.empty() && sum > 0) {
                char b = ans.back();
                ans.pop_back();
                ans += " ";
                ans += b;
            }
            ans += " ";
        }
        cout << "Case #" << i << ": " << ans << "\n";
    }
    return 0;
}
