#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        priority_queue<Party> pq;
        int total = 0;
        for (char i = 'A'; i < 'A' + N; i++) {
            int count;
            cin >> count;
            pq.push({i, count});
            total += count;
        }

        vector<string> plan;
        while (!pq.empty()) {
            Party first = pq.top();
            pq.pop();
            total--;
            if (total == 0) {
                plan.push_back(string(1, first.name));
                break;
            }
            Party second = pq.top();
            pq.pop();
            total--;
            plan.push_back(string(1, first.name) + string(1, second.name));
            first.count--;
            second.count--;
            if (first.count > 0) {
                pq.push(first);
            }
            if (second.count > 0) {
                pq.push(second);
            }
        }

        cout << "Case #" << t << ": ";
        for (string& step : plan) {
            cout << step << " ";
        }
        cout << endl;
    }

    return 0;
}
