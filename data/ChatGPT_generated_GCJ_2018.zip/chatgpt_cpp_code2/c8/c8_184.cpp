#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

struct Party {
    int size;
    char name;
};

struct PartyComparator {
    bool operator() (const Party& p1, const Party& p2) const {
        return p1.size < p2.size;
    }
};

int getPartyIndex(char name) {
    return name - 'A';
}

string createEvacuationPlan(vector<Party>& parties) {
    priority_queue<Party, vector<Party>, PartyComparator> pq;
    for (int i = 0; i < parties.size(); i++) {
        pq.push(parties[i]);
    }

    string plan = "";

    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        Party p2 = pq.top();
        pq.pop();

        plan += p1.name;
        plan += p2.name;

        p1.size--;
        p2.size--;

        if (p1.size > 0) {
            pq.push(p1);
        }
        if (p2.size > 0) {
            pq.push(p2);
        }

        if (!pq.empty()) {
            plan += " ";
        }
    }

    return plan;
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;

        vector<Party> parties;
        for (int j = 0; j < n; j++) {
            Party p;
            cin >> p.size;
            p.name = 'A' + j;
            parties.push_back(p);
        }

        string plan = createEvacuationPlan(parties);

        cout << "Case #" << i << ": " << plan << endl;
    }

    return 0;
}
