#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;

struct Party {
    char name;
    int count;
    Party(char name, int count) : name(name), count(count) {}
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
}

void evacuate(int t, vector<Party>& parties) {
    cout << "Case #" << t << ": ";
    priority_queue<Party> pq;
    for (Party& p : parties) {
        pq.push(p);
    }
    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        Party p2 = pq.top();
        pq.pop();
        cout << p1.name;
        p1.count--;
        if (p1.count > 0) {
            pq.push(p1);
        }
        if (p2.count > 0) {
            cout << p2.name;
            p2.count--;
            if (p2.count > 0) {
                pq.push(p2);
            }
        }
        cout << " ";
    }
    cout << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<Party> parties;
        for (int i = 0; i < N; i++) {
            char name = 'A' + i;
            int count;
            cin >> count;
            parties.emplace_back(name, count);
        }
        evacuate(t, parties);
    }
    return 0;
}
