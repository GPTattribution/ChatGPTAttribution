#include <iostream>
#include <queue>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<Party> parties;
        for (int i = 0; i < N; i++) {
            int count;
            cin >> count;
            parties.push({'A' + i, count});
        }
        cout << "Case #" << t << ":";
        while (!parties.empty()) {
            Party p1 = parties.top();
            parties.pop();
            if (parties.empty()) {
                for (int i = 0; i < p1.count; i++) {
                    cout << " " << p1.name;
                }
                break;
            }
            Party p2 = parties.top();
            parties.pop();
            cout << " " << p1.name << p2.name;
            if (p1.count > 1) {
                parties.push({p1.name, p1.count - 1});
            }
            if (p2.count > 1) {
                parties.push({p2.name, p2.count - 1});
            }
        }
        cout << endl;
    }
    return 0;
}
