#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
};

bool partyCompare(Party& p1, Party& p2) {
    return p1.count > p2.count;
}

string generateEvacuationPlan(vector<Party>& parties) {
    sort(parties.begin(), parties.end(), partyCompare);

    string plan;

    priority_queue<Party, vector<Party>, decltype(&partyCompare)> pq(&partyCompare);
    for (auto& party : parties) {
        pq.push(party);
    }

    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        plan += p1.name;
        p1.count--;
        if (!pq.empty() && pq.top().count > p1.count) {
            Party p2 = pq.top();
            pq.pop();
            plan += p2.name;
            p2.count--;
            if (p2.count > 0) {
                pq.push(p2);
            }
        }
        if (p1.count > 0) {
            pq.push(p1);
        }
        if (!pq.empty()) {
            plan += ' ';
        }
    }

    return plan;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<Party> parties;
        for (int i = 0; i < N; i++) {
            int count;
            cin >> count;
            Party party = {'A' + i, count};
            parties.push_back(party);
        }
        string plan = generateEvacuationPlan(parties);
        cout << "Case #" << t << ": " << plan << endl;
    }

    return 0;
}
