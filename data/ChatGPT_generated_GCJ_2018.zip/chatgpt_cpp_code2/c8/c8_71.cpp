#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <cstring>

using namespace std;

struct Party {
    char name;
    int count;
    Party(char name, int count) : name(name), count(count) {}
};

struct CompareParties {
    bool operator()(const Party& p1, const Party& p2) {
        return p1.count < p2.count;
    }
};

string constructEvacuationPlan(vector<Party>& parties) {
    string plan;
    priority_queue<Party, vector<Party>, CompareParties> pq;

    for (auto& party : parties) {
        pq.push(party);
    }

    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();

        if (pq.size() >= 1) {
            Party p2 = pq.top();
            pq.pop();
            plan += p1.name;
            plan += p2.name;
            p1.count--;
            p2.count--;

            if (p1.count > 0) {
                pq.push(p1);
            }
            if (p2.count > 0) {
                pq.push(p2);
            }
        } else {
            plan += p1.name;
            p1.count--;

            if (p1.count > 0) {
                pq.push(p1);
            }
        }

        plan += " ";
    }

    if (plan.back() == ' ') {
        plan.pop_back();
    }

    return plan;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<Party> parties;
        for (int i = 0; i < N; i++) {
            int count;
            cin >> count;
            parties.emplace_back('A' + i, count);
        }

        string plan = constructEvacuationPlan(parties);
        cout << "Case #" << t << ": " << plan << endl;
    }

    return 0;
}
