#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties(n);
        for (int j = 0; j < n; j++) {
            cin >> parties[j].first;
            parties[j].second = 'A' + j;
        }
        sort(parties.begin(), parties.end(), greater<pair<int, char>>());
        cout << "Case #" << i << ": ";
        while (parties[0].first > 0) {
            if (parties[0].first > parties[1].first) {
                cout << parties[0].second << parties[0].second << " ";
                parties[0].first -= 2;
            } else {
                cout << parties[0].second << parties[1].second << " ";
                parties[0].first--;
                parties[1].first--;
            }
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());
        }
        cout << endl;
    }
    return 0;
}
