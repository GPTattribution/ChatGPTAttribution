#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties(n);
        int total = 0;
        for (int j = 0; j < n; j++) {
            cin >> parties[j].first;
            parties[j].second = 'A' + j;
            total += parties[j].first;
        }
        sort(parties.rbegin(), parties.rend());
        cout << "Case #" << i << ": ";
        while (total > 0) {
            if (parties[0].first > (total - 1) / 2) {
                cout << parties[0].second << parties[1].second << " ";
                parties[0].first--;
                parties[1].first--;
                total -= 2;
            } else {
                cout << parties[0].second << " ";
                parties[0].first--;
                total--;
            }
            sort(parties.rbegin(), parties.rend());
        }
        cout << endl;
    }
    return 0;
}
