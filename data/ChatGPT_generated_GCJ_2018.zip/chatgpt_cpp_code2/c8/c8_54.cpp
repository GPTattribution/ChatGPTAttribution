#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<int> parties(N);
        priority_queue<pair<int, int>> q;
        for (int i = 0; i < N; i++) {
            cin >> parties[i];
            q.push({parties[i], i});
        }
        string ans;
        while (!q.empty()) {
            int p1 = q.top().second;
            q.pop();
            if (q.empty()) {
                ans += char('A' + p1);
                break;
            }
            int p2 = q.top().second;
            q.pop();
            ans += char('A' + p1);
            ans += char('A' + p2);
            parties[p1]--;
            parties[p2]--;
            if (parties[p1] > 0) {
                q.push({parties[p1], p1});
            }
            if (parties[p2] > 0) {
                q.push({parties[p2], p2});
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
