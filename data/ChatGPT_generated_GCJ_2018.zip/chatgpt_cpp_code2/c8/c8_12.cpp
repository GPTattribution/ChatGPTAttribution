#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            parties.push_back(make_pair(P, 'A' + i));
        }
        priority_queue<pair<int, char>> pq;
        for (int i = 0; i < N; i++) {
            pq.push(make_pair(parties[i].first, parties[i].second));
        }
        string ans = "";
        while (!pq.empty()) {
            pair<int, char> p1 = pq.top();
            pq.pop();
            if (pq.empty()) {
                ans += p1.second;
                break;
            }
            pair<int, char> p2 = pq.top();
            pq.pop();
            ans += p1.second;
            ans += p2.second;
            p1.first--;
            p2.first--;
            if (p1.first > 0) pq.push(p1);
            if (p2.first > 0) pq.push(p2);
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
