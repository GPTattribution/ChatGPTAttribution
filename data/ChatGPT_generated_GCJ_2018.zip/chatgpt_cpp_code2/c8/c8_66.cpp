#include <iostream>
#include <queue>
#include <vector>

using namespace std;

struct Party {
    char name;
    int count;
};

struct EvacuationStep {
    string parties;
    vector<int> counts;
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
}

vector<Party> read_parties(int n) {
    vector<Party> parties(n);
    for (int i = 0; i < n; i++) {
        parties[i].name = 'A' + i;
        cin >> parties[i].count;
    }
    return parties;
}

string evacuate(vector<Party> parties) {
    int n = parties.size();

    priority_queue<Party> q;
    for (Party& p : parties) {
        q.push(p);
    }

    vector<EvacuationStep> steps;

    while (!q.empty()) {
        EvacuationStep step;
        step.counts.reserve(n);

        Party p1 = q.top(); q.pop();
        step.parties.push_back(p1.name);
        p1.count--;
        step.counts.push_back(p1.count);
        if (p1.count > 0) {
            q.push(p1);
        }

        if (q.empty()) {
            steps.push_back(step);
            break;
        }

        Party p2 = q.top(); q.pop();
        step.parties.push_back(p2.name);
        p2.count--;
        step.counts.push_back(p2.count);
        if (p2.count > 0) {
            q.push(p2);
        }

        steps.push_back(step);

        if (p1.count > p2.count) {
            swap(p1, p2);
        }

        if (p2.count > 0) {
            q.push(p2);
        }
    }

    string result;
    for (int i = 0; i < steps.size(); i++) {
        for (int j = 0; j < steps[i].parties.size(); j++) {
            result.push_back(steps[i].parties[j]);
        }
        if (i < steps.size() - 1) {
            result.push_back(' ');
        }
    }

    return result;
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;

        vector<Party> parties = read_parties(n);

        string result = evacuate(parties);

        cout << "Case #" << i << ": " << result << endl;
    }

    return 0;
}
