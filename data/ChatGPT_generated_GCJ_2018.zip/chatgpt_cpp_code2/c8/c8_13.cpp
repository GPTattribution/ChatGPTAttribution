#include<bits/stdc++.h>
using namespace std;

struct Party{
    int count;
    char name;
};

void solve(int n, vector<Party>& parties, int t){
    priority_queue<pair<int, char>> q;
    for(int i=0; i<n; i++){
        q.push({parties[i].count, parties[i].name});
    }
    cout<<"Case #"<<t<<": ";
    while(!q.empty()){
        char first_party = q.top().second;
        q.pop();
        char second_party = ' ';
        if(!q.empty() && q.top().first > 1){
            second_party = q.top().second;
            q.pop();
            q.push({q.top().first-1, q.top().second});
        }
        cout<<first_party<<second_party<<" ";
    }
    cout<<endl;
}

int main(){
    int t;
    cin>>t;
    for(int i=1; i<=t; i++){
        int n;
        cin>>n;
        vector<Party> parties(n);
        int total_senators = 0;
        for(int j=0; j<n; j++){
            cin>>parties[j].count;
            parties[j].name = 'A'+j;
            total_senators += parties[j].count;
        }
        solve(n, parties, i);
    }
    return 0;
}
