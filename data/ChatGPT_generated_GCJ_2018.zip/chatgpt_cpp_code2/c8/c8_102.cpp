#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties;
        for (char c = 'A'; c < 'A' + n; c++) {
            int p;
            cin >> p;
            parties.push_back({p, c});
        }

        vector<string> plan;
        while (true) {
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());
            if (parties[0].first == 0) {
                break;
            }

            string step;
            for (int j = 0; j < 2; j++) { 
                if (parties[j].first > 0) {
                    step += parties[j].second;
                    parties[j].first--;
                }
            }
            plan.push_back(step);
        }

        cout << "Case #" << i << ": ";
        for (const string& step : plan) {
            cout << step << " ";
        }
        cout << endl;
    }

    return 0;
}
