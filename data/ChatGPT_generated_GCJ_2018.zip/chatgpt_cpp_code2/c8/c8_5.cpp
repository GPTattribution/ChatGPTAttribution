#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> pq;
        int total_senators = 0;
        for (char c = 'A'; c < 'A' + n; c++) {
            int p;
            cin >> p;
            pq.push({p, c});
            total_senators += p;
        }
        string ans;
        while (!pq.empty()) {
            auto first = pq.top();
            pq.pop();
            total_senators--;
            ans += first.second;
            first.first--;
            if (first.first > 0) pq.push(first);
            if (total_senators == 0) break;
            auto second = pq.top();
            pq.pop();
            total_senators--;
            ans += second.second;
            second.first--;
            if (second.first > 0) pq.push(second);
            pq.push(first);
            if (total_senators == 0) break;
        }
        cout << "Case #" << i << ": " << ans << "\n";
    }
    return 0;
}
