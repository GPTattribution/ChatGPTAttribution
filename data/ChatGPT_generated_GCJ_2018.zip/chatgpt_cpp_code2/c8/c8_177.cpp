#include <iostream>
#include <vector>
#include <queue>

using namespace std;

struct Party {
    int count;
    char name;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

vector<Party> read_parties(int n) {
    vector<Party> parties(n);
    for (int i = 0; i < n; i++) {
        int count;
        cin >> count;
        parties[i] = {count, 'A' + i};
    }
    return parties;
}

void print_plan(int case_number, const vector<string>& plan) {
    cout << "Case #" << case_number << ":";
    for (const string& move : plan) {
        cout << " " << move;
    }
    cout << endl;
}

vector<string> evacuate(vector<Party> parties) {
    vector<string> plan;
    priority_queue<Party> q;
    for (Party& p : parties) {
        q.push(p);
    }
    while (!q.empty()) {
        Party first = q.top();
        q.pop();
        if (first.count == 1) {
            Party second = q.top();
            q.pop();
            second.count--;
            plan.push_back(string(1, first.name) + second.name);
            if (second.count > 0) {
                q.push(second);
            }
        } else {
            first.count--;
            Party second = q.top();
            q.pop();
            second.count--;
            plan.push_back(string(1, first.name) + string(1, second.name));
            if (first.count > 0) {
                q.push(first);
            }
            if (second.count > 0) {
                q.push(second);
            }
        }
    }
    return plan;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<Party> parties = read_parties(n);
        vector<string> plan = evacuate(parties);
        print_plan(i, plan);
    }
    return 0;
}
