#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

struct Party {
    int count;
    char name;
};

struct Evacuation {
    char p1;
    char p2;
};

bool operator<(const Party& a, const Party& b) {
    return a.count < b.count;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;

        priority_queue<Party> pq;
        for (int i = 0; i < n; i++) {
            int count;
            cin >> count;
            pq.push({count, 'A' + i});
        }

        vector<Evacuation> evacuations;

        while (true) {
            Party p1 = pq.top();
            pq.pop();

            if (pq.empty()) {
                if (p1.count == 1) {
                    evacuations.push_back({p1.name});
                } else {
                    evacuations.push_back({p1.name, p1.name});
                }
                break;
            }

            Party p2 = pq.top();
            pq.pop();

            evacuations.push_back({p1.name, p2.name});

            p1.count--;
            p2.count--;

            if (p1.count > 0) {
                pq.push(p1);
            }

            if (p2.count > 0) {
                pq.push(p2);
            }
        }

        reverse(evacuations.begin(), evacuations.end());

        cout << "Case #" << t << ":";
        for (Evacuation e : evacuations) {
            cout << " " << e.p1;
            if (e.p2 != 0) {
                cout << e.p2;
            }
        }
        cout << endl;
    }

    return 0;
}
