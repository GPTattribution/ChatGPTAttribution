#include <iostream>
#include <vector>
#include <queue>
#include <string>

using namespace std;

struct Party {
    int count;
    char name;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

string evacuate(int N, vector<int>& parties) {
    priority_queue<Party> pq;
    for (int i = 0; i < N; i++) {
        Party p;
        p.count = parties[i];
        p.name = 'A' + i;
        pq.push(p);
    }

    string plan;
    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        Party p2 = pq.top();
        pq.pop();

        if (p1.count > p2.count) {
            plan += p1.name;
            p1.count--;
        }
        else {
            plan += p1.name;
            plan += p2.name;
            p1.count--;
            p2.count--;
        }

        if (p1.count > 0) {
            pq.push(p1);
        }
        if (p2.count > 0) {
            pq.push(p2);
        }
    }

    return plan;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<int> parties(N);
        int total = 0;
        for (int i = 0; i < N; i++) {
            cin >> parties[i];
            total += parties[i];
        }

        string plan = evacuate(N, parties);

        cout << "Case #" << t << ": " << plan << endl;
    }

    return 0;
}
