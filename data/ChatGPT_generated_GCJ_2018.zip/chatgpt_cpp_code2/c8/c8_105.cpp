#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;

        vector<pair<int, char>> senators; 
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            senators.push_back(make_pair(p, 'A' + j));
        }

        string plan;
        while (senators.size() > 0) {
            sort(senators.rbegin(), senators.rend());

            plan += senators[0].second;
            senators[0].first--;
            if (senators[0].first == 0) senators.erase(senators.begin());

            if (senators.size() >= 2 && senators[1].first > 0) {
                plan += senators[1].second;
                senators[1].first--;
                if (senators[1].first == 0) senators.erase(senators.begin() + 1);
            }

            bool valid = true;
            int total = 0;
            for (auto& s : senators) total += s.first;
            for (auto& s : senators) {
                if (s.first > total/2) {
                    valid = false;
                    break;
                }
            }
            if (!valid) {
                senators[0].first++;
                if (senators.size() >= 2 && senators[1].first > 0) senators[1].first++;
                plan.pop_back();
                plan.pop_back();
                plan += senators[0].second;
                plan += senators[0].second;
                senators[0].first -= 2;
                if (senators[0].first == 0) senators.erase(senators.begin());
                if (senators.size() >= 2 && senators[1].first == 0) senators.erase(senators.begin() + 1);
            }
        }

        cout << "Case #" << i << ": " << plan << endl;
    }

    return 0;
}
