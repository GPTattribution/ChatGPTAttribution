#include <iostream>
#include <queue>
#include <string>
#include <vector>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<pair<int, char>> q;
        int total = 0;
        for (int i = 0; i < N; i++) {
            int p;
            cin >> p;
            q.push({p, 'A' + i});
            total += p;
        }
        string ans;
        while (!q.empty()) {
            auto p1 = q.top(); q.pop();
            total--;
            ans += p1.second;
            if (q.empty()) {
                break;
            }
            auto p2 = q.top(); q.pop();
            total--;
            ans += p2.second;
            if (p1.first > 1) {
                q.push({p1.first - 1, p1.second});
            }
            if (p2.first > 1) {
                q.push({p2.first - 1, p2.second});
            }
            if (p1.first > 1 || p2.first > 1) {
                q.push({total, ' '});
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
