#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    for(int i=1;i<=t;i++)
    {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> pq;
        int total = 0;
        for(int j=0;j<n;j++)
        {
            int p;
            cin >> p;
            pq.push(make_pair(p, j+'A'));
            total += p;
        }
        cout << "Case #" << i << ": ";
        while(!pq.empty())
        {
            auto first = pq.top();
            pq.pop();
            auto second = pq.top();
            pq.pop();
            cout << first.second;
            first.first--;
            total--;
            if(first.first>0)
                pq.push(first);
            if(total%2==1 || (second.first>(total-2)/2))
            {
                cout << second.second;
                second.first--;
                total--;
                if(second.first>0)
                    pq.push(second);
            }
            if(!pq.empty())
                cout << " ";
        }
        cout << endl;
    }
    return 0;
}
