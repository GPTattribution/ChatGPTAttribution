#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

struct Party {
    char name;
    int count;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<Party> parties;
        int total = 0;
        for (char c = 'A'; c < 'A' + N; c++) {
            int count;
            cin >> count;
            parties.push({c, count});
            total += count;
        }
        vector<string> instructions;
        while (!parties.empty()) {
            Party first = parties.top();
            parties.pop();
            total--;
            if (first.count > 1) {
                instructions.push_back(string(1, first.name) + string(1, first.name));
                first.count -= 2;
                total -= 2;
                if (first.count > 0) {
                    parties.push(first);
                }
            } else {
                Party second = parties.top();
                parties.pop();
                total--;
                instructions.push_back(string(1, first.name) + string(1, second.name));
                first.count--;
                second.count--;
                if (first.count > 0) {
                    parties.push(first);
                }
                if (second.count > 0) {
                    parties.push(second);
                }
                if (total % 2 == 1) {
                    Party last = parties.top();
                    parties.pop();
                    instructions.push_back(string(1, last.name));
                }
            }
        }
        cout << "Case #" << t << ": ";
        for (const string& instruction : instructions) {
            cout << instruction << " ";
        }
        cout << endl;
    }
    return 0;
}
