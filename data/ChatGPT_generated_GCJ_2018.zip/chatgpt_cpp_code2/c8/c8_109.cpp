#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> pq;
        int total = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            pq.push(make_pair(p, 'A' + j));
            total += p;
        }
        cout << "Case #" << i << ":";
        while (!pq.empty()) {
            char a = pq.top().second;
            pq.pop();
            total--;
            cout << " " << a;
            if (!pq.empty() && pq.top().first * 2 > total) {
                char b = pq.top().second;
                pq.pop();
                total--;
                cout << b;
                if (pq.top().first * 2 <= total) {
                    pq.push(make_pair(pq.top().first, pq.top().second));
                    pq.pop();
                }
            }
            if (!pq.empty() && pq.top().first * 2 > total) {
                pq.push(make_pair(pq.top().first, pq.top().second));
                pq.pop();
            }
        }
        cout << "\n";
    }
    return 0;
}
