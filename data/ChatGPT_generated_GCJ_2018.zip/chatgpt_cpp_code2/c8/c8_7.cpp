#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<Party> parties;
        int total = 0;
        for (char c = 'A'; c < 'A' + N; c++) {
            int count;
            cin >> count;
            parties.push({c, count});
            total += count;
        }
        vector<string> plan;
        while (!parties.empty()) {
            Party p1 = parties.top();
            parties.pop();
            total--;
            if (parties.empty() || (parties.top().count * 2 <= total)) {
                plan.push_back(string(1, p1.name));
            } else {
                Party p2 = parties.top();
                parties.pop();
                total--;
                plan.push_back(string(1, p1.name) + string(1, p2.name));
                if (p2.count > 1) {
                    parties.push({p2.name, p2.count - 1});
                    total++;
                }
            }
            if (p1.count > 1) {
                parties.push({p1.name, p1.count - 1});
                total++;
            }
        }
        cout << "Case #" << t << ": ";
        for (const string& step : plan) {
            cout << step << " ";
        }
        cout << endl;
    }
    return 0;
}
