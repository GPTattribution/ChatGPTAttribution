#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> pq;
        int total = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            total += p;
            pq.push({p, 'A' + j});
        }
        string ans;
        while (!pq.empty()) {
            auto [count1, party1] = pq.top();
            pq.pop();
            total--;
            ans += party1;
            if (!pq.empty()) {
                auto [count2, party2] = pq.top();
                pq.pop();
                total--;
                ans += party2;
                if (count2 > 1) {
                    count2--;
                    pq.push({count2, party2});
                }
            }
            if (count1 > 1) {
                count1--;
                pq.push({count1, party1});
            }
            if (!pq.empty() && pq.top().first > total / 2) {
                auto [count3, party3] = pq.top();
                pq.pop();
                total--;
                ans += party3;
                if (count3 > 1) {
                    count3--;
                    pq.push({count3, party3});
                }
            }
            ans += " ";
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
