#include <iostream>
#include <queue>
#include <string>
#include <utility>
#include <vector>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> q;
        int total = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            q.push(make_pair(p, 'A' + j));
            total += p;
        }
        cout << "Case #" << i << ": ";
        while (!q.empty()) {
            vector<pair<int, char>> v;
            v.push_back(q.top());
            q.pop();
            if (!q.empty() && q.top().first == v[0].first) {
                v.push_back(q.top());
                q.pop();
            }
            if (v.size() == 1 || total == 3) {
                cout << v[0].second << " ";
                v[0].first--;
                total--;
            } else {
                cout << v[0].second << v[1].second << " ";
                v[0].first--;
                v[1].first--;
                total -= 2;
            }
            for (auto p : v) {
                if (p.first > 0) {
                    q.push(p);
                }
            }
        }
        cout << endl;
    }
    return 0;
}
