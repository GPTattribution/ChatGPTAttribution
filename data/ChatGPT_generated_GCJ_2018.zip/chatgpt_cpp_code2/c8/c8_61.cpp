#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int test = 1; test <= t; test++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> pq;
        int total_senators = 0;
        for (int i = 0; i < n; i++) {
            int p;
            cin >> p;
            pq.push({p, 'A' + i});
            total_senators += p;
        }
        string ans;
        while (!pq.empty()) {
            auto [p1, c1] = pq.top();
            pq.pop();
            total_senators--;
            ans += c1;
            if (!pq.empty()) {
                auto [p2, c2] = pq.top();
                pq.pop();
                total_senators--;
                ans += c2;
                if (p2 > 1) {
                    pq.push({p2 - 1, c2});
                }
            }
            if (p1 > 1) {
                pq.push({p1 - 1, c1});
            }
            if (!pq.empty() && pq.top().first * 2 > total_senators) {
                auto [p3, c3] = pq.top();
                pq.pop();
                total_senators--;
                ans += c3;
                if (p3 > 1) {
                    pq.push({p3 - 1, c3});
                }
                pq.push({p1, c1});
                if (!ans.empty() && ans.back() == c2) {
                    ans.pop_back();
                    pq.push({p2, c2});
                }
            }
        }
        cout << "Case #" << test << ": " << ans << "\n";
    }
    return 0;
}
