#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        priority_queue<pair<int, char>> pq;
        int total = 0;

        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            pq.push(make_pair(P, 'A' + i));
            total += P;
        }

        vector<string> res;
        while (!pq.empty()) {
            pair<int, char> p1 = pq.top();
            pq.pop();

            total--;

            if (pq.empty() || (total > 0 && pq.top().first * 2 <= total)) {
                res.push_back(string(1, p1.second));
            } else {
                pair<int, char> p2 = pq.top();
                pq.pop();
                total--;
                res.push_back(string(1, p1.second) + string(1, p2.second));
                p2.first--;
                if (p2.first > 0) {
                    pq.push(p2);
                    total++;
                }
            }

            p1.first--;
            if (p1.first > 0) {
                pq.push(p1);
                total++;
            }
        }

        cout << "Case #" << t << ": ";
        for (int i = 0; i < res.size(); i++) {
            if (i > 0) {
                cout << " ";
            }
            cout << res[i];
        }
        cout << endl;
    }

    return 0;
}
