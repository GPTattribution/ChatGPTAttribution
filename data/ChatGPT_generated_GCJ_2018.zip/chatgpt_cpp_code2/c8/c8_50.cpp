#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<pair<int, char>> pq;
        int total = 0;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            pq.push(make_pair(P, 'A' + i));
            total += P;
        }
        string ans = "";
        while (!pq.empty()) {
            pair<int, char> p1 = pq.top();
            pq.pop();
            total--;
            ans += p1.second;
            if (pq.empty()) {
                break;
            }
            pair<int, char> p2 = pq.top();
            pq.pop();
            total--;
            ans += p2.second;
            if (p1.first > 1) {
                pq.push(make_pair(p1.first - 1, p1.second));
            }
            if (p2.first > 1) {
                pq.push(make_pair(p2.first - 1, p2.second));
            }
            if (pq.top().first > total / 2) {
                pair<int, char> p3 = pq.top();
                pq.pop();
                total--;
                ans += p3.second;
                pq.push(make_pair(p3.first - 1, p3.second));
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
