#include <iostream>
#include <queue>
#include <string>
#include <vector>
using namespace std;

struct Party {
    int count;
    char name;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

void evacuate(int n, vector<Party>& parties) {
    priority_queue<Party> q;
    for (int i = 0; i < n; i++) {
        q.push(parties[i]);
    }
    while (!q.empty()) {
        Party first = q.top();
        q.pop();
        Party second = q.top();
        q.pop();
        cout << " " << first.name << second.name;
        first.count--;
        second.count--;
        if (first.count > 0) {
            q.push(first);
        }
        if (second.count > 0) {
            q.push(second);
        }
    }
    cout << endl;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<Party> parties;
        for (int j = 0; j < n; j++) {
            Party p;
            p.name = 'A' + j;
            cin >> p.count;
            parties.push_back(p);
        }
        cout << "Case #" << i << ":";
        evacuate(n, parties);
    }
    return 0;
}
