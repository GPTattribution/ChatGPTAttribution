#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

struct PartyComparator {
    bool operator() (const pair<int, char>& p1, const pair<int, char>& p2) {
        return p1.first < p2.first;
    }
};

string evacuate(int n, vector<int>& parties) {
    priority_queue<pair<int, char>, vector<pair<int, char>>, PartyComparator> pq;
    for (int i = 0; i < n; i++) {
        if (parties[i] > 0) {
            pq.push(make_pair(parties[i], 'A' + i));
        }
    }

    string plan = "";

    while (!pq.empty()) {
        pair<int, char> p1 = pq.top();
        pq.pop();
        p1.first--;
        plan += p1.second;

        if (!pq.empty()) {
            pair<int, char> p2 = pq.top();
            pq.pop();
            p2.first--;
            plan += p2.second;

            if (p2.first > 0) {
                pq.push(p2);
            }
        }

        if (p1.first > 0) {
            pq.push(p1);
        }

        sort(pq.begin(), pq.end(), PartyComparator());
    }

    return plan;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;
        vector<int> parties(n);
        for (int i = 0; i < n; i++) {
            cin >> parties[i];
        }
        string plan = evacuate(n, parties);
        cout << "Case #" << t << ": " << plan << endl;
    }

    return 0;
}
