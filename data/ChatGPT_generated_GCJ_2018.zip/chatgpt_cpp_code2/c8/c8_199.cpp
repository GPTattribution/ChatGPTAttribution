#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

struct Party {
    char name;
    int count;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

void evacuate(int n, vector<Party>& parties) {
    priority_queue<Party> pq;
    for (int i = 0; i < n; i++) {
        pq.push(parties[i]);
    }
    cout << " ";
    while (!pq.empty()) {
        Party p1 = pq.top(); pq.pop();
        Party p2 = pq.top(); pq.pop();
        cout << p1.name << p2.name << " ";
        p1.count--; p2.count--;
        if (p1.count > 0) {
            pq.push(p1);
        }
        if (p2.count > 0) {
            pq.push(p2);
        }
    }
    cout << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;
        vector<Party> parties(n);
        int total = 0;
        for (int i = 0; i < n; i++) {
            parties[i].name = 'A' + i;
            cin >> parties[i].count;
            total += parties[i].count;
        }
        cout << "Case #" << t << ":";
        evacuate(n, parties);
    }
    return 0;
}
