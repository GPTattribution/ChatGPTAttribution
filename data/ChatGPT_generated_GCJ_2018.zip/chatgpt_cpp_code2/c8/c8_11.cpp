#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties(n);
        int total_senators = 0;
        for (int j = 0; j < n; j++) {
            cin >> parties[j].first;
            parties[j].second = 'A' + j;
            total_senators += parties[j].first;
        }
        vector<string> evacuation_plan;
        while (total_senators > 0) {
            sort(parties.rbegin(), parties.rend());
            string current_step = "";
            current_step += parties[0].second;
            parties[0].first--;
            total_senators--;
            if (parties[0].first * 2 > total_senators) {
                current_step += parties[0].second;
                parties[0].first--;
                total_senators--;
            }
            evacuation_plan.push_back(current_step);
        }
        cout << "Case #" << i << ": ";
        for (string step : evacuation_plan) {
            cout << step << " ";
        }
        cout << endl;
    }
    return 0;
}
