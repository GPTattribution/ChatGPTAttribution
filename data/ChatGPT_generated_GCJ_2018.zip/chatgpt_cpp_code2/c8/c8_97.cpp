#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

struct Party {
    char name;
    int count;
};

struct Plan {
    string steps;
    int remaining;
};

bool operator<(const Plan& a, const Plan& b) {
    return a.remaining > b.remaining;
}

void evacuate(int n, vector<Party>& parties) {
    priority_queue<Plan> q;
    string initial = "";
    for (int i = 0; i < n; i++) {
        initial += string(parties[i].count, parties[i].name);
    }
    q.push({initial, initial.length()});
    while (!q.empty()) {
        Plan p = q.top();
        q.pop();
        if (p.remaining == 0) {
            cout << "Case #" << (n - q.size()) << ": " << p.steps << endl;
            return;
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j) {
                    if (parties[i].count >= 2 && p.steps.back() != parties[i].name) {
                        Plan next = p;
                        next.steps += string(2, parties[i].name);
                        next.remaining -= 2;
                        next.steps.back() == next.steps[next.steps.length()-2] ? next.steps.pop_back() : 0;
                        next.steps.back() == next.steps[next.steps.length()-2] ? next.steps.pop_back() : 0;
                        q.push(next);
                    }
                } else {
                    if (parties[i].count >= 1 && parties[j].count >= 1 && p.steps.back() != parties[i].name && p.steps[p.steps.length()-2] != parties[j].name) {
                        Plan next = p;
                        next.steps += string(1, parties[i].name) + string(1, parties[j].name);
                        next.remaining -= 2;
                        q.push(next);
                    }
                }
            }
        }
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;
        vector<Party> parties(n);
        for (int i = 0; i < n; i++) {
            parties[i].name = 'A' + i;
            cin >> parties[i].count;
        }
        evacuate(n, parties);
    }
    return 0;
}
