#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<pair<int, char>> parties(N);
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            parties[i] = make_pair(P, 'A' + i);
        }

        vector<string> plan;
        while (true) {
            sort(parties.rbegin(), parties.rend());

            if (parties[0].first == 0) break;

            string step;

            if (parties[0].first > 1) {
                step += parties[0].second;
                parties[0].first--;
            }

            if (parties[1].first > 0 && parties[1].first * 2 > parties[0].first) {
                step += parties[1].second;
                parties[1].first--;
            }

            if (step.empty()) {
                step += parties[0].second;
                parties[0].first--;
            }

            plan.push_back(step);
        }

        cout << "Case #" << t << ": ";
        for (auto& step : plan) cout << step << " ";
        cout << endl;
    }

    return 0;
}
