#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
};

struct PartyCompare {
    bool operator()(const Party& p1, const Party& p2) const {
        return p1.count < p2.count;
    }
};

string evacuate(const vector<int>& senators) {
    priority_queue<Party, vector<Party>, PartyCompare> q;
    int total = 0;
    for (int i = 0; i < senators.size(); i++) {
        char name = 'A' + i;
        int count = senators[i];
        total += count;
        q.push({name, count});
    }
    string result;
    while (!q.empty()) {
        Party p1 = q.top();
        q.pop();
        total--;
        result += p1.name;
        if (!q.empty()) {
            Party p2 = q.top();
            q.pop();
            total--;
            result += p2.name;
            if (p2.count > 1) {
                p2.count--;
                q.push(p2);
            }
        }
        if (p1.count > 1) {
            p1.count--;
            q.push(p1);
        }
        if (!q.empty() && q.top().count * 2 > total) {
            return "IMPOSSIBLE";
        }
        result += " ";
    }
    result.pop_back();
    return result;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<int> senators(N);
        for (int i = 0; i < N; i++) {
            cin >> senators[i];
        }
        cout << "Case #" << t << ": " << evacuate(senators) << endl;
    }
    return 0;
}
