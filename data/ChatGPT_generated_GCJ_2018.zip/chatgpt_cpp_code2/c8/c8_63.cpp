#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> q; 
        for (char c = 'A'; c < 'A' + n; c++) {
            int p;
            cin >> p;
            q.push({p, c});
        }
        cout << "Case #" << i << ": ";
        while (!q.empty()) {
            int cnt1 = q.top().first;
            char party1 = q.top().second;
            q.pop();
            int cnt2 = q.top().first;
            char party2 = q.top().second;
            q.pop();
            cout << party1 << party2 << " ";
            cnt1--;
            cnt2--;
            if (cnt1 > 0) q.push({cnt1, party1});
            if (cnt2 > 0) q.push({cnt2, party2});
        }
        cout << endl;
    }
    return 0;
}
