#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>

using namespace std;

struct Party {
    char name;
    int senators;
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.senators < p2.senators;
}

void evacuate(int case_number, vector<Party>& parties) {
    string plan;
    priority_queue<Party> pq;
    for (Party& p : parties) {
        pq.push(p);
    }
    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        if (pq.empty()) {
            plan += p1.name;
            break;
        }
        Party p2 = pq.top();
        pq.pop();
        plan += p1.name;
        plan += p2.name;
        if (--p1.senators > 0) {
            pq.push(p1);
        }
        if (--p2.senators > 0) {
            pq.push(p2);
        }
    }
    cout << "Case #" << case_number << ": " << plan << endl;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<Party> parties;
        int total_senators = 0;
        for (int j = 0; j < n; j++) {
            int senators;
            cin >> senators;
            parties.push_back({ 'A' + j, senators });
            total_senators += senators;
        }
        evacuate(i, parties);
    }
    return 0;
}
