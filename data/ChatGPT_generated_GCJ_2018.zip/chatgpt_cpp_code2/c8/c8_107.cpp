#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<pair<int, char>> parties;
        for (int i = 0; i < N; i++) {
            int p;
            cin >> p;
            parties.push_back({p, 'A' + i});
        }

        vector<string> plan;
        while (true) {
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());

            if (parties[0].first == 0) {
                break;
            }

            string step;
            if (parties[0].first == parties[1].first && parties[1].first != 0 && (parties.size() == 2 || parties[2].first < parties[1].first)) {
                step += parties[0].second;
                step += parties[1].second;
                parties[0].first--;
                parties[1].first--;
            } else {
                step += parties[0].second;
                parties[0].first--;
            }

            plan.push_back(step);
        }

        cout << "Case #" << t << ": ";
        for (const string& step : plan) {
            cout << step << " ";
        }
        cout << endl;
    }

    return 0;
}
