#include <iostream>
#include <vector>
#include <queue>

using namespace std;

struct Party {
    char name;
    int count;

    Party(char name, int count) : name(name), count(count) {}
};

struct EvacuationStep {
    char from1, from2, to1, to2;

    EvacuationStep(char from1, char from2, char to1, char to2)
        : from1(from1), from2(from2), to1(to1), to2(to2) {}
};

vector<EvacuationStep> evacuate(vector<Party>& parties) {
    int n = parties.size();
    vector<EvacuationStep> steps;

    auto cmp = [](const Party& a, const Party& b) { return a.count < b.count; };
    priority_queue<Party, vector<Party>, decltype(cmp)> q(cmp);

    for (auto& p : parties) {
        q.push(p);
    }

    while (!q.empty()) {
        Party p1 = q.top();
        q.pop();

        Party p2('0', 0);
        if (!q.empty()) {
            p2 = q.top();
            q.pop();
        }

        steps.emplace_back(p1.name, p2.name, p1.name, p2.name);

        if (--p1.count > 0) {
            q.push(p1);
        }

        if (--p2.count > 0) {
            q.push(p2);
        }
    }

    return steps;
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;

        vector<Party> parties;
        for (int j = 0; j < n; j++) {
            int count;
            cin >> count;
            parties.emplace_back('A' + j, count);
        }

        auto steps = evacuate(parties);

        cout << "Case #" << i << ": ";
        for (auto& step : steps) {
            if (step.from2 == '0') {
                cout << step.from1 << " ";
            } else {
                cout << step.from1 << step.from2 << " ";
            }
        }
        cout << endl;
    }

    return 0;
}
