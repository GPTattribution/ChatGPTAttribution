#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int caseNum = 1; caseNum <= t; caseNum++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> q;
        int total = 0;
        for (int i = 0; i < n; i++) {
            int p;
            cin >> p;
            q.push({p, 'A' + i});
            total += p;
        }
        cout << "Case #" << caseNum << ":";
        while (!q.empty()) {
            char a = q.top().second;
            int pa = q.top().first;
            q.pop();
            char b = 0;
            int pb = 0;
            if (!q.empty() && q.top().first > total / 2) {
                b = q.top().second;
                pb = q.top().first;
                q.pop();
            }
            if (b != 0) {
                pb--;
                total--;
                cout << " " << a << b;
                if (pa > 1) {
                    q.push({pa - 1, a});
                    total--;
                }
                if (pb > 1) {
                    q.push({pb - 1, b});
                    total--;
                }
                if (pa == 1 && pb == 1) {
                    if (!q.empty() && q.top().first > total / 2) {
                        b = q.top().second;
                        pb = q.top().first;
                        q.pop();
                    } else {
                        b = q.top().second;
                        pb = q.top().first;
                        q.pop();
                        char c = q.top().second;
                        int pc = q.top().first;
                        q.pop();
                        cout << " " << a << b << c;
                        if (pa > 1) {
                            q.push({pa - 1, a});
                            total--;
                        }
                        if (pb > 1) {
                            q.push({pb - 1, b});
                            total--;
                        }
                        if (pc > 1) {
                            q.push({pc - 1, c});
                            total--;
                        }
                    }
                } else {
                    q.push({pb, b});
                }
            } else {
                pa--;
                total--;
                cout << " " << a;
                if (pa > 1) {
                    q.push({pa - 1, a});
                    total--;
                }
            }
        }
        cout << "\n";
    }
    return 0;
}
