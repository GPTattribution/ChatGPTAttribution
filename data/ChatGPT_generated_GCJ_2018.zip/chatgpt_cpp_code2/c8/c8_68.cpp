#include <iostream>
#include <queue>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

struct Party {
    int count;
    char name;
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
}

void evacuate(int case_num, vector<Party>& parties) {
    priority_queue<Party> q;
    for (auto& p : parties) {
        q.push(p);
    }
    cout << "Case #" << case_num << ": ";
    while (!q.empty()) {
        Party p1 = q.top();
        q.pop();
        Party p2;
        if (!q.empty() && q.top().count > 1) {
            p2 = q.top();
            q.pop();
        }
        if (p2.count == 0) {
            cout << p1.name << " ";
            p1.count--;
        } else {
            cout << p1.name << p2.name << " ";
            p1.count--;
            p2.count--;
        }
        if (p1.count > 0) {
            q.push(p1);
        }
        if (p2.count > 0) {
            q.push(p2);
        }
    }
    cout << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<Party> parties;
        int total_senators = 0;
        for (int i = 0; i < N; i++) {
            Party p;
            cin >> p.count;
            p.name = 'A' + i;
            parties.push_back(p);
            total_senators += p.count;
        }
        evacuate(t, parties);
    }
    return 0;
}
