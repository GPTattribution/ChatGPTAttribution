#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> senators;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            senators.push_back(make_pair(p, 'A' + j));
        }
        vector<string> plan;
        while (true) {
            sort(senators.begin(), senators.end(), greater<pair<int, char>>());
            if (senators[0].first == 0) {
                break;
            }
            string step = "";
            if (senators[0].first > senators[1].first) {
                step += senators[0].second;
                senators[0].first--;
            }
            if (senators[0].first > senators[1].first) {
                step += senators[0].second;
                senators[0].first--;
            } else {
                step += senators[0].second;
                step += senators[1].second;
                senators[0].first--;
                senators[1].first--;
            }
            plan.push_back(step);
        }
        cout << "Case #" << i << ": ";
        for (string step : plan) {
            cout << step << " ";
        }
        cout << endl;
    }
    return 0;
}
