#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n;
        cin >> n;
        vector<int> p(n);
        for (int i = 0; i < n; i++) {
            cin >> p[i];
        }

        cout << "Case #" << case_num << ": ";
        while (true) {
            int first = -1, second = -1;
            for (int i = 0; i < n; i++) {
                if (p[i] > 0 && (first == -1 || p[i] > p[first])) {
                    second = first;
                    first = i;
                } else if (p[i] > 0 && (second == -1 || p[i] > p[second])) {
                    second = i;
                }
            }

            if (p[first] == 0 || p[second] == 0) {
                break;
            }

            if (p[first] - p[second] >= 2 || (p[first] - p[second] == 1 && p[first] > 1)) {
                p[first] -= 2;
                cout << (char)('A' + first) << (char)('A' + first) << " ";
            } else {
                p[first]--;
                p[second]--;
                cout << (char)('A' + first) << (char)('A' + second) << " ";
            }
        }
        cout << endl;
    }
    return 0;
}
