#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> pq;
        int total = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            pq.push({p, j + 'A'});
            total += p;
        }
        cout << "Case #" << i << ": ";
        while (!pq.empty()) {
            auto p1 = pq.top();
            pq.pop();
            auto p2 = pq.top();
            pq.pop();
            if (p1.first > 1) {
                cout << p1.second << p1.second << " ";
                p1.first -= 2;
            } else {
                cout << p1.second << " ";
                p1.first--;
            }
            if (p2.first > 1) {
                cout << p2.second << p2.second << " ";
                p2.first -= 2;
            } else {
                cout << p2.second << " ";
                p2.first--;
            }
            total -= 2;
            if (p1.first > 0) pq.push(p1);
            if (p2.first > 0) pq.push(p2);
            if (pq.size() == 1 && pq.top().first * 2 > total) {
                auto p = pq.top();
                pq.pop();
                cout << p.second << " ";
                p.first--;
                if (p.first > 0) pq.push(p);
                total--;
            }
        }
        cout << "\n";
    }
    return 0;
}
