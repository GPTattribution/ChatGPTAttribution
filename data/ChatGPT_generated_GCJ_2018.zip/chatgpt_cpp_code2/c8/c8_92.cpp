#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            parties.push_back({p, 'A' + j});
        }
        string plan = "";
        while (true) {
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());
            if (parties[0].first == 0) break;
            if (parties[0].first == parties[1].first && parties[0].first == 1) {
                plan += string(1, parties[0].second) + " ";
                parties[0].first--;
            } else if (parties[0].first - parties[1].first >= 2) {
                plan += string(2, parties[0].second) + " ";
                parties[0].first -= 2;
            } else {
                plan += string(1, parties[0].second) + string(1, parties[1].second) + " ";
                parties[0].first--;
                parties[1].first--;
            }
        }
        cout << "Case #" << i << ": " << plan << endl;
    }
    return 0;
}
