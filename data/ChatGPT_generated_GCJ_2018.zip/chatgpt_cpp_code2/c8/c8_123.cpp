#include <iostream>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int case_num = 1; case_num <= t; case_num++) {
        int n;
        cin >> n;

        vector<pair<int, char>> parties;
        for (int i = 0; i < n; i++) {
            int p;
            cin >> p;
            parties.push_back(make_pair(p, 'A' + i));
        }

        string evacuation_plan;

        while (true) {
            sort(parties.begin(), parties.end());

            if (parties[n - 1].first == 0) {
                break;
            }

            string next_step = "";

            if (parties[n - 1].first > 1) {
                next_step += parties[n - 1].second;
                parties[n - 1].first--;
            }

            if (parties[n - 2].first > 1) {
                next_step += parties[n - 2].second;
                parties[n - 2].first--;
            } else {
                next_step += parties[n - 1].second;
                parties[n - 1].first--;
            }

            evacuation_plan += next_step + " ";
        }

        cout << "Case #" << case_num << ": " << evacuation_plan << endl;
    }

    return 0;
}
