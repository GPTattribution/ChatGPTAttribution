#include <iostream>
#include <queue>
#include <vector>
#include <cstring>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;

        priority_queue<pair<int, char>> q;
        int total = 0;

        for (char c = 'A'; c < 'A' + n; c++) {
            int p;
            cin >> p;
            q.push(make_pair(p, c));
            total += p;
        }

        cout << "Case #" << i << ": ";

        while (!q.empty()) {
            char c1 = q.top().second;
            int p1 = q.top().first;
            q.pop();

            char c2 = ' ';
            int p2 = 0;

            if (!q.empty()) {
                c2 = q.top().second;
                p2 = q.top().first;
                q.pop();
            }

            cout << c1;

            if (p1 > 1) {
                q.push(make_pair(p1 - 1, c1));
            }

            if (p2 > 1 && p2 > total - 2) {
                cout << c2;
                q.push(make_pair(p2 - 1, c2));
            }

            total -= 2;
            cout << " ";
        }

        cout << endl;
    }

    return 0;
}
