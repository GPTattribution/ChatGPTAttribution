#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            parties.push_back({P, 'A' + i});
        }
        string plan;
        while (!parties.empty()) {
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());
            char party1 = parties[0].second;
            parties[0].first--;
            if (parties[0].first == 0) {
                parties.erase(parties.begin());
            }
            if (!parties.empty()) {
                sort(parties.begin(), parties.end(), greater<pair<int, char>>());
                char party2 = parties[0].second;
                parties[0].first--;
                if (parties[0].first == 0) {
                    parties.erase(parties.begin());
                }
                plan += party1;
                plan += party2;
            } else {
                plan += party1;
            }
            plan += " ";
        }
        cout << "Case #" << t << ": " << plan << endl;
    }
    return 0;
}
