#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <cstring>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int ti = 1; ti <= t; ti++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> pq; 
        int total = 0;
        for (char c = 'A'; c < 'A' + n; c++) {
            int count;
            cin >> count;
            pq.push({count, c});
            total += count;
        }
        cout << "Case #" << ti << ":";
        while (!pq.empty()) {
            char p1 = pq.top().second;
            pq.pop();
            total--;
            if (pq.empty() || pq.top().first * 2 <= total) {
                cout << " " << p1;
            } else {
                char p2 = pq.top().second;
                pq.pop();
                total--;
                cout << " " << p1 << p2;
                if (pq.top().first * 2 > total) {
                    pq.push({-1 * (pq.top().first - 1), pq.top().second});
                    pq.pop();
                    total++;
                    pq.push({-1 * (pq.top().first - 1), p1});
                    total++;
                    pq.push({-1 * (pq.top().first - 1), p2});
                } else {
                    pq.push({-1 * (pq.top().first - 1), p1});
                    pq.push({-1 * (pq.top().first - 1), p2});
                    total += 2;
                }
            }
        }
        cout << "\n";
    }
    return 0;
}
