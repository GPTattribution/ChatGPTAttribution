#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool cmp(const pair<int, char>& a, const pair<int, char>& b) {
    return a.first > b.first;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties(N);
        int total = 0;
        for (int i = 0; i < N; i++) {
            cin >> parties[i].first;
            parties[i].second = 'A' + i;
            total += parties[i].first;
        }
        sort(parties.begin(), parties.end(), cmp);
        cout << "Case #" << t << ": ";
        while (total > 0) {
            if (parties[0].first > 1 && parties[0].first - 2 >= total / 2) {
                cout << parties[0].second << parties[0].second << " ";
                parties[0].first -= 2;
                total -= 2;
            }
            else {
                cout << parties[0].second << parties[1].second << " ";
                parties[0].first -= 1;
                parties[1].first -= 1;
                total -= 2;
            }
            sort(parties.begin(), parties.end(), cmp);
        }
        cout << endl;
    }
    return 0;
}
