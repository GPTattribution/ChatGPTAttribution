#include <iostream>
#include <vector>
#include <queue>
#include <string>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<int> P(N);
        for (int i = 0; i < N; i++) {
            cin >> P[i];
        }

        priority_queue<pair<int, int>> q;
        for (int i = 0; i < N; i++) {
            if (P[i] > 0) {
                q.push(make_pair(P[i], i));
            }
        }

        cout << "Case #" << t << ": ";

        while (!q.empty()) {
            pair<int, int> p1 = q.top();
            q.pop();

            pair<int, int> p2 = q.top();
            q.pop();

            int cnt1 = min(2, p1.first);
            int cnt2 = min(2, p2.first);

            p1.first -= cnt1;
            p2.first -= cnt2;

            for (int i = 0; i < cnt1; i++) {
                cout << (char)('A' + p1.second);
            }
            for (int i = 0; i < cnt2; i++) {
                cout << (char)('A' + p2.second);
            }

            if (p1.first > 0) {
                q.push(p1);
            }
            if (p2.first > 0) {
                q.push(p2);
            }

            if (!q.empty()) {
                cout << " ";
            }
        }

        cout << endl;
    }

    return 0;
}
