#include <iostream>
#include <queue>
#include <string>
#include <vector>
using namespace std;

struct Party {
    char name;
    int count;  
};

struct PartyCompare {
    bool operator()(const Party& a, const Party& b) const {
        return a.count < b.count;
    }
};

vector<string> evacuate(vector<Party>& parties) {
    priority_queue<Party, vector<Party>, PartyCompare> pq;
    for (const auto& party : parties) {
        pq.push(party);
    }

    vector<string> plan;

    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        Party p2;
        if (!pq.empty()) {
            p2 = pq.top();
            pq.pop();
        }

        string step;
        step.push_back(p1.name);
        p1.count--;
        if (p1.count > 0) {
            pq.push(p1);
        }
        if (p2.count > 0) {
            step.push_back(p2.name);
            p2.count--;
            if (p2.count > 0) {
                pq.push(p2);
            }
        }
        plan.push_back(step);

        int total_count = 0;
        int max_count = 0;
        for (const auto& party : pq) {
            total_count += party.count;
            max_count = max(max_count, party.count);
        }
        if (max_count > total_count / 2) {
            Party p = pq.top();
            pq.pop();
            plan.push_back(string(1, p.name));
            p.count--;
            if (p.count > 0) {
                pq.push(p);
            }
        }
    }

    return plan;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<Party> parties;
        int total_count = 0;
        for (char c = 'A'; c < 'A' + N; c++) {
            int count;
            cin >> count;
            parties.push_back({c, count});
            total_count += count;
        }

        vector<string> plan = evacuate(parties);
        cout << "Case #" << t << ": ";
        for (const auto& step : plan) {
            cout << step << " ";
        }
        cout << endl;
    }

    return 0;
}
