#include <bits/stdc++.h>
using namespace std;

int T, N;
int P[26];

string evacuate() {
    string ans = "";
    priority_queue<pair<int, int>> q;
    for (int i = 0; i < N; i++) {
        if (P[i] > 0) {
            q.push(make_pair(P[i], i));
        }
    }
    while (!q.empty()) {
        pair<int, int> p1 = q.top();
        q.pop();
        int party1 = p1.second;
        P[party1]--;
        if (q.empty()) {
            ans += char(party1 + 'A');
            break;
        }
        pair<int, int> p2 = q.top();
        q.pop();
        int party2 = p2.second;
        P[party2]--;
        ans += char(party1 + 'A');
        ans += char(party2 + 'A');
        if (P[party1] > 0) {
            q.push(make_pair(P[party1], party1));
        }
        if (P[party2] > 0) {
            q.push(make_pair(P[party2], party2));
        }
    }
    return ans;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N;
        for (int i = 0; i < N; i++) {
            cin >> P[i];
        }
        string ans = evacuate();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
