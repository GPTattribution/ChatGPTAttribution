#include <iostream>
#include <queue>
#include <algorithm>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
};

bool operator<(const Party& a, const Party& b) {
    return a.count < b.count;
}

void solve(int t) {
    int n;
    cin >> n;
    priority_queue<Party> q;
    for (int i = 0; i < n; i++) {
        int count;
        cin >> count;
        q.push({'A' + i, count});
    }

    cout << "Case #" << t << ": ";

    while (!q.empty()) {
        Party p1 = q.top();
        q.pop();
        Party p2 = q.top();
        q.pop();

        cout << p1.name << p2.name << " ";
        if (--p1.count > 0) {
            q.push(p1);
        }
        if (--p2.count > 0) {
            q.push(p2);
        }
    }

    cout << endl;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        solve(i);
    }
    return 0;
}
