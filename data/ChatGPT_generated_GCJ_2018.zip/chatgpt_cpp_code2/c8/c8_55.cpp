#include <iostream>
#include <queue>
#include <vector>
#include <cstring>

using namespace std;

const int MAXN = 26;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int n;
        cin >> n;
        priority_queue<pair<int, int>> pq;
        int total = 0;
        for (int i = 0; i < n; ++i) {
            int p;
            cin >> p;
            pq.push({p, i});
            total += p;
        }
        cout << "Case #" << t << ": ";
        while (!pq.empty()) {
            int cnt = min(2, total - 2 * pq.top().first);
            if (cnt == 0) break;
            vector<int> parties;
            for (int i = 0; i < cnt; ++i) {
                int p = pq.top().second;
                parties.push_back(p);
                pq.pop();
                --total;
            }
            for (int p : parties) {
                cout << (char)('A' + p);
            }
            if (cnt == 2) {
                for (int p : parties) {
                    pq.push({-1 * pq.top().first, pq.top().second});
                    pq.pop();
                }
                cout << " ";
            }
            else {
                cout << " ";
                int p = pq.top().second;
                pq.pop();
                --total;
                cout << (char)('A' + p) << " ";
                pq.push({-1 * pq.top().first, pq.top().second});
                pq.pop();
            }
        }
        cout << endl;
    }
    return 0;
}
