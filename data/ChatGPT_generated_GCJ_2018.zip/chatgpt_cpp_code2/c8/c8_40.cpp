#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<pair<int, char>> parties(N);
        int total = 0;
        for (int i = 0; i < N; i++) {
            cin >> parties[i].first;
            parties[i].second = 'A' + i;
            total += parties[i].first;
        }

        string plan;
        while (total > 0) {
            sort(parties.rbegin(), parties.rend());
            if (total == 3 && parties[0].first == 2 && parties[1].first == 1) {
                plan += parties[0].second;
                total--;
                parties[0].first--;
            } else if (parties[0].first > parties[1].first) {
                plan += parties[0].second;
                total--;
                parties[0].first--;
            } else {
                plan += parties[0].second;
                plan += parties[1].second;
                total -= 2;
                parties[0].first--;
                parties[1].first--;
            }
        }

        cout << "Case #" << t << ": " << plan << endl;
    }

    return 0;
}
