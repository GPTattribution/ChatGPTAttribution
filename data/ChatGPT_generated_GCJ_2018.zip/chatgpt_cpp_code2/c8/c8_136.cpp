#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>
using namespace std;

struct Party {
    int size;
    char name;
};

struct Evacuation {
    int parties[2];
};

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N;
        cin >> N;
        vector<Party> parties(N);
        for (int i = 0; i < N; ++i) {
            cin >> parties[i].size;
            parties[i].name = 'A' + i;
        }
        auto cmp = [](const Party& a, const Party& b) {
            return a.size < b.size;
        };
        priority_queue<Party, vector<Party>, decltype(cmp)> q(cmp);
        for (const auto& p : parties) {
            q.push(p);
        }
        vector<Evacuation> evacuations;
        while (q.size() > 1) {
            Evacuation e;
            e.parties[0] = q.top().name;
            q.pop();
            e.parties[1] = q.top().name;
            q.pop();
            --parties[e.parties[0] - 'A'].size;
            --parties[e.parties[1] - 'A'].size;
            evacuations.push_back(e);
            if (parties[e.parties[0] - 'A'].size > 0) {
                q.push(parties[e.parties[0] - 'A']);
            }
            if (parties[e.parties[1] - 'A'].size > 0) {
                q.push(parties[e.parties[1] - 'A']);
            }
        }
        string result;
        for (const auto& e : evacuations) {
            result += e.parties[0];
            if (e.parties[1] != 0) {
                result += e.parties[1];
            }
            result += " ";
        }
        cout << "Case #" << t << ": " << result << endl;
    }
    return 0;
}
