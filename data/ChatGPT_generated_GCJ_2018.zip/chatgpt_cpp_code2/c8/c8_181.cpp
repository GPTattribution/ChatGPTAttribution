#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;

const int MAXN = 26;

int t, n;
int p[MAXN];
int total;
priority_queue<pair<int, int>> pq;

void solve(int test_case) {
    total = 0;
    for (int i = 0; i < n; i++) {
        cin >> p[i];
        total += p[i];
        pq.push({p[i], i});
    }
    cout << "Case #" << test_case << ": ";
    while (!pq.empty()) {
        pair<int, int> first = pq.top();
        pq.pop();
        pair<int, int> second = pq.top();
        pq.pop();
        if (first.first > 1) {
            cout << (char)('A' + first.second) << (char)('A' + first.second) << " ";
            pq.push({first.first - 2, first.second});
            total -= 2;
        }
        if (second.first > 1 && second.first * 2 > total - 2) {
            cout << (char)('A' + second.second) << (char)('A' + second.second) << " ";
            pq.push({second.first - 2, second.second});
            total -= 2;
        } else {
            cout << (char)('A' + first.second) << (char)('A' + second.second) << " ";
            pq.push({first.first - 1, first.second});
            pq.push({second.first - 1, second.second});
            total -= 2;
        }
    }
    cout << endl;
}

int main() {
    cin >> t;
    for (int i = 1; i <= t; i++) {
        cin >> n;
        solve(i);
    }
    return 0;
}
