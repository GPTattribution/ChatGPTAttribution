#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
};

bool operator<(const Party& a, const Party& b) {
    return a.count < b.count;
}

void solve(int t) {
    int n;
    cin >> n;
    priority_queue<Party> parties;

    for (int i = 0; i < n; i++) {
        int count;
        cin >> count;
        Party party;
        party.name = 'A' + i;
        party.count = count;
        parties.push(party);
    }

    cout << "Case #" << t << ": ";

    while (!parties.empty()) {
        Party p1 = parties.top();
        parties.pop();
        Party p2 = parties.empty() ? Party{'_', 0} : parties.top();
        parties.pop();

        cout << p1.name;
        if (p1.count > 1) {
            p1.count--;
            parties.push(p1);
        }

        if (p2.count > 0 && p2.count > p1.count) {
            cout << p2.name;
            p2.count--;
            parties.push(p2);
        }
        cout << " ";
    }

    cout << endl;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        solve(i);
    }
    return 0;
}
