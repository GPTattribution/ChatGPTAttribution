#include <iostream>
#include <queue>
#include <vector>
#include <cstring>
using namespace std;

const int MAXN = 26;
const int MAXP = 1000;

int P[MAXN];
int cnt[MAXN];
bool used[MAXN];

vector<string> solve(int N) {
    memset(cnt, 0, sizeof(cnt));
    for (int i = 0; i < N; i++) {
        cin >> P[i];
        cnt[i] = P[i];
    }

    vector<string> ans;

    while (true) {
        int max_cnt = 0;
        int max_i = -1;
        int second_max_cnt = 0;
        int second_max_i = -1;

        for (int i = 0; i < N; i++) {
            if (cnt[i] > max_cnt) {
                second_max_cnt = max_cnt;
                second_max_i = max_i;
                max_cnt = cnt[i];
                max_i = i;
            } else if (cnt[i] > second_max_cnt) {
                second_max_cnt = cnt[i];
                second_max_i = i;
            }
        }

        if (max_cnt == 0) break;

        string step = "";

        if (max_cnt > 1 && max_cnt - 2 >= second_max_cnt) {
            cnt[max_i] -= 2;
            step += ('A' + max_i);
            step += ('A' + max_i);
        } else {
            cnt[max_i] -= 1;
            step += ('A' + max_i);
            if (second_max_cnt == 0 || (N > 2 && (max_cnt - 1 >= second_max_cnt || (max_cnt - 1 == second_max_cnt && cnt[second_max_i] == 1)))) {
                for (int i = 0; i < N; i++) {
                    if (i != max_i && cnt[i] > 0) {
                        cnt[i] -= 1;
                        step += ('A' + i);
                        break;
                    }
                }
            } else {
                cnt[second_max_i] -= 1;
                step += ('A' + second_max_i);
            }
        }

        ans.push_back(step);
    }

    return ans;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<string> ans = solve(N);

        cout << "Case #" << t << ":";
        for (const string& step : ans) {
            cout << " " << step;
        }
        cout << endl;
    }

    return 0;
}
