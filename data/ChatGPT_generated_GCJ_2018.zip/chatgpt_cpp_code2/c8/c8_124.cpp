#include <iostream>
#include <vector>
#include <queue>
#include <string>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N;
        cin >> N;
        vector<int> P(N);
        priority_queue<pair<int, int>> q;
        for (int i = 0; i < N; ++i) {
            cin >> P[i];
            q.push({P[i], i});
        }

        string ans;
        while (!q.empty()) {
            int i = q.top().second;
            q.pop();

            if (!ans.empty() && ans.back() == 'A' + i) {
                int j = q.top().second;
                q.pop();
                ans += 'A' + j;
                --P[j];
                if (P[j] > 0) {
                    q.push({P[j], j});
                }
            } else {
                ans += 'A' + i;
                --P[i];
                if (P[i] > 0) {
                    q.push({P[i], i});
                }
                if (!q.empty()) {
                    int j = q.top().second;
                    q.pop();
                    ans += 'A' + j;
                    --P[j];
                    if (P[j] > 0) {
                        q.push({P[j], j});
                    }
                }
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
