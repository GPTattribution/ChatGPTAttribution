#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

struct Party {
    char name;
    int count;
    Party(char name, int count) : name(name), count(count) {}
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

string evacuate(int N, vector<int>& parties) {
    string plan;
    priority_queue<Party> q;
    for (int i = 0; i < N; i++) {
        q.push(Party('A' + i, parties[i]));
    }
    while (!q.empty()) {
        Party p1 = q.top();
        q.pop();
        if (q.empty()) {
            for (int i = 0; i < p1.count; i++) {
                plan += p1.name;
            }
            break;
        }
        Party p2 = q.top();
        q.pop();
        plan += p1.name;
        plan += p2.name;
        p1.count--;
        p2.count--;
        if (p1.count > 0) {
            q.push(p1);
        }
        if (p2.count > 0) {
            q.push(p2);
        }
    }
    return plan;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<int> parties(N);
        int total = 0;
        for (int i = 0; i < N; i++) {
            cin >> parties[i];
            total += parties[i];
        }
        string plan = evacuate(N, parties);
        cout << "Case #" << t << ": " << plan << endl;
    }
    return 0;
}
