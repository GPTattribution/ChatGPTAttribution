#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>

using namespace std;

struct Party {
    int count;
    char name;
};

struct Evacuation {
    Party p1;
    Party p2;
    int remaining;
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
}

vector<Evacuation> get_evacuation_plan(vector<Party>& parties) {
    vector<Evacuation> plan;
    priority_queue<Party> pq;
    for (Party& party : parties) {
        pq.push(party);
    }
    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        if (pq.empty()) {
            if (p1.count == 1) {
                break;
            }
            plan.push_back({p1, {' ', ' '}, p1.count - 1});
            break;
        }
        Party p2 = pq.top();
        pq.pop();
        if (p1.count == 1 && p2.count == 1) {
            break;
        }
        plan.push_back({p1, p2, p1.count + p2.count - 2});
        if (p1.count > 1) {
            p1.count--;
            pq.push(p1);
        }
        if (p2.count > 1) {
            p2.count--;
            pq.push(p2);
        }
    }
    return plan;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<Party> parties(N);
        for (int i = 0; i < N; i++) {
            parties[i].count;
            parties[i].name = 'A' + i;
            cin >> parties[i].count;
        }
        vector<Evacuation> plan = get_evacuation_plan(parties);
        cout << "Case #" << t << ":";
        for (Evacuation& evacuation : plan) {
            cout << " " << evacuation.p1.name;
            if (evacuation.p2.name != ' ') {
                cout << evacuation.p2.name;
            }
        }
        cout << endl;
    }
    return 0;
}
