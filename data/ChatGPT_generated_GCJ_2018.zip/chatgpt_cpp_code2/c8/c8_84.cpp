#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties;
        for (int i = 0; i < N; i++) {
            int p;
            cin >> p;
            parties.push_back({p, 'A' + i});
        }

        string evacuation_plan;
        while (true) {
            sort(parties.rbegin(), parties.rend()); 
            if (parties[0].first == 0) break;
            string step;
            step.push_back(parties[0].second);
            parties[0].first--;
            if (parties[1].first > 0 && parties[1].first * 2 > accumulate(parties.begin(), parties.end(), 0, [](int s, const pair<int, char>& p) { return s + p.first; })) {
                step.push_back(parties[1].second);
                parties[1].first--;
            }
            evacuation_plan += step + " ";
        }

        cout << "Case #" << t << ": " << evacuation_plan << endl;
    }
    return 0;
}
