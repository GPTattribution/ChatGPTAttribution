#include <bits/stdc++.h>
using namespace std;

int T, N;
int P[30];

int main() {
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        cin >> N;
        priority_queue<pair<int, char>> pq;
        int total_senators = 0;
        for (int i = 0; i < N; ++i) {
            cin >> P[i];
            pq.push(make_pair(P[i], 'A' + i));
            total_senators += P[i];
        }
        vector<string> res;
        while (!pq.empty()) {
            auto p1 = pq.top(); pq.pop();
            auto p2 = pq.top(); pq.pop();
            if (p1.first > p2.first || total_senators == 3) {
                res.push_back(string(1, p1.second));
                p1.first--;
                total_senators--;
                if (p1.first > 0) pq.push(p1);
            } else {
                res.push_back(string(1, p1.second) + string(1, p2.second));
                p1.first--;
                p2.first--;
                total_senators -= 2;
                if (p1.first > 0) pq.push(p1);
                if (p2.first > 0) pq.push(p2);
            }
        }
        cout << "Case #" << t << ": ";
        for (auto s : res) cout << s << " ";
        cout << endl;
    }
    return 0;
}
