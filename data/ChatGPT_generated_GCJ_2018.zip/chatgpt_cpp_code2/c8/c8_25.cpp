#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties(n);
        int total = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            parties[j] = {p, 'A' + j};
            total += p;
        }
        vector<string> plan;
        while (total > 0) {
            sort(parties.rbegin(), parties.rend());
            string evac;
            int count = min(2, total);
            for (int j = 0; j < count; j++) {
                evac += parties[j].second;
                parties[j].first--;
                total--;
            }
            if (parties[0].first > total / 2) {
                evac += parties[0].second;
                parties[0].first--;
                total--;
            }
            plan.push_back(evac);
        }
        cout << "Case #" << i << ": ";
        for (const string& s : plan) {
            cout << s << " ";
        }
        cout << endl;
    }
    return 0;
}
