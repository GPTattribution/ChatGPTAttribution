#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties(N);
        for (int i = 0; i < N; i++) {
            int p;
            cin >> p;
            parties[i] = make_pair(p, 'A' + i);
        }
        sort(parties.begin(), parties.end(), greater<pair<int, char>>()); 
        string evacuation_plan;
        while (true) {
            int remaining_senators = 0;
            for (auto& p : parties) {
                remaining_senators += p.first;
            }
            if (remaining_senators == 0) {
                break;
            }
            string step;
            if (parties[0].first > 0 && (remaining_senators > 2 || (remaining_senators == 2 && parties[0].first == 2))) {
                step += parties[0].second;
                parties[0].first -= 1;
                step += parties[0].second;
                parties[0].first -= 1;
            } else {
                step += parties[0].second;
                parties[0].first -= 1;
                if (parties[1].first > parties[2].first) {
                    step += parties[1].second;
                    parties[1].first -= 1;
                } else {
                    step += parties[2].second;
                    parties[2].first -= 1;
                }
            }
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());
            evacuation_plan += " " + step;
        }
        cout << "Case #" << t << ":" << evacuation_plan << endl;
    }
    return 0;
}
