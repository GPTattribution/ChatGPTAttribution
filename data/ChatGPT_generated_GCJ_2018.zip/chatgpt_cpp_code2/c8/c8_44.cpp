#include<bits/stdc++.h>
using namespace std;
const int MAXN = 26;
int T, n, sum;
int p[MAXN];
vector<string> res;
void solve() {
    res.clear();
    cin >> n;
    sum = 0;
    for (int i = 0; i < n; i++) {
        cin >> p[i];
        sum += p[i];
    }
    while (sum > 0) {
        string s;
        int maxi = 0;
        for (int i = 1; i < n; i++) {
            if (p[i] > p[maxi]) {
                maxi = i;
            }
        }
        p[maxi] -= 1;
        sum -= 1;
        s += ('A' + maxi);
        if (sum == 2) {
            for (int i = 0; i < n; i++) {
                if (p[i] > p[maxi]) {
                    maxi = i;
                }
            }
            p[maxi] -= 1;
            sum -= 1;
            s += ('A' + maxi);
        }
        res.push_back(s);
    }
    reverse(res.begin(), res.end());
    cout << "Case #" << ++caseno << ": ";
    for (int i = 0; i < res.size(); i++) {
        cout << res[i] << " ";
    }
    cout << endl;
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin >> T;
    int caseno = 0;
    while (T--) {
        solve();
    }
    return 0;
}
