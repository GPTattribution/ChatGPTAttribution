#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties(n);
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            parties[j] = {p, 'A' + j};
        }
        string plan;
        while (true) {
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());
            if (parties[0].first == 0) break;
            if (parties[0].first > parties[1].first || (n > 2 && parties[1].first == 0)) {
                plan += parties[0].second;
                parties[0].first--;
            } else {
                plan += parties[0].second;
                plan += parties[1].second;
                parties[0].first--;
                parties[1].first--;
            }
        }
        cout << "Case #" << i << ": " << plan << endl;
    }
    return 0;
}
