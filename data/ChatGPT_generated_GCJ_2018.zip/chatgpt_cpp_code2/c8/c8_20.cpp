#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
};

struct Evacuation {
    Party p1;
    Party p2;
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
}

vector<Evacuation> evacuate(vector<Party> parties) {
    priority_queue<Party> pq;
    for (Party p : parties) {
        pq.push(p);
    }
    vector<Evacuation> evacs;
    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        Party p2 = Party{'_', 0};  
        if (!pq.empty()) {
            p2 = pq.top();
            pq.pop();
        }
        if (p1.count > 1) {
            p1.count--;
            if (p1.count > pq.top().count) {
                pq.push(p1);
            } else {
                pq.push(p2);
                pq.push(p1);
            }
        }
        if (p2.count > 0) {
            p2.count--;
            evacs.push_back(Evacuation{p1, p2});
        } else {
            evacs.push_back(Evacuation{p1, Party{'_', 0}});
        }
    }
    return evacs;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<Party> parties(N);
        for (int i = 0; i < N; i++) {
            parties[i].name = 'A' + i;
            cin >> parties[i].count;
        }
        vector<Evacuation> evacs = evacuate(parties);
        cout << "Case #" << t << ": ";
        for (Evacuation e : evacs) {
            string p1(e.p1.count, e.p1.name);
            string p2(e.p2.count, e.p2.name);
            cout << p1 << p2 << " ";
        }
        cout << endl;
    }
    return 0;
}
