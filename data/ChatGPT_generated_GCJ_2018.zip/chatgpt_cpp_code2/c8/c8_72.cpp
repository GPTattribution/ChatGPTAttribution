#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

struct Party {
    int count;
    char name;
};

bool operator<(const Party& a, const Party& b) {
    return a.count < b.count;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;

        priority_queue<Party> q;
        int total = 0;

        for (int i = 0; i < n; i++) {
            int count;
            cin >> count;
            q.push({count, 'A' + i});
            total += count;
        }

        vector<string> res;

        while (!q.empty()) {
            Party p1 = q.top();
            q.pop();
            total--;
            p1.count--;

            if (p1.count > 0) {
                q.push(p1);
            }

            if (!q.empty()) {
                Party p2 = q.top();
                q.pop();
                total--;
                p2.count--;

                if (p2.count > 0) {
                    q.push(p2);
                }

                res.push_back(string(1, p1.name) + string(1, p2.name));
            } else {
                res.push_back(string(1, p1.name));
            }
        }

        reverse(res.begin(), res.end());

        cout << "Case #" << t << ": ";

        for (string s : res) {
            cout << s << " ";
        }

        cout << endl;
    }

    return 0;
}
