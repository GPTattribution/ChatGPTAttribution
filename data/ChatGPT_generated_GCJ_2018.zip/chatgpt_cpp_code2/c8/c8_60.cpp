#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

struct Party {
    char name;
    int count;
    Party(char name, int count) : name(name), count(count) {}
};

vector<string> evacuate(vector<Party>& parties) {
    int n = parties.size();
    priority_queue<pair<int, char>> pq;
    for (int i = 0; i < n; i++) {
        pq.push(make_pair(parties[i].count, parties[i].name));
    }
    vector<string> plan;
    while (!pq.empty()) {
        auto top1 = pq.top();
        pq.pop();
        if (pq.empty()) {
            plan.push_back(string(1, top1.second));
            break;
        }
        auto top2 = pq.top();
        pq.pop();
        int count1 = top1.first, count2 = top2.first;
        char name1 = top1.second, name2 = top2.second;
        plan.push_back(string(1, name1) + string(1, name2));
        if (--count1 > 0) pq.push(make_pair(count1, name1));
        if (--count2 > 0) pq.push(make_pair(count2, name2));
    }
    return plan;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<Party> parties;
        for (int j = 0; j < n; j++) {
            int count;
            cin >> count;
            parties.emplace_back('A' + j, count);
        }
        auto plan = evacuate(parties);
        cout << "Case #" << i << ": ";
        for (auto s : plan) {
            cout << s << " ";
        }
        cout << endl;
    }
    return 0;
}
