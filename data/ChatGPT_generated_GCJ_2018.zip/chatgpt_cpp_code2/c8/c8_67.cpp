#include <iostream>
#include <queue>
#include <vector>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<pair<int, char>> q;
        int total = 0;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            q.push(make_pair(P, 'A' + i));
            total += P;
        }
        cout << "Case #" << t << ":";
        while (!q.empty()) {
            vector<pair<int, char>> evac;
            int remaining = total;
            int max_party = q.top().first;
            char max_party_name = q.top().second;
            q.pop();
            evac.push_back(make_pair(max_party_name, 0));
            remaining -= max_party;
            if (remaining >= max_party - 1) {
                int second_party = q.top().first;
                char second_party_name = q.top().second;
                q.pop();
                evac.push_back(make_pair(second_party_name, 0));
                remaining -= second_party;
            }
            if (max_party > 1) {
                max_party--;
                q.push(make_pair(max_party, max_party_name));
                remaining--;
            }
            while (!q.empty() && remaining >= q.top().first) {
                int next_party = q.top().first;
                char next_party_name = q.top().second;
                q.pop();
                evac.back().second = next_party_name;
                remaining -= next_party;
                if (next_party > 1) {
                    next_party--;
                    q.push(make_pair(next_party, next_party_name));
                    remaining--;
                }
            }
            for (auto p : evac) {
                if (p.second == 0) {
                    cout << " " << p.first;
                } else {
                    cout << " " << p.first << p.second;
                }
            }
        }
        cout << endl;
    }
    return 0;
}
