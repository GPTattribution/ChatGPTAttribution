#include <iostream>
#include <vector>
#include <queue>
#include <string>
#include <algorithm>
using namespace std;

struct Party {
    char name;
    int count;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<Party> parties;
        int total = 0;
        for (int j = 0; j < n; j++) {
            int count;
            cin >> count;
            total += count;
            Party p = { 'A' + j, count };
            parties.push(p);
        }
        cout << "Case #" << i << ":";
        while (!parties.empty()) {
            Party p1 = parties.top();
            parties.pop();
            if (parties.empty()) {
                for (int k = 0; k < p1.count; k++) {
                    cout << " " << p1.name;
                }
            }
            else {
                Party p2 = parties.top();
                parties.pop();
                cout << " " << p1.name << p2.name;
                p1.count--;
                p2.count--;
                total -= 2;
                if (p1.count > 0) {
                    parties.push(p1);
                }
                if (p2.count > 0) {
                    parties.push(p2);
                }
            }
        }
        cout << endl;
    }
    return 0;
}
