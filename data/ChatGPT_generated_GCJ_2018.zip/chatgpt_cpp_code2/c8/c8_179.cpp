#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

string evacuate(int n, vector<int>& parties) {
    string plan = "";
    while (true) {
        sort(parties.rbegin(), parties.rend());
        if (parties[1] == 0) {
            for (int i = 0; i < parties[0]; i++) {
                plan += char('A' + i);
                plan += " ";
            }
            break;
        }
        int p1 = 0, p2 = 0;
        while (parties[p1] == 0) p1++;
        parties[p1]--;
        plan += char('A' + p1);
        if (parties[p2] == 0) p2 = p1 + 1;
        parties[p2]--;
        plan += char('A' + p2);
        plan += " ";
    }
    return plan;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<int> parties(n);
        for (int j = 0; j < n; j++) {
            cin >> parties[j];
        }
        cout << "Case #" << i << ": " << evacuate(n, parties) << endl;
    }
    return 0;
}
