#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            parties.push_back({p, 'A' + j});
        }
        string ans;
        while (true) {
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());
            if (parties[0].first == 0) break;
            if (parties[0].first == 1) {
                ans += parties[0].second;
                parties[0].first--;
            } else if (parties[0].first - parties[1].first >= 2) {
                ans += parties[0].second;
                ans += parties[0].second;
                parties[0].first -= 2;
            } else {
                ans += parties[0].second;
                ans += parties[1].second;
                parties[0].first--;
                parties[1].first--;
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
