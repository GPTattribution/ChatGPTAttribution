#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <sstream>

using namespace std;

struct Party {
    char name;
    int count;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<Party> q;
        int total_senators = 0;
        for (int j = 0; j < n; j++) {
            int count;
            cin >> count;
            q.push({ 'A' + j, count });
            total_senators += count;
        }
        string plan;
        while (!q.empty()) {
            Party p1 = q.top();
            q.pop();
            total_senators--;
            if (!q.empty()) {
                Party p2 = q.top();
                q.pop();
                total_senators--;
                plan += p1.name;
                plan += p2.name;
                p1.count--;
                p2.count--;
                if (p1.count > 0) {
                    q.push(p1);
                }
                if (p2.count > 0) {
                    q.push(p2);
                }
            } else {
                plan += p1.name;
                p1.count--;
                if (p1.count > 0) {
                    q.push(p1);
                }
            }
            if (!q.empty()) {
                Party p3 = q.top();
                if (p3.count > total_senators / 2) {
                    q.pop();
                    total_senators--;
                    plan += p3.name;
                    p3.count--;
                    if (p3.count > 0) {
                        q.push(p3);
                    }
                }
            }
            plan += ' ';
        }
        cout << "Case #" << i << ": " << plan << endl;
    }
    return 0;
}
