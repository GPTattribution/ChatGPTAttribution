#include <iostream>
#include <vector>
#include <queue>

using namespace std;

struct Party {
    int count;
    char name;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

string evacuate(int N, vector<int>& senators) {
    priority_queue<Party> pq;
    for (int i = 0; i < N; i++) {
        Party p;
        p.count = senators[i];
        p.name = 'A' + i;
        pq.push(p);
    }
    string ans;
    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        Party p2;
        if (!pq.empty()) {
            p2 = pq.top();
            pq.pop();
        }
        if (p1.count > p2.count) {
            ans += p1.name;
            p1.count--;
            if (p1.count > 0) {
                pq.push(p1);
            }
        }
        else {
            ans += p1.name;
            ans += p2.name;
            p1.count--;
            p2.count--;
            if (p1.count > 0) {
                pq.push(p1);
            }
            if (p2.count > 0) {
                pq.push(p2);
            }
        }
        ans += ' ';
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<int> senators(N);
        int total = 0;
        for (int i = 0; i < N; i++) {
            cin >> senators[i];
            total += senators[i];
        }
        cout << "Case #" << t << ": " << evacuate(N, senators) << endl;
    }
    return 0;
}
