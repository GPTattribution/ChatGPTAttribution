#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> pq;
        int total = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            pq.push({p, 'A' + j});
            total += p;
        }
        string ans;
        while (!pq.empty()) {
            auto p1 = pq.top();
            pq.pop();
            total--;
            ans += p1.second;
            if (pq.empty()) break;
            auto p2 = pq.top();
            pq.pop();
            total--;
            ans += p2.second;
            if (p1.first > 1) pq.push({p1.first - 1, p1.second});
            if (p2.first > 1) pq.push({p2.first - 1, p2.second});
            if (p1.first - 1 > p2.first) pq.push({p1.first - 1, p1.second});
            else pq.push({p2.first, p2.second});
        }
        cout << "Case #" << i << ": " << ans << "\n";
    }
    return 0;
}
