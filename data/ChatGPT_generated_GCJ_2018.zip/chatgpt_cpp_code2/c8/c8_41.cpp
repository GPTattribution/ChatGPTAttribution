#include <iostream>
#include <queue>
#include <vector>
#include <cstring>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int tc = 1; tc <= t; tc++) {
        int n;
        cin >> n;

        int p[n];
        int total = 0;
        for (int i = 0; i < n; i++) {
            cin >> p[i];
            total += p[i];
        }

        priority_queue<pair<int, int>> q;
        for (int i = 0; i < n; i++) {
            q.push(make_pair(p[i], i));
        }

        vector<pair<int, int>> plan;

        while (total > 0) {
            int party1 = q.top().second;
            q.pop();
            total--;
            p[party1]--;
            if (total == 0) {
                plan.push_back(make_pair(party1, -1));
                break;
            }
            if (q.top().first * 2 <= total) {
                int party2 = q.top().second;
                q.pop();
                total--;
                p[party2]--;
                plan.push_back(make_pair(party1, party2));
                if (p[party2] > 0) {
                    q.push(make_pair(p[party2], party2));
                }
            } else {
                int party2 = q.top().second;
                q.pop();
                total--;
                p[party2]--;
                plan.push_back(make_pair(party1, party2));
                q.push(make_pair(p[party1], party1));
                if (p[party2] > 0) {
                    q.push(make_pair(p[party2], party2));
                }
            }
        }

        cout << "Case #" << tc << ": ";
        for (auto p : plan) {
            char c1 = 'A' + p.first;
            char c2 = (p.second >= 0) ? ('A' + p.second) : '-';
            cout << c1 << c2 << " ";
        }
        cout << endl;
    }
    return 0;
}
