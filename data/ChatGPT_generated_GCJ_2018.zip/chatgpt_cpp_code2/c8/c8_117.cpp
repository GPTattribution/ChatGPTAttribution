#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Party {
    char name;
    int count;
};

bool cmp(Party& a, Party& b) {
    return a.count > b.count;
}

void evacuate(int n, vector<Party>& parties) {
    sort(parties.begin(), parties.end(), cmp);
    vector<string> steps;
    while (parties[0].count > 0) {
        string step = "";
        if (parties[0].count > 1) {
            step += parties[0].name;
            parties[0].count--;
        }
        step += parties[1].name;
        parties[1].count--;
        steps.push_back(step);
        sort(parties.begin(), parties.end(), cmp);
    }
    while (parties[1].count > 0) {
        steps.push_back(string(1, parties[0].name) + parties[1].name);
        parties[0].count--;
        parties[1].count--;
    }
    cout << "Case #" << n << ": ";
    for (int i = 0; i < steps.size(); i++) {
        cout << steps[i];
        if (i < steps.size() - 1) {
            cout << " ";
        }
    }
    cout << endl;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<Party> parties;
        for (int j = 0; j < n; j++) {
            Party party;
            party.name = 'A' + j;
            cin >> party.count;
            parties.push_back(party);
        }
        evacuate(i, parties);
    }
    return 0;
}
