#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

int main() {
    int t;
    cin >> t;
    for (int caseNum = 1; caseNum <= t; caseNum++) {
        int n;
        cin >> n;
        priority_queue<Party> parties;
        for (char i = 'A'; i < 'A' + n; i++) {
            int p;
            cin >> p;
            parties.push({i, p});
        }
        string plan;
        while (!parties.empty()) {
            Party first = parties.top();
            parties.pop();
            if (first.count > 1) {
                Party second = parties.top();
                parties.pop();
                plan += first.name;
                plan += second.name;
                first.count--;
                second.count--;
                if (first.count > 0) {
                    parties.push(first);
                }
                if (second.count > 0) {
                    parties.push(second);
                }
            } else {
                plan += first.name;
                first.count--;
                if (first.count > 0) {
                    parties.push(first);
                }
            }
            plan += " ";
        }
        cout << "Case #" << caseNum << ": " << plan << endl;
    }
    return 0;
}
