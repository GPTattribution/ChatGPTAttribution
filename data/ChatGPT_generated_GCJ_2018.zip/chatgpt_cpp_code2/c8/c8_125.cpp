#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        priority_queue<pair<int, char>> parties;

        for (char c = 'A'; c < 'A' + N; c++) {
            int P;
            cin >> P;
            parties.push({P, c});
        }

        string plan;

        while (!parties.empty()) {
            char c1 = parties.top().second;
            int p1 = parties.top().first;
            parties.pop();

            if (parties.empty()) {
                for (int i = 0; i < p1; i++) {
                    plan += c1;
                }
                break;
            }

            char c2 = parties.top().second;
            int p2 = parties.top().first;
            parties.pop();

            if (p1 > p2 + 1) {
                plan += c1;
                plan += c1;
                parties.push({p1 - 2, c1});
                parties.push({p2, c2});
            } else {
                plan += c1;
                plan += c2;
                parties.push({p1 - 1, c1});
                if (p2 > 1) {
                    parties.push({p2 - 1, c2});
                }
            }
        }

        cout << "Case #" << t << ": " << plan << endl;
    }

    return 0;
}
