#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;

        priority_queue<pair<int, char>> pq;

        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;

            pq.push(make_pair(p, 'A' + j));
        }

        cout << "Case #" << i << ": ";

        while (!pq.empty()) {
            pair<int, char> first = pq.top();
            pq.pop();

            pair<int, char> second = pq.top();
            pq.pop();

            cout << first.second;
            first.first--;

            if (second.first > 0) {
                cout << second.second;
                second.first--;
            }

            if (first.first > 0) {
                pq.push(first);
            }

            if (second.first > 0) {
                pq.push(second);
            }

            cout << " ";
        }

        cout << endl;
    }

    return 0;
}
