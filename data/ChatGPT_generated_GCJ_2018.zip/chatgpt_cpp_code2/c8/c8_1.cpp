#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool cmp(pair<char, int> p1, pair<char, int> p2) {
    return p1.second > p2.second;
}

string evacuate(vector<pair<char, int>>& parties) {
    string plan = "";
    while (true) {
        sort(parties.begin(), parties.end(), cmp);

        if (parties.size() == 1) {
            for (int i = 0; i < parties[0].second; i++) {
                plan += parties[0].first;
            }
            break;
        }

        int s1 = parties[0].second;
        int s2 = parties[1].second;
        if (s1 == s2) {
            plan += parties[0].first;
            plan += parties[1].first;
            parties[0].second--;
            parties[1].second--;
        } else if (s1 > s2 && s1 >= 2 && s1 - 2 >= s2) {
            plan += parties[0].first;
            plan += parties[0].first;
            parties[0].second -= 2;
        } else {
            plan += parties[0].first;
            plan += parties[1].first;
            parties[0].second--;
            parties[1].second--;
        }

        for (int i = 0; i < parties.size(); i++) {
            if (parties[i].second == 0) {
                parties.erase(parties.begin() + i);
                i--;
            }
        }
    }
    return plan;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<char, int>> parties;
        for (int i = 0; i < N; i++) {
            int senators;
            cin >> senators;
            parties.push_back(make_pair('A' + i, senators));
        }
        string plan = evacuate(parties);
        cout << "Case #" << t << ": " << plan << endl;
    }
    return 0;
}
