#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int test_case = 1; test_case <= t; test_case++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties;
        for (int i = 0; i < n; i++) {
            int p;
            cin >> p;
            parties.push_back({p, 'A' + i}); 
        }
        string plan;
        while (true) {
            sort(parties.rbegin(), parties.rend());
            if (parties[0].first == 0) break;
            if (parties[0].first > parties[1].first || parties[0].first == parties[1].first && n > 2 && parties[2].first == 0) { // Evacuate one senator
                plan += parties[0].second;
                parties[0].first--;
            } else {
                plan += parties[0].second;
                plan += parties[1].second;
                parties[0].first--;
                parties[1].first--;
            }
        }
        cout << "Case #" << test_case << ": " << plan << endl;
    }
    return 0;
}
