#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<pair<int, char>> parties;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            parties.push_back(make_pair(P, 'A' + i));
        }

        string plan;
        while (true) {
            sort(parties.rbegin(), parties.rend());

            if (parties[0].first == 0) {
                break;
            }

            if (parties[0].first > parties[1].first || parties[0].first == parties[1].first && N == 2) {
                plan += parties[0].second;
                parties[0].first--;
            } else {
                plan += parties[0].second;
                parties[0].first--;
                plan += parties[1].second;
                parties[1].first--;
            }
        }

        cout << "Case #" << t << ": " << plan << endl;
    }

    return 0;
}
