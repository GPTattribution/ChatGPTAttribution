#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
    Party(char name, int count) : name(name), count(count) {}
};

struct PartyComparator {
    bool operator()(const Party& a, const Party& b) {
        return a.count < b.count;
    }
};

vector<Party> read_input() {
    int n;
    cin >> n;
    vector<Party> parties;
    for (int i = 0; i < n; i++) {
        int count;
        cin >> count;
        parties.emplace_back('A' + i, count);
    }
    return parties;
}

string evacuate(vector<Party>& parties) {
    priority_queue<Party, vector<Party>, PartyComparator> pq;
    for (const Party& party : parties) {
        pq.push(party);
    }
    string plan;
    while (!pq.empty()) {
        Party a = pq.top();
        pq.pop();
        Party b = pq.top();
        pq.pop();
        a.count--;
        b.count--;
        plan += a.name;
        plan += b.name;
        if (a.count > 0) {
            pq.push(a);
        }
        if (b.count > 0) {
            pq.push(b);
        }
    }
    return plan;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        vector<Party> parties = read_input();
        string plan = evacuate(parties);
        cout << "Case #" << i << ": " << plan << endl;
    }
    return 0;
}
