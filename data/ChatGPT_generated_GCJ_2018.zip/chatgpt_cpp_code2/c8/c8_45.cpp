#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;

        priority_queue<pair<int, char>> pq; 
        for (char c = 'A'; c < 'A' + n; c++) {
            int p;
            cin >> p;
            pq.push(make_pair(p, c));
        }

        cout << "Case #" << t << ": ";
        while (!pq.empty()) {
            auto p1 = pq.top();
            pq.pop();

            auto p2 = pq.top();
            pq.pop();

            cout << p1.second;
            p1.first--;

            if (p2.first > 1) {
                cout << p2.second;
                p2.first--;
            }

            if (p1.first > 0) {
                pq.push(p1);
            }
            if (p2.first > 0) {
                pq.push(p2);
            }

            cout << " ";
        }

        cout << endl;
    }

    return 0;
}
