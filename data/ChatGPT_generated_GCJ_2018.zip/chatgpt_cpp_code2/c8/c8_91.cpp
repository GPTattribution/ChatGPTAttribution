#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<int> senators(n);
        priority_queue<pair<int, int>> pq; 
        int total = 0;
        for (int j = 0; j < n; j++) {
            cin >> senators[j];
            pq.push({senators[j], j});
            total += senators[j];
        }
        string ans;
        while (!pq.empty()) {
            int p1 = pq.top().second;
            pq.pop();
            total--;
            if (!pq.empty() && pq.top().first * 2 > total) {
                int p2 = pq.top().second;
                pq.pop();
                total--;
                ans += (char)('A' + p1);
                ans += (char)('A' + p2);
                pq.push({senators[p1] + senators[p2], p1});
            } else {
                ans += (char)('A' + p1);
                if (pq.empty()) break;
                int p2 = pq.top().second;
                pq.pop();
                total--;
                ans += (char)('A' + p2);
                pq.push({senators[p1] + senators[p2], p1});
            }
        }
        cout << "Case #" << i << ": " << ans << "\n";
    }
    return 0;
}
