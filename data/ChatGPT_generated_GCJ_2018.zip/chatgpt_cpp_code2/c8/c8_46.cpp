#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

string evacuate(int n, vector<int>& parties) {
    string plan;
    while (true) {
        int max_party = max_element(parties.begin(), parties.end()) - parties.begin();
        if (parties[max_party] == 0) break; 

        parties[max_party]--;
        plan += ('A' + max_party);

        int second_max_party = max_element(parties.begin(), parties.end()) - parties.begin();
        if (parties[second_max_party] == 0) {
            plan += ('A' + max_party);
            break;
        }

        parties[second_max_party]--;
        plan += ('A' + second_max_party);
    }
    return plan;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;
        vector<int> parties(n);
        for (int i = 0; i < n; i++) {
            cin >> parties[i];
        }

        string plan = evacuate(n, parties);
        cout << "Case #" << t << ": " << plan << endl;
    }
    return 0;
}
