#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

struct Party {
    int count;
    char name;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<Party> parties(N);
        int total = 0;
        for (int i = 0; i < N; i++) {
            cin >> parties[i].count;
            parties[i].name = 'A' + i;
            total += parties[i].count;
        }
        priority_queue<Party> pq(parties.begin(), parties.end());
        vector<string> ans;
        while (!pq.empty()) {
            Party p1 = pq.top();
            pq.pop();
            if (p1.count > 1) {
                ans.push_back(string(1, p1.name) + string(1, p1.name));
                p1.count -= 2;
            } else {
                ans.push_back(string(1, p1.name));
                p1.count--;
            }
            total--;
            if (pq.empty()) break;
            Party p2 = pq.top();
            pq.pop();
            if (p2.count > 1 && p2.count - 2 >= total - p2.count) {
                ans.push_back(string(1, p1.name) + string(1, p2.name));
                p2.count -= 2;
            } else {
                ans.push_back(string(1, p1.name) + string(1, p2.name));
                p1.count--;
                p2.count--;
            }
            if (p1.count > 0) pq.push(p1);
            if (p2.count > 0) pq.push(p2);
            total -= 2;
        }
        cout << "Case #" << t << ": ";
        for (string s : ans) {
            cout << s << " ";
        }
        cout << endl;
    }
    return 0;
}
