#include <iostream>
#include <queue>
#include <vector>
using namespace std;

struct Party {
    int count;
    char name;
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
}

vector<Party> readParties(int n) {
    vector<Party> parties;
    for (int i = 0; i < n; i++) {
        Party party;
        party.count = 0;
        party.name = 'A' + i;
        cin >> party.count;
        parties.push_back(party);
    }
    return parties;
}

string evacuate(int n, vector<Party> parties) {
    priority_queue<Party> pq;
    for (Party party : parties) {
        pq.push(party);
    }
    string plan;
    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        plan += p1.name;
        p1.count--;
        if (!pq.empty()) {
            Party p2 = pq.top();
            pq.pop();
            plan += p2.name;
            p2.count--;
            if (p2.count > 0) {
                pq.push(p2);
            }
        }
        if (p1.count > 0) {
            pq.push(p1);
        }
        plan += " ";
    }
    return plan;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<Party> parties = readParties(n);
        string plan = evacuate(n, parties);
        cout << "Case #" << i << ": " << plan << endl;
    }
    return 0;
}
