#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties(N);
        for (int i = 0; i < N; i++) {
            cin >> parties[i].first;
            parties[i].second = 'A' + i;
        }
        sort(parties.rbegin(), parties.rend());
        string ans;
        while (parties[0].first > 0) {
            ans += parties[0].second;
            parties[0].first--;
            if (parties[1].first > 0) {
                ans += parties[1].second;
                parties[1].first--;
            } else if (parties[2].first > 0) {
                ans += parties[2].second;
                parties[2].first--;
            }
            sort(parties.rbegin(), parties.rend());
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
