#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> senators;
        int total = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            senators.push_back(make_pair(p, 'A' + j));
            total += p;
        }
        cout << "Case #" << i << ": ";
        while (total > 0) {
            sort(senators.begin(), senators.end(), greater<pair<int, char>>());
            if (total == 3 && senators[0].first == 2 && senators[1].first == 1) {
                cout << senators[0].second << senators[1].second << " ";
                total -= 2;
                senators[0].first--;
                senators[1].first--;
            } else {
                cout << senators[0].second << senators[1].second << " ";
                total -= 2;
                senators[0].first--;
                senators[1].first--;
                if (senators[2].first * 2 > total) {
                    cout << senators[0].second << " ";
                    total--;
                    senators[0].first--;
                }
            }
        }
        cout << endl;
    }
    return 0;
}
