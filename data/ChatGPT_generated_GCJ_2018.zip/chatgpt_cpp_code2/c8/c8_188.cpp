#include <iostream>
#include <queue>
#include <vector>

using namespace std;

struct Party {
  char name;
  int count;
};

struct CompareParty {
  bool operator()(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
  }
};

int main() {
  int t;
  cin >> t;

  for (int i = 1; i <= t; i++) {
    int n;
    cin >> n;

    priority_queue<Party, vector<Party>, CompareParty> pq;

    for (int j = 0; j < n; j++) {
      int count;
      cin >> count;
      pq.push({static_cast<char>('A' + j), count});
    }

    cout << "Case #" << i << ": ";

    while (!pq.empty()) {
      Party p1 = pq.top();
      pq.pop();

      if (!pq.empty()) {
        Party p2 = pq.top();
        pq.pop();

        cout << p1.name << p2.name << " ";
        p1.count--;
        p2.count--;

        if (p1.count > 0) {
          pq.push(p1);
        }

        if (p2.count > 0) {
          pq.push(p2);
        }
      } else {
        cout << p1.name << " ";
        p1.count--;

        if (p1.count > 0) {
          pq.push(p1);
        }
      }
    }

    cout << endl;
  }

  return 0;
}
