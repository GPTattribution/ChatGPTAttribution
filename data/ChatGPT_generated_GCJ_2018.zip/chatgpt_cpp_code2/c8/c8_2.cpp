#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

vector<Party> parse_input(int n) {
    vector<Party> parties(n);
    for (int i = 0; i < n; i++) {
        parties[i].name = 'A' + i;
        cin >> parties[i].count;
    }
    return parties;
}

string evacuate(const vector<Party>& parties) {
    string res;
    priority_queue<Party> q;
    for (const auto& party : parties) {
        q.push(party);
    }
    while (!q.empty()) {
        Party first = q.top();
        q.pop();
        if (q.empty()) {
            res += first.name;
            break;
        }
        Party second = q.top();
        q.pop();
        res += first.name;
        res += second.name;
        first.count--;
        second.count--;
        if (first.count > 0) {
            q.push(first);
        }
        if (second.count > 0) {
            q.push(second);
        }
    }
    return res;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<Party> parties = parse_input(n);
        string res = evacuate(parties);
        cout << "Case #" << i << ": " << res << endl;
    }
    return 0;
}
