#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> senators(N);
        for (int i = 0; i < N; i++) {
            cin >> senators[i].first;
            senators[i].second = 'A' + i;
        }
        string ans;
        while (true) {
            sort(senators.rbegin(), senators.rend());
            if (senators[0].first == 0) {
                break;
            }
            ans += senators[0].second;
            senators[0].first--;
            if (senators[1].first > 0 && senators[0].first <= senators[1].first) {
                ans += senators[1].second;
                senators[1].first--;
            }
            ans += " ";
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
