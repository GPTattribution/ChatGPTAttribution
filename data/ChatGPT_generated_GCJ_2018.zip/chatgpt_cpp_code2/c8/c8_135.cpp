#include <iostream>
#include <queue>
#include <vector>
using namespace std;

struct Party {
  int count;
  char name;
  bool operator<(const Party& other) const {
    return count < other.count;
  }
};

string evacuate(vector<Party>& parties) {
  string plan;
  priority_queue<Party> q;
  for (Party& party : parties) {
    q.push(party);
  }
  while (!q.empty()) {
    Party p1 = q.top();
    q.pop();
    Party p2 = q.empty() || p1.count > parties.size() / 2 ? Party{0, '-'} : q.top();
    q.pop();
    plan += p1.name;
    p1.count--;
    if (p2.count > 0) {
      plan += p2.name;
      p2.count--;
      if (p2.count > 0) {
        q.push(p2);
      }
    }
    if (p1.count > 0) {
      q.push(p1);
    }
    plan += ' ';
  }
  plan.pop_back();
  return plan;
}

int main() {
  int T;
  cin >> T;
  for (int t = 1; t <= T; t++) {
    int N;
    cin >> N;
    vector<Party> parties(N);
    for (int i = 0; i < N; i++) {
      parties[i].name = 'A' + i;
      cin >> parties[i].count;
    }
    cout << "Case #" << t << ": " << evacuate(parties) << endl;
  }
  return 0;
}
