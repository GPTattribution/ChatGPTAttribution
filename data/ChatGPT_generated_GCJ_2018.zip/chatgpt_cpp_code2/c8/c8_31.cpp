#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        priority_queue<pair<int, int>> pq;

        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            pq.push({P, i});
        }

        string ans = "";
        while (!pq.empty()) {
            auto p1 = pq.top(); pq.pop();
            auto p2 = pq.top(); pq.pop();

            if (p1.first > 1) {
                ans += 'A' + p1.second;
                p1.first--;
                pq.push(p1);
            }

            if (p2.first > 1) {
                ans += 'A' + p2.second;
                p2.first--;
                pq.push(p2);
            }

            if (pq.size() == 1 && pq.top().first == 1) {
                ans += 'A' + pq.top().second;
                pq.pop();
            }

            if (pq.size() == 0) break;

            ans += 'A' + p1.second;
            ans += 'A' + p2.second;
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
