#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            parties.push_back(make_pair(P, 'A' + i));
        }
        vector<string> plan;
        while (true) {
            sort(parties.rbegin(), parties.rend());
            if (parties[0].first == 0) break;
            if (parties[0].first == parties[1].first) {
                parties[0].first--;
                parties[1].first--;
                plan.push_back(string(1, parties[0].second) + parties[1].second);
            } else {
                parties[0].first -= 2;
                plan.push_back(string(2, parties[0].second));
            }
        }
        cout << "Case #" << t << ":";
        for (const string& step : plan) {
            cout << " " << step;
        }
        cout << endl;
    }
    return 0;
}
