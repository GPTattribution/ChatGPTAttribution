#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <cstring>
using namespace std;

const int MAXN = 26;
const char PARTY_NAMES[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

int T, N, sum;
int P[MAXN];
int freq[MAXN];
vector<pair<int, int>> evac;

void init() {
    evac.clear();
    sum = 0;
    memset(freq, 0, sizeof(freq));
}

void read_input() {
    cin >> N;
    for (int i = 0; i < N; i++) {
        cin >> P[i];
        sum += P[i];
        freq[i] = P[i];
    }
}

void evacuate() {
    while (true) {
        int max_freq = 0;
        int max_index = -1;
        for (int i = 0; i < N; i++) {
            if (freq[i] > max_freq) {
                max_freq = freq[i];
                max_index = i;
            }
        }
        if (max_freq == 0) {
            break; 
        }
        freq[max_index]--;
        if (max_freq > 1) {
            int second_max_freq = 0;
            int second_max_index = -1;
            for (int i = 0; i < N; i++) {
                if (i != max_index && freq[i] > second_max_freq) {
                    second_max_freq = freq[i];
                    second_max_index = i;
                }
            }
            if (second_max_freq == 0) {
                freq[max_index]--;
                evac.push_back(make_pair(max_index, max_index));
            } else {
                freq[second_max_index]--;
                evac.push_back(make_pair(max_index, second_max_index));
            }
        } else {
            evac.push_back(make_pair(max_index, -1));
        }
    }
}

void print_output(int t) {
    cout << "Case #" << t << ":";
    for (int i = 0; i < evac.size(); i++) {
        int first_party = evac[i].first;
        int second_party = evac[i].second;
        cout << " ";
        cout << PARTY_NAMES[first_party];
        if (second_party >= 0) {
            cout << PARTY_NAMES[second_party];
        }
    }
    cout << endl;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        init();
        read_input();
        evacuate();
        print_output(t);
    }
    return 0;
}
