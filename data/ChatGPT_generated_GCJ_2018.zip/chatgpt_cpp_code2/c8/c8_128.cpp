#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            parties.push_back(make_pair(p, 'A' + j));
        }
        string plan;
        while (true) {
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());
            if (parties[0].first == 0) break;
            int i1 = 0, i2 = 1;
            while (i2 < n && parties[i2].first == 0) i2++;
            if (i2 < n && parties[i2].first > 0 && parties[0].first - parties[i2].first >= 2) {
                plan += parties[0].second;
                plan += parties[i2].second;
                parties[0].first -= 1;
                parties[i2].first -= 1;
            } else {
                plan += parties[0].second;
                parties[0].first -= 1;
            }
        }
        cout << "Case #" << i << ": " << plan << endl;
    }
    return 0;
}
