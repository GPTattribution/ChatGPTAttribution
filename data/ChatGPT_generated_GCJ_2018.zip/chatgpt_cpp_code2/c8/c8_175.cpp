#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<pair<int, char>> q; 
        int total = 0;
        for (int i = 0; i < N; i++) {
            int p;
            cin >> p;
            q.push(make_pair(p, 'A' + i));
            total += p;
        }
        cout << "Case #" << t << ": ";
        while (!q.empty()) {
            vector<char> parties;
            parties.push_back(q.top().second);
            q.pop();
            if (!q.empty() && q.top().first * 2 > total - 2) {
                parties.push_back(q.top().second);
                q.pop();
            }
            for (char party : parties) {
                cout << party;
                total--;
                if (parties.size() == 2) {
                    cout << party;
                    total--;
                }
                if (!q.empty() && q.top().first * 2 > total - 2) {
                    parties.push_back(q.top().second);
                    q.pop();
                }
            }
            if (!q.empty()) {
                cout << " ";
            }
        }
        cout << endl;
    }
    return 0;
}
