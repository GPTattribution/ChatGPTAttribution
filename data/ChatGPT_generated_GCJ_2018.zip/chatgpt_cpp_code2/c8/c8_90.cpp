#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>

using namespace std;

struct Party {
    char name;
    int senators;
    bool operator<(const Party& other) const {
        return senators < other.senators;
    }
};

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<Party> parties;
        int total_senators = 0;

        for (int i = 0; i < N; i++) {
            int senators;
            cin >> senators;
            parties.push_back({char('A' + i), senators});
            total_senators += senators;
        }

        priority_queue<Party> pq(parties.begin(), parties.end());

        vector<string> plan;

        while (!pq.empty()) {
            Party p1 = pq.top();
            pq.pop();

            if (pq.empty()) {
                for (int i = 0; i < p1.senators; i++) {
                    plan.push_back(string(1, p1.name));
                }
                break;
            }

            Party p2 = pq.top();
            pq.pop();

            plan.push_back(string(1, p1.name) + string(1, p2.name));
            p1.senators--;
            p2.senators--;
            total_senators -= 2;

            if (p1.senators > 0) {
                pq.push(p1);
            }
            if (p2.senators > 0) {
                pq.push(p2);
            }
        }

        cout << "Case #" << t << ": ";
        for (const string& s : plan) {
            cout << s << " ";
        }
        cout << endl;
    }

    return 0;
}
