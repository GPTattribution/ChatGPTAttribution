#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties;
        for (int i = 0; i < N; i++) {
            int p;
            cin >> p;
            parties.push_back({p, 'A' + i});
        }
        string plan;
        while (!parties.empty()) {
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());
            if (parties[0].first > 1) {
                plan += parties[0].second;
                plan += parties[0].second;
                parties[0].first -= 2;
            } else {
                plan += parties[0].second;
                parties[0].first--;
            }
            if (parties[1].first > 1) {
                plan += parties[1].second;
                plan += parties[1].second;
                parties[1].first -= 2;
            } else {
                plan += parties[1].second;
                parties[1].first--;
            }
            if (parties[0].first == 0) {
                parties.erase(parties.begin());
            }
            if (parties[1].first == 0) {
                parties.erase(parties.begin() + 1);
            }
        }
        cout << "Case #" << t << ": " << plan << endl;
    }
    return 0;
}
