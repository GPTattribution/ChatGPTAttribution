#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> pq;
        int total = 0;
        for (char c = 'A'; c < 'A' + n; c++) {
            int p;
            cin >> p;
            pq.push(make_pair(p, c));
            total += p;
        }
        string plan;
        while (!pq.empty()) {
            int count = min(2, total - pq.top().first);
            if (count == 1 && pq.size() == 2) {
                count = 2;
            }
            vector<char> evacuated;
            for (int j = 0; j < count; j++) {
                char party = pq.top().second;
                evacuated.push_back(party);
                pq.pop();
                total--;
            }
            sort(evacuated.begin(), evacuated.end());
            for (char party : evacuated) {
                plan += party;
            }
            if (count == 2) {
                plan += " ";
            }
        }
        cout << "Case #" << i << ": " << plan << endl;
    }
    return 0;
}
