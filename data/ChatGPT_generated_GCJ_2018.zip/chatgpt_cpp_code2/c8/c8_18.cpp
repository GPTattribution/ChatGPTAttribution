#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties(n);
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            parties[j] = make_pair(p, 'A' + j); 
        }
        sort(parties.rbegin(), parties.rend());
        string ans;
        while (parties[0].first > 0) {
            if (parties[0].first > parties[1].first) {
                ans += parties[0].second;
                parties[0].first--;
            }
            else if (parties[0].first == parties[1].first && parties[1].first == parties[2].first && n > 2) {
                ans += parties[0].second;
                parties[0].first--;
            }
            else if (parties[0].first == parties[1].first && n == 2) {
                ans += parties[0].second;
                parties[0].first--;
            }
            else {
                ans += parties[0].second;
                ans += parties[1].second;
                parties[0].first--;
                parties[1].first--;
            }
            sort(parties.rbegin(), parties.rend());
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
