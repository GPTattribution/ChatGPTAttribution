#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

struct Party {
    int count;
    char name;
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
}

string evacuate(int n, vector<Party>& parties) {
    priority_queue<Party> q;
    for (auto& p : parties) {
        q.push(p);
    }
    string res;
    while (!q.empty()) {
        Party p1 = q.top();
        q.pop();
        if (p1.count == 1) {
            res += p1.name;
            if (!q.empty()) {
                Party p2 = q.top();
                q.pop();
                res += p2.name;
                if (p2.count > 1) {
                    p2.count--;
                    q.push(p2);
                }
            }
        } else {
            res += p1.name;
            p1.count--;
            q.push(p1);
            if (!q.empty()) {
                Party p2 = q.top();
                q.pop();
                res += p2.name;
                p2.count--;
                q.push(p2);
            }
        }
        res += ' ';
    }
    return res;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;
        vector<Party> parties(n);
        for (int i = 0; i < n; i++) {
            parties[i].count = 0;
            parties[i].name = 'A' + i;
            cin >> parties[i].count;
        }
        cout << "Case #" << t << ": " << evacuate(n, parties) << endl;
    }
    return 0;
}
