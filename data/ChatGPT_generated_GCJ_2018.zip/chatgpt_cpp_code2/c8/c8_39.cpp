#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties(n);
        for (int j = 0; j < n; j++) {
            cin >> parties[j].first;
            parties[j].second = 'A' + j;
        }

        vector<string> evacuations;
        while (true) {
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());
            if (parties[0].first == 0) break;

            string curr_evacuation;
            curr_evacuation += parties[0].second;
            parties[0].first--;
            if (parties[1].first > 0 && parties[0].first <= parties[1].first) {
                curr_evacuation += parties[1].second;
                parties[1].first--;
            }
            evacuations.push_back(curr_evacuation);
        }

        cout << "Case #" << i << ": ";
        for (int j = 0; j < evacuations.size(); j++) {
            cout << evacuations[j] << " ";
        }
        cout << endl;
    }

    return 0;
}
