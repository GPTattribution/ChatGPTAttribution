#include <iostream>
#include <queue>
#include <vector>
#include <cstring>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;

        priority_queue<pair<int, char>> pq;
        int total = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            pq.push(make_pair(p, 'A' + j));
            total += p;
        }

        cout << "Case #" << i << ": ";
        while (!pq.empty()) {
            pair<int, char> p1 = pq.top();
            pq.pop();
            total--;
            cout << p1.second;
            p1.first--;
            if (p1.first > 0) pq.push(p1);

            if (pq.empty()) break;

            pair<int, char> p2 = pq.top();
            pq.pop();
            total--;
            cout << p2.second;
            p2.first--;
            if (p2.first > 0) pq.push(p2);

            if (p1.first > p2.first) {
                pq.push(p1);
            } else if (p2.first > p1.first) {
                pq.push(p2);
            }
        }
        cout << endl;
    }

    return 0;
}
