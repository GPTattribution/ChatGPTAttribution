#include<bits/stdc++.h>
using namespace std;

int main(){
    int t;
    cin>>t;

    for(int i=1;i<=t;i++){
        int n;
        cin>>n;

        vector<pair<int,char>> v;
        for(int j=0;j<n;j++){
            int p;
            cin>>p;
            v.push_back(make_pair(p,'A'+j));
        }

        cout<<"Case #"<<i<<": ";

        while(v.size()>0){
            sort(v.begin(),v.end());
            reverse(v.begin(),v.end());

            if(v[0].first>v[1].first+1){
                cout<<v[0].second<<v[0].second<<" ";
                v[0].first-=2;
            }
            else if(v[0].first>v[1].first){
                cout<<v[0].second<<v[1].second<<" ";
                v[0].first--;
                v[1].first--;
            }
            else{
                cout<<v[0].second<<" ";
                v[0].first--;
            }

            if(v[0].first==0) v.erase(v.begin());
            if(v.size()>0 && v[0].first==0) v.erase(v.begin()+1);
        }

        cout<<endl;
    }

    return 0;
}
