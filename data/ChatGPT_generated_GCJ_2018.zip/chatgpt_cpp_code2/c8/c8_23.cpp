#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            parties.push_back(make_pair(p, 'A' + j));
        }
        string plan;
        while (!parties.empty()) {
            sort(parties.rbegin(), parties.rend());
            if (parties[0].first > parties[1].first || parties.size() == 2) {
                plan += parties[0].second;
                parties[0].first--;
            }
            else {
                plan += parties[0].second;
                plan += parties[1].second;
                parties[0].first--;
                parties[1].first--;
            }
            if (parties[0].first == 0) {
                parties.erase(parties.begin());
            }
            if (parties.size() == 2 && parties[0].first == parties[1].first) {
                plan += parties[0].second;
                plan += parties[1].second;
                parties.clear();
            }
        }
        cout << "Case #" << i << ": " << plan << endl;
    }
    return 0;
}
