#include <iostream>
#include <vector>
#include <queue>

using namespace std;

struct Party {
    int size;
    char name;
    bool operator<(const Party& other) const {
        return size < other.size;
    }
};

string evacuate(int N, vector<int>& senators) {
    priority_queue<Party> q;
    for (int i = 0; i < N; i++) {
        q.push({senators[i], 'A' + i});
    }
    string plan;
    while (!q.empty()) {
        Party p1 = q.top();
        q.pop();
        Party p2 = q.top();
        q.pop();
        plan += p1.name;
        plan += p2.name;
        p1.size--;
        p2.size--;
        if (p1.size > 0) q.push(p1);
        if (p2.size > 0) q.push(p2);
    }
    return plan;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<int> senators(N);
        for (int i = 0; i < N; i++) {
            cin >> senators[i];
        }
        string plan = evacuate(N, senators);
        cout << "Case #" << t << ": " << plan << endl;
    }
    return 0;
}
