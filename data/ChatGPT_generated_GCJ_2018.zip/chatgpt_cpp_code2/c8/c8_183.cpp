#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;

        priority_queue<pair<int, char>> pq;  
        int total = 0;
        for (char ch = 'A'; ch < 'A' + n; ch++) {
            int p;
            cin >> p;
            pq.push({p, ch});
            total += p;
        }

        string ans;
        while (!pq.empty()) {
            auto [p1, ch1] = pq.top();
            pq.pop();
            total--;
            ans += ch1;

            if (!pq.empty()) {
                auto [p2, ch2] = pq.top();
                pq.pop();
                total--;
                ans += ch2;

                if (p2 > 1) {
                    pq.push({p2 - 1, ch2});
                }
            }

            if (p1 > 1) {
                pq.push({p1 - 1, ch1});
            }

            if (!pq.empty() && (pq.top().first > total / 2)) {
                auto [p3, ch3] = pq.top();
                pq.pop();
                total--;
                ans += ch3;

                if (p3 > 1) {
                    pq.push({p3 - 1, ch3});
                }

                pq.push({p1, ch1});
                if (!ans.empty() && ans.back() == ch1) {
                    ans.pop_back();
                }
                pq.push({p2, ch2});
                if (!ans.empty() && ans.back() == ch2) {
                    ans.pop_back();
                }
            }
        }

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
