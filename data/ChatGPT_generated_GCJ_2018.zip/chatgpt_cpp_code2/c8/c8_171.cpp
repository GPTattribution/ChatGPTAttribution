#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
};

struct CompareParty {
    bool operator()(Party const& p1, Party const& p2) {
        return p1.count < p2.count;
    }
};

vector<string> evacuate(vector<Party>& parties) {
    vector<string> plan;
    priority_queue<Party, vector<Party>, CompareParty> pq;
    for (Party& p : parties) {
        if (p.count > 0) {
            pq.push(p);
        }
    }
    while (!pq.empty()) {
        Party p1 = pq.top(); pq.pop();
        Party p2 = pq.top(); pq.pop();
        p1.count--;
        p2.count--;
        plan.push_back(string(1, p1.name) + string(1, p2.name));
        if (p1.count > 0) {
            pq.push(p1);
        }
        if (p2.count > 0) {
            pq.push(p2);
        }
    }
    return plan;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<Party> parties(N);
        for (int i = 0; i < N; i++) {
            parties[i].name = 'A' + i;
            cin >> parties[i].count;
        }
        vector<string> plan = evacuate(parties);
        cout << "Case #" << t << ":";
        for (string s : plan) {
            cout << " " << s;
        }
        cout << endl;
    }
    return 0;
}
