#include <iostream>
#include <vector>
#include <queue>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        priority_queue<pair<int, char>> q;
        int total = 0;

        for (char c = 'A'; c < 'A' + N; c++) {
            int p;
            cin >> p;
            q.push(make_pair(p, c));
            total += p;
        }

        vector<string> plan;
        while (!q.empty()) {
            int count = 2;
            string step = "";

            pair<int, char> p1 = q.top(); q.pop();
            step += p1.second;
            p1.first--;
            total--;
            if (p1.first > 0) {
                q.push(p1);
            } else {
                count--;
            }

            if (!q.empty()) {
                pair<int, char> p2 = q.top(); q.pop();
                if (p2.first > 1) {
                    step += p2.second;
                    p2.first--;
                    total--;
                    q.push(p2);
                } else {
                    count--;
                }
            } else {
                count--;
            }

            plan.push_back(step);

            if (total == 0) {
                break;
            }

            if (q.top().first > total / 2) {
                pair<int, char> p3 = q.top(); q.pop();
                if (p3.first > 1) {
                    step = "";
                    step += p3.second;
                    step += p3.second;
                    p3.first -= 2;
                    total -= 2;
                    q.push(p3);
                } else {
                    count--;
                }
                plan.push_back(step);
            }
        }

        cout << "Case #" << t << ":";
        for (const auto& s : plan) {
            cout << " " << s;
        }
        cout << endl;
    }

    return 0;
}
