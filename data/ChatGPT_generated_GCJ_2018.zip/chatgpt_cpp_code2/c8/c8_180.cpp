#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> q;
        int total = 0;
        for (char c = 'A'; c < 'A' + n; c++) {
            int p;
            cin >> p;
            q.push({p, c});
            total += p;
        }
        string ans = "";
        while (total > 0) {
            auto [p1, c1] = q.top(); q.pop();
            ans += c1;
            total--;
            if (q.empty()) {
                continue;
            }
            auto [p2, c2] = q.top(); q.pop();
            ans += c2;
            total--;
            if (p1 > 1) {
                q.push({p1 - 1, c1});
            }
            if (p2 > 1) {
                q.push({p2 - 1, c2});
            }
        }
        cout << "Case #" << i << ": " << ans << "\n";
    }
    return 0;
}
