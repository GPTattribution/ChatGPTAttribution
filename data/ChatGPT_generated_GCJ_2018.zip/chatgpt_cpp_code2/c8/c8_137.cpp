#include <iostream>
#include <queue>
#include <vector>
#include <cstring>
using namespace std;

const int MAXN = 26;

struct Party {
    char name;
    int count;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<Party> parties(N);
        for (int i = 0; i < N; i++) {
            parties[i].name = 'A' + i;
            cin >> parties[i].count;
        }
        priority_queue<Party> q;
        for (int i = 0; i < N; i++) {
            q.push(parties[i]);
        }
        cout << "Case #" << t << ":";
        while (!q.empty()) {
            Party p1 = q.top();
            q.pop();
            cout << " " << p1.name;
            if (p1.count > 1) {
                Party p2 = q.top();
                q.pop();
                cout << p2.name;
                p1.count--;
                p2.count--;
                if (p1.count > 0) {
                    q.push(p1);
                }
                if (p2.count > 0) {
                    q.push(p2);
                }
            } else if (p1.count == 1 && !q.empty()) {
                Party p2 = q.top();
                q.pop();
                cout << p2.name;
                p2.count--;
                if (p2.count > 0) {
                    q.push(p2);
                }
            }
        }
        cout << endl;
    }
    return 0;
}
