#include <iostream>
#include <vector>
#include <queue>

using namespace std;

struct Party {
    int count;
    char name;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

string evacuate(int n, vector<int>& parties) {
    priority_queue<Party> q;
    for (int i = 0; i < n; i++) {
        Party p;
        p.count = parties[i];
        p.name = 'A' + i;
        q.push(p);
    }
    string plan;
    while (!q.empty()) {
        Party p1 = q.top();
        q.pop();
        if (q.empty()) {
            plan += p1.name;
            break;
        }
        Party p2 = q.top();
        q.pop();
        plan += p1.name;
        plan += p2.name;
        p1.count--;
        p2.count--;
        if (p1.count > 0) {
            q.push(p1);
        }
        if (p2.count > 0) {
            q.push(p2);
        }
    }
    return plan;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<int> parties(n);
        int total = 0;
        for (int j = 0; j < n; j++) {
            cin >> parties[j];
            total += parties[j];
        }
        cout << "Case #" << i << ": " << evacuate(n, parties) << endl;
    }
    return 0;
}
