#include <iostream>
#include <vector>
#include <queue>

using namespace std;

struct Party {
    int count;
    char name;
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<Party> parties;
        int total = 0;
        for (int i = 0; i < N; i++) {
            int count;
            cin >> count;
            parties.push({count, 'A' + i});
            total += count;
        }
        cout << "Case #" << t << ":";
        while (!parties.empty()) {
            Party p1 = parties.top();
            parties.pop();
            char c1 = p1.name;
            p1.count--;
            total--;
            if (!parties.empty() && parties.top().count * 2 > total) {
                Party p2 = parties.top();
                parties.pop();
                char c2 = p2.name;
                p2.count--;
                total--;
                if (p1.count > 0) {
                    parties.push(p1);
                }
                if (p2.count > 0) {
                    parties.push(p2);
                }
                cout << " " << c1 << c2;
            } else {
                if (p1.count > 0) {
                    parties.push(p1);
                }
                cout << " " << c1;
            }
        }
        cout << endl;
    }
    return 0;
}
