#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<Party> pq;
        int total = 0;
        for (int i = 0; i < N; i++) {
            int count;
            cin >> count;
            pq.push({ 'A' + i, count });
            total += count;
        }
        cout << "Case #" << t << ":";
        while (!pq.empty()) {
            Party p1 = pq.top();
            pq.pop();
            total--;
            if (total == 0 || pq.empty()) {
                cout << " " << p1.name;
                continue;
            }
            Party p2 = pq.top();
            pq.pop();
            total--;
            cout << " " << p1.name << p2.name;
            if (p1.count > 1) {
                p1.count--;
                pq.push(p1);
            }
            if (p2.count > 1) {
                p2.count--;
                pq.push(p2);
            }
        }
        cout << endl;
    }
    return 0;
}
