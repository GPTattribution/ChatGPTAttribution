#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<pair<int, char>> parties(N);
        for (int i = 0; i < N; i++) {
            cin >> parties[i].first;
            parties[i].second = 'A' + i;
        }

        string plan;
        while (true) {
            sort(parties.rbegin(), parties.rend());
            if (parties[0].first == 0) {
                break;
            }

            if (parties[0].first == parties[1].first) {
                plan += parties[0].second;
                plan += parties[1].second;
                parties[0].first--;
                parties[1].first--;
            } else {
                plan += parties[0].second;
                parties[0].first--;
            }
        }

        cout << "Case #" << t << ": " << plan << endl;
    }

    return 0;
}
