#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Party {
    char name;
    int count;
    Party(char name, int count) : name(name), count(count) {}
};

string evacuate(int n, vector<Party>& parties) {
    string ans;
    while (true) {
        sort(parties.begin(), parties.end(), [](Party& a, Party& b) {
            return a.count > b.count;
        });

        if (parties.size() == 1) {
            for (int i = 0; i < parties[0].count; i++) {
                ans += parties[0].name;
                ans += " ";
            }
            break;
        }

        ans += parties[0].name;
        ans += parties[1].name;
        ans += " ";
        parties[0].count--;
        parties[1].count--;

        parties.erase(remove_if(parties.begin(), parties.end(), [](Party& p) {
            return p.count == 0;
        }), parties.end());

        if (parties.size() == 1) {
            for (int i = 0; i < parties[0].count; i++) {
                ans += parties[0].name;
                ans += " ";
            }
            break;
        }

        ans += parties[0].name;
        ans += parties[0].name;
        ans += " ";
        parties[0].count -= 2;

        parties.erase(remove_if(parties.begin(), parties.end(), [](Party& p) {
            return p.count == 0;
        }), parties.end());
    }
    return ans;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<Party> parties;
        for (int j = 0; j < n; j++) {
            int count;
            cin >> count;
            Party party('A' + j, count);
            parties.push_back(party);
        }
        string ans = evacuate(n, parties);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
