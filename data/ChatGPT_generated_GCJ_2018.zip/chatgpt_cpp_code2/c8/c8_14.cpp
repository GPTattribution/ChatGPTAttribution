#include <bits/stdc++.h>
using namespace std;

void solve(int t) {
    int n;
    cin >> n;
    vector<pair<int, char>> parties;
    for (int i = 0; i < n; i++) {
        int p;
        cin >> p;
        parties.push_back({p, 'A' + i});
    }
    string ans;
    while (true) {
        sort(parties.begin(), parties.end(), greater<pair<int, char>>());
        if (parties[0].first == 0) break;
        if (parties[0].first > parties[1].first || parties[0].first == parties[1].first && n == 2) {
            ans += parties[0].second;
            parties[0].first--;
        }
        else {
            ans += parties[0].second;
            ans += parties[1].second;
            parties[0].first--;
            parties[1].first--;
        }
    }
    cout << "Case #" << t << ": " << ans << endl;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        solve(i);
    }
    return 0;
}
