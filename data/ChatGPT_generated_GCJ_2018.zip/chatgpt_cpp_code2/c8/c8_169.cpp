#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;

struct Party {
    int count;
    char name;
    Party(int c, char n) : count(c), name(n) {}
};

struct EvacuationStep {
    char party1;
    char party2;
    EvacuationStep(char p1, char p2) : party1(p1), party2(p2) {}
};

struct PartyCountGreater {
    bool operator()(const Party& p1, const Party& p2) const {
        return p1.count < p2.count;
    }
};

vector<EvacuationStep> evacuate(vector<Party>& parties) {
    priority_queue<Party, vector<Party>, PartyCountGreater> pq;
    for (Party& p : parties) {
        pq.push(p);
    }

    // Create the evacuation plan
    vector<EvacuationStep> plan;
    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        Party p2 = pq.top();
        pq.pop();
        if (p1.count > p2.count) {
            plan.push_back(EvacuationStep(p1.name, p1.name));
            plan.push_back(EvacuationStep(p1.name, p2.name));
            p1.count -= 2;
            p2.count -= 1;
        } else {
            plan.push_back(EvacuationStep(p1.name, p2.name));
            p1.count -= 1;
            p2.count -= 1;
        }
        if (p1.count > 0) {
            pq.push(p1);
        }
        if (p2.count > 0) {
            pq.push(p2);
        }
    }

    return plan;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<Party> parties;
        int total_senators = 0;
        for (int i = 0; i < N; i++) {
            int count;
            cin >> count;
            parties.push_back(Party(count, 'A' + i));
            total_senators += count;
        }
        vector<EvacuationStep> plan = evacuate(parties);
        cout << "Case #" << t << ":";
        for (EvacuationStep& step : plan) {
            cout << " " << step.party1;
            if (step.party2 != 0) {
                cout << step.party2;
            }
        }
        cout << endl;
    }
    return 0;
}
