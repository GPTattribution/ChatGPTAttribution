#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int n;
        cin >> n;
        vector<pair<int, char>> senators(n);
        int total_senators = 0;
        for (int i = 0; i < n; ++i) {
            cin >> senators[i].first;
            senators[i].second = 'A' + i;
            total_senators += senators[i].first;
        }
        cout << "Case #" << t << ":";
        while (total_senators > 0) {
            sort(senators.rbegin(), senators.rend());
            if (total_senators == 3 && senators[0].first == 2 && senators[1].first == 1) {
                cout << " " << senators[0].second << senators[2].second;
                total_senators -= 2;
                senators[0].first -= 1;
                senators[2].first -= 1;
            } else if (senators[0].first >= senators[1].first + 2) {
                cout << " " << senators[0].second << senators[0].second;
                total_senators -= 2;
                senators[0].first -= 2;
            } else {
                cout << " " << senators[0].second << senators[1].second;
                total_senators -= 2;
                senators[0].first -= 1;
                senators[1].first -= 1;
            }
        }
        cout << endl;
    }
    return 0;
}
