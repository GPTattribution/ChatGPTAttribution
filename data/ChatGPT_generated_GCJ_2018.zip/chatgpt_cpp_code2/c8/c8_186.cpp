#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

struct Party {
    char name;
    int count;
};

bool operator<(const Party& a, const Party& b) {
    return a.count < b.count;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N;
        cin >> N;
        vector<Party> parties(N);
        for (int i = 0; i < N; ++i) {
            parties[i].name = 'A' + i;
            cin >> parties[i].count;
        }
        priority_queue<Party> q(parties.begin(), parties.end());
        cout << "Case #" << t << ":";
        while (!q.empty()) {
            Party p1 = q.top();
            q.pop();
            cout << " " << p1.name;
            --p1.count;
            if (!q.empty()) {
                Party p2 = q.top();
                q.pop();
                cout << p2.name;
                --p2.count;
                if (p2.count > 0) {
                    q.push(p2);
                }
            }
            if (p1.count > 0) {
                q.push(p1);
            }
        }
        cout << "\n";
    }
    return 0;
}
