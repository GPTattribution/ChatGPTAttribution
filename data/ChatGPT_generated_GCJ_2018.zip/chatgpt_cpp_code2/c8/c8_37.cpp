#include <iostream>
#include <queue>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<int> P(N);
        priority_queue<pair<int, int>> q;
        for (int i = 0; i < N; i++) {
            cin >> P[i];
            q.push(make_pair(P[i], i));
        }
        string ans;
        while (!q.empty()) {
            int p1 = q.top().second;
            q.pop();
            int p2 = -1;
            if (!q.empty() && q.top().first > 1) {
                p2 = q.top().second;
                q.pop();
            }
            if (p2 != -1) {
                ans += ('A' + p1);
                ans += ('A' + p2);
                P[p1]--;
                P[p2]--;
                if (P[p1] > 0) q.push(make_pair(P[p1], p1));
                if (P[p2] > 0) q.push(make_pair(P[p2], p2));
            } else {
                ans += ('A' + p1);
                P[p1]--;
                if (P[p1] > 0) q.push(make_pair(P[p1], p1));
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
