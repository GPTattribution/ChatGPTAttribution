#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        priority_queue<pair<int, int>> pq;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            pq.push({P, i});
        }

        cout << "Case #" << t << ": ";

        while (!pq.empty()) {
            pair<int, int> first = pq.top();
            pq.pop();

            if (pq.empty()) {
                for (int i = 0; i < first.first; i++) {
                    cout << char('A' + first.second);
                }
                break;
            }

            pair<int, int> second = pq.top();
            pq.pop();

            if (first.first > second.first + 1) {
                cout << char('A' + first.second) << char('A' + first.second) << " ";
                first.first -= 2;
                pq.push(first);
                pq.push(second);
            } else {
                cout << char('A' + first.second) << char('A' + second.second) << " ";
                first.first--;
                second.first--;
                if (first.first > 0) {
                    pq.push(first);
                }
                if (second.first > 0) {
                    pq.push(second);
                }
            }
        }

        cout << endl;
    }

    return 0;
}
