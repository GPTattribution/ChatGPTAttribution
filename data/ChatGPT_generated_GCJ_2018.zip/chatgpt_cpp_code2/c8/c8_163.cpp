#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

string evacuate(int n, vector<int> parties) {
    string plan;
    vector<pair<int, char>> senators;
    for (int i = 0; i < n; i++) {
        senators.push_back(make_pair(parties[i], 'A' + i));
    }
    while (true) {
        sort(senators.begin(), senators.end());
        if (senators[n - 1].first == 0) {
            break;
        }
        if (senators[n - 1].first > 1) {
            senators[n - 1].first -= 2;
            senators[n - 2].first -= 1;
            plan += senators[n - 1].second;
            plan += senators[n - 1].second;
            if (senators[n - 2].first == 0) {
                break;
            }
            plan += senators[n - 2].second;
        } else {
            senators[n - 1].first -= 1;
            senators[n - 2].first -= 1;
            plan += senators[n - 1].second;
            plan += senators[n - 2].second;
        }
    }
    return plan;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<int> parties(n);
        for (int j = 0; j < n; j++) {
            cin >> parties[j];
        }
        string plan = evacuate(n, parties);
        cout << "Case #" << i << ": " << plan << endl;
    }
    return 0;
}
