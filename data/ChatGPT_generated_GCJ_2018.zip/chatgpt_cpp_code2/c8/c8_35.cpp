#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;

        priority_queue<pair<int, int>> q;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            q.push(make_pair(p, j));
        }

        string ans;
        while (!q.empty()) {
            int p1 = q.top().second;
            q.pop();
            ans += 'A' + p1;

            if (!q.empty()) {
                int p2 = q.top().second;
                q.pop();
                ans += 'A' + p2;
                if (--q.top().first > 0) {
                    q.push(q.top());
                }
            }

            if (q.top().first == 0) {
                q.pop();
            }
        }

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
