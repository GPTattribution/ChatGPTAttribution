#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<pair<int, char>> pq;
        int total = 0;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            pq.push({P, 'A' + i});
            total += P;
        }
        string plan;
        while (!pq.empty()) {
            auto p1 = pq.top();
            pq.pop();
            auto p2 = pq.top();
            pq.pop();
            if (p1.first > 1) pq.push({p1.first - 1, p1.second});
            if (p2.first > 1) pq.push({p2.first - 1, p2.second});
            total -= 2;
            plan += p1.second;
            plan += p2.second;
            if (total > 0 && total / 2 < pq.top().first) {
                auto p3 = pq.top();
                pq.pop();
                if (p3.first > 1) pq.push({p3.first - 1, p3.second});
                total--;
                plan += p1.second;
            }
            plan += ' ';
        }
        cout << "Case #" << t << ": " << plan << endl;
    }
    return 0;
}
