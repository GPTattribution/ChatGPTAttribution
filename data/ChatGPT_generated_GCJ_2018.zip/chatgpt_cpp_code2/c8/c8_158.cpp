#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Party {
    char name;
    int count;
};

bool cmp(const Party& a, const Party& b) {
    return a.count > b.count;
}

vector<Party> read_parties(int n) {
    vector<Party> parties;
    for (int i = 0; i < n; i++) {
        Party p;
        p.name = 'A' + i;
        cin >> p.count;
        parties.push_back(p);
    }
    return parties;
}

string evacuate(vector<Party> parties) {
    string plan;
    while (true) {
        sort(parties.begin(), parties.end(), cmp);
        if (parties[0].count == 0) break;
        if (parties[0].count > parties[1].count || parties.size() == 2) {
            plan += parties[0].name;
            parties[0].count--;
        } else {
            plan += parties[0].name;
            plan += parties[1].name;
            parties[0].count--;
            parties[1].count--;
        }
        plan += " ";
    }
    plan.pop_back(); 
    return plan;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<Party> parties = read_parties(n);
        string plan = evacuate(parties);
        cout << "Case #" << i << ": " << plan << endl;
    }
    return 0;
}
