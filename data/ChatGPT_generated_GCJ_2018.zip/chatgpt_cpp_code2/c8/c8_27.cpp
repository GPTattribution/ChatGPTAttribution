#include <iostream>
#include <queue>
#include <string>
#include <vector>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        priority_queue<pair<int, char>> pq;
        int total_senators = 0;

        for (char party = 'A'; party < 'A' + N; party++) {
            int senators;
            cin >> senators;
            pq.push({senators, party});
            total_senators += senators;
        }

        cout << "Case #" << t << ": ";

        while (!pq.empty()) {
            auto p1 = pq.top(); pq.pop();
            auto p2 = pq.top(); pq.pop();

            int s1 = p1.first;
            char party1 = p1.second;
            string evac = "";
            evac += party1;
            s1--;

            if (s1 > 0) {
                pq.push({s1, party1});
            }

            if (!pq.empty()) {
                int s2 = p2.first;
                char party2 = p2.second;
                evac += party2;
                s2--;

                if (s2 > 0) {
                    pq.push({s2, party2});
                }
            }

            cout << evac << " ";
        }

        cout << endl;
    }

    return 0;
}
