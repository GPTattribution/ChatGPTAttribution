#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<pair<int, int>> pq;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            pq.push({P, i});
        }
        cout << "Case #" << t << ":";
        while (!pq.empty()) {
            int p1 = pq.top().second;
            pq.pop();
            int p2 = -1;
            if (!pq.empty() && pq.top().first > (N - 1) / 2) {
                p2 = pq.top().second;
                pq.pop();
            }
            if (p2 != -1) {
                pq.push({p2, p2});
            }
            cout << " " << (char)('A' + p1);
            if (p2 != -1) {
                cout << (char)('A' + p2);
            }
        }
        cout << "\n";
    }
    return 0;
}
