#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

struct Party {
    char name;
    int count;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

vector<Party> parties;

void evacuate(int t) {
    cout << "Case #" << t << ": ";
    priority_queue<Party> max_heap;
    for (int i = 0; i < parties.size(); i++) {
        max_heap.push(parties[i]);
    }
    while (!max_heap.empty()) {
        Party first = max_heap.top();
        max_heap.pop();
        Party second = max_heap.empty() ? Party{'X', 0} : max_heap.top();
        max_heap.pop();
        if (first.count > 1) {
            cout << first.name << first.name << " ";
            first.count -= 2;
        } else {
            cout << first.name << " ";
            first.count--;
        }
        if (second.count > 1) {
            max_heap.push(second);
            second.count -= 2;
        } else if (second.count == 1) {
            second.count--;
        }
        if (first.count > 0) {
            max_heap.push(first);
        }
    }
    cout << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        parties.clear();
        for (int i = 0; i < N; i++) {
            Party party;
            party.name = 'A' + i;
            cin >> party.count;
            parties.push_back(party);
        }
        evacuate(t);
    }
    return 0;
}
