#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties(N);
        int total_senators = 0;
        for (int i = 0; i < N; i++) {
            cin >> parties[i].first;
            parties[i].second = 'A' + i;
            total_senators += parties[i].first;
        }
        string plan;
        while (total_senators > 0) {
            sort(parties.rbegin(), parties.rend());
            if (parties[0].first > 0) {
                plan += parties[0].second;
                parties[0].first--;
                total_senators--;
            }
            if (parties[1].first > 0) {
                plan += parties[1].second;
                parties[1].first--;
                total_senators--;
            }
            if (parties[0].first < parties[1].first) {
                swap(parties[0], parties[1]);
            }
        }
        cout << "Case #" << t << ": " << plan << endl;
    }
    return 0;
}
