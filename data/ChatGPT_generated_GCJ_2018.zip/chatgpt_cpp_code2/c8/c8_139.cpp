#include <iostream>
#include <queue>
#include <vector>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<pair<int, char>> q; 
        int total = 0;
        for (int i = 0; i < N; i++) {
            int count;
            cin >> count;
            q.push(make_pair(count, 'A' + i));
            total += count;
        }
        cout << "Case #" << t << ":";
        while (!q.empty()) {
            vector<pair<int, char>> evacuated;
            int remaining = total;
            for (int i = 0; i < 2 && !q.empty(); i++) {
                int count = q.top().first;
                char party = q.top().second;
                q.pop();
                if (count > 1) {
                    evacuated.push_back(make_pair(count - 1, party));
                    remaining--;
                }
                else if (!evacuated.empty() && evacuated.back().second == party) {
                    evacuated.back().first++;
                    remaining--;
                }
                else {
                    evacuated.push_back(make_pair(1, party));
                    remaining--;
                }
            }
            total = remaining;
            for (const auto& p : evacuated) {
                for (int i = 0; i < p.first; i++) {
                    cout << " " << p.second;
                }
            }
        }
        cout << endl;
    }
    return 0;
}
