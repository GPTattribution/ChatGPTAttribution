#include <iostream>
#include <queue>
#include <string>
#include <vector>

using namespace std;

struct Party {
    char name;
    int count;
    Party(char n, int c) : name(n), count(c) {}
};

struct Evacuation {
    string steps;
    vector<Party> remaining;
    Evacuation(string s, vector<Party> r) : steps(s), remaining(r) {}
};

bool operator<(const Evacuation& e1, const Evacuation& e2) {
    return e1.steps.size() > e2.steps.size();
}

string evacuate(vector<Party>& parties) {
    priority_queue<Evacuation> q;
    q.push(Evacuation("", parties));
    while (!q.empty()) {
        Evacuation e = q.top();
        q.pop();
        if (e.remaining.size() == 0) {
            return e.steps;
        }
        for (int i = 0; i < e.remaining.size(); i++) {
            Party p1 = e.remaining[i];
            if (p1.count == 0) {
                continue;
            }
            for (int j = 0; j < e.remaining.size(); j++) {
                if (i == j) {
                    continue;
                }
                Party p2 = e.remaining[j];
                if (p2.count == 0) {
                    continue;
                }
                vector<Party> newRemaining = e.remaining;
                newRemaining[i].count--;
                newRemaining[j].count--;
                bool valid = true;
                for (Party p : newRemaining) {
                    if (2 * p.count > parties.size()) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    string newSteps = e.steps + p1.name + p2.name + " ";
                    q.push(Evacuation(newSteps, newRemaining));
                }
            }
            vector<Party> newRemaining = e.remaining;
            newRemaining[i].count--;
            bool valid = true;
            for (Party p : newRemaining) {
                if (2 * p.count > parties.size()) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                string newSteps = e.steps + p1.name + " ";
                q.push(Evacuation(newSteps, newRemaining));
            }
        }
    }
    return "";
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<Party> parties;
        int total = 0;
        for (int i = 0; i < N; i++) {
            int count;
            cin >> count;
            parties.push_back(Party('A' + i, count));
            total += count;
        }
        cout << "Case #" << t << ": " << evacuate(parties) << endl;
    }
    return 0;
}
