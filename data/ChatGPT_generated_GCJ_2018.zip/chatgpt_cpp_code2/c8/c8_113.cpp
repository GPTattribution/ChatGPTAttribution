#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;

        priority_queue<pair<int, char>> pq;
        for (char c = 'A'; c < 'A' + n; c++) {
            int p;
            cin >> p;
            pq.push({p, c});
        }

        cout << "Case #" << i << ": ";
        while (!pq.empty()) {
            char c1 = pq.top().second;
            pq.pop();

            if (pq.empty()) {
                cout << c1 << endl;
                break;
            }

            char c2 = pq.top().second;
            pq.pop();

            cout << c1 << c2 << " ";

            if (--pq.top().first > 0) {
                pq.push(pq.top());
            }
        }
    }

    return 0;
}
