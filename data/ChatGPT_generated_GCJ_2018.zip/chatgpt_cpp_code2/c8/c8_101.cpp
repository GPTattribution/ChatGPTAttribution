#include <iostream>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            parties.push_back({P, 'A' + i});
        }
        string plan;
        while (true) {
            sort(parties.begin(), parties.end());
            reverse(parties.begin(), parties.end());
            if (parties[0].first == 0) {
                break;
            }
            if (parties[0].first > parties[1].first || parties[1].first == 0) {
                parties[0].first -= 2;
                plan += parties[0].second;
                plan += parties[0].second;
            } else {
                parties[0].first -= 1;
                parties[1].first -= 1;
                plan += parties[0].second;
                plan += parties[1].second;
            }
            plan += " "; 
        }
        cout << "Case #" << t << ": " << plan << endl;
    }
    return 0;
}
