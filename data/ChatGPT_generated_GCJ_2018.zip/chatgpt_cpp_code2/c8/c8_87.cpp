#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties(n);
        int total_senators = 0;
        for (int j = 0; j < n; j++) {
            cin >> parties[j].first;
            parties[j].second = 'A' + j;
            total_senators += parties[j].first;
        }
        cout << "Case #" << i << ": ";
        while (total_senators > 0) {
            sort(parties.begin(), parties.end());
            reverse(parties.begin(), parties.end());
            char p1 = parties[0].second;
            parties[0].first--;
            total_senators--;
            if (parties[0].first * 2 > total_senators) {
                char p2 = parties[1].second;
                parties[1].first--;
                total_senators--;
                cout << p1 << p2 << " ";
            } else {
                cout << p1 << " ";
            }
        }
        cout << endl;
    }
    return 0;
}
