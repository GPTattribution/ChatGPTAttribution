#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> pq;
        int total = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            total += p;
            pq.push(make_pair(p, 'A' + j));
        }
        cout << "Case #" << i << ": ";
        while (total > 0) {
            pair<int, char> p1 = pq.top();
            pq.pop();
            total--;
            cout << p1.second;
            if (pq.empty()) continue;
            pair<int, char> p2 = pq.top();
            pq.pop();
            total--;
            cout << p2.second;
            if (p1.first > 1) pq.push(make_pair(p1.first - 1, p1.second));
            if (p2.first > 1) pq.push(make_pair(p2.first - 1, p2.second));
            if (pq.top().first * 2 > total) { 
                pair<int, char> p3 = pq.top();
                pq.pop();
                total--;
                cout << p3.second;
                if (p3.first > 1) pq.push(make_pair(p3.first - 1, p3.second));
            }
            cout << " ";
        }
        cout << endl;
    }
    return 0;
}
