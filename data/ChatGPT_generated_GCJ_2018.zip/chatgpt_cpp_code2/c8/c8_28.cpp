#include <iostream>
#include <queue>
#include <vector>

using namespace std;

struct Party {
    char name;
    int count;
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
}

vector<string> evacuation_plan(int n, vector<Party>& parties) {
    priority_queue<Party> pq;
    for (int i = 0; i < n; i++) {
        pq.push(parties[i]);
    }

    vector<string> plan;
    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();

        Party p2 = Party{' ', 0};
        if (!pq.empty()) {
            p2 = pq.top();
            pq.pop();
        }

        plan.push_back(string(1, p1.name));
        p1.count--;
        if (p1.count > 0) {
            pq.push(p1);
        }

        if (p2.count > 0) {
            plan.back() += string(1, p2.name);
            p2.count--;
            if (p2.count > 0) {
                pq.push(p2);
            }
        }
    }

    return plan;
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;

        vector<Party> parties(n);
        for (int j = 0; j < n; j++) {
            parties[j] = Party{'A' + j, 0};
            cin >> parties[j].count;
        }

        vector<string> plan = evacuation_plan(n, parties);

        cout << "Case #" << i << ": ";
        for (string step : plan) {
            cout << step << " ";
        }
        cout << endl;
    }

    return 0;
}
