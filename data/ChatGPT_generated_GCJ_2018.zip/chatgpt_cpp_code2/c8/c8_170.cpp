#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int caseNum = 1; caseNum <= t; caseNum++) {
        int n;
        cin >> n;

        vector<pair<int, char>> parties(n);
        for (int i = 0; i < n; i++) {
            cin >> parties[i].first;
            parties[i].second = 'A' + i;
        }

        vector<string> plan;

        while (true) {
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());

            if (parties[0].first == 0) {
                break;
            }

            string step;
            int p1 = parties[0].second - 'A';
            parties[0].first--;
            step += parties[0].second;

            if (parties[1].first > parties[0].first || parties[1].first == 0) {
                p1 = -1;
                for (int i = 2; i < n; i++) {
                    if (parties[i].first > 0) {
                        p1 = i;
                        break;
                    }
                }
                parties[p1].first--;
                step += parties[p1].second;
            } else {
                parties[1].first--;
                step += parties[1].second;
            }

            plan.push_back(step);
        }

        cout << "Case #" << caseNum << ": ";
        for (const string& step : plan) {
            cout << step << " ";
        }
        cout << endl;
    }

    return 0;
}
