#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

using senator = pair<char, int>;

struct cmp {
    bool operator()(const senator& s1, const senator& s2) {
        return s1.second < s2.second;
    }
};

void print_plan(int case_num, const vector<string>& plan) {
    cout << "Case #" << case_num << ": ";
    for (const auto& instr : plan) {
        cout << instr << " ";
    }
    cout << endl;
}

void solve_case(int case_num) {
    int n;
    cin >> n;

    vector<senator> senators;
    for (int i = 0; i < n; i++) {
        int count;
        cin >> count;
        senators.push_back(make_pair('A' + i, count));
    }

    priority_queue<senator, vector<senator>, cmp> pq(senators.begin(), senators.end());

    vector<string> plan;

    while (!pq.empty()) {
        senator s1 = pq.top();
        pq.pop();
        senator s2 = pq.empty() ? make_pair('X', 0) : pq.top();
        pq.pop();

        string instr;
        instr.push_back(s1.first);
        s1.second--;
        if (s2.second > 0) {
            instr.push_back(s2.first);
            s2.second--;
            pq.push(s2);
        }
        if (s1.second > 0) {
            pq.push(s1);
        }
        plan.push_back(instr);
    }

    print_plan(case_num, plan);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        solve_case(i);
    }
    return 0;
}
