#include <bits/stdc++.h>
using namespace std;

const int N = 26;

int n, t, a[N];

void evacuate() {
    priority_queue<pair<int, char>> pq;
    for (char c = 'A'; c < 'A' + n; ++c) {
        if (a[c - 'A'] > 0) {
            pq.push({a[c - 'A'], c});
        }
    }
    string ans;
    while (!pq.empty()) {
        auto p1 = pq.top(); pq.pop();
        if (pq.empty()) {
            ans += p1.second;
            break;
        }
        auto p2 = pq.top(); pq.pop();
        ans += p1.second;
        ans += p2.second;
        if (--p1.first > 0) {
            pq.push(p1);
        }
        if (--p2.first > 0) {
            pq.push(p2);
        }
    }
    cout << "Case #" << t << ": " << ans << endl;
}

int main() {
    int T;
    cin >> T;
    for (t = 1; t <= T; ++t) {
        cin >> n;
        for (int i = 0; i < n; ++i) {
            cin >> a[i];
        }
        evacuate();
    }
    return 0;
}
