#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>
#include <sstream>

using namespace std;

struct Party {
    char name;
    int count;

    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

void evacuate(int case_num, vector<Party>& parties) {
    priority_queue<Party> pq;
    for (Party& party : parties) {
        pq.push(party);
    }

    cout << "Case #" << case_num << ":";
    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        p1.count--;
        if (pq.empty() || pq.top().count * 2 <= parties.size() - 1) {
            cout << " " << p1.name;
        } else {
            Party p2 = pq.top();
            pq.pop();
            p2.count--;
            cout << " " << p1.name << p2.name;
            if (p2.count > 0) {
                pq.push(p2);
            }
        }
        if (p1.count > 0) {
            pq.push(p1);
        }
    }
    cout << endl;
}

int main() {
    int T;
    cin >> T;

    for (int case_num = 1; case_num <= T; case_num++) {
        int N;
        cin >> N;

        vector<Party> parties;
        int total = 0;
        for (int i = 0; i < N; i++) {
            int count;
            cin >> count;
            parties.push_back({ 'A' + i, count });
            total += count;
        }

        evacuate(case_num, parties);
    }

    return 0;
}
