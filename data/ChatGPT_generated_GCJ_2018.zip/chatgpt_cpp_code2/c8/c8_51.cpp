#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

struct Party {
    char name;
    int count;
    Party(char name, int count) : name(name), count(count) {}
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

void evacuate(int t, int n, vector<int>& senators) {
    priority_queue<Party> pq;
    for (int i = 0; i < n; i++) {
        pq.push(Party('A' + i, senators[i]));
    }

    string plan;
    while (!pq.empty()) {
        Party first = pq.top();
        pq.pop();
        plan += first.name;
        if (first.count > 1) {
            pq.push(Party(first.name, first.count - 1));
        }

        if (pq.empty()) {
            break;
        }

        Party second = pq.top();
        pq.pop();
        plan += second.name;
        if (second.count > 1) {
            pq.push(Party(second.name, second.count - 1));
        }
    }

    cout << "Case #" << t << ": " << plan << endl;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;

        vector<int> senators(n);
        int total = 0;
        for (int i = 0; i < n; i++) {
            cin >> senators[i];
            total += senators[i];
        }

        evacuate(t, n, senators);
    }

    return 0;
}
