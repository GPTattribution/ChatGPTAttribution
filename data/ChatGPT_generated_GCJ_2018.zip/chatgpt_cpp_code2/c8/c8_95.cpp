#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
};

struct PartyComparator {
    bool operator()(const Party& a, const Party& b) const {
        return a.count < b.count;
    }
};

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        priority_queue<Party, vector<Party>, PartyComparator> parties;

        for (int i = 0; i < N; i++) {
            int count;
            cin >> count;
            parties.push({(char)('A' + i), count});
        }

        vector<string> plan;

        while (!parties.empty()) {
            Party p1 = parties.top();
            parties.pop();

            if (p1.count > 1) {
                plan.push_back(string(1, p1.name));
                parties.push({p1.name, p1.count - 1});
            }

            if (!parties.empty()) {
                Party p2 = parties.top();
                parties.pop();

                if (p2.count > 1) {
                    plan.push_back(string(1, p1.name) + string(1, p2.name));
                    parties.push({p2.name, p2.count - 1});
                }
                else {
                    plan.push_back(string(1, p1.name));
                }
            }
            else {
                plan.push_back(string(1, p1.name));
            }
        }

        cout << "Case #" << t << ": ";
        for (const string& instruction : plan) {
            cout << instruction << " ";
        }
        cout << endl;
    }

    return 0;
}
