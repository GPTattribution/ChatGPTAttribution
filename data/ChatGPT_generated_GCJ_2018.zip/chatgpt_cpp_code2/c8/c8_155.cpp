#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

struct cmp {
    bool operator()(const pair<int, char>& a, const pair<int, char>& b) {
        return a.first < b.first;
    }
};

void evacuate(priority_queue<pair<int, char>, vector<pair<int, char>>, cmp>& q, char p1, char p2 = '\0') {
    cout << p1 << p2 << " ";
    if (p2 == '\0') {
        q.push({q.top().first - 1, p1});
    } else {
        q.push({q.top().first - 1, p1});
        q.push({q.top().first - 1, p2});
    }
    q.pop();
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<pair<int, char>, vector<pair<int, char>>, cmp> q;
        int total_senators = 0;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            q.push({P, 'A' + i});
            total_senators += P;
        }
        cout << "Case #" << t << ": ";
        while (!q.empty()) {
            if (q.size() == 1 && q.top().first * 2 > total_senators) {
                evacuate(q, q.top().second);
            } else {
                char p1 = q.top().second;
                q.pop();
                char p2 = q.top().second;
                q.pop();
                evacuate(q, p1, p2);
            }
        }
        cout << endl;
    }
    return 0;
}
