#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for(int i=1; i<=t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int,char>> pq;
        for(int j=0; j<n; j++) {
            int x;
            cin >> x;
            pq.push({x, 'A'+j});
        }
        string ans = "";
        while(!pq.empty()) {
            auto p1 = pq.top(); pq.pop();
            auto p2 = pq.top(); pq.pop();
            ans += p1.second;
            p1.first--;
            if(p2.first > 0) {
                ans += p2.second;
                p2.first--;
            }
            if(p1.first > 0) pq.push(p1);
            if(p2.first > 0) pq.push(p2);
            ans += " ";
        }
        ans.pop_back();
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
