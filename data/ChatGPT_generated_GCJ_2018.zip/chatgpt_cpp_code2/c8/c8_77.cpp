#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

struct Party {
    char name;
    int count;
    Party(char name, int count) : name(name), count(count) {}
};

struct PartyCmp {
    bool operator()(const Party& a, const Party& b) const {
        return a.count < b.count;
    }
};

string generatePlan(priority_queue<Party, vector<Party>, PartyCmp>& q) {
    string plan;
    while (!q.empty()) {
        Party a = q.top();
        q.pop();
        if (!q.empty()) {
            Party b = q.top();
            q.pop();
            plan += a.name;
            plan += b.name;
            a.count--;
            b.count--;
            if (a.count > 0) q.push(a);
            if (b.count > 0) q.push(b);
        } else {
            plan += a.name;
            a.count--;
            if (a.count > 0) q.push(a);
        }
        plan += " ";
    }
    return plan;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<Party, vector<Party>, PartyCmp> q;
        for (char c = 'A'; c < 'A' + N; c++) {
            int count;
            cin >> count;
            q.push(Party(c, count));
        }
        string plan = generatePlan(q);
        cout << "Case #" << t << ": " << plan << endl;
    }
    return 0;
}
