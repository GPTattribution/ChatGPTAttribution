#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> senators;
        int total = 0;
        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            senators.push_back(make_pair(P, 'A' + i));
            total += P;
        }
        string plan;
        while (total > 0) {
            sort(senators.begin(), senators.end());
            reverse(senators.begin(), senators.end());
            if (senators[0].first > 1 && senators[1].first > 0) {
                plan += senators[0].second;
                plan += senators[1].second;
                senators[0].first--;
                senators[1].first--;
                total -= 2;
            } else {
                plan += senators[0].second;
                senators[0].first--;
                total--;
            }
            plan += " ";
        }
        cout << "Case #" << t << ": " << plan << endl;
    }
    return 0;
}
