#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

struct Party {
    int count;
    char name;
    Party(int count, char name) : count(count), name(name) {}
};

struct EvacuationStep {
    char party1, party2;
    EvacuationStep(char party1, char party2) : party1(party1), party2(party2) {}
};

bool operator<(const Party& p1, const Party& p2) {
    return p1.count < p2.count;
}

vector<EvacuationStep> evacuate(vector<Party>& parties) {
    vector<EvacuationStep> plan;
    priority_queue<Party> q;
    for (Party& party : parties) {
        q.push(party);
    }
    while (!q.empty()) {
        Party p1 = q.top();
        q.pop();
        if (q.empty()) {
            plan.push_back(EvacuationStep(p1.name, ' '));
            p1.count--;
        } else {
            Party p2 = q.top();
            q.pop();
            plan.push_back(EvacuationStep(p1.name, p2.name));
            p1.count--;
            p2.count--;
            if (p2.count > 0) {
                q.push(p2);
            }
        }
        if (p1.count > 0) {
            q.push(p1);
        }
    }
    return plan;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<Party> parties;
        int total = 0;
        for (int i = 0; i < N; i++) {
            int count;
            cin >> count;
            parties.emplace_back(count, 'A' + i);
            total += count;
        }
        vector<EvacuationStep> plan = evacuate(parties);
        cout << "Case #" << t << ": ";
        for (const EvacuationStep& step : plan) {
            if (step.party2 == ' ') {
                cout << step.party1 << " ";
            } else {
                cout << step.party1 << step.party2 << " ";
            }
        }
        cout << endl;
    }
    return 0;
}
