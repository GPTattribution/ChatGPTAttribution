#include <iostream>
#include <vector>
#include <queue>
#include <string>

using namespace std;

struct Party {
    int count;
    char name;
};

struct PartyComparator {
    bool operator()(Party p1, Party p2) const {
        return p1.count < p2.count;
    }
};

void evacuate(int caseNum, vector<Party>& parties) {
    priority_queue<Party, vector<Party>, PartyComparator> pq;
    for (Party p : parties) {
        pq.push(p);
    }

    string plan;

    while (!pq.empty()) {
        Party p1 = pq.top();
        pq.pop();
        p1.count--;
        plan += p1.name;

        if (!pq.empty()) {
            Party p2 = pq.top();
            pq.pop();
            p2.count--;
            plan += p2.name;
            if (p2.count > 0) {
                pq.push(p2);
            }
        }

        if (p1.count > 0) {
            pq.push(p1);
        }
    }

    cout << "Case #" << caseNum << ": " << plan << endl;
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        int N;
        cin >> N;

        vector<Party> parties;
        for (int j = 0; j < N; j++) {
            Party p;
            p.name = 'A' + j;
            cin >> p.count;
            parties.push_back(p);
        }

        evacuate(i, parties);
    }

    return 0;
}
