#include <iostream>
#include <queue>
#include <vector>
#include <cstring>
using namespace std;

const int MAXN = 26;
int p[MAXN+1];

void solve(int t) {
    int n;
    cin >> n;
    priority_queue<pair<int, int>> pq; 
    for (int i = 0; i < n; i++) {
        cin >> p[i];
        if (p[i] > 0)
            pq.push(make_pair(p[i], i));
    }

    cout << "Case #" << t << ": ";
    while (!pq.empty()) {
        pair<int, int> a = pq.top();
        pq.pop();
        if (pq.empty()) {
            for (int i = 0; i < a.first; i++)
                cout << (char)('A'+a.second) << " ";
        } else {
            pair<int, int> b = pq.top();
            pq.pop();
            cout << (char)('A'+a.second) << (char)('A'+b.second) << " ";
            a.first--;
            b.first--;
            if (a.first > 0)
                pq.push(a);
            if (b.first > 0)
                pq.push(b);
        }
    }
    cout << endl;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++)
        solve(i);
    return 0;
}
