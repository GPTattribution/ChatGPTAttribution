#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

string evacuation_plan(int N, vector<int>& parties) {
    string plan = "";

    priority_queue<pair<int, char>> pq;
    for (int i = 0; i < N; i++) {
        pq.push(make_pair(parties[i], 'A' + i));
    }

    while (!pq.empty()) {
        int p1_size = pq.top().first;
        char p1_name = pq.top().second;
        pq.pop();
        int p2_size = pq.top().first;
        char p2_name = pq.top().second;
        pq.pop();

        if (p1_size > 1) {
            pq.push(make_pair(p1_size - 1, p1_name));
        }
        if (p2_size > 1) {
            pq.push(make_pair(p2_size - 1, p2_name));
        }
        plan += p1_name;
        plan += p2_name;
        plan += " ";
    }

    return plan;
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        int N;
        cin >> N;

        vector<int> parties(N);
        for (int j = 0; j < N; j++) {
            cin >> parties[j];
        }

        string plan = evacuation_plan(N, parties);
        cout << "Case #" << i << ": " << plan << endl;
    }

    return 0;
}
