#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <cstring>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> pq;
        int total = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            pq.push(make_pair(p, 'A' + j));
            total += p;
        }
        string ans;
        while (!pq.empty()) {
            pair<int, char> first = pq.top();
            pq.pop();
            ans += first.second;
            first.first--;
            total--;
            if (!pq.empty() && first.first * 2 > total) {
                pair<int, char> second = pq.top();
                pq.pop();
                ans += second.second;
                second.first--;
                total--;
                if (second.first > 0) pq.push(second);
            }
            if (first.first > 0) pq.push(first);
            ans += ' ';
        }
        ans.pop_back();
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
