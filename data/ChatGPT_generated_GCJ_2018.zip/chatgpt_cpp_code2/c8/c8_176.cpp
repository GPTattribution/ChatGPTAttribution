#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties(N);
        for (int i = 0; i < N; ++i) {
            int P;
            cin >> P;
            parties[i] = make_pair(P, 'A' + i);
        }
        sort(parties.rbegin(), parties.rend()); 
        cout << "Case #" << t << ": ";
        while (parties[0].first > parties[1].first) {
            cout << parties[0].second << parties[0].second << " ";
            --parties[0].first;
        }
        for (int i = 2; i < N; ++i) {
            while (parties[i].first > 0) {
                cout << parties[i].second << " ";
                --parties[i].first;
            }
        }
        while (parties[0].first > 0 || parties[1].first > 0) {
            if (parties[0].first > 0) {
                cout << parties[0].second;
                --parties[0].first;
            }
            if (parties[1].first > 0) {
                cout << parties[1].second;
                --parties[1].first;
            }
            cout << " ";
        }
        cout << endl;
    }
    return 0;
}
