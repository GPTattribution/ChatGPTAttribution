#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;
        vector<int> parties(n);
        for (int i = 0; i < n; i++) {
            cin >> parties[i];
        }
        cout << "Case #" << t << ": ";
        while (true) {
            int max_index = max_element(parties.begin(), parties.end()) - parties.begin();
            int second_max_index = -1;
            for (int i = 0; i < n; i++) {
                if (i != max_index && (second_max_index == -1 || parties[i] > parties[second_max_index])) {
                    second_max_index = i;
                }
            }
            if (parties[max_index] == 0) {
                break;
            }
            cout << char('A' + max_index);
            parties[max_index]--;
            if (second_max_index != -1 && parties[second_max_index] > 0 && parties[second_max_index] > parties[max_index] - 2) {
                cout << char('A' + second_max_index);
                parties[second_max_index]--;
            }
            cout << " ";
        }
        cout << endl;
    }
    return 0;
}
