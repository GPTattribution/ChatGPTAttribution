#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;

struct Party {
    int count;
    char name;
    bool operator < (const Party& other) const {
        return count < other.count;
    }
};

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; ++case_num) {
        int n;
        cin >> n;
        vector<Party> parties(n);
        int total_senators = 0;
        for (int i = 0; i < n; ++i) {
            cin >> parties[i].count;
            parties[i].name = 'A' + i;
            total_senators += parties[i].count;
        }
        vector<string> plan;
        while (total_senators > 0) {
            sort(parties.rbegin(), parties.rend());
            if (parties[0].count > 0) {
                parties[0].count -= 1;
                total_senators -= 1;
                plan.push_back(string(1, parties[0].name));
            }
            if (total_senators == 0) {
                break;
            }
            sort(parties.rbegin(), parties.rend());
            if (parties[0].count > 0) {
                parties[0].count -= 1;
                total_senators -= 1;
                plan.push_back(string(1, parties[0].name));
            }
            if (total_senators == 0) {
                break;
            }
            sort(parties.rbegin(), parties.rend());
            if (parties[0].count > 0 && parties[1].count > 0) {
                parties[0].count -= 1;
                parties[1].count -= 1;
                total_senators -= 2;
                plan.push_back(string(1, parties[0].name) + string(1, parties[1].name));
            } else {
                parties[0].count -= 2;
                total_senators -= 2;
                plan.push_back(string(1, parties[0].name) + string(1, parties[0].name));
            }
        }
        cout << "Case #" << case_num << ":";
        for (const auto& instr : plan) {
            cout << " " << instr;
        }
        cout << endl;
    }
    return 0;
}
