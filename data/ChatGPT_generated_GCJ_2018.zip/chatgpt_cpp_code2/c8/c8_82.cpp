#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <cstring>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<pair<int, char>> pq;
        int total = 0;
        for (int i = 0; i < N; i++) {
            int Pi;
            cin >> Pi;
            total += Pi;
            pq.push({ Pi, 'A' + i });
        }
        vector<string> plan;
        while (!pq.empty()) {
            auto [cnt1, p1] = pq.top();
            pq.pop();
            total -= cnt1;
            if (total <= cnt1 * 2) {
                plan.push_back(string(1, p1));
            } else {
                auto [cnt2, p2] = pq.top();
                pq.pop();
                total -= cnt2;
                plan.push_back(string(1, p1) + string(1, p2));
                if (cnt2 > 1) {
                    pq.push({ cnt2 - 1, p2 });
                    total++;
                }
            }
            if (cnt1 > 1) {
                pq.push({ cnt1 - 1, p1 });
                total++;
            }
        }
        reverse(plan.begin(), plan.end());
        cout << "Case #" << t << ": ";
        for (const auto& p : plan) {
            cout << p << " ";
        }
        cout << endl;
    }
    return 0;
}
