#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N;
        cin >> N;
        priority_queue<pair<int, char>> q;
        int total = 0;
        for (int i = 0; i < N; ++i) {
            int p;
            cin >> p;
            q.push({p, 'A' + i});
            total += p;
        }
        cout << "Case #" << t << ":";
        while (!q.empty()) {
            auto [count1, party1] = q.top();
            q.pop();
            if (q.empty()) {
                cout << " " << party1;
                break;
            }
            auto [count2, party2] = q.top();
            q.pop();
            if (count1 > count2 + 1) {
                cout << " " << party1 << party1;
                q.push({count1 - 2, party1});
                q.push({count2, party2});
            } else {
                cout << " " << party1 << party2;
                q.push({count1 - 1, party1});
                q.push({count2 - 1, party2});
            }
        }
        cout << endl;
    }
    return 0;
}
