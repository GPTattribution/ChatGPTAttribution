#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        priority_queue<pair<int, char>> pq;

        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            pq.push(make_pair(P, 'A' + i));
        }

        vector<string> steps;

        while (!pq.empty()) {
            pair<int, char> p1 = pq.top();
            pq.pop();

            if (pq.empty()) {
                steps.push_back(string(1, p1.second));
                break;
            }

            pair<int, char> p2 = pq.top();
            pq.pop();

            steps.push_back(string(1, p1.second) + string(1, p2.second));

            if (p1.first > 1) {
                pq.push(make_pair(p1.first - 1, p1.second));
            }

            if (p2.first > 1) {
                pq.push(make_pair(p2.first - 1, p2.second));
            }
        }

        cout << "Case #" << t << ": ";

        for (int i = 0; i < steps.size(); i++) {
            cout << steps[i];

            if (i < steps.size() - 1) {
                cout << " ";
            }
        }

        cout << endl;
    }

    return 0;
}
