#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

struct Party {
    char name;
    int count;
};

bool operator<(const Party& a, const Party& b) {
    return a.count < b.count;
}

vector<string> evacuate(vector<Party>& parties) {
    int n = parties.size();
    priority_queue<Party> q;
    for (int i = 0; i < n; i++) {
        q.push(parties[i]);
    }
    vector<string> plan;
    while (!q.empty()) {
        Party a = q.top();
        q.pop();
        if (a.count > 1) {
            Party b = q.top();
            q.pop();
            a.count--;
            b.count--;
            plan.push_back(string(1, a.name) + b.name);
            if (b.count > 0) {
                q.push(b);
            }
        } else {
            plan.push_back(string(1, a.name));
        }
        if (a.count > 0) {
            q.push(a);
        }
    }
    reverse(plan.begin(), plan.end());
    return plan;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<Party> parties(n);
        for (int j = 0; j < n; j++) {
            parties[j].name = 'A' + j;
            cin >> parties[j].count;
        }
        vector<string> plan = evacuate(parties);
        cout << "Case #" << i << ": ";
        for (string s : plan) {
            cout << s << " ";
        }
        cout << endl;
    }
    return 0;
}
