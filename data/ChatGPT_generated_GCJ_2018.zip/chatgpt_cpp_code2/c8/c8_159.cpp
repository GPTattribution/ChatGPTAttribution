#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N;
        cin >> N;
        vector<pair<int, char>> senators;
        for (int i = 0; i < N; ++i) {
            int p;
            cin >> p;
            senators.push_back({p, 'A' + i});
        }
        cout << "Case #" << t << ": ";
        while (!senators.empty()) {
            sort(senators.rbegin(), senators.rend());
            if (senators.size() == 3 && senators[0].first == 1 && senators[1].first == 1 && senators[2].first == 1) {
                cout << senators[0].second << " ";
                senators.erase(senators.begin());
            } else if (senators[0].first > senators[1].first) {
                cout << senators[0].second << senators[0].second << " ";
                senators[0].first -= 2;
            } else {
                cout << senators[0].second << senators[1].second << " ";
                senators[0].first -= 1;
                senators[1].first -= 1;
            }
            if (senators[0].first == 0) {
                senators.erase(senators.begin());
            }
            if (senators.size() == 2 && senators[0].first == senators[1].first) {
                cout << senators[0].second << senators[1].second << " ";
                senators[0].first -= 1;
                senators[1].first -= 1;
            }
        }
        cout << endl;
    }
    return 0;
}
