#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties;
        for (int i = 0; i < N; i++) {
            int p;
            cin >> p;
            parties.push_back({p, 'A' + i});
        }
        string ans;
        while (true) {
            sort(parties.rbegin(), parties.rend());
            if (parties[0].first == 0) break;
            if (parties[0].first == 1) {
                ans += parties[0].second;
                parties[0].first--;
            } else if (parties[1].first == 0 || (parties[0].first - parties[1].first >= 2)) {
                ans += parties[0].second;
                ans += parties[0].second;
                parties[0].first -= 2;
            } else {
                ans += parties[0].second;
                ans += parties[1].second;
                parties[0].first--;
                parties[1].first--;
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
