#include <iostream>
#include <queue>
#include <vector>
#include <cstring>

using namespace std;

const int MAXN = 26;
const int MAXP = 1000;

int T, N;
int P[MAXN];

struct Party {
    int cnt;
    char name;
    Party(int cnt, char name) : cnt(cnt), name(name) {}
};

struct PartyCmp {
    bool operator()(const Party& p1, const Party& p2) {
        return p1.cnt < p2.cnt;
    }
};

priority_queue<Party, vector<Party>, PartyCmp> pq;

void solve() {
    while (!pq.empty()) pq.pop();
    cin >> N;
    for (int i = 0; i < N; i++) {
        cin >> P[i];
        pq.push(Party(P[i], 'A' + i));
    }
    cout << "Case #" << T << ":";
    while (!pq.empty()) {
        Party p1 = pq.top(); pq.pop();
        Party p2 = pq.top(); pq.pop();
        if (p1.cnt > 1) {
            cout << " " << p1.name << p1.name;
            p1.cnt -= 2;
            if (p1.cnt > 0) pq.push(p1);
        } else {
            cout << " " << p1.name;
        }
        if (p2.cnt > 1) {
            cout << p2.name << p2.name;
            p2.cnt -= 2;
            if (p2.cnt > 0) pq.push(p2);
        } else {
            cout << p2.name;
        }
    }
    cout << endl;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        solve();
    }
    return 0;
}
