#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

void evacuate(int t, int n, vector<int>& parties) {
    string ans;
    while (true) {
        int i = max_element(parties.begin(), parties.end()) - parties.begin();
        if (parties[i] == 0) break; 
        ans += 'A' + i;
        parties[i]--;
        int j = max_element(parties.begin(), parties.end()) - parties.begin();
        if (parties[j] == 0) break;
        ans += 'A' + j;
        parties[j]--;
    }
    cout << "Case #" << t << ": " << ans << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;
        vector<int> parties(n);
        for (int i = 0; i < n; i++) {
            cin >> parties[i];
        }
        evacuate(t, n, parties);
    }
    return 0;
}
