#include<bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for(int i=1; i<=t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char> > pq;
        int total = 0;
        for(int j=0; j<n; j++) {
            int x;
            cin >> x;
            pq.push(make_pair(x, j+'A'));
            total += x;
        }
        cout << "Case #" << i << ": ";
        while(total > 0) {
            pair<int, char> p1 = pq.top();
            pq.pop();
            pair<int, char> p2 = pq.top();
            pq.pop();
            if(p1.first > p2.first) {
                cout << p1.second << p1.second << " ";
                p1.first -= 2;
            }
            else {
                cout << p1.second << p2.second << " ";
                p1.first--;
                p2.first--;
            }
            if(p1.first > 0) pq.push(p1);
            if(p2.first > 0) pq.push(p2);
            total -= 2;
        }
        cout << endl;
    }
    return 0;
}
