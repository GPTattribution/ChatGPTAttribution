#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    for(int i=1;i<=t;i++)
    {
        int n;
        cin>>n;
        priority_queue<pair<int,char>> pq;
        for(int j=0;j<n;j++)
        {
            int p;
            cin>>p;
            pq.push({p,'A'+j});
        }
        cout<<"Case #"<<i<<": ";
        while(!pq.empty())
        {
            pair<int,char> first=pq.top();
            pq.pop();
            pair<int,char> second=pq.top();
            pq.pop();
            cout<<first.second<<second.second<<" ";
            if(first.first-1>0) pq.push({first.first-1,first.second});
            if(second.first-1>0) pq.push({second.first-1,second.second});
        }
        cout<<endl;
    }
    return 0;
}
