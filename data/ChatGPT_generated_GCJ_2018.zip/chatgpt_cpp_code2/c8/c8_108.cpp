#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> senators; 
        int total_senators = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            senators.push_back(make_pair(p, 'A' + j));
            total_senators += p;
        }
        string plan;
        while (total_senators > 0) {
            sort(senators.rbegin(), senators.rend());
            if (senators[0].first > total_senators / 2) {
                plan += senators[0].second;
                senators[0].first--;
                total_senators--;
            } else {
                plan += senators[0].second;
                senators[0].first--;
                total_senators--;
                if (senators[1].first * 2 > total_senators) {
                    plan += senators[1].second;
                    senators[1].first--;
                    total_senators--;
                } else {
                    plan += senators[0].second;
                    senators[0].first--;
                    total_senators--;
                }
            }
            plan += " ";
        }
        cout << "Case #" << i << ": " << plan << "\n";
    }
    return 0;
}
