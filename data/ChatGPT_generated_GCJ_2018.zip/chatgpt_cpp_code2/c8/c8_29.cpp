#include <iostream>
#include <queue>
#include <vector>

using namespace std;

struct Party {
    char name;
    int count;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

void print_evacuation(char party1, char party2 = '\0') {
    cout << party1;
    if (party2 != '\0') {
        cout << party2;
    }
    cout << " ";
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<Party> parties;
        int total_senators = 0;
        for (char c = 'A'; c < 'A' + N; c++) {
            int count;
            cin >> count;
            parties.push({c, count});
            total_senators += count;
        }
        cout << "Case #" << t << ": ";
        while (!parties.empty()) {
            vector<Party> evacuated;
            int remaining_senators = total_senators;
            Party p1 = parties.top();
            parties.pop();
            evacuated.push_back(p1);
            remaining_senators -= p1.count;
            if (parties.empty()) {
                print_evacuation(p1.name);
                break;
            }
            Party p2 = parties.top();
            parties.pop();
            evacuated.push_back(p2);
            remaining_senators -= p2.count;
            print_evacuation(p1.name, p2.name);
            if (p1.count > 1) {
                parties.push({p1.name, p1.count - 1});
            }
            if (p2.count > 1) {
                parties.push({p2.name, p2.count - 1});
            }
            for (const Party& p : parties) {
                if (2 * p.count > remaining_senators) {
                    Party p3 = p;
                    parties.pop();
                    evacuated.push_back(p3);
                    remaining_senators -= p3.count;
                    print_evacuation(p3.name);
                    if (p3.count > 1) {
                        parties.push({p3.name, p3.count - 1});
                    }
                    break;
                }
            }
            for (const Party& p : evacuated) {
                if (2 * p.count <= remaining_senators) {
                    parties.push(p);
                }
            }
        }
        cout << endl;
    }
    return 0;
}
