#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> senators;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            senators.push_back({p, 'A' + j});
        }
        sort(senators.rbegin(), senators.rend());
        cout << "Case #" << i << ":";
        while (senators[0].first > senators[1].first || senators[0].first > 1) {
            cout << " " << senators[0].second << senators[1].second;
            senators[0].first--;
            senators[1].first--;
            sort(senators.rbegin(), senators.rend());
        }
        for (int j = 2; j < n; j++) {
            while (senators[j].first > 0) {
                cout << " " << senators[0].second << senators[j].second;
                senators[0].first--;
                senators[j].first--;
            }
        }
        cout << endl;
    }
    return 0;
}
