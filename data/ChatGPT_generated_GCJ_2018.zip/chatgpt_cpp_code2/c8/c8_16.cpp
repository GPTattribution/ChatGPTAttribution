#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;

        priority_queue<pair<int, char>> pq;
        int total = 0;

        for (char c = 'A'; c < 'A' + n; c++) {
            int p;
            cin >> p;
            pq.push({p, c});
            total += p;
        }

        cout << "Case #" << i << ": ";

        while (!pq.empty()) {
            pair<int, char> first = pq.top();
            pq.pop();
            pair<int, char> second = pq.top();
            pq.pop();

            if (first.first - 1 > total - first.first) {
                cout << first.second << " ";
                pq.push({first.first - 1, first.second});
            } else {
                cout << first.second << second.second << " ";
                pq.push({first.first - 1, first.second});
                pq.push({second.first - 1, second.second});
            }

            total -= 2;
        }

        cout << endl;
    }

    return 0;
}
