#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void evacuate(int T) {
    for (int t = 1; t <= T; ++t) {
        int N;
        cin >> N;

        vector<pair<int, char>> parties(N);
        for (int i = 0; i < N; ++i) {
            int senators;
            cin >> senators;
            parties[i] = make_pair(senators, 'A' + i);
        }

        cout << "Case #" << t << ": ";

        while (true) {
            sort(parties.rbegin(), parties.rend());

            if (parties[0].first == 0) {
                break;
            }

            if (parties[0].first >= 2 && parties[1].first * 2 <= parties[0].first - 2) {
                cout << parties[0].second << parties[0].second << " ";
                parties[0].first -= 2;
            } else {
                cout << parties[0].second << parties[1].second << " ";
                parties[0].first -= 1;
                parties[1].first -= 1;
            }
        }

        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;
    evacuate(T);
    return 0;
}
