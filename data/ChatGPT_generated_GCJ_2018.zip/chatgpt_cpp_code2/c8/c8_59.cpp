#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> senators(n);
        int total = 0;
        for (int j = 0; j < n; j++) {
            cin >> senators[j].first;
            senators[j].second = 'A' + j;
            total += senators[j].first;
        }
        cout << "Case #" << i << ": ";
        while (total > 0) {
            sort(senators.rbegin(), senators.rend());
            if (senators[0].first > 0 && senators[1].first > 0) {
                cout << senators[0].second << senators[1].second << " ";
                senators[0].first--;
                senators[1].first--;
                total -= 2;
            } else {
                cout << senators[0].second << " ";
                senators[0].first--;
                total--;
            }
        }
        cout << endl;
    }
    return 0;
}
