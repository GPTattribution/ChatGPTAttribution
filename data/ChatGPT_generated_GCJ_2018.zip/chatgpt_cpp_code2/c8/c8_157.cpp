#include <bits/stdc++.h>
#define int long long
#define pb push_back
#define mp make_pair
#define pii pair<int, int>
#define vi vector<int>
#define vpii vector<pair<int, int>>
#define all(x) (x).begin(), (x).end()
#define F first
#define S second
#define mod 1000000007
#define MOD 998244353
#define inf 1e18
#define PI 3.14159265358979323846
using namespace std;
int t;
signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin >> t;
    for (int T = 1; T <= t; T++) {
        int n;
        cin >> n;
        vector<pii> p;
        int sum = 0;
        for (int i = 0; i < n; i++) {
            int x;
            cin >> x;
            p.pb({x, i});
            sum += x;
        }
        cout << "Case #" << T << ": ";
        while (sum > 0) {
            sort(all(p), greater<pii>());
            int i = p[0].S, j = -1;
            if (sum == 3) {
                cout << char(i + 'A') << " ";
                p[i].F--;
                sum--;
                continue;
            }
            if (p[1].F >= p[2].F) {
                j = p[1].S;
                cout << char(i + 'A') << char(j + 'A') << " ";
                p[i].F--;
                p[j].F--;
                sum -= 2;
                continue;
            }
            cout << char(i + 'A') << " ";
            p[i].F--;
            sum--;
        }
        cout << endl;
    }
    return 0;
}
