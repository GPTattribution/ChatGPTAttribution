#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        priority_queue<pair<int, char>> q;
        int total = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            q.push(make_pair(p, 'A' + j));
            total += p;
        }
        cout << "Case #" << i << ": ";
        while (!q.empty()) {
            pair<int, char> p1 = q.top();
            q.pop();
            pair<int, char> p2 = q.top();
            q.pop();
            cout << p1.second << p2.second << " ";
            p1.first--;
            p2.first--;
            total -= 2;
            if (p1.first > 0) {
                q.push(p1);
            }
            if (p2.first > 0) {
                q.push(p2);
            }
            if (q.size() == 1) {
                pair<int, char> p3 = q.top();
                q.pop();
                cout << p3.second << " ";
                total--;
                if (p3.first > 1) {
                    q.push(make_pair(p3.first - 1, p3.second));
                }
            }
        }
        cout << endl;
    }
    return 0;
}
