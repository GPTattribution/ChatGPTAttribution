#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

struct Party {
    char name;
    int count;
    bool operator<(const Party& other) const {
        return count < other.count;
    }
};

vector<string> evacuate(int n, vector<Party>& parties) {
    vector<string> plan;
    priority_queue<Party> q;
    for (auto& p : parties) {
        q.push(p);
    }
    while (!q.empty()) {
        string step;
        for (int i = 0; i < 2; i++) {
            if (q.empty()) {
                break;
            }
            Party p = q.top();
            q.pop();
            p.count--;
            step += p.name;
            if (p.count > 0) {
                q.push(p);
            }
        }
        plan.push_back(step);
    }
    reverse(plan.begin(), plan.end());
    return plan;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;
        vector<Party> parties;
        for (char c = 'A'; c < 'A' + n; c++) {
            int count;
            cin >> count;
            parties.push_back({c, count});
        }
        vector<string> plan = evacuate(n, parties);
        cout << "Case #" << t << ": ";
        for (string step : plan) {
            cout << step << " ";
        }
        cout << endl;
    }
    return 0;
}
