#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n;
        cin >> n;
        vector<pair<int, char>> parties;
        int total_senators = 0;
        for (int j = 0; j < n; j++) {
            int p;
            cin >> p;
            parties.push_back({p, 'A' + j});
            total_senators += p;
        }
        string plan = "";
        while (total_senators > 0) {
            sort(parties.begin(), parties.end(), greater<pair<int, char>>());
            char p1 = parties[0].second;
            parties[0].first--;
            total_senators--;
            if (total_senators == 2 && parties[1].first == 1) {
                char p2 = parties[1].second;
                parties[1].first--;
                total_senators--;
                plan += " " + string({p1, p2});
            } else {
                char p2 = parties[1].second;
                parties[1].first--;
                total_senators--;
                plan += " " + string({p1, p2});
                if (parties[2].first > total_senators / 2) {
                    p1 = parties[0].second;
                    parties[0].first--;
                    total_senators--;
                    plan += " " + string({p1});
                }
            }
        }
        cout << "Case #" << i << ":" << plan << endl;
    }
    return 0;
}
