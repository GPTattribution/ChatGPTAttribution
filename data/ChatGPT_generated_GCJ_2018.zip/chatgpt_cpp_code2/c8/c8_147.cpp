#include <iostream>
#include <vector>
#include <queue>
#include <cstring>

using namespace std;

const int MAX_N = 26;

struct Party {
    char name;
    int count;
    bool operator < (const Party& other) const {
        return count < other.count;
    }
};

void evacuate(int t, int n, vector<Party>& parties) {
    cout << "Case #" << t << ":";
    priority_queue<Party> pq;
    for (int i = 0; i < n; i++) {
        pq.push(parties[i]);
    }
    while (!pq.empty()) {
        Party p1 = pq.top(); pq.pop();
        if (pq.empty()) {
            cout << " " << p1.name;
            break;
        }
        Party p2 = pq.top(); pq.pop();
        cout << " " << p1.name << p2.name;
        if (--p1.count > 0) {
            pq.push(p1);
        }
        if (--p2.count > 0) {
            pq.push(p2);
        }
    }
    cout << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;
        vector<Party> parties(n);
        for (int i = 0; i < n; i++) {
            parties[i].name = 'A' + i;
            cin >> parties[i].count;
        }
        evacuate(t, n, parties);
    }
    return 0;
}
