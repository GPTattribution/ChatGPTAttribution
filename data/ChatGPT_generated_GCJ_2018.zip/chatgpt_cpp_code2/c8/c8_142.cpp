#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        priority_queue<pair<int, char>> pq;
        int total = 0;
        for (int i = 0; i < N; i++) {
            int p;
            cin >> p;
            total += p;
            pq.push(make_pair(p, 'A' + i));
        }
        vector<string> res;
        while (!pq.empty()) {
            pair<int, char> p1 = pq.top();
            pq.pop();
            if (pq.empty()) {
                res.push_back(string(1, p1.second));
                break;
            }
            pair<int, char> p2 = pq.top();
            pq.pop();
            if (p1.first - p2.first > 1) {
                res.push_back(string(2, p1.second));
                pq.push(make_pair(p1.first - 2, p1.second));
                pq.push(p2);
            } else if (p1.first - p2.first == 1) {
                res.push_back(string(1, p1.second) + p2.second);
                pq.push(make_pair(p1.first - 1, p1.second));
                pq.push(p2);
            } else {
                res.push_back(string(2, p1.second) + p2.second);
                pq.push(make_pair(p1.first - 2, p1.second));
                pq.push(make_pair(p2.first - 1, p2.second));
            }
        }
        cout << "Case #" << t << ": ";
        for (int i = 0; i < res.size(); i++) {
            if (i > 0) {
                cout << " ";
            }
            cout << res[i];
        }
        cout << endl;
    }
    return 0;
}
