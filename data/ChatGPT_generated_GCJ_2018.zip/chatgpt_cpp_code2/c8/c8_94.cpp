#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        vector<pair<int, char>> senators;

        for (int i = 0; i < N; i++) {
            int P;
            cin >> P;
            senators.push_back({P, 'A' + i});
        }

        string plan;

        while (senators.size() > 0) {
            sort(senators.rbegin(), senators.rend());
            int num_evacuated = 0;
            string step;

            for (int i = 0; i < min(2, (int)senators.size()); i++) {
                step += senators[i].second;
                senators[i].first--;
                num_evacuated++;

                if (senators[i].first == 0) {
                    senators.erase(senators.begin() + i);
                    i--;
                }
            }

            if (num_evacuated == 1) { 
                for (int i = 0; i < min(2, (int)senators.size()); i++) {
                    if (senators[i].first > 0) {
                        step += senators[i].second;
                        senators[i].first--;
                        if (senators[i].first == 0) {
                            senators.erase(senators.begin() + i);
                        }
                        break;
                    }
                }
            }

            plan += step + " ";
        }

        cout << "Case #" << t << ": " << plan << endl;
    }

    return 0;
}
