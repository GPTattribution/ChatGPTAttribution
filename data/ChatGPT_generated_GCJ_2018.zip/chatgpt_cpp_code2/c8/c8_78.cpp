#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;
        vector<pair<int, char>> parties(N);
        priority_queue<pair<int, char>> pq; 
        for (int i = 0; i < N; i++) {
            cin >> parties[i].first;
            parties[i].second = 'A' + i;
            pq.push(parties[i]);
        }
        string plan;
        while (!pq.empty()) {
            pair<int, char> p1 = pq.top(); pq.pop();
            pair<int, char> p2 = pq.top(); pq.pop();
            plan += p1.second;
            p1.first--;
            if (p2.first > 0) {
                plan += p2.second;
                p2.first--;
            }
            if (p1.first > 0) pq.push(p1);
            if (p2.first > 0) pq.push(p2);
        }
        cout << "Case #" << t << ": " << plan << endl;
    }
    return 0;
}
