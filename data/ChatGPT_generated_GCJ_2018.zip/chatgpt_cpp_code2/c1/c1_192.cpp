#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double PI = acos(-1.0);

void solve(int testCase, double A) {
    cout << "Case #" << testCase << ":" << endl;

    double theta = asin(A / sqrt(2));
    double cosTheta = cos(theta);
    double sinTheta = sin(theta);

    double p1x = 0.5 * cosTheta;
    double p1y = 0.5 * sinTheta;
    double p1z = 0;

    double p2x = -0.5 * sinTheta;
    double p2y = 0.5 * cosTheta;
    double p2z = 0;

    double p3x = 0;
    double p3y = 0;
    double p3z = 0.5;

    cout << fixed << setprecision(15);
    cout << p1x << " " << p1y << " " << p1z << endl;
    cout << p2x << " " << p2y << " " << p2z << endl;
    cout << p3x << " " << p3y << " " << p3z << endl;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        solve(t, A);
    }

    return 0;
}
