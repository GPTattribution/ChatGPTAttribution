#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

const double eps = 1e-6;
const double pi = acos(-1.0);

void solve(int case_num, double A) {
    double alpha = asin(A / sqrt(2.0)) / 2;

    double x1 = 0.5 * cos(alpha);
    double y1 = 0.5 * sin(alpha);
    double x2 = 0.5 * cos(alpha + pi / 2);
    double y2 = 0.5 * sin(alpha + pi / 2);
    double x3 = 0.5;
    double y3 = 0;

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(15) << x1 << " " << y1 << " " << 0.0 << endl;
    cout << fixed << setprecision(15) << x2 << " " << y2 << " " << 0.0 << endl;
    cout << fixed << setprecision(15) << x3 << " " << y3 << " " << 0.5 << endl;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;
        solve(i, A);
    }
    return 0;
}
