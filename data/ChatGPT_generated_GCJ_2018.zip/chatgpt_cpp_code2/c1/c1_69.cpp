#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double eps = 1e-6;

double find_angle(double a, double b, double c) {
    return acos((a * a + b * b - c * c) / (2 * a * b));
}

void solve(int t, double A) {
    cout << "Case #" << t << ":" << endl;

    double angle = find_angle(A, 1.0, 1.0);
    double sin_angle = sin(angle);
    double cos_angle = cos(angle);

    cout << setprecision(12);
    cout << 0.5 << " " << 0.0 << " " << 0.0 << endl;
    cout << 0.0 << " " << 0.5 * cos_angle << " " << 0.5 * sin_angle << endl;
    cout << 0.0 << " " << 0.5 * sin_angle << " " << -0.5 * cos_angle << endl;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        solve(t, A);
    }

    return 0;
}
