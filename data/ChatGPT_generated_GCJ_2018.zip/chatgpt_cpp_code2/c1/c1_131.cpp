#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

void rotate_cube(double A) {
    double half_side = 0.5;
    double theta = acos(A / sqrt(2));

    double x1 = half_side * cos(theta);
    double z1 = half_side * sin(theta);

    double x2 = half_side * cos(theta + M_PI / 2);
    double z2 = half_side * sin(theta + M_PI / 2);

    cout << fixed << setprecision(15)
         << x1 << " " << 0.0 << " " << z1 << endl
         << x2 << " " << 0.0 << " " << z2 << endl
         << 0.0 << " " << 0.0 << " " << half_side << endl;
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;
        cout << "Case #" << i << ":" << endl;
        rotate_cube(A);
    }

    return 0;
}
