#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

void solve(int case_num, double A) {
    const double max_edge = sqrt(2);
    double edge = A / max_edge;
    double half_edge = edge / 2;

    cout.precision(10);
    cout << "Case #" << case_num << ":" << endl;
    cout << half_edge << " " << half_edge << " 0" << endl;
    cout << -half_edge << " " << half_edge << " 0" << endl;
    cout << "0 0 0.5" << endl;
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;
        solve(i, A);
    }

    return 0;
}
