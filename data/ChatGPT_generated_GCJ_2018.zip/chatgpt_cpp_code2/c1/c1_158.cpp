#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

const double EPS = 1e-6;

vector<vector<double>> find_points(double A) {
    double theta = (A - 1) / (sqrt(2) - 1);
    double phi = acos(theta) / 2;
    double sin_phi = sin(phi);
    double cos_phi = cos(phi);

    return {
        {0.5 * cos_phi, 0.5 * sin_phi, 0},
        {0.5 * sin_phi, 0.5 * cos_phi, 0},
        {0, 0, 0.5},
    };
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int T;
    cin >> T;

    cout << fixed << setprecision(10);

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        vector<vector<double>> points = find_points(A);

        cout << "Case #" << t << ":\n";
        for (const auto& point : points) {
            cout << point[0] << " " << point[1] << " " << point[2] << "\n";
        }
    }

    return 0;
}
