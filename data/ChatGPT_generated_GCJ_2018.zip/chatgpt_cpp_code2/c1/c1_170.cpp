#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

vector<double> find_face_centers(double A) {
    double angle = (A - 1.0) / (sqrt(2) - 1.0);
    double theta = acos(angle) / 2.0;

    double x1 = 0.5 * cos(theta);
    double y1 = 0.5 * sin(theta);
    double z1 = 0;

    double x2 = -0.5 * cos(theta);
    double y2 = 0.5 * sin(theta);
    double z2 = 0;

    double x3 = 0;
    double y3 = 0;
    double z3 = 0.5;

    return {x1, y1, z1, x2, y2, z2, x3, y3, z3};
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<double> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (int i = 0; i < 9; i += 3) {
            cout << face_centers[i] << " " << face_centers[i + 1] << " " << face_centers[i + 2] << endl;
        }
    }

    return 0;
}
