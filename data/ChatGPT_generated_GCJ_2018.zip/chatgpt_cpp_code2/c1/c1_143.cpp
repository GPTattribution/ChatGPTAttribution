#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double pi = acos(-1);

void solve(double A) {
    double theta = acos(A / sqrt(2));
    double phi = pi / 4 - theta / 2;

    double v1x = 0.5 * cos(phi);
    double v1z = 0.5 * sin(phi);

    double v2x = 0.5 * cos(pi / 4 + phi);
    double v2z = -0.5 * sin(pi / 4 + phi);

    cout << setprecision(10) << v1x << " " << 0.0 << " " << v1z << endl;
    cout << setprecision(10) << v2x << " " << 0.0 << " " << v2z << endl;
    cout << setprecision(10) << 0.0 << " " << 0.5 << " " << 0.0 << endl;
}

int main() {
    int T;
    double A;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> A;
        cout << "Case #" << t << ":" << endl;
        solve(A);
    }
    return 0;
}
