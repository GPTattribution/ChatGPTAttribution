#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

const double PI = acos(-1);

void solve(double A) {
    double theta = asin(A / sqrt(2));
    double phi = PI / 4;

    vector<vector<double>> points(3, vector<double>(3));
    points[0][0] = 0.5 * cos(theta) * cos(phi);
    points[0][1] = 0.5 * cos(theta) * sin(phi);
    points[0][2] = 0.5 * sin(theta);

    points[1][0] = 0.5 * (cos(theta) * cos(phi) - sin(theta));
    points[1][1] = 0.5 * (cos(theta) * sin(phi) + cos(theta));
    points[1][2] = 0;

    points[2][0] = 0.5 * (cos(theta) * cos(phi) + sin(theta));
    points[2][1] = 0.5 * (cos(theta) * sin(phi) - cos(theta));
    points[2][2] = 0;

    cout << fixed << setprecision(15);
    for (const auto& point : points) {
        for (const auto& coord : point) {
            cout << coord << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        cout << "Case #" << t << ":" << endl;
        solve(A);
    }
    return 0;
}
