#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

double area(const vector<vector<double>>& points) {
    double res = 0.0;
    int n = points.size();
    for (int i = 0; i < n; i++) {
        res += points[i][0] * points[(i + 1) % n][1] - points[i][1] * points[(i + 1) % n][0];
    }
    return fabs(res) / 2.0;
}

vector<vector<double>> projection(const vector<vector<double>>& points) {
    vector<vector<double>> projected(points.size(), vector<double>(2));
    for (int i = 0; i < points.size(); i++) {
        double factor = -3 / (points[i][1] - 3);
        projected[i][0] = points[i][0] * factor;
        projected[i][1] = points[i][2] * factor;
    }
    return projected;
}

int main() {
    int t;
    cin >> t;
    for (int i = 0; i < t; i++) {
        double A;
        cin >> A;
        double angle = asin(A / sqrt(2));
        double sin_angle = sin(angle);
        double cos_angle = cos(angle);

        cout.precision(10);
        cout << "Case #" << i + 1 << ":" << endl;
        cout << 0.5 * cos_angle << " " << 0.5 * sin_angle << " " << 0.0 << endl;
        cout << -0.5 * sin_angle << " " << 0.5 * cos_angle << " " << 0.0 << endl;
        cout << 0.0 << " " << 0.0 << " " << 0.5 << endl;
    }
    return 0;
}
