#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(int case_num, double area) {
    double angle = (area - 1) / (sqrt(2) - 1);
    double x = 0.5 * angle;
    double y = 0.5 * angle;
    double z = 0.5;

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(9);
    cout << x << " " << y << " " << 0.0 << endl;
    cout << -x << " " << y << " " << 0.0 << endl;
    cout << 0.0 << " " << 0.0 << " " << z << endl;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        double A;
        cin >> A;
        solve(i, A);
    }

    return 0;
}
