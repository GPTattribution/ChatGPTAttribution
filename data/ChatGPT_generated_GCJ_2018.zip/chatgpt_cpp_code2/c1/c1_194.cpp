#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

const double PI = 3.14159265358979323846;

void find_face_centers(double A) {
    double alpha = acos(A / sqrt(2));
    double beta = PI / 4 - alpha;

    double x = 0.5 * cos(beta);
    double z = 0.5 * sin(beta);

    std::vector<std::vector<double>> face_centers = {
        {x, 0.5, z},
        {-x, 0.5, z},
        {0, 0.5, 0.5}
    };

    for (const auto &face_center : face_centers) {
        for (double coordinate : face_center) {
            std::cout << std::setprecision(15) << coordinate << " ";
        }
        std::cout << std::endl;
    }
}

int main() {
    int T;
    double A;
    std::cin >> T;

    for (int i = 1; i <= T; ++i) {
        std::cin >> A;
        std::cout << "Case #" << i << ":" << std::endl;
        find_face_centers(A);
    }

    return 0;
}
