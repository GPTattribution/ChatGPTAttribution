#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

const double EPSILON = 1e-6;

void solve(int testCase, double targetArea) {
    double halfSideLength = 0.5;
    double angle = acos(targetArea / (sqrt(3) * halfSideLength * halfSideLength)) / 2.0;

    vector<vector<double>> faceCenters = {
        {halfSideLength * cos(angle), halfSideLength * sin(angle), 0.0},
        {halfSideLength * cos(angle + 2.0 * M_PI / 3.0), halfSideLength * sin(angle + 2.0 * M_PI / 3.0), 0.0},
        {0.0, 0.0, halfSideLength}
    };

    cout << "Case #" << testCase << ":" << endl;
    cout << fixed << setprecision(15);
    for (const auto& faceCenter : faceCenters) {
        for (const auto& coordinate : faceCenter) {
            cout << coordinate << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;
        solve(i, A);
    }
    return 0;
}
