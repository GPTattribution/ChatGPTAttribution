#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

int main() {
int T;
double A;
cin >> T;
for (int t = 1; t <= T; ++t) {
    cin >> A;

    double angle = (A - 1) * M_PI / 4;
    double x = 0.5 * cos(angle);
    double z = 0.5 * sin(angle);

    cout << fixed << setprecision(15);
    cout << "Case #" << t << ":" << endl;
    cout << x << " " << 0 << " " << z << endl;
    cout << -z << " " << 0 << " " << x << endl;
    cout << 0 << " " << 0.5 << " " << 0 << endl;
}

return 0;

}
