#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

vector<vector<double>> get_face_centers(double A) {
    double theta = acos(A / sqrt(2));
    double phi = M_PI_2 - theta;

    double half_sqrt_2 = sqrt(2) / 2;

    double x = half_sqrt_2 * cos(phi);
    double y = half_sqrt_2 * sin(phi);
    double z = 0.5;

    return {{x, y, z}, {-x, y, z}, {z, y, -x}};
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(9);

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        vector<vector<double>> face_centers = get_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                cout << face_centers[i][j] << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
