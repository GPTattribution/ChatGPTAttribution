#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(int case_number, double target_area) {
    double a = 0.5, b = 0.5, c = 0.5;

    if (target_area < 1.0 + 1e-6) {
        double angle = (acos(target_area / sqrt(2)) - M_PI / 4) / 2;
        a = 0.5 * cos(angle);
        b = 0.5 * sin(angle);
    } else if (target_area > sqrt(2) - 1e-6) {
        double angle = (acos(target_area / sqrt(3)) - M_PI / 4) / 2;
        a = 0.5 * cos(angle);
        b = 0.5 * sin(angle);
        c = 0.5 * sin(angle);
    }

    cout << "Case #" << case_number << ":" << endl;
    cout << fixed << setprecision(10) << a << " " << b << " 0" << endl;
    cout << -b << " " << a << " 0" << endl;
    cout << "0 0 " << c << endl;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        double target_area;
        cin >> target_area;
        solve(i, target_area);
    }
    return 0;
}
