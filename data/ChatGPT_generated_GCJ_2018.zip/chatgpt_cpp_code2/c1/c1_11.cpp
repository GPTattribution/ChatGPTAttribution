#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

double calculate_alpha(double A) {
    return acos((A * A - 2) / (A * A));
}

void solve_test_case(int case_num, double A) {
    double alpha = calculate_alpha(A);
    double half_side = 0.5;

    double x1 = half_side * cos(alpha);
    double z1 = half_side * sin(alpha);
    double x2 = half_side * cos(alpha + M_PI / 2);
    double z2 = half_side * sin(alpha + M_PI / 2);

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(15) << x1 << " 0 " << z1 << endl;
    cout << x2 << " 0 " << z2 << endl;
    cout << "0 0 " << half_side << endl;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        double A;
        cin >> A;
        solve_test_case(i, A);
    }
    return 0;
}
