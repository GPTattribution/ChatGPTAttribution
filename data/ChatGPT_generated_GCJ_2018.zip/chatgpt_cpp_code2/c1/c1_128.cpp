#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

double eps = 1e-9;

void solve(int test_case) {
    double A;
    cin >> A;

    double p = acos(A / sqrt(2));
    double q = M_PI / 4 - p;

    double x1 = 0.5 * cos(q);
    double z1 = 0.5 * sin(q);
    double x2 = 0.5 * sin(q);
    double z2 = 0.5 * cos(q);

    cout << "Case #" << test_case << ":" << endl;
    printf("%.10lf %.10lf %.10lf\n", x1, 0.0, z1);
    printf("%.10lf %.10lf %.10lf\n", x2, 0.0, -z2);
    printf("%.10lf %.10lf %.10lf\n", 0.0, 0.5, 0.0);
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; ++i) {
        solve(i);
    }

    return 0;
}
