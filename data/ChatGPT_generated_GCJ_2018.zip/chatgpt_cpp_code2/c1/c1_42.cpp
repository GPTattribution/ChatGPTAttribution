#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

double eps = 1e-9;

vector<vector<double>> find_rotation(double A) {
    double theta = 2 * acos(A / sqrt(2));

    double x = 0.5 * cos(theta);
    double z = 0.5 * sin(theta);

    return {
        {x, 0.5, z},
        {-x, 0.5, -z},
        {0, 0.5, 0.5}
    };
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(10);
    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        vector<vector<double>> rotation = find_rotation(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto& point : rotation) {
            for (double coord : point) {
                cout << coord << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
