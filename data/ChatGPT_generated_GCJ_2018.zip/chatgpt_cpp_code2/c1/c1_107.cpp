#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(double A) {
    double u = 0.5 * A / sqrt(2.0);
    double v = 0.5 - u;
    cout << fixed << setprecision(10) << u << " " << v << " " << v << endl;
    cout << fixed << setprecision(10) << v << " " << u << " " << v << endl;
    cout << fixed << setprecision(10) << v << " " << v << " " << u << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        cout << "Case #" << t << ":" << endl;
        solve(A);
    }
    return 0;
}
