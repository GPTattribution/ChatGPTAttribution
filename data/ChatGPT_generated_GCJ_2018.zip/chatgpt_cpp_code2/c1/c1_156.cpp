#include <iostream>
#include <iomanip>
#include <cmath>

const double PI = acos(-1.0);

void solve(int t, double A) {
    std::cout << "Case #" << t << ":" << std::endl;

    double angle = asin(A / sqrt(2));

    double half_edge_length = 0.5;

    double c = cos(angle);
    double s = sin(angle);

    std::cout << std::fixed << std::setprecision(10)
              << half_edge_length * c << " " << 0.0 << " " << half_edge_length * s << std::endl;
    std::cout << std::fixed << std::setprecision(10)
              << -half_edge_length * s << " " << 0.0 << " " << half_edge_length * c << std::endl;
    std::cout << std::fixed << std::setprecision(10)
              << 0.0 << " " << half_edge_length << " " << 0.0 << std::endl;
}

int main() {
    int T;
    std::cin >> T;
    for (int t = 1; t <= T; t++) {
        double A;
        std::cin >> A;
        solve(t, A);
    }
    return 0;
}
