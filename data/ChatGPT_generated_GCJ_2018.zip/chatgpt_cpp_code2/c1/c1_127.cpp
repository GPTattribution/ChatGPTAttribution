#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double PI = acos(-1.0);

void solve(int t, double A) {
    double theta = atan(1.0 / (A / sqrt(2) - 1));
    double phi = PI / 4.0;

    double x1 = 0.5 * cos(theta);
    double y1 = 0.5 * sin(theta);
    double z1 = 0;

    double x2 = -0.5 * sin(phi) * sin(theta);
    double y2 = 0.5 * sin(phi) * cos(theta);
    double z2 = 0.5 * cos(phi);

    double x3 = 0.5 * cos(phi) * sin(theta);
    double y3 = -0.5 * cos(phi) * cos(theta);
    double z3 = 0.5 * sin(phi);

    cout << "Case #" << t << ":\n";
    cout << fixed << setprecision(10) << x1 << " " << y1 << " " << z1 << "\n";
    cout << fixed << setprecision(10) << x2 << " " << y2 << " " << z2 << "\n";
    cout << fixed << setprecision(10) << x3 << " " << y3 << " " << z3 << "\n";
}

int main() {
    int T;
    double A;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        cin >> A;
        solve(t, A);
    }

    return 0;
}
