#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

double desired_area(double A) {
    return (A - 1.0) / (sqrt(2) - 1.0);
}

vector<vector<double>> find_points(double x, double y) {
    vector<vector<double>> points(3, vector<double>(3));

    points[0][0] = x;
    points[0][1] = y;
    points[0][2] = 0;

    points[1][0] = -y;
    points[1][1] = x;
    points[1][2] = 0;

    points[2][0] = 0;
    points[2][1] = 0;
    points[2][2] = 0.5;

    return points;
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; ++t) {
        cin >> A;

        double a = desired_area(A);
        double x = 0.5 * a / sqrt(2);
        double y = 0.5 - x;

        vector<vector<double>> points = find_points(x, y);

        cout << "Case #" << t << ":" << endl;
        for (const auto& p : points) {
            for (const auto& coord : p) {
                cout << coord << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
