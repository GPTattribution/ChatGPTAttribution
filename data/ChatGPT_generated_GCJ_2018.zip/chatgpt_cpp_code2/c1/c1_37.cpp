#include <iostream>
#include <cmath>
#include <iomanip>

const double PI = std::acos(-1.0);

void solve(int case_num, double A) {
    std::cout << "Case #" << case_num << ":" << std::endl;
    std::cout << std::fixed << std::setprecision(15);

    double theta = std::acos(A / std::sqrt(2));
    double s = std::sin(theta);
    double c = std::cos(theta);

    std::cout << 0.5 * c << " " << 0.0 << " " << 0.5 * s << std::endl;
    std::cout << 0.5 * (-s) << " " << 0.0 << " " << 0.5 * c << std::endl;
    std::cout << 0.0 << " " << 0.5 << " " << 0.0 << std::endl;
}

int main() {
    int T;
    std::cin >> T;

    for (int i = 1; i <= T; ++i) {
        double A;
        std::cin >> A;
        solve(i, A);
    }

    return 0;
}
