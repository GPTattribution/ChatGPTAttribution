#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

const double EPSILON = 1e-6;

vector<vector<double>> find_rotation_points(double A) {
    double theta = acos((A - 1) / sqrt(2));
    double half_side = 0.5;

    vector<vector<double>> rotation_points = {
        {half_side * cos(theta), half_side * sin(theta), 0},
        {-half_side * sin(theta), half_side * cos(theta), 0},
        {0, 0, half_side},
    };

    return rotation_points;
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(10);

    for (int case_num = 1; case_num <= T; ++case_num) {
        double A;
        cin >> A;

        vector<vector<double>> rotation_points = find_rotation_points(A);

        cout << "Case #" << case_num << ":" << endl;
        for (const auto &point : rotation_points) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
