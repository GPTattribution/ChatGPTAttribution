#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

int main() {
    int T;
    double A;

    cin >> T;

    for (int t = 1; t <= T; t++) {
        cin >> A;

        double angle = asin(A / sqrt(2)) / 2;

        vector<vector<double>> face_centers = {
            {0.5 * cos(angle), 0.5 * sin(angle), 0},
            {-0.5 * sin(angle), 0.5 * cos(angle), 0},
            {0, 0, 0.5}
        };

        cout << "Case #" << t << ":" << endl;
        cout << fixed << setprecision(15);
        for (auto &face_center : face_centers) {
            for (double coordinate : face_center) {
                cout << coordinate << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
