#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

vector<vector<double>> rotate_cube(double A) {
    double p = acos((A - 1) / sqrt(2));
    double c = cos(p / 2), s = sin(p / 2);

    vector<vector<double>> points(3, vector<double>(3));
    points[0] = {0.5 * c, 0.5 * s, 0};
    points[1] = {-0.5 * c, 0.5 * s, 0};
    points[2] = {0, 0, 0.5};

    return points;
}

int main() {
    int T;
    double A;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        cin >> A;
        vector<vector<double>> points = rotate_cube(A);
        cout << "Case #" << t << ":" << endl;

        for (const auto &point : points) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
