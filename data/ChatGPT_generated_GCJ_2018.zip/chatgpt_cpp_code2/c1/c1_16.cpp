#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void rotate_cube(double A) {
    double r = 0.5;
    double pi = acos(-1.0);
    double angle = (A - 1) / (sqrt(2) - 1) * (pi / 4);
    double x = r * cos(angle);
    double z = r * sin(angle);

    cout << setprecision(15) << x << " " << 0.0 << " " << z << endl;
    cout << setprecision(15) << -x << " " << 0.0 << " " << z << endl;
    cout << setprecision(15) << 0.0 << " " << 0.0 << " " << r << endl;
}

int main() {
    int T;
    double A;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        cin >> A;
        cout << "Case #" << t << ":" << endl;
        rotate_cube(A);
    }
    return 0;
}
