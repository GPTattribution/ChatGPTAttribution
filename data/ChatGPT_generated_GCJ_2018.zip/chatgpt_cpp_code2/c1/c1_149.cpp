#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

const double EPS = 1e-9;

vector<vector<double>> rotate_cube(double A) {
    double theta = acos(A / sqrt(2));
    double half_pi = acos(0);

    vector<vector<double>> face_centers(3, vector<double>(3, 0.0));
    face_centers[0][0] = 0.5;
    face_centers[1][1] = 0.5 * cos(theta);
    face_centers[1][2] = 0.5 * sin(theta);
    face_centers[2][1] = 0.5 * cos(half_pi - theta);
    face_centers[2][2] = 0.5 * sin(half_pi - theta);

    return face_centers;
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(10);

    for (int t = 1; t <= T; t++) {
        cin >> A;
        vector<vector<double>> face_centers = rotate_cube(A);
        cout << "Case #" << t << ":" << endl;
        for (const auto &face_center : face_centers) {
            cout << face_center[0] << " " << face_center[1] << " " << face_center[2] << endl;
        }
    }

    return 0;
}
