#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

vector<vector<double>> find_face_centers(double A) {
    double x = (A - 1) / sqrt(2);
    double y = (1 + x * x) / 2;

    return {
        {y, x, 0},
        {-x, y, 0},
        {0, 0, 0.5}
    };
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(10);

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<vector<double>> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto &center : face_centers) {
            cout << center[0] << " " << center[1] << " " << center[2] << endl;
        }
    }

    return 0;
}
