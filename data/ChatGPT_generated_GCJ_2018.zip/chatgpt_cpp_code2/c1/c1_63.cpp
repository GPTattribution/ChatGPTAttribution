#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(int caseNumber, double desiredArea) {
    double halfSide = 0.5;
    double maxArea = sqrt(2) * halfSide * halfSide;
    double angle = asin(desiredArea / maxArea);

    double x1 = halfSide * cos(angle);
    double z1 = halfSide * sin(angle);

    double x2 = halfSide * cos(angle + M_PI / 2);
    double z2 = halfSide * sin(angle + M_PI / 2);

    cout << "Case #" << caseNumber << ":" << endl;
    cout << fixed << setprecision(15) << x1 << " 0.0 " << z1 << endl;
    cout << x2 << " 0.0 " << z2 << endl;
    cout << "0.0 0.5 0.0" << endl;
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        double A;
        cin >> A;
        solve(i, A);
    }

    return 0;
}
