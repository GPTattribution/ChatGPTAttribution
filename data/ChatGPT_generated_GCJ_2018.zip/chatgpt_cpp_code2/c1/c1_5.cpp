#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(double A) {
    double angle = (acos(A / sqrt(2)) - M_PI_4) / 2;
    double a = 0.5 * cos(angle);
    double b = 0.5 * sin(angle);

    cout << fixed << setprecision(15);
    cout << a << " " << b << " " << 0.0 << endl;
    cout << -b << " " << a << " " << 0.0 << endl;
    cout << 0.0 << " " << 0.0 << " " << 0.5 << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        cout << "Case #" << t << ":" << endl;
        solve(A);
    }
    return 0;
}
