#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

const double EPSILON = 1e-6;

struct Point {
    double x, y, z;

    Point(double x, double y, double z) : x(x), y(y), z(z) {}
};

void solve(int case_num, double target_area) {
    double a = 0.5 * target_area / sqrt(2);

    Point p1(a, a, 0);
    Point p2(-a, a, 0);
    Point p3(0, 0, 0.5);

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(15) << p1.x << " " << p1.y << " " << p1.z << endl;
    cout << fixed << setprecision(15) << p2.x << " " << p2.y << " " << p2.z << endl;
    cout << fixed << setprecision(15) << p3.x << " " << p3.y << " " << p3.z << endl;
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        double a;
        cin >> a;
        solve(i, a);
    }

    return 0;
}
