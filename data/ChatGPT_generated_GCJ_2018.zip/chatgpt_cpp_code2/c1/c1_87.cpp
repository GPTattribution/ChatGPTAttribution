#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

int main() {
    int T;
    double A;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        cin >> A;

        double angle = asin(A / sqrt(2));
        double offsetX = 0.5 * cos(angle);
        double offsetZ = 0.5 * sin(angle);

        vector<vector<double>> faceCenters = {
            {offsetX, 0.5, offsetZ},
            {-offsetX, 0.5, offsetZ},
            {0, 0.5, 0.5}
        };

        cout << "Case #" << t << ":" << endl;
        for (const auto& faceCenter : faceCenters) {
            cout << faceCenter[0] << " " << faceCenter[1] << " " << faceCenter[2] << endl;
        }
    }

    return 0;
}
