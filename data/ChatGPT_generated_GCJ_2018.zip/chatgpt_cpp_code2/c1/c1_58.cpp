#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

int main() {
    int T;
    double A;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        cin >> A;

        double theta = asin(A / sqrt(2));

        vector<vector<double>> face_centers = {
            {0.5 * cos(theta), 0.5 * sin(theta), 0},
            {-0.5 * sin(theta), 0.5 * cos(theta), 0},
            {0, 0, 0.5}
        };

        cout << "Case #" << t << ":" << endl;
        cout << fixed << setprecision(10);
        for (const auto &face_center : face_centers) {
            for (const auto &coordinate : face_center) {
                cout << coordinate << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
