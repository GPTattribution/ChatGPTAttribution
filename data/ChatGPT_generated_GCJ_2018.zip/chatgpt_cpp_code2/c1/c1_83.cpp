#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

const double eps = 1e-9;

vector<double> find_face_centers(double A) {
    double s = sqrt(A);
    double alpha = asin(s / sqrt(2));

    double x = 0.5 * cos(alpha);
    double y = 0.5 * sin(alpha);

    return {x, y, 0.5, -x, y, 0.5, 0.5, 0.5, 0};
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<double> face_centers = find_face_centers(A);

        cout.precision(10);
        cout << "Case #" << t << ":" << endl;
        for (int i = 0; i < 3; ++i) {
            cout << face_centers[i * 3] << " " << face_centers[i * 3 + 1] << " " << face_centers[i * 3 + 2] << endl;
        }
    }

    return 0;
}
