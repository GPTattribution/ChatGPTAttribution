#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(int case_num, double A) {
    const double half = 0.5;
    const double eps = 1e-6;

    double theta = asin(A / sqrt(2)) / 2;

    double p1_x = half * cos(theta);
    double p1_y = half * sin(theta);
    double p1_z = 0;

    double p2_x = -half * cos(theta);
    double p2_y = half * sin(theta);
    double p2_z = 0;

    double p3_x = 0;
    double p3_y = 0;
    double p3_z = half;

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(10);
    cout << p1_x << " " << p1_y << " " << p1_z << endl;
    cout << p2_x << " " << p2_y << " " << p2_z << endl;
    cout << p3_x << " " << p3_y << " " << p3_z << endl;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        double A;
        cin >> A;
        solve(i, A);
    }
    return 0;
}
