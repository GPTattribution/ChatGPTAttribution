#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

const double PI = acos(-1);

void solve(int case_num, double A) {
    double angle = (A - 1) / (sqrt(2) - 1);
    double theta = angle * PI / 4;

    vector<vector<double>> face_centers = {
        {cos(theta) / 2, sin(theta) / 2, 0},
        {-sin(theta) / 2, cos(theta) / 2, 0},
        {0, 0, 0.5}
    };

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(15);
    for (const auto& face_center : face_centers) {
        for (const double& coord : face_center) {
            cout << coord << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        solve(t, A);
    }

    return 0;
}
