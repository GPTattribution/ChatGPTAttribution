#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

vector<vector<double>> find_face_centers(double A) {
    double angle = (A - 1) / (sqrt(2) - 1);
    double theta = asin(angle);

    vector<vector<double>> face_centers = {
        {0.5 * cos(theta), 0.5 * sin(theta), 0},
        {0.5 * cos(theta + M_PI / 2), 0.5 * sin(theta + M_PI / 2), 0},
        {0, 0, 0.5}
    };

    return face_centers;
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; ++t) {
        cin >> A;
        vector<vector<double>> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto &fc : face_centers) {
            cout << fc[0] << " " << fc[1] << " " << fc[2] << endl;
        }
    }

    return 0;
}
