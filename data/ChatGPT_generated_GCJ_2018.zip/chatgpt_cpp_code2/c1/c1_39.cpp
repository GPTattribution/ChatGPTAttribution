#include <iostream>
#include <cmath>
#include <vector>

const double EPS = 1e-9;

std::vector<double> find_face_centers(double A) {
    double phi = std::acos((A * A - 2) / (2 * A * A - 2));
    double theta = std::atan(A * std::sin(phi) / (A * std::cos(phi) - 1));

    std::vector<double> p1 = {0.5 * std::cos(theta), 0.5 * std::sin(theta), 0};
    std::vector<double> p2 = {0.5 * std::cos(theta + 2 * M_PI / 3), 0.5 * std::sin(theta + 2 * M_PI / 3), 0};
    std::vector<double> p3 = {0.5 * std::cos(theta + 4 * M_PI / 3), 0.5 * std::sin(theta + 4 * M_PI / 3), 0};

    return {p1[0], p1[1], p1[2], p2[0], p2[1], p2[2], p3[0], p3[1], p3[2]};
}

int main() {
    int T;
    double A;
    std::cin >> T;

    for (int t = 1; t <= T; ++t) {
        std::cin >> A;
        std::vector<double> face_centers = find_face_centers(A);
        std::cout << "Case #" << t << ":\n";
        for (int i = 0; i < 9; i += 3) {
            std::cout << face_centers[i] << ' ' << face_centers[i + 1] << ' ' << face_centers[i + 2] << '\n';
        }
    }

    return 0;
}
