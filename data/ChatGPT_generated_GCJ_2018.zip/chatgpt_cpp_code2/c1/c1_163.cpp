#include <iostream>
#include <cmath>
#include <vector>

const double EPS = 1e-6;

void solve(double A) {
    double alpha = asin((A - 1.0) / sqrt(2.0));

    double R[3][3] = {
        {cos(alpha), -sin(alpha), 0},
        {sin(alpha), cos(alpha), 0},
        {0, 0, 1}
    };

    std::vector<std::vector<double>> cube_face_centers = {
        {0.5, 0, 0},
        {0, 0.5, 0},
        {0, 0, 0.5}
    };

    std::vector<std::vector<double>> rotated_face_centers(3, std::vector<double>(3, 0));
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            for (int k = 0; k < 3; ++k) {
                rotated_face_centers[i][j] += R[i][k] * cube_face_centers[k][j];
            }
        }
    }

    for (const auto &center : rotated_face_centers) {
        printf("%.15lf %.15lf %.15lf\n", center[0], center[1], center[2]);
    }
}

int main() {
    int T;
    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;
        std::cout << "Case #" << t << ":\n";
        solve(A);
    }
    return 0;
}
