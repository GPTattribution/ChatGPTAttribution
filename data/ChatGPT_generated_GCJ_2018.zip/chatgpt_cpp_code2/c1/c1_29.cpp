#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

const double PI = acos(-1);

void solve(int t, double A) {
    double theta = acos(A / sqrt(2));

    double p1x = 0.5 * cos(theta);
    double p1z = 0.5 * sin(theta);
    double p2x = 0.5 * cos(theta + PI / 2);
    double p2z = 0.5 * sin(theta + PI / 2);

    cout << "Case #" << t << ":" << endl;
    cout << fixed << setprecision(15) << p1x << " 0 " << p1z << endl;
    cout << fixed << setprecision(15) << p2x << " 0 " << p2z << endl;
    cout << "0 0.5 0" << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        solve(t, A);
    }
    return 0;
}
