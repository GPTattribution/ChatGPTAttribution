#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void rotate(double a) {
    double theta = acos(a / sqrt(2));
    double half_side = 0.5;

    double x1 = half_side * cos(theta);
    double z1 = half_side * sin(theta);

    double x2 = -half_side * cos(theta);
    double z2 = half_side * sin(theta);

    double y = 0;

    cout << fixed << setprecision(10);
    cout << x1 << " " << y << " " << z1 << endl;
    cout << x2 << " " << y << " " << z2 << endl;
    cout << 0 << " " << half_side << " " << 0 << endl;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        cout << "Case #" << t << ":" << endl;
        rotate(A);
    }

    return 0;
}
