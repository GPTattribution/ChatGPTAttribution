#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPS = 1e-6;
const double PI = acos(-1);

void solve(int t, double A) {
    double theta = asin(A / sqrt(2));

    double x1 = 0.5 * cos(theta);
    double y1 = 0.5 * sin(theta);
    double x2 = 0.5 * cos(PI / 4 - theta);
    double y2 = 0.5 * sin(PI / 4 - theta);

    cout << "Case #" << t << ":" << endl;
    cout << fixed << setprecision(10) << x1 << " " << y1 << " " << 0.0 << endl;
    cout << -x2 << " " << y2 << " " << 0.0 << endl;
    cout << 0.0 << " " << 0.5 << " " << 0.0 << endl;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        solve(t, A);
    }

    return 0;
}
