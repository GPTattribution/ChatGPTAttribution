#include <iostream>
#include <cmath>
#include <vector>

const double PI = std::acos(-1);

void solve(int case_num, double target_area) {
double theta = std::acos(target_area / std::sqrt(2.0));
double phi = PI / 4.0;
std::vector<std::vector<double>> face_centers = {
    {0.5 * std::cos(theta) * std::cos(phi), 0.5 * std::cos(theta) * std::sin(phi), 0.5 * std::sin(theta)},
    {0.5 * std::sin(theta) * std::cos(phi + PI / 2.0), 0.5 * std::sin(theta) * std::sin(phi + PI / 2.0), 0.5 * std::cos(theta)},
    {0.5 * std::cos(phi), 0.5 * std::sin(phi), -0.5 * std::sin(theta)}
};

std::cout << "Case #" << case_num << ":\n";
for (const auto &face_center : face_centers) {
    for (const auto &coord : face_center) {
        std::cout << coord << " ";
    }
    std::cout << "\n";
}
}

int main() {
int T;
std::cin >> T;
for (int i = 1; i <= T; ++i) {
    double A;
    std::cin >> A;
    solve(i, A);
}

return 0;
}
