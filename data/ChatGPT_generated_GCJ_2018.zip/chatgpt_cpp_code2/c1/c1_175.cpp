#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

const double PI = acos(-1);
const double EPS = 1e-9;

struct Point {
    double x, y, z;
};

Point getFaceCenter(double angle) {
    double R = 0.5;
    double a = angle;
    double b = PI / 4;
    double c = PI / 2 - b - a;

    double Y = R * sin(a) / sin(c);
    double X = sqrt(R * R - Y * Y);

    return {X, Y, sqrt(0.25 - X * X - Y * Y)};
}

void solve(int caseNum, double A) {
    double targetAngle = 2 * acos((A - 1.0) / sqrt(2.0));

    Point p1 = getFaceCenter(targetAngle / 2);
    Point p2 = getFaceCenter(targetAngle / 2 + PI / 2);
    Point p3 = getFaceCenter(targetAngle / 2 + PI);

    cout << "Case #" << caseNum << ":" << endl;
    cout << fixed << setprecision(15);
    cout << p1.x << " " << p1.y << " " << p1.z << endl;
    cout << p2.x << " " << p2.y << " " << p2.z << endl;
    cout << p3.x << " " << p3.y << " " << p3.z << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;
        solve(t, A);
    }
    return 0;
}
