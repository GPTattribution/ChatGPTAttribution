#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(double A) {
double angle = asin(A / sqrt(2));
double a = 0.5 * cos(angle);
double b = 0.5 * sin(angle);
cout << fixed << setprecision(10);
cout << a << " " << b << " " << 0 << endl;
cout << -b << " " << a << " " << 0 << endl;
cout << 0 << " " << 0 << " " << 0.5 << endl;
}

int main() {
int T;
cin >> T;
for (int i = 1; i <= T; ++i) {
    double A;
    cin >> A;

    cout << "Case #" << i << ":" << endl;
    solve(A);
}

return 0;
}
