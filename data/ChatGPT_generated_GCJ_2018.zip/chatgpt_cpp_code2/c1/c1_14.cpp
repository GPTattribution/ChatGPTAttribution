#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

vector<vector<double>> get_face_centers(double A) {
    double theta = acos(A / sqrt(2));
    double x = 0.5 * cos(theta);
    double z = 0.5 * sin(theta);

    return {
        {x, 0.5, z},
        {-x, 0.5, z},
        {0, 0.5, 0.5}
    };
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(10);

    for (int t = 1; t <= T; ++t) {
        cin >> A;
        auto face_centers = get_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto &point : face_centers) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
