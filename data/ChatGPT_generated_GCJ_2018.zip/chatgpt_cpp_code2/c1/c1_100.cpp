#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPSILON = 1e-9;

vector<vector<double>> find_face_centers(double target_area) {
    double half_side = 0.5;
    double alpha = asin(target_area / (sqrt(2.0) * half_side * half_side));
    double c = cos(alpha);
    double s = sin(alpha);

    vector<vector<double>> face_centers(3, vector<double>(3));

    face_centers[0][0] = c * half_side;
    face_centers[0][1] = 0;
    face_centers[0][2] = s * half_side;

    face_centers[1][0] = -s * half_side;
    face_centers[1][1] = 0;
    face_centers[1][2] = c * half_side;

    face_centers[2][0] = 0;
    face_centers[2][1] = half_side;
    face_centers[2][2] = 0;

    return face_centers;
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(12);

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<vector<double>> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto &face_center : face_centers) {
            for (const double coordinate : face_center) {
                cout << coordinate << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
