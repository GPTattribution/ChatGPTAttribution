#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(int case_num, double A) {
    double a = (A - 1.0) / sqrt(2);
    double x = 0.5 - 0.5 * a;
    double z = 0.5 * a;

    cout << "Case #" << case_num << ":\n";
    cout << fixed << setprecision(15) << x << " " << 0.0 << " " << z << "\n";
    cout << -x << " " << 0.0 << " " << z << "\n";
    cout << 0.0 << " " << 0.5 << " " << 0.0 << endl;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        solve(t, A);
    }

    return 0;
}
dd
