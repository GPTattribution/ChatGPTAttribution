#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

const double EPSILON = 1e-6;

void solve(double A) {
    double theta = acos(A / sqrt(2.0));
    double half_side = 0.5;

    std::vector<std::vector<double>> face_centers(3, std::vector<double>(3));

    face_centers[0][0] = half_side * cos(theta);
    face_centers[0][1] = half_side * sin(theta);
    face_centers[0][2] = 0;

    face_centers[1][0] = -half_side * sin(theta);
    face_centers[1][1] = half_side * cos(theta);
    face_centers[1][2] = 0;

    face_centers[2][0] = 0;
    face_centers[2][1] = half_side;
    face_centers[2][2] = half_side;

    for (const auto& point : face_centers) {
        std::cout << std::fixed << std::setprecision(15) << point[0] << " " << point[1] << " " << point[2] << std::endl;
    }
}

int main() {
    int T;
    double A;
    std::cin >> T;

    for (int i = 1; i <= T; ++i) {
        std::cin >> A;
        std::cout << "Case #" << i << ":" << std::endl;
        solve(A);
    }

    return 0;
}
