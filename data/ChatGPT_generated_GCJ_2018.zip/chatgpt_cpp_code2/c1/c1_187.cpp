#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

vector<double> findRotation(double A) {
    double a = A / sqrt(2);
    double angle = acos(a / 0.5);
    double half_pi = acos(0);

    return {
        0.5 * cos(angle),
        0.5 * sin(angle),
        0.5 * cos(half_pi - angle),
    };
}

int main() {
    int T;
    cin >> T;

    cout << setprecision(12) << fixed;

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        auto p1 = findRotation(A);
        auto p2 = findRotation(acos(0) - A);
        auto p3 = findRotation(acos(-1) / 2 - A);

        cout << "Case #" << t << ":" << endl;
        cout << p1[0] << " " << p1[1] << " " << p1[2] << endl;
        cout << p2[0] << " " << p2[1] << " " << p2[2] << endl;
        cout << p3[0] << " " << p3[1] << " " << p3[2] << endl;
    }

    return 0;
}
