#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

const double EPS = 1e-6;
const double PI = acos(-1.0);

double calculateShadowArea(double alpha, double beta) {
    double x1 = 0.5 * cos(alpha) * cos(beta);
    double z1 = 0.5 * cos(alpha) * sin(beta);
    double y1 = 0.5 * sin(alpha);
    double x2 = 0.5 * cos(alpha - PI / 2) * cos(beta);
    double z2 = 0.5 * cos(alpha - PI / 2) * sin(beta);
    double y2 = 0.5 * sin(alpha - PI / 2);
    double x3 = 0.5 * cos(alpha) * cos(beta - PI / 2);
    double z3 = 0.5 * cos(alpha) * sin(beta - PI / 2);
    double y3 = 0.5 * sin(alpha);

    return abs((y1 + 3) * (x2 * z3 - z2 * x3) + (y2 + 3) * (x3 * z1 - z3 * x1) + (y3 + 3) * (x1 * z2 - z1 * x2));
}

void solve(int case_num, double A) {
    double alpha = 0, beta = 0;
    double low = 0, high = PI / 2;
    while (abs(calculateShadowArea(alpha, beta) - A) > EPS) {
        if (calculateShadowArea(alpha + EPS, beta) > A) {
            high = alpha;
            alpha = (low + alpha) / 2;
        } else {
            low = alpha;
            alpha = (alpha + high) / 2;
        }
    }

    double x1 = 0.5 * cos(alpha) * cos(beta);
    double z1 = 0.5 * cos(alpha) * sin(beta);
    double y1 = 0.5 * sin(alpha);
    double x2 = 0.5 * cos(alpha - PI / 2) * cos(beta);
    double z2 = 0.5 * cos(alpha - PI / 2) * sin(beta);
    double y2 = 0.5 * sin(alpha - PI / 2);
    double x3 = 0.5 * cos(alpha) * cos(beta - PI / 2);
    double z3 = 0.5 * cos(alpha) * sin(beta - PI / 2);
    double y3 = 0.5 * sin(alpha);

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(10) << x1 << " " << y1 << " " << z1 << endl;
    cout << x2 << " " << y2 << " " << z2 << endl;
    cout << x3 << " " << y3 << " " << z3 << endl;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        double A;
        cin >> A;
        solve(i, A);
    }
    return 0;
}
