#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

const double eps = 1e-9;

std::vector<std::vector<double>> find_rotation(double A) {
    double a = acos((A - 1.0) / sqrt(2.0));
    double x = 0.5 * cos(a);
    double z = 0.5 * sin(a);

    return {
        { x, 0.5, z},
        {-x, 0.5, z},
        { 0, 0.5, 0.5},
    };
}

int main() {
    int T;
    std::cin >> T;

    std::cout << std::fixed << std::setprecision(15);
    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;
        auto points = find_rotation(A);

        std::cout << "Case #" << t << ":\n";
        for (const auto& point : points) {
            std::cout << point[0] << ' ' << point[1] << ' ' << point[2] << '\n';
        }
    }

    return 0;
}
