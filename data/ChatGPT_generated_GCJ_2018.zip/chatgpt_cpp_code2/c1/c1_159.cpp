#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

vector<double> find_face_centers(double A) {
    double theta = acos(A / sqrt(2));
    double half_side = 0.5;

    vector<double> p1 = {half_side * cos(theta), half_side * sin(theta), 0};
    vector<double> p2 = {half_side * cos(theta + M_PI / 2), half_side * sin(theta + M_PI / 2), 0};
    vector<double> p3 = {0, 0, half_side};

    return {p1[0], p1[1], p1[2], p2[0], p2[1], p2[2], p3[0], p3[1], p3[2]};
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<double> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (int i = 0; i < 9; i += 3) {
            cout << face_centers[i] << " " << face_centers[i + 1] << " " << face_centers[i + 2] << endl;
        }
    }

    return 0;
}
