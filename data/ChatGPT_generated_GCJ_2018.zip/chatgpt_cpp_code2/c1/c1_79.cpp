#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

int main() {
    int T;
    double A;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        cin >> A;

        double alpha = acos(A / sqrt(2));
        double beta = (M_PI / 4) - alpha;
        double x = 0.5 * cos(beta);
        double z = 0.5 * sin(beta);

        vector<vector<double>> face_centers = {
            { x, 0, z},
            {-x, 0, z},
            { 0, 0, 0.5}
        };

        cout << "Case #" << t << ":" << endl;
        for (auto& face_center : face_centers) {
            cout << face_center[0] << " " << face_center[1] << " " << face_center[2] << endl;
        }
    }

    return 0;
}
