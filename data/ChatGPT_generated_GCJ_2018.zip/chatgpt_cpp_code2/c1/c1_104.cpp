#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(double A) {
double theta = asin(A / sqrt(2)) / 2;
double x1 = 0.5 * cos(theta);
double z1 = 0.5 * sin(theta);
double x2 = -0.5 * sin(theta);
double z2 = 0.5 * cos(theta);

cout << fixed << setprecision(15);
cout << x1 << " " << 0.0 << " " << z1 << endl;
cout << x2 << " " << 0.0 << " " << z2 << endl;
cout << 0.0 << " " << 0.5 << " " << 0.0 << endl;
}

int main() {
int T;
cin >> T;
for (int t = 1; t <= T; ++t) {
    double A;
    cin >> A;

    cout << "Case #" << t << ":" << endl;
    solve(A);
}

return 0;
}
