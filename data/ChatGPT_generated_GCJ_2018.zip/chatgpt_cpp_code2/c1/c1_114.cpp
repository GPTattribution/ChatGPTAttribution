#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(int t, double A) {
    cout << "Case #" << t << ":" << endl;

    double theta = acos(A / sqrt(2));
    double cos_theta = cos(theta);
    double sin_theta = sin(theta);

    cout << setprecision(15);
    cout << 0.5 * cos_theta << " " << 0.5 * sin_theta << " " << 0.0 << endl;
    cout << -0.5 * sin_theta << " " << 0.5 * cos_theta << " " << 0.0 << endl;
    cout << 0.0 << " " << 0.0 << " " << 0.5 << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        solve(t, A);
    }
    return 0;
}
