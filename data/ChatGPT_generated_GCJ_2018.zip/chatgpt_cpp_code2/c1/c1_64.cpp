#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

vector<vector<double>> find_face_centers(double A) {
    double angle = (A - 1.0) * (M_PI / 4.0) / (sqrt(2) - 1.0);
    double x = 0.5 * cos(angle);
    double z = 0.5 * sin(angle);

    vector<vector<double>> face_centers = {
        {x, 0.5, z},
        {-x, 0.5, -z},
        {0, 0.5, 0.5}
    };

    return face_centers;
}

int main() {
    int T;
    double A;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        cin >> A;
        vector<vector<double>> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto& center : face_centers) {
            cout << fixed << setprecision(10) << center[0] << " " << center[1] << " " << center[2] << endl;
        }
    }

    return 0;
}
