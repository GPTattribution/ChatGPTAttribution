#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void rotate_cube(double A) {
double half = 0.5;
double pi = acos(-1.0);
double theta = asin(A / (sqrt(2.0) * half)) / 2.0;

double p1_x = half * cos(theta);
double p1_y = half * sin(theta);
double p2_x = half * cos(pi / 4.0 - theta);
double p2_y = half * sin(pi / 4.0 - theta);

cout << fixed << setprecision(10)
     << p1_x << " " << p1_y << " " << 0.0 << endl
     << -p2_x << " " << p2_y << " " << 0.0 << endl
     << 0.0 << " " << half << " " << 0.0 << endl;
   }

   int main() {
   int T;
   cin >> T;
   for (int i = 1; i <= T; i++) {
    double A;
    cin >> A;
    cout << "Case #" << i << ":" << endl;
    rotate_cube(A);
}

return 0;
}
