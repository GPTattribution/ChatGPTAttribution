#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

vector<vector<double>> findRotation(double A) {
    double theta = acos(A / sqrt(3));
    double u = 0.5 * cos(theta);
    double v = 0.5 * sin(theta);
    return {
        {u, v, 0},
        {-v, u, 0},
        {0, 0, 0.5}
    };
}

int main() {
    int T;
    cin >> T;
    cout << fixed << setprecision(10);

    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;

        vector<vector<double>> rotation = findRotation(A);
        cout << "Case #" << i << ":" << endl;
        for (const auto &face_center : rotation) {
            cout << face_center[0] << " " << face_center[1] << " " << face_center[2] << endl;
        }
    }

    return 0;
}
