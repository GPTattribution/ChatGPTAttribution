#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

int main() {
    int T;
    double A;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        cin >> A;

        double theta = asin(A / sqrt(2));

        vector<vector<double>> face_centers(3, vector<double>(3, 0));
        face_centers[0][0] = 0.5 * cos(theta);
        face_centers[0][1] = 0.5 * sin(theta);

        face_centers[1][0] = -0.5 * sin(theta);
        face_centers[1][1] = 0.5 * cos(theta);

        face_centers[2][2] = 0.5;

        cout << "Case #" << t << ":" << endl;
        for (const auto& face_center : face_centers) {
            for (double coord : face_center) {
                cout << coord << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
