#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

const double eps = 1e-6;

void solve(int test_case, double A) {
    double theta = acos(A / sqrt(2));
    double face_center_x = 0.5 * cos(theta);
    double face_center_y = 0.5 * sin(theta);

    cout << "Case #" << test_case << ":" << endl;
    cout.precision(12);
    cout << face_center_x << " " << face_center_y << " " << 0.0 << endl;
    cout << -face_center_y << " " << face_center_x << " " << 0.0 << endl;
    cout << 0.0 << " " << 0.0 << " " << 0.5 << endl;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;
        solve(i, A);
    }
    return 0;
}
