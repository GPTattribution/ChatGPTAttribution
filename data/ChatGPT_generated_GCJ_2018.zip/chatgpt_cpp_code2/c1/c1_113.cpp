#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

const double pi = acos(-1.0);

void solve(double A) {
    double phi = acos(A / sqrt(2));
    double theta = pi / 4 - phi / 2;

    std::vector<std::vector<double>> face_centers(3, std::vector<double>(3));

    face_centers[0][0] = 0.5 * cos(theta);
    face_centers[0][1] = 0.5;
    face_centers[0][2] = 0.5 * sin(theta);

    face_centers[1][0] = 0.5 * sin(theta);
    face_centers[1][1] = 0.5;
    face_centers[1][2] = -0.5 * cos(theta);

    face_centers[2][0] = 0;
    face_centers[2][1] = 0.5;
    face_centers[2][2] = 0.5;

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            std::cout << std::fixed << std::setprecision(10) << face_centers[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

int main() {
    int T;
    std::cin >> T;
    for (int t = 1; t <= T; t++) {
        double A;
        std::cin >> A;
        std::cout << "Case #" << t << ":" << std::endl;
        solve(A);
    }
    return 0;
}
