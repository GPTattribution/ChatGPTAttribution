#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

const double EPSILON = 1e-6;
const double PI = acos(-1);

vector<double> find_rotation(double target_area) {
    double theta = acos(target_area / sqrt(3));

    double x = 0.5 * sin(theta);
    double z = 0.5 * cos(theta);

    return {x, 0.5, z};
}

int main() {
    int T;
    cin >> T;

    for (int test_case = 1; test_case <= T; ++test_case) {
        double A;
        cin >> A;

        auto rotation = find_rotation(A);
        double x = rotation[0];
        double z = rotation[2];

        cout << "Case #" << test_case << ":" << endl;
        cout << x << " " << 0.5 << " " << z << endl;
        cout << -x << " " << 0.5 << " " << -z << endl;
        cout << 0 << " " << 0.5 << " " << 0.5 << endl;
    }

    return 0;
}
