#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double PI = acos(-1.0);

void solve(double A) {
    double theta = acos(A / sqrt(2));
    double phi = PI / 4 - theta / 2;

    double x = 0.5 * cos(phi);
    double z = 0.5 * sin(phi);

    cout << fixed << setprecision(15);
    cout << x << " " << 0.0 << " " << z << endl;
    cout << -x << " " << 0.0 << " " << z << endl;
    cout << 0.0 << " " << 0.5 << " " << 0.0 << endl;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        cout << "Case #" << t << ":" << endl;
        solve(A);
    }

    return 0;
}
