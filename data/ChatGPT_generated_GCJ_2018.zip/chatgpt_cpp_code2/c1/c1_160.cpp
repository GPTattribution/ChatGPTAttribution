#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

const double EPS = 1e-6;

void solve(int case_number, double A) {
    double theta = acos(A / sqrt(2.0)) / 2.0;
    double r = 0.5;

    vector<vector<double>> face_centers(3, vector<double>(3));

    face_centers[0][0] = r * cos(theta);
    face_centers[0][1] = r * sin(theta);
    face_centers[0][2] = 0.0;

    face_centers[1][0] = -r * cos(theta);
    face_centers[1][1] = r * sin(theta);
    face_centers[1][2] = 0.0;

    face_centers[2][0] = 0.0;
    face_centers[2][1] = r * cos(theta);
    face_centers[2][2] = r * sin(theta);

    cout << "Case #" << case_number << ":" << endl;
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            cout << face_centers[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;
        solve(i, A);
    }
    return 0;
}
