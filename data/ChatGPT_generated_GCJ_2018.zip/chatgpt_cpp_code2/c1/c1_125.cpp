#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

const double EPS = 1e-6;

vector<vector<double>> find_face_centers(double A) {
    double angle = (A - 1.0) / (sqrt(2.0) - 1.0);
    double r_angle = angle * M_PI / 4;
    double x = 0.5 * cos(r_angle);
    double z = 0.5 * sin(r_angle);

    vector<vector<double>> face_centers = {
        {x, 0.5, z},
        {-x, 0.5, -z},
        {0, 0.5, 0.5}
    };

    return face_centers;
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(10);
    for (int t = 1; t <= T; ++t) {
        cin >> A;
        vector<vector<double>> face_centers = find_face_centers(A);
        cout << "Case #" << t << ":" << endl;
        for (const auto &point : face_centers) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
