#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

vector<vector<double>> solve(double A) {
    double theta = acos((A - 1) / sqrt(2));
    double half_side = 0.5;

    double cosTheta = cos(theta);
    double sinTheta = sin(theta);
    double cos45 = cos(M_PI / 4);
    double sin45 = sin(M_PI / 4);

    vector<vector<double>> points(3, vector<double>(3));

    points[0][0] = half_side * (cosTheta * cos45 - sinTheta * sin45);
    points[0][1] = half_side * (sinTheta * cos45 + cosTheta * sin45);
    points[0][2] = 0;

    points[1][0] = half_side * (cosTheta * cos45 + sinTheta * sin45);
    points[1][1] = half_side * (cosTheta * sin45 - sinTheta * cos45);
    points[1][2] = 0;

    points[2][0] = 0;
    points[2][1] = half_side * cosTheta;
    points[2][2] = half_side * sinTheta;

    return points;
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << setprecision(15);

    for (int t = 1; t <= T; ++t) {
        cin >> A;
        auto points = solve(A);
        cout << "Case #" << t << ":" << endl;
        for (const auto &point : points) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
