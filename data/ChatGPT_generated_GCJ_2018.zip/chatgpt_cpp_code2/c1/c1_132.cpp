#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

const double PI = acos(-1);

vector<double> find_face_centers(double A) {
    double theta = 2 * PI / 3;
    double phi = acos(A / sqrt(3) - 1);

    double x1 = 0.5 * cos(theta) * sin(phi);
    double y1 = 0.5 * sin(theta) * sin(phi);
    double z1 = 0.5 * cos(phi);

    double x2 = 0.5 * cos(theta + 2 * PI / 3) * sin(phi);
    double y2 = 0.5 * sin(theta + 2 * PI / 3) * sin(phi);
    double z2 = z1;

    double x3 = 0.5 * cos(theta - 2 * PI / 3) * sin(phi);
    double y3 = 0.5 * sin(theta - 2 * PI / 3) * sin(phi);
    double z3 = z1;

    return {x1, y1, z1, x2, y2, z2, x3, y3, z3};
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<double> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (int i = 0; i < 9; i += 3) {
            cout << face_centers[i] << " " << face_centers[i + 1] << " " << face_centers[i + 2] << endl;
        }
    }

    return 0;
}
