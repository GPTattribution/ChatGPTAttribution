#include <iostream>
#include <cmath>
#include <vector>

const double EPSILON = 1e-6;

std::vector<double> findRotation(double A) {
    double theta = 2.0 * (A - 1.0) / sqrt(2);
    double phi = (M_PI / 4.0) - theta / 2.0;

    return {
        0.5 * cos(phi), 0.5 * sin(phi), 0,
        -0.5 * sin(phi), 0.5 * cos(phi), 0,
        0, 0, 0.5
    };
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;

        std::vector<double> rotation = findRotation(A);

        std::cout << "Case #" << t << ":" << std::endl;
        for (int i = 0; i < 9; i += 3) {
            std::cout << rotation[i] << " " << rotation[i + 1] << " " << rotation[i + 2] << std::endl;
        }
    }

    return 0;
}
