#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPS = 1e-6;
const double PI = acos(-1);

void solve(int case_num, double A) {
    double angle = (A - 1) * (PI / 4) / (sqrt(2) - 1);
    double x = 0.5 * cos(angle);
    double z = 0.5 * sin(angle);

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(10) << x << " " << 0.0 << " " << z << endl;
    cout << -z << " " << 0.0 << " " << x << endl;
    cout << 0.0 << " " << 0.5 << " " << 0.0 << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        solve(t, A);
    }
    return 0;
}
