#include <iostream>
#include <cmath>
#include <iomanip>

void solve(int t, double A) {
    double theta = std::acos(A / std::sqrt(2));
    double p1_x = 0.5 * std::cos(theta);
    double p1_z = 0.5 * std::sin(theta);
    double p2_x = 0.5 * std::cos(theta + M_PI / 2);
    double p2_z = 0.5 * std::sin(theta + M_PI / 2);

    std::cout << std::fixed << std::setprecision(15);
    std::cout << "Case #" << t << ":\n";
    std::cout << p1_x << " " << 0.0 << " " << p1_z << "\n";
    std::cout << p2_x << " " << 0.0 << " " << p2_z << "\n";
    std::cout << 0.0 << " " << 0.5 << " " << 0.0 << "\n";
}

int main() {
    int T;
    double A;
    std::cin >> T;

    for (int t = 1; t <= T; ++t) {
        std::cin >> A;
        solve(t, A);
    }

    return 0;
}
