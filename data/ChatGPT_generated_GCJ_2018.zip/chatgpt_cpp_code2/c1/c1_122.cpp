#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPS = 1e-6;
const double PI = acos(-1.0);

vector<vector<double>> rotate(double a) {
    double theta = acos(a / sqrt(2));
    double phi = theta - PI / 4;

    vector<vector<double>> face_centers(3, vector<double>(3, 0));

    face_centers[0][0] = 0.5 * cos(phi);
    face_centers[0][1] = 0.5 * sin(phi);

    face_centers[1][0] = -0.5 * sin(phi);
    face_centers[1][1] = 0.5 * cos(phi);

    face_centers[2][2] = 0.5;

    return face_centers;
}

int main() {
    int T;
    double A;

    cin >> T;

    for (int i = 1; i <= T; i++) {
        cin >> A;

        vector<vector<double>> face_centers = rotate(A);

        cout << "Case #" << i << ":" << endl;
        cout << fixed << setprecision(15);
        for (int j = 0; j < 3; j++) {
            for (int k = 0; k < 3; k++) {
                cout << face_centers[j][k] << (k < 2 ? ' ' : '\n');
            }
        }
    }

    return 0;
}
