#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

const double eps = 1e-9;

vector<vector<double>> find_rotation(double A) {
    double a = A / sqrt(2);
    double angle = asin(a) / 2;
    double x = 0.5 * cos(angle);
    double z = 0.5 * sin(angle);

    return {
        {x, 0.5, z},
        {-x, 0.5, z},
        {0, 0.5, 0}
    };
}

int main() {
    int T;
    cin >> T;
    cout << fixed << setprecision(10);

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        vector<vector<double>> rotation = find_rotation(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto &point : rotation) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
