#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

const double EPS = 1e-6;

void solve(double A) {
    double theta = acos(A / sqrt(2));
    double alpha = theta / 2;

    double x1 = 0.5 * cos(alpha);
    double z1 = 0.5 * sin(alpha);

    double x2 = 0.5 * cos(alpha + M_PI / 2);
    double z2 = 0.5 * sin(alpha + M_PI / 2);

    vector<vector<double>> face_centers = {
        {x1, 0, z1},
        {x2, 0, z2},
        {0, 0.5, 0}
    };

    for (const auto &face_center : face_centers) {
        for (double coord : face_center) {
            cout << setprecision(10) << coord << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        cout << "Case #" << t << ":" << endl;
        solve(A);
    }

    return 0;
}
