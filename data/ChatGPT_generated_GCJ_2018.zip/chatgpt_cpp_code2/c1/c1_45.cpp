#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

vector<vector<double>> find_face_centers(double A) {
    double theta = acos(A / sqrt(3));
    double phi = 0.5 * M_PI - theta;

    vector<vector<double>> face_centers(3, vector<double>(3, 0.0));
    face_centers[0] = {0.5 * cos(phi), 0.5 * sin(phi), 0.0};
    face_centers[1] = {-0.5 * sin(phi) * cos(phi), 0.5 * sin(phi) * sin(phi), 0.5 * cos(phi)};
    face_centers[2] = {0.5 * sin(phi) * cos(phi), 0.5 * sin(phi) * sin(phi), 0.5 * cos(phi)};

    return face_centers;
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; t++) {
        cin >> A;
        vector<vector<double>> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto& face_center : face_centers) {
            cout << face_center[0] << " " << face_center[1] << " " << face_center[2] << endl;
        }
    }

    return 0;
}
