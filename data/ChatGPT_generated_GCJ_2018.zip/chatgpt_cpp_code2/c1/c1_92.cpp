#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

vector<vector<double>> find_rotation(double A) {
    double theta = acos(A / sqrt(2.0)) / 2;
    double half_side = 0.5;

    double x = half_side * cos(theta);
    double z = half_side * sin(theta);

    return {
        {x, half_side, z},
        {-x, half_side, z},
        {0, half_side, -half_side},
    };
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(12);

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<vector<double>> rotation = find_rotation(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto& point : rotation) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
