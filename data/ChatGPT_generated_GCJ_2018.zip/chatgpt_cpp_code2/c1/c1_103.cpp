#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

double getAngle(double area) {
    return acos(area / sqrt(2));
}

vector<vector<double>> getFaceCenters(double angle) {
    double x = 0.5 * cos(angle);
    double z = 0.5 * sin(angle);

    return {
        {x, 0.5, z},
        {-x, 0.5, z},
        {0, 0.5, 0.5}
    };
}

int main() {
    int T;
    double A;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        cin >> A;
        double angle = getAngle(A);
        vector<vector<double>> faceCenters = getFaceCenters(angle);

        cout << "Case #" << t << ":" << endl;
        for (const auto &center : faceCenters) {
            cout << center[0] << " " << center[1] << " " << center[2] << endl;
        }
    }

    return 0;
}
