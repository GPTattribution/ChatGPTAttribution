#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double PI = acos(-1);

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        double angle = asin(A / sqrt(2));

        double x = 0.5 * cos(angle);
        double y = 0.5 * sin(angle);

        cout << fixed << setprecision(10);
        cout << "Case #" << t << ":" << endl;
        cout << x << " " << y << " " << 0.0 << endl;
        cout << -y << " " << x << " " << 0.0 << endl;
        cout << 0.0 << " " << 0.0 << " " << 0.5 << endl;
    }

    return 0;
}
