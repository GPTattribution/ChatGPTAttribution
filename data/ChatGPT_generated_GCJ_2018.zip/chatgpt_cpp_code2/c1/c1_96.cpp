#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

double A;
const double EPS = 1e-6;
const double PI = acos(-1.0);

vector<vector<double>> find_face_centers(double A) {
    double theta = acos(A / sqrt(2));
    double phi = PI / 4;
    double sin_theta = sin(theta);
    double cos_theta = cos(theta);

    return {
        {0.5 * cos_theta * cos(phi), 0.5 * sin_theta, 0.5 * cos_theta * sin(phi)},
        {0.5 * cos_theta * cos(phi + PI / 2), 0.5 * sin_theta, 0.5 * cos_theta * sin(phi + PI / 2)},
        {0.5 * cos_theta * cos(phi + PI), 0.5 * sin_theta, 0.5 * cos_theta * sin(phi + PI)},
    };
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int test_case = 1; test_case <= T; ++test_case) {
        cin >> A;

        vector<vector<double>> face_centers = find_face_centers(A);

        cout << "Case #" << test_case << ":" << endl;
        for (const auto &face_center : face_centers) {
            cout << face_center[0] << " " << face_center[1] << " " << face_center[2] << endl;
        }
    }

    return 0;
}
