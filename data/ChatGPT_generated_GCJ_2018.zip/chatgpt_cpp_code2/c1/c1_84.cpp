#include <iostream>
#include <cmath>
#include <iomanip>

const double EPSILON = 1e-6;

void solve(int case_num, double A) {
    double theta = 2 * acos((A - 1) / (sqrt(2) - 1));

    double half_side = 0.5;
    double x = half_side * cos(theta);
    double z = half_side * sin(theta);

    std::cout << "Case #" << case_num << ":" << std::endl;
    std::cout << std::fixed << std::setprecision(15) << x << " 0.5 0" << std::endl;
    std::cout << "0 0.5 " << z << std::endl;
    std::cout << x << " 0.5 " << -z << std::endl;
}

int main() {
    int T;
    std::cin >> T;

    for (int i = 1; i <= T; ++i) {
        double A;
        std::cin >> A;
        solve(i, A);
    }

    return 0;
}
