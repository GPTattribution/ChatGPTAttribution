#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPS = 1e-6;

void solve(int case_num, double A) {
    cout << "Case #" << case_num << ":\n";

    double half_diag = sqrt(2) / 2;
    double max_area = 1.732050;

    if (A <= 1.414213) {
        double angle = (A - 1) / (half_diag - 1);
        double x = 0.5 * angle;
        double z = 0.5 * sqrt(1 - angle * angle);
        cout << fixed << setprecision(10) << x << " 0 " << z << "\n";
        cout << "0 0.5 0\n";
        cout << z << " 0 " << x << "\n";
    } else {
        double angle = (A - 1.414213) / (max_area - 1.414213);
        double r = half_diag * (1 - angle);
        double x = r / sqrt(2);
        cout << fixed << setprecision(10) << x << " " << x << " 0\n";
        cout << x << " " << -x << " 0\n";
        cout << "0 0 0.5\n";
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        solve(t, A);
    }
    return 0;
}
