#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

const double EPSILON = 1e-6;

double compute_area(double a) {
    double l = 0.5, r = 1.0;
    while (r - l > EPSILON) {
        double m = (l + r) / 2.0;
        double b = sqrt(0.5 * 0.5 - m * m);
        double area = 2 * m * b;

        if (area < a) {
            l = m;
        } else {
            r = m;
        }
    }
    return (l + r) / 2.0;
}

vector<vector<double>> get_face_centers(double a) {
    double b = compute_area(a);
    return {
        {b, 0.5, 0},
        {-b, 0.5, 0},
        {0, 0.5, b},
    };
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<vector<double>> face_centers = get_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto& center : face_centers) {
            for (double coord : center) {
                cout << coord << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
