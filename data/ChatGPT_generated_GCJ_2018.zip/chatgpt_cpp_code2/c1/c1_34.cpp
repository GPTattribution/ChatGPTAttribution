#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

vector<vector<double>> find_rotation(double area) {
    double angle = (area - 1.0) / (sqrt(2) - 1.0);
    double theta = angle * M_PI / 4.0;

    vector<vector<double>> result = {
        {0.5 * cos(theta), 0.5 * sin(theta), 0},
        {-0.5 * sin(theta), 0.5 * cos(theta), 0},
        {0, 0, 0.5}
    };

    return result;
}

int main() {
    int t;
    double area;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        cin >> area;
        auto rotation = find_rotation(area);

        cout << "Case #" << i << ":" << endl;
        cout << fixed << setprecision(15);
        for (const auto& point : rotation) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
