#include <iostream>
#include <cmath>
#include <vector>

const double EPS = 1e-6;

void solve(double A) {
    double theta = acos(A / sqrt(2));
    double phi = (M_PI / 4) - theta;

    double x1 = 0.5 * cos(phi);
    double z1 = 0.5 * sin(phi);

    double x2 = 0.5 * cos(M_PI / 4);
    double z2 = 0.5 * sin(M_PI / 4);

    double x3 = x2 * cos(phi) - z2 * sin(phi);
    double z3 = x2 * sin(phi) + z2 * cos(phi);

    std::vector<std::vector<double>> points = {
        {x1, 0.5, z1},
        {-x3, 0.5, z3},
        {0, 0.5, 0.5}
    };

    for (const auto &point : points) {
        for (const auto &coord : point) {
            std::cout.precision(10);
            std::cout << coord << " ";
        }
        std::cout << std::endl;
    }
}

int main() {
    int T;
    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;

        std::cout << "Case #" << t << ":" << std::endl;
        solve(A);
    }
    return 0;
}
