#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(double A) {
    double theta = asin(A / sqrt(2));
    double cos_theta = cos(theta);
    double sin_theta = sin(theta);

    cout << setprecision(15) << 0.5 * cos_theta << " " << 0.5 * sin_theta << " 0" << endl;
    cout << setprecision(15) << -0.5 * sin_theta << " " << 0.5 * cos_theta << " 0" << endl;
    cout << "0 0 0.5" << endl;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;
        cout << "Case #" << i << ":" << endl;
        solve(A);
    }
    return 0;
}
