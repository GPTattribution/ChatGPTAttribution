#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

vector<vector<double>> rotate_cube(double target_area) {
    double angle = asin(target_area / sqrt(2.0));
    double half = 0.5;
    double quarter = 0.25;

    vector<vector<double>> face_centers = {
        {half * cos(angle), half * sin(angle), 0},
        {-half * sin(angle), half * cos(angle), 0},
        {0, 0, half}
    };

    return face_centers;
}

int main() {
    int T;
    double A;

    cin >> T;
    for (int t = 1; t <= T; ++t) {
        cin >> A;
        vector<vector<double>> face_centers = rotate_cube(A);

        cout.precision(15);
        cout << "Case #" << t << ":" << endl;
        for (const auto& face_center : face_centers) {
            for (const auto& coord : face_center) {
                cout << coord << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
