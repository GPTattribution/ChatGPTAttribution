#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

const double EPSILON = 1e-9;

std::vector<double> find_rotation(double desired_area) {
    double theta = std::asin(desired_area / 1.732050);
    double half_side_length = 0.5;

    std::vector<double> p1 = {half_side_length * std::cos(theta), half_side_length * std::sin(theta), 0};
    std::vector<double> p2 = {-half_side_length * std::cos(theta), half_side_length * std::sin(theta), 0};
    std::vector<double> p3 = {0, 0, half_side_length};

    return {p1[0], p1[1], p1[2], p2[0], p2[1], p2[2], p3[0], p3[1], p3[2]};
}

int main() {
    int T;
    std::cin >> T;

    std::cout << std::fixed << std::setprecision(10);
    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;
        std::vector<double> result = find_rotation(A);

        std::cout << "Case #" << t << ":\n";
        for (int i = 0; i < 9; i += 3) {
            std::cout << result[i] << " " << result[i + 1] << " " << result[i + 2] << "\n";
        }
    }

    return 0;
}
