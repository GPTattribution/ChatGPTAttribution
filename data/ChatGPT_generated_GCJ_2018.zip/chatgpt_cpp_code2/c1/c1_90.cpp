#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPSILON = 1e-6;

void rotate_cube(double A) {
    double a = (A - 1) / sqrt(2);

    vector<vector<double>> points = {
        {0.5 - a, 0.5 + a, 0},
        {-0.5 + a, 0.5 + a, 0},
        {0, 0, 0.5}
    };

    for (const auto& point : points) {
        cout << fixed << setprecision(10);
        for (const auto& coord : point) {
            cout << coord << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;

        cout << "Case #" << i << ":" << endl;
        rotate_cube(A);
    }

    return 0;
}
