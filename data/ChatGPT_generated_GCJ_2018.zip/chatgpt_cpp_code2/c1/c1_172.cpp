#include <iostream>
#include <cmath>
#include <iomanip>

const double PI = std::acos(-1.0);

void solve(int case_num, double target_area) {
    double half_side = 0.5;
    double alpha = std::asin((target_area - 1) / 1.732050);
    double beta = PI / 4 - alpha;

    double x1 = half_side * std::cos(beta);
    double z1 = half_side * std::sin(beta);
    double x2 = half_side * std::cos(beta + PI / 2);
    double z2 = half_side * std::sin(beta + PI / 2);

    std::cout << "Case #" << case_num << ":\n";
    std::cout << std::fixed << std::setprecision(15) << x1 << " 0.0 " << z1 << "\n";
    std::cout << std::fixed << std::setprecision(15) << x2 << " 0.0 " << z2 << "\n";
    std::cout << "0.0 0.5 0.0\n";
}

int main() {
    int T;
    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;
        solve(t, A);
    }
    return 0;
}
