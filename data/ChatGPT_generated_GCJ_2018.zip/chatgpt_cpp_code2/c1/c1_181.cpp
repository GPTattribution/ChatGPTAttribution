#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

void rotate_cube(int t, double A) {
    double angle = (A - 1.0) / (sqrt(2) - 1);

    vector<vector<double>> face_centers(3, vector<double>(3));
    face_centers[0] = {0.5 * angle, 0.5 * angle, 0};
    face_centers[1] = {-0.5 * angle, 0.5 * angle, 0};
    face_centers[2] = {0, 0, 0.5};

    cout << "Case #" << t << ":" << endl;
    cout << fixed << setprecision(10);
    for (const auto &face_center : face_centers) {
        for (double coord : face_center) {
            cout << coord << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        rotate_cube(t, A);
    }
    return 0;
}
