#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

void find_rotation(double A, vector<vector<double>> &face_centers) {
    double angle = (A - 1) / (sqrt(2) - 1);
    double cos_angle = cos(angle);
    double sin_angle = sin(angle);

    face_centers = {
        {0.5 * cos_angle, 0.5 * sin_angle, 0},
        {-0.5 * sin_angle, 0.5 * cos_angle, 0},
        {0, 0, 0.5}
    };
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<vector<double>> face_centers;
        find_rotation(A, face_centers);

        cout << "Case #" << t << ":" << endl;
        for (const auto &face_center : face_centers) {
            for (const double coordinate : face_center) {
                cout << coordinate << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
