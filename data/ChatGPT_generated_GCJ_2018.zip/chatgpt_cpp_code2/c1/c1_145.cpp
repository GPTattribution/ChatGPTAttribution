#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

vector<vector<double>> get_rotation_matrix(double angle) {
    double c = cos(angle);
    double s = sin(angle);
    vector<vector<double>> rotation_matrix = {
        {c, -s, 0},
        {s, c, 0},
        {0, 0, 1}
    };

    return rotation_matrix;
}

vector<double> rotate_point(const vector<double>& point, const vector<vector<double>>& rotation_matrix) {
    vector<double> rotated_point(3, 0);
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            rotated_point[i] += rotation_matrix[i][j] * point[j];
        }
    }
    return rotated_point;
}

void solve(int case_no, double A) {
    double angle = acos(A / sqrt(2));
    vector<vector<double>> rotation_matrix = get_rotation_matrix(angle);

    vector<vector<double>> points = {
        {0.5, 0, 0},
        {0, 0.5, 0},
        {0, 0, 0.5}
    };

    cout << "Case #" << case_no << ":\n";
    for (const auto& point : points) {
        vector<double> rotated_point = rotate_point(point, rotation_matrix);
        for (const auto& coord : rotated_point) {
            cout << fixed << setprecision(15) << coord << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        double A;
        cin >> A;
        solve(i, A);
    }
    return 0;
}
