#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

vector<vector<double>> find_cube_rotation(double A) {
    double theta = acos(A / sqrt(3));
    double phi = (M_PI / 4) - theta / 2;

    double a = 0.5 * cos(phi);
    double b = 0.5 * sin(phi);

    return {
        {a, b, 0},
        {-a, b, 0},
        {0, 0, 0.5}
    };
}

int main() {
    int T;
    double A;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        cin >> A;
        vector<vector<double>> rotation = find_cube_rotation(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto& point : rotation) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
