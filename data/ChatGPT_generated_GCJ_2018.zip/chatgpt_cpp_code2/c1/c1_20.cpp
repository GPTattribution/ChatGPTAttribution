#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void find_rotation(double A) {
double theta = asin((A - 1.0) / sqrt(2));
double p1x = 0.5 * cos(theta);
double p1z = 0.5 * sin(theta);

double p2x = -0.5 * sin(theta);
double p2z = 0.5 * cos(theta);

cout << setprecision(15) << p1x << " 0 " << p1z << endl;
cout << setprecision(15) << p2x << " 0 " << p2z << endl;
cout << "0 0 0.5" << endl;
}

int main() {
int T;
double A;
cin >> T;
for (int t = 1; t <= T; t++) {
    cin >> A;
    cout << "Case #" << t << ":" << endl;
    find_rotation(A);
}

return 0;
}
