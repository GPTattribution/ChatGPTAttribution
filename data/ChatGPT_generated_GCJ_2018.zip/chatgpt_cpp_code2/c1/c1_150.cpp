#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

const double PI = acos(-1);
const double EPSILON = 1e-6;

struct Point {
    double x, y, z;

    Point(double x = 0, double y = 0, double z = 0) : x(x), y(y), z(z) {}
};

void solve(int caseNumber, double A) {
    double phi = (A - 1) / (sqrt(2) - 1);
    double theta = asin(phi) / 2;

    vector<Point> result = {
        Point(0.5 * cos(theta), 0.5 * sin(theta), 0),
        Point(-0.5 * sin(theta / 2), 0.5 * cos(theta / 2), 0.5 * cos(theta / 2)),
        Point(-0.5 * sin(theta / 2), 0.5 * cos(theta / 2), -0.5 * cos(theta / 2))
    };

    cout << "Case #" << caseNumber << ":" << endl;
    cout << fixed << setprecision(10);
    for (const Point& p : result) {
        cout << p.x << " " << p.y << " " << p.z << endl;
    }
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        solve(t, A);
    }

    return 0;
}
