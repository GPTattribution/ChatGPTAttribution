#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

void solve(int case_num, double A) {
    double pi = acos(-1);
    double half_angle = acos(A / sqrt(2));
    double angle = pi / 4 - half_angle;

    double x = 0.5 * cos(angle);
    double z = 0.5 * sin(angle);

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(15);
    cout << x << " " << 0.5 << " " << z << endl;
    cout << x << " " << -0.5 << " " << -z << endl;
    cout << -x << " " << -0.5 << " " << z << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;
        solve(t, A);
    }
    return 0;
}
