#include <iostream>
#include <cmath>
#include <vector>

const double PI = 3.14159265358979323846;

struct Point {
    double x, y, z;
};

double calc_theta(double target_area) {
    return (asin(target_area - 1) + PI / 4);
}

void solve(int test_case, double target_area) {
    double theta = calc_theta(target_area);

    std::vector<Point> points{
        {cos(theta) / 2, sin(theta) / 2, 0},
        {-sin(theta) / 2, cos(theta) / 2, 0},
        {0, 0, 0.5}
    };

    std::cout << "Case #" << test_case << ":\n";
    for (const auto &point : points) {
        std::cout << point.x << ' ' << point.y << ' ' << point.z << '\n';
    }
}

int main() {
    int T;
    std::cin >> T;

    for (int i = 1; i <= T; ++i) {
        double target_area;
        std::cin >> target_area;
        solve(i, target_area);
    }

    return 0;
}
