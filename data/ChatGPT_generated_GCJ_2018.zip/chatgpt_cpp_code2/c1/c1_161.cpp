#include <iostream>
#include <cmath>
#include <iomanip>

const double EPS = 1e-9;

struct Point {
    double x, y, z;
};

double calc_area(Point p1, Point p2, Point p3, double A) {
    double projected_area = std::abs((p1.x * (p2.z - p3.z) + p2.x * (p3.z - p1.z) + p3.x * (p1.z - p2.z)) / 6.0);
    return projected_area * 9;
}

void solve(int case_num, double A) {
    double angle = (A - 1) / (std::sqrt(2) - 1);

    Point p1 = {0.5, 0, 0};
    Point p2 = {0, 0.5, 0};
    Point p3 = {0, 0, 0.5};

    Point rotated_p2 = {p2.x * std::cos(angle) - p2.z * std::sin(angle), p2.y, p2.x * std::sin(angle) + p2.z * std::cos(angle)};
    Point rotated_p3 = {p3.x * std::cos(angle) - p3.z * std::sin(angle), p3.y, p3.x * std::sin(angle) + p3.z * std::cos(angle)};

    double area = calc_area(p1, rotated_p2, rotated_p3, A);

    if (std::abs(area - A) > EPS) {
        rotated_p2 = {p2.x, p2.y * std::cos(angle) - p2.z * std::sin(angle), p2.y * std::sin(angle) + p2.z * std::cos(angle)};
        rotated_p3 = {p3.x, p3.y * std::cos(angle) - p3.z * std::sin(angle), p3.y * std::sin(angle) + p3.z * std::cos(angle)};
    }

    std::cout << "Case #" << case_num << ":" << std::endl;
    std::cout << std::fixed << std::setprecision(15);
    std::cout << p1.x << " " << p1.y << " " << p1.z << std::endl;
    std::cout << rotated_p2.x << " " << rotated_p2.y << " " << rotated_p2.z << std::endl;
    std::cout << rotated_p3.x << " " << rotated_p3.y << " " << rotated_p3.z << std::endl;
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; t++) {
        double A;
        std::cin >> A;
        solve(t, A);
    }

    return 0;
}
