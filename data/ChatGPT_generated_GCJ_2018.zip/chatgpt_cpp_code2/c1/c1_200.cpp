#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

const double EPS = 1e-6;

vector<double> rotate(const vector<double>& p, double angle) {
    return {cos(angle) * p[0] - sin(angle) * p[2], p[1], sin(angle) * p[0] + cos(angle) * p[2]};
}

int main() {
    int T;
    cin >> T;

    for (int caseNum = 1; caseNum <= T; ++caseNum) {
        double A;
        cin >> A;

        double lo = 0, hi = acos(-1) / 4;
        vector<double> p1 = {0.5, 0, 0};
        vector<double> p2 = {0, 0.5, 0};
        vector<double> p3 = {0, 0, 0.5};

        while (hi - lo > EPS) {
            double mid = (lo + hi) / 2;

            vector<double> r1 = rotate(p1, mid);
            vector<double> r2 = rotate(p2, mid);
            vector<double> r3 = rotate(p3, mid);

            double area = abs(r1[0] * r2[2] - r1[2] * r2[0]);

            if (area < A) {
                lo = mid;
            } else {
                hi = mid;
            }
        }

        vector<double> r1 = rotate(p1, lo);
        vector<double> r2 = rotate(p2, lo);
        vector<double> r3 = rotate(p3, lo);

        cout << "Case #" << caseNum << ":" << endl;
        cout << fixed << setprecision(10);
        cout << r1[0] << " " << r1[1] << " " << r1[2] << endl;
        cout << r2[0] << " " << r2[1] << " " << r2[2] << endl;
        cout << r3[0] << " " << r3[1] << " " << r3[2] << endl;
    }

    return 0;
}
