#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

const double EPS = 1e-9;

void solve(double A) {
    double r = A / std::sqrt(2.0);
    if (r > 0.5) {
        double t = 0.5 * (A - 1.0);
        r = 0.5 - t;
    }
    std::vector<std::vector<double>> points = {
        {r, r, 0.0},
        {-r, r, 0.0},
        {0.0, 0.0, 0.5}
    };

    std::cout << std::fixed << std::setprecision(9);
    for (const auto& point : points) {
        for (const auto& coord : point) {
            std::cout << coord << " ";
        }
        std::cout << "\n";
    }
}

int main() {
    int T;
    double A;
    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        std::cin >> A;
        std::cout << "Case #" << t << ":\n";
        solve(A);
    }
    return 0;
}
