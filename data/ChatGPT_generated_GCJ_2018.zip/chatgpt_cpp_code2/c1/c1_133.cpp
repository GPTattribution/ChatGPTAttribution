#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

const double PI = acos(-1);
const double EPS = 1e-6;

vector<vector<double>> get_rotation(double A) {
    double theta = asin((A - 1) / sqrt(2));
    double alpha = theta / 2;
    double beta = PI / 4 - alpha;

    double x = 0.5 * cos(beta);
    double z = 0.5 * sin(beta);

    return {
        { x, 0, z },
        { -x, 0, z },
        { 0, 0.5, 0 }
    };
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(9);

    for (int t = 1; t <= T; ++t) {
        cin >> A;
        auto rotation = get_rotation(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto& point : rotation) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
