#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPS = 1e-9;

void solve(int case_num, double A) {
    double theta = asin(A / sqrt(2)) / 2.0;
    double ct = cos(theta);
    double st = sin(theta);
    double coords[3][3] = {
        {0.5 * ct, 0.5 * st, 0},
        {-0.5 * st, 0.5 * ct, 0},
        {0, 0, 0.5}
    };

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(10);
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            cout << coords[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;
        solve(i, A);
    }
    return 0;
}
