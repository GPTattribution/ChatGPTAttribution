#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

void solve(double A) {
    double phi = acos(A / sqrt(2));
    double theta = phi - M_PI / 4;
    double x = 0.5 * cos(theta);
    double z = 0.5 * sin(theta);

    vector<vector<double>> face_centers = {
        {x, 0.5, z},
        {-x, 0.5, -z},
        {0, 0.5, 0.5}
    };

    for (const auto& face_center : face_centers) {
        cout << face_center[0] << " " << face_center[1] << " " << face_center[2] << endl;
    }
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        cout << "Case #" << t << ":" << endl;
        solve(A);
    }

    return 0;
}
