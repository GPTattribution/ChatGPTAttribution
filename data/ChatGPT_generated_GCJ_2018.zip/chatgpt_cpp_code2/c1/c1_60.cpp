#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

void solve(int caseNum, double targetArea) {
    double halfSideLength = 0.5;

    double angle = asin(targetArea / 1.732050);

    vector<vector<double>> faceCenters(3, vector<double>(3));
    faceCenters[0][0] = halfSideLength * cos(angle);
    faceCenters[0][1] = halfSideLength * sin(angle);
    faceCenters[1][0] = halfSideLength * cos(angle + 2.0 * M_PI / 3.0);
    faceCenters[1][1] = halfSideLength * sin(angle + 2.0 * M_PI / 3.0);
    faceCenters[2][0] = halfSideLength * cos(angle + 4.0 * M_PI / 3.0);
    faceCenters[2][1] = halfSideLength * sin(angle + 4.0 * M_PI / 3.0);

    cout << "Case #" << caseNum << ":" << endl;
    for (int i = 0; i < 3; i++) {
        cout.precision(15);
        cout << faceCenters[i][0] << " " << faceCenters[i][1] << " " << faceCenters[i][2] << endl;
    }
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        double A;
        cin >> A;
        solve(i, A);
    }

    return 0;
}
