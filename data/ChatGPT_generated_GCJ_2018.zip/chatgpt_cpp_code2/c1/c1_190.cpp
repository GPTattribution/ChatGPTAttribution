#include <iostream>
#include <cmath>
#include <vector>

const double eps = 1e-6;

double find_phi(double target_area) {
    double low = 0, high = acos(-1) / 4;
    while (high - low > eps) {
        double mid = (low + high) / 2;
        double cur_area = 0.5 * 0.5 * sin(2 * mid);
        if (cur_area < target_area) {
            low = mid;
        } else {
            high = mid;
        }
    }
    return (low + high) / 2;
}

std::vector<std::vector<double>> find_points(double phi) {
    double a = 0.5 * cos(phi);
    double b = 0.5 * sin(phi);
    return {{a, b, 0}, {-b, a, 0}, {0, 0, 0.5}};
}

int main() {
    int t;
    std::cin >> t;
    for (int i = 1; i <= t; ++i) {
        double target_area;
        std::cin >> target_area;
        double phi = find_phi(target_area);
        std::vector<std::vector<double>> points = find_points(phi);

        std::cout << "Case #" << i << ":\n";
        for (const auto &point : points) {
            for (double coord : point) {
                std::cout << coord << ' ';
            }
            std::cout << '\n';
        }
    }
    return 0;
}
