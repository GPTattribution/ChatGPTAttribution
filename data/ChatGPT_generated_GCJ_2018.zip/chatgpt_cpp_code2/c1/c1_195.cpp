#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

const double PI = acos(-1.0);

vector<vector<double>> solve(double A) {
    double theta = (A - 1.0) / sqrt(2);
    double phi = PI / 4 - theta;

    double x = 0.5 * cos(phi);
    double z = 0.5 * sin(phi);

    vector<vector<double>> result = {
        {x, 0.0, z},
        {-x, 0.0, z},
        {0.0, 0.5, 0.0}
    };

    return result;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        vector<vector<double>> result = solve(A);

        cout << "Case #" << t << ":" << endl;
        cout << fixed << setprecision(10);
        for (const auto& point : result) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
