#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

double calculate_phi(double A) {
    return acos((A * A - 2) / (A * A));
}

void print_face_centers(double phi) {
    double half_side = 0.5;
    double x = half_side * cos(phi);
    double z = half_side * sin(phi);

    cout << fixed << setprecision(12) << x << " " << 0.0 << " " << z << endl;
    cout << fixed << setprecision(12) << -x << " " << 0.0 << " " << z << endl;
    cout << fixed << setprecision(12) << 0.0 << " " << 0.0 << " " << half_side << endl;
}

int main() {
    int T;
    double A;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        cin >> A;
        double phi = calculate_phi(A);
        cout << "Case #" << i << ":" << endl;
        print_face_centers(phi);
    }

    return 0;
}
