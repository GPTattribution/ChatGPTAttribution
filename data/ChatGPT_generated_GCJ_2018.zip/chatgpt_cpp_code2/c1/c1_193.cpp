#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

struct Point {
    double x, y, z;
};

void findRotation(double A, vector<Point>& result) {
    const double PI = acos(-1.0);
    double theta = 2 * asin(sqrt(A) / sqrt(2));
    double phi = (PI - theta) / 2;

    result[0] = {0.5 * cos(phi), 0.5 * sin(phi), 0};
    result[1] = {0.5 * sin(phi), -0.5 * cos(phi), 0};
    result[2] = {0, 0, 0.5};
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(10);

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<Point> result(3);
        findRotation(A, result);

        cout << "Case #" << t << ":" << endl;
        for (const auto& p : result) {
            cout << p.x << " " << p.y << " " << p.z << endl;
        }
    }

    return 0;
}
