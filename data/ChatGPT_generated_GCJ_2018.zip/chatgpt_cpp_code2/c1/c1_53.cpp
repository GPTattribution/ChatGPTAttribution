#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

void find_face_centers(double A) {
    double half_edge = 0.5;
    double theta = acos(A / (2 * sqrt(2))) - M_PI / 4;
    double half_diag = sqrt(2) * half_edge;

    double x = half_diag * cos(theta);
    double z = half_diag * sin(theta);

    cout << x << " 0.0 " << z << endl;
    cout << -x << " 0.0 " << z << endl;
    cout << "0.0 0.0 0.5" << endl;
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        double A;
        cin >> A;

        cout << "Case #" << i << ":" << endl;
        find_face_centers(A);
    }

    return 0;
}
