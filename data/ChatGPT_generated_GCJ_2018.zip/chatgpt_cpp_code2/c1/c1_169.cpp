#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

double EPS = 1e-9;

vector<vector<double>> solve(double A) {
    double alpha = acos((A * A - 2) / 2);
    double beta = M_PI / 4 - alpha / 2;
    double a = 0.5 * cos(beta);
    double b = 0.5 * sin(beta);

    vector<vector<double>> points = {
        {a, b, 0},
        {-b, a, 0},
        {0, 0, 0.5}
    };

    return points;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<vector<double>> result = solve(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto &point : result) {
            cout.precision(12);
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
