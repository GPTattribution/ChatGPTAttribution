#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

const double EPS = 1e-9;

vector<double> find_rotation(double A) {
    double l = 0, r = 0.5 * M_PI;
    double target_area = A / 3.0;

    while (r - l > EPS) {
        double theta = (l + r) / 2;
        double projected_length = 0.5 * sin(theta);

        if (projected_length * projected_length < target_area) {
            l = theta;
        } else {
            r = theta;
        }
    }

    double theta = (l + r) / 2;
    return {0.5 * cos(theta), 0.5 * sin(theta), 0};
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<double> p1 = find_rotation(A);
        vector<double> p2 = {-p1[1], p1[0], 0};
        vector<double> p3 = {0, 0, 0.5};

        cout << "Case #" << t << ":" << endl;
        for (const auto& p : {p1, p2, p3}) {
            cout << p[0] << " " << p[1] << " " << p[2] << endl;
        }
    }

    return 0;
}
