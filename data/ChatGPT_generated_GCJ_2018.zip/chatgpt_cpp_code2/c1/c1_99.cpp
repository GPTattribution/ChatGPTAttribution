#include <iostream>
#include <cmath>
#include <vector>

const double PI = 3.14159265358979323846;

std::vector<std::vector<double>> find_face_centers(double A) {
double theta = acos(A / sqrt(2));
double alpha = PI / 4 - theta / 2;
double half = 0.5;
std::vector<std::vector<double>> face_centers = {
    {half * cos(alpha), half * sin(alpha), 0},
    {half * -sin(alpha), half * cos(alpha), 0},
    {0, 0, half}
};

return face_centers;
}

int main() {
int T;
double A;
std::cin >> T;
for (int i = 0; i < T; ++i) {
    std::cin >> A;
    std::vector<std::vector<double>> face_centers = find_face_centers(A);

    std::cout.precision(10);
    std::cout << "Case #" << i + 1 << ":" << std::endl;
    for (const auto &face_center : face_centers) {
        for (const auto &coord : face_center) {
            std::cout << coord << " ";
        }
        std::cout << std::endl;
    }
}

return 0;
}
