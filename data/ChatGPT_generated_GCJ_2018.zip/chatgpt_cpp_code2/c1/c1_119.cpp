#include <iostream>
#include <cmath>
#include <iomanip>

const double EPS = 1e-6;
const double PI = acos(-1.0);

void solve(double area) {
    double angle = (area - 1.0) / (sqrt(2.0) - 1.0);
    double rot_angle = angle * (PI / 4.0);
    double x = 0.5 * cos(rot_angle);
    double z = 0.5 * sin(rot_angle);

    std::cout << std::setprecision(16) << x << " " << 0.0 << " " << z << "\n";
    std::cout << -x << " " << 0.0 << " " << z << "\n";
    std::cout << 0.0 << " " << 0.5 << " " << 0.0 << "\n";
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;

        std::cout << "Case #" << t << ":\n";
        solve(A);
    }

    return 0;
}
