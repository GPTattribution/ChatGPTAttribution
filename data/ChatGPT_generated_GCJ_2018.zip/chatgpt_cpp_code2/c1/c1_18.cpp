#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

double PI = acos(-1.0);

vector<vector<double>> solve(double A) {
    double phi = acos((A - 1.0) / (sqrt(2.0) - 1.0));
    double theta = PI / 4.0 - phi / 2.0;

    double x = 0.5 * cos(theta);
    double z = 0.5 * sin(theta);

    vector<vector<double>> face_centers = {
        {x, 0.5, z},
        {-x, 0.5, -z},
        {0, 0.5, 0.5}
    };

    return face_centers;
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(10);

    for (int t = 1; t <= T; t++) {
        cin >> A;
        vector<vector<double>> face_centers = solve(A);
        cout << "Case #" << t << ":" << endl;
        for (const auto& face_center : face_centers) {
            for (double coordinate : face_center) {
                cout << coordinate << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
