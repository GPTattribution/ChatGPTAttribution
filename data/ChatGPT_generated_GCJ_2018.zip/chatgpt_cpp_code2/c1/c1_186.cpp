#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

const double EPS = 1e-9;

vector<vector<double>> find_face_centers(double A) {
    double a = (A - 1) / sqrt(2);
    double b = 0.5 - a;

    return {
        {0.5, 0, 0},
        {a, b, 0},
        {a, 0, b}
    };
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(9);

    for (int t = 1; t <= T; ++t) {
        cin >> A;
        vector<vector<double>> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (auto &center : face_centers) {
            cout << center[0] << " " << center[1] << " " << center[2] << endl;
        }
    }

    return 0;
}
