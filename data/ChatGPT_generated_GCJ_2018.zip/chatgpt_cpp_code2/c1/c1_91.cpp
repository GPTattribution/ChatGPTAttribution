#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

const double EPSILON = 1e-6;

vector<vector<double>> solve(double A) {
    double cos_theta = (A * A - 2) / (2 * A * A);
    double theta = acos(cos_theta);

    double x = 0.5 * cos(theta);
    double z = 0.5 * sin(theta);

    return {{x, 0, z},
            {-x, 0, z},
            {0, 0, 0.5}};
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<vector<double>> result = solve(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto& point : result) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
