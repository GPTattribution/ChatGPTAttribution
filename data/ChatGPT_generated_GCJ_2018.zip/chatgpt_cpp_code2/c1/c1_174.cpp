#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

void solve(int t, double A) {
    double theta = acos((A - 1) / sqrt(2));
    double a = 0.5 * cos(theta);
    double b = 0.5 * sin(theta);

    printf("Case #%d:\n", t);
    printf("%.15lf %.15lf %.15lf\n", a, b, 0.0);
    printf("%.15lf %.15lf %.15lf\n", b, a, 0.0);
    printf("%.15lf %.15lf %.15lf\n", 0.0, 0.0, 0.5);
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        solve(t, A);
    }

    return 0;
}
