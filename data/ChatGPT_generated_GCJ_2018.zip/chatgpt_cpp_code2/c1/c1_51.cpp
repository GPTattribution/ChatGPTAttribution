#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

void solve(int case_num, double A) {
    double theta = acos(A / sqrt(2.0));
    double phi = atan(1.0 / sqrt(2.0));

    vector<vector<double>> face_centers(3, vector<double>(3));
    face_centers[0] = {0.5 * cos(theta), 0.5 * sin(theta), 0};
    face_centers[1] = {0.5 * sin(phi) * sin(theta), -0.5 * sin(phi) * cos(theta), 0.5 * cos(phi)};
    face_centers[2] = {0.5 * -sin(phi) * sin(theta), 0.5 * -sin(phi) * cos(theta), 0.5 * cos(phi)};

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(15);
    for (const auto &face_center : face_centers) {
        for (const double coord : face_center) {
            cout << coord << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;
        solve(t, A);
    }
    return 0;
}
