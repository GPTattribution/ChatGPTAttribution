#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

void solve(double A) {
    double theta = acos(A / sqrt(2)) / 2;
    double half_side = 0.5;

    vector<vector<double>> points(3, vector<double>(3));

    points[0] = {half_side * cos(theta), half_side * sin(theta), 0};
    points[1] = {half_side * cos(theta + M_PI / 2), half_side * sin(theta + M_PI / 2), 0};
    points[2] = {0, half_side, 0};

    for (const auto& point : points) {
        cout << fixed << setprecision(15);
        cout << point[0] << " " << point[1] << " " << point[2] << endl;
    }
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;
        cout << "Case #" << t << ":" << endl;
        solve(A);
    }

    return 0;
}
