#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

void solve(int case_num, double A) {
    double area_ratio = A / sqrt(2.0);
    double angle = asin(area_ratio);
    double half_side = 0.5;

    double x1 = half_side * cos(angle);
    double y1 = half_side * sin(angle);
    double z1 = 0;

    double x2 = 0;
    double y2 = half_side * cos(angle);
    double z2 = half_side * sin(angle);

    double x3 = 0;
    double y3 = half_side;
    double z3 = 0;

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(10) << x1 << " " << y1 << " " << z1 << endl;
    cout << fixed << setprecision(10) << x2 << " " << y2 << " " << z2 << endl;
    cout << fixed << setprecision(10) << x3 << " " << y3 << " " << z3 << endl;
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        double A;
        cin >> A;
        solve(i, A);
    }

    return 0;
}
