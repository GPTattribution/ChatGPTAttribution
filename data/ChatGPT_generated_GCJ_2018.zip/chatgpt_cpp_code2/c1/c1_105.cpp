#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(int case_num, double A) {
double angle = asin(A / sqrt(3)) / 2;
double half_side = 0.5;
double x1 = half_side * cos(angle);
double z1 = half_side * sin(angle);

double x2 = half_side * cos(angle + M_PI / 2);
double z2 = half_side * sin(angle + M_PI / 2);

cout << "Case #" << case_num << ":" << endl;
cout << setprecision(15) << x1 << " " << 0.0 << " " << z1 << endl;
cout << setprecision(15) << x2 << " " << 0.0 << " " << z2 << endl;
cout << setprecision(15) << 0.0 << " " << 0.0 << " " << half_side << endl;
}

int main() {
int T;
cin >> T;
for (int i = 1; i <= T; i++) {
double A;
cin >> A;
solve(i, A);
}
return 0;
}
