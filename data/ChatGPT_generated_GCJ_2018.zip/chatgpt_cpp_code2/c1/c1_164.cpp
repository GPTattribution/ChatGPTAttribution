#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

vector<double> calculate_face_centers(double A) {
    double theta = acos(A / sqrt(2.0));

    double x = 0.5 * cos(theta);
    double z = 0.5 * sin(theta);

    return {x, 0.5, z, -x, 0.5, -z, 0, 0.5, 0.5};
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<double> face_centers = calculate_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (int i = 0; i < 9; i += 3) {
            cout << face_centers[i] << " " << face_centers[i + 1] << " " << face_centers[i + 2] << endl;
        }
    }

    return 0;
}
