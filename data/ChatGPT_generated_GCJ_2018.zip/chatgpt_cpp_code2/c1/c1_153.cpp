#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

const double EPS = 1e-9;

vector<vector<double>> getFaceCenters(double A) {
    double u = (A - 1.0) / (sqrt(2) - 1);
    double a = 0.5 * u;
    double b = 0.5 * sqrt(1 - u * u);

    return {
        { a, b, 0 },
        { -a, b, 0 },
        { 0, b, sqrt(0.25 - b * b) }
    };
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<vector<double>> faceCenters = getFaceCenters(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto &center : faceCenters) {
            cout << fixed << setprecision(9);
            cout << center[0] << " " << center[1] << " " << center[2] << endl;
        }
    }

    return 0;
}
