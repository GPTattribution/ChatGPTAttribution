#include <iostream>
#include <cmath>
#include <vector>

const double EPSILON = 1e-6;

struct Point {
    double x, y, z;
};

void findRotation(double A, std::vector<Point>& faceCenters) {
    double a = acos((A - 1) / sqrt(2));
    double halfA = a / 2;

    faceCenters.push_back({0.5 * cos(halfA), 0.5 * sin(halfA), 0});
    faceCenters.push_back({-0.5 * cos(halfA), 0.5 * sin(halfA), 0});
    faceCenters.push_back({0, 0, 0.5});
}

int main() {
    int T;
    double A;
    std::cin >> T;

    for (int t = 1; t <= T; ++t) {
        std::cin >> A;
        std::vector<Point> faceCenters;

        findRotation(A, faceCenters);

        std::cout << "Case #" << t << ":\n";
        for (const auto& center : faceCenters) {
            std::cout << center.x << ' ' << center.y << ' ' << center.z << '\n';
        }
    }

    return 0;
}
