#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void findFaceCenters(double A) {
    double angle = (acos((A - 1) / sqrt(2)) - M_PI / 4);
    double coord1 = 0.5 * cos(angle);
    double coord2 = 0.5 * sin(angle);

    cout << fixed << setprecision(15);
    cout << coord1 << " " << coord2 << " " << 0.0 << endl;
    cout << -coord1 << " " << coord2 << " " << 0.0 << endl;
    cout << 0.0 << " " << 0.5 << " " << 0.0 << endl;
}

int main() {
    int T;
    double A;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        cin >> A;
        cout << "Case #" << i << ":" << endl;
        findFaceCenters(A);
    }

    return 0;
}
