#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(double A) {
    double theta = acos(A / sqrt(2));
    double half_pi = acos(0);
    double phi = half_pi - theta;

    double x = 0.5 * cos(phi);
    double y = 0.5 * sin(phi);

    cout << fixed << setprecision(15);
    cout << x << " " << y << " " << 0.0 << endl;
    cout << -y << " " << x << " " << 0.0 << endl;
    cout << 0.0 << " " << 0.0 << " " << 0.5 << endl;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        double A;
        cin >> A;
        cout << "Case #" << i << ":" << endl;
        solve(A);
    }
    return 0;
}
