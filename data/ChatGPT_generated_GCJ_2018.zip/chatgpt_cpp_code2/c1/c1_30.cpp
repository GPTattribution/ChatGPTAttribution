#include <iostream>
#include <cmath>
#include <iomanip>

void solve(int t, double A) {
double s = (A - 1.0) / (sqrt(2) - 1.0);
double angle = s * M_PI / 4;
double c = cos(angle);
double s2 = sin(angle);
std::cout << std::fixed << std::setprecision(15);
std::cout << "Case #" << t << ":\n";
std::cout << 0.5 * c << " " << 0.5 * -s2 << " " << 0.5 * c << "\n";
std::cout << 0.5 * c << " " << 0.5 * c << " " << 0.5 * s2 << "\n";
std::cout << 0.5 * s2 << " " << 0.5 * c << " " << 0.5 * -s2 << "\n";
}

int main() {
int T;
std::cin >> T;
for (int t = 1; t <= T; ++t) {
double A;
std::cin >> A;
solve(t, A);
}
return 0;
}
