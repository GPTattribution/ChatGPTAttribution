#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

const double eps = 1e-9;

void solve(double A) {
    double x, y, z;
    double angle = asin((A - 1.0) / (sqrt(2.0) - 1.0));
    double c = cos(angle) * 0.5;
    double s = sin(angle) * 0.5;

    x = c + s;
    y = c - s;
    z = 0.5;

    std::vector<std::vector<double>> points = {
        {x, y, z},
        {-y, x, z},
        {z, z, z}
    };

    for (const auto& point : points) {
        std::cout << std::fixed << std::setprecision(10);
        for (const auto& coordinate : point) {
            std::cout << coordinate << " ";
        }
        std::cout << std::endl;
    }
}

int main() {
    int T;
    double A;

    std::cin >> T;

    for (int i = 1; i <= T; ++i) {
        std::cin >> A;
        std::cout << "Case #" << i << ":" << std::endl;
        solve(A);
    }

    return 0;
}
