#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>

using namespace std;

const double PI = acos(-1.0);

void solve(int case_num, double A) {
    double theta = asin(A / sqrt(2.0)) / 2.0;

    double x1 = 0.5 * cos(theta);
    double z1 = 0.5 * sin(theta);

    double x2 = 0.5 * cos(theta + PI / 2);
    double z2 = 0.5 * sin(theta + PI / 2);

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(10);
    cout << x1 << " 0 " << z1 << endl;
    cout << x2 << " 0 " << z2 << endl;
    cout << "0 0 0.5" << endl;
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;
        solve(i, A);
    }

    return 0;
}
