#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double PI = acos(-1.0);

void solve(int case_num, double A) {
    double alpha = (A - 1.0) / sqrt(2.0);
    double theta = asin(alpha);

    double p1_x = 0.5 * cos(theta);
    double p1_y = 0.5 * sin(theta);
    double p1_z = 0;

    double p2_x = -0.5 * sin(theta);
    double p2_y = 0.5 * cos(theta);
    double p2_z = 0;

    double p3_x = 0;
    double p3_y = 0;
    double p3_z = 0.5;

    cout << "Case #" << case_num << ":\n";
    cout << setprecision(15) << p1_x << " " << p1_y << " " << p1_z << "\n";
    cout << setprecision(15) << p2_x << " " << p2_y << " " << p2_z << "\n";
    cout << setprecision(15) << p3_x << " " << p3_y << " " << p3_z << "\n";
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;
        solve(i, A);
    }
    return 0;
}
