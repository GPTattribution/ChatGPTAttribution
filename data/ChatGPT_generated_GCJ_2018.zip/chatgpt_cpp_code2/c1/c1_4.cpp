#include <iostream>
#include <cmath>
#include <vector>

const double EPS = 1e-9;

std::vector<double> findFaceCenters(double A) {
    double theta = asin((A - 1.0) / (sqrt(2) - 1.0));
    double a = 0.5 * cos(theta);
    double b = 0.5 * sin(theta);

    return {a, b, 0.0, -a, b, 0.0, 0.0, 0.5, 0.0};
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;

        std::vector<double> faceCenters = findFaceCenters(A);

        std::cout << "Case #" << t << ":\n";
        for (int i = 0; i < 3; ++i) {
            std::cout.precision(10);
            std::cout << faceCenters[i * 3] << " " << faceCenters[i * 3 + 1] << " " << faceCenters[i * 3 + 2] << std::endl;
        }
    }

    return 0;
}
