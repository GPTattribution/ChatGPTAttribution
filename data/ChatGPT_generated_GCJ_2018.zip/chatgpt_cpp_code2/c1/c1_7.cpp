#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

const double EPS = 1e-6;

void solve(int case_number, double A) {
    double theta = acos(A / sqrt(2));

    vector<vector<double>> face_centers = {
        {cos(theta) / 2, sin(theta) / 2, 0},
        {-sin(theta) / 2, cos(theta) / 2, 0},
        {0, 0, 0.5}
    };

    cout << "Case #" << case_number << ":" << endl;
    for (const auto& point : face_centers) {
        for (double coord : point) {
            cout << fixed << setprecision(10) << coord << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;
        solve(i, A);
    }

    return 0;
}
