#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

vector<double> getFaceCenters(double A) {
    double theta = acos(A / sqrt(2));
    double halfSide = 0.5;
    double x = halfSide * cos(theta);
    double z = halfSide * sin(theta);

    return {x, halfSide, z};
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        auto faceCenters = getFaceCenters(A);

        cout << "Case #" << t << ":" << endl;
        cout << faceCenters[0] << " " << faceCenters[1] << " " << 0.0 << endl;
        cout << -faceCenters[0] << " " << faceCenters[1] << " " << 0.0 << endl;
        cout << 0.0 << " " << faceCenters[1] << " " << faceCenters[2] << endl;
    }

    return 0;
}
