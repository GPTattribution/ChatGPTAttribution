#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

vector<vector<double>> find_face_centers(double A) {
double a = acos(A / sqrt(2)) / 2;
vector<vector<double>> face_centers = {
    {0.5 * cos(a), 0.5 * sin(a), 0},
    {-0.5 * cos(a), 0.5 * sin(a), 0},
    {0, 0.5, 0.5}
};

return face_centers;
}

int main() {
int T;
cin >> T;
for (int t = 1; t <= T; t++) {
    double A;
    cin >> A;

    vector<vector<double>> face_centers = find_face_centers(A);

    cout << "Case #" << t << ":" << endl;
    cout << fixed << setprecision(15);
    for (const auto& face_center : face_centers) {
        for (const auto& coord : face_center) {
            cout << coord << " ";
        }
        cout << endl;
    }
}

return 0;
}
