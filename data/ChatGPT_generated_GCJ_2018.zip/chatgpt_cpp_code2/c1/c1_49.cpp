#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

vector<vector<double>> rotation_matrix(double A) {
    double angle = acos((A - 1) / (sqrt(2)));
    double cos_angle = cos(angle);
    double sin_angle = sin(angle);

    return {
        {cos_angle, -sin_angle, 0},
        {sin_angle, cos_angle, 0},
        {0, 0, 1}
    };
}

vector<double> multiply(vector<vector<double>>& matrix, vector<double>& vec) {
    vector<double> result(3);
    for (int i = 0; i < 3; ++i) {
        result[i] = 0;
        for (int j = 0; j < 3; ++j) {
            result[i] += matrix[i][j] * vec[j];
        }
    }
    return result;
}

void solve(int case_num, double A) {
    vector<vector<double>> face_centers = {
        {0.5, 0, 0},
        {0, 0.5, 0},
        {0, 0, 0.5}
    };

    auto rot_matrix = rotation_matrix(A);

    for (int i = 0; i < 3; ++i) {
        face_centers[i] = multiply(rot_matrix, face_centers[i]);
    }

    cout << "Case #" << case_num << ":\n";
    for (int i = 0; i < 3; ++i) {
        cout << face_centers[i][0] << " " << face_centers[i][1] << " " << face_centers[i][2] << "\n";
    }
}

int main() {
    int T;
    double A;

    cin >> T;
    for (int i = 1; i <= T; ++i) {
        cin >> A;
        solve(i, A);
    }

    return 0;
}
