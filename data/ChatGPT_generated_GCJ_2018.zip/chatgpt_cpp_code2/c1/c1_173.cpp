#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

const double EPS = 1e-6;

double area_of_shadow(double a) {
    double low = 0;
    double high = acos(-1) / 4;
    while (high - low > EPS) {
        double mid = (low + high) / 2;
        double cur_area = 3 * pow(sin(mid), 2) * pow(cos(mid), 2);
        if (cur_area < a) {
            low = mid;
        } else {
            high = mid;
        }
    }
    return (low + high) / 2;
}

vector<vector<double>> face_centers(double angle) {
    double p1 = 0.5 * cos(angle);
    double p2 = 0.5 * sin(angle);
    return {
        {p1, p2, p2},
        {p2, p1, p2},
        {p2, p2, p1}
    };
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; ++i) {
        double a;
        cin >> a;
        double angle = area_of_shadow(a);
        vector<vector<double>> centers = face_centers(angle);
        cout.precision(15);
        cout << "Case #" << i << ":" << endl;
        for (const auto& center : centers) {
            cout << center[0] << ' ' << center[1] << ' ' << center[2] << endl;
        }
    }
    return 0;
}
