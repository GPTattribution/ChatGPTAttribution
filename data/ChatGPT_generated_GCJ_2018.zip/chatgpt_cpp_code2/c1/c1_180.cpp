#include <iostream>
#include <cmath>
#include <iomanip>

void solve(double desired_area) {
    double theta = (desired_area - 1) / (3 * std::sqrt(2) - 1);
    double phi = std::acos(theta);
    double s = std::sin(phi);
    double c = std::cos(phi);

    double p1x = 0.5 * s;
    double p1y = 0.5 * c;
    double p1z = 0;

    double p2x = -0.5 * s;
    double p2y = 0.5 * c;
    double p2z = 0;

    double p3x = 0;
    double p3y = 0.5 * c;
    double p3z = 0.5 * s;

    std::cout << std::setprecision(15) << p1x << " " << p1y << " " << p1z << std::endl;
    std::cout << std::setprecision(15) << p2x << " " << p2y << " " << p2z << std::endl;
    std::cout << std::setprecision(15) << p3x << " " << p3y << " " << p3z << std::endl;
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; t++) {
        double desired_area;
        std::cin >> desired_area;

        std::cout << "Case #" << t << ":" << std::endl;
        solve(desired_area);
    }

    return 0;
}
