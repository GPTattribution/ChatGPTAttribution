#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

double degToRad(double deg) {
    return deg * M_PI / 180.0;
}

vector<vector<double>> findFaceCenters(double area) {
    double theta = acos((area - 1) / sqrt(2));
    double face_center_x = 0.5 * cos(theta);
    double face_center_y = 0.5 * sin(theta);

    return {
        {face_center_x, face_center_y, 0},
        {-face_center_x, face_center_y, 0},
        {0, 0, 0.5}
    };
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(15);
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        auto face_centers = findFaceCenters(A);
        cout << "Case #" << t << ":" << endl;
        for (const auto& face_center : face_centers) {
            cout << face_center[0] << " " << face_center[1] << " " << face_center[2] << endl;
        }
    }

    return 0;
}
