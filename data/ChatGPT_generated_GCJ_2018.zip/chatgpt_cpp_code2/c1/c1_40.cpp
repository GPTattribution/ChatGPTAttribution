#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

vector<vector<double>> find_rotation(double A) {
    double theta = acos(A / sqrt(2));
    double c1 = 0.5 * cos(theta);
    double s1 = 0.5 * sin(theta);

    return {
        {c1, s1, 0},
        {-s1, c1, 0},
        {0, 0, 0.5}
    };
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        auto rotation = find_rotation(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto &point : rotation) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
