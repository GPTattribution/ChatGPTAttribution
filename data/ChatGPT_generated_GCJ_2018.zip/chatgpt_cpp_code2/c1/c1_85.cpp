#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

const double EPS = 1e-6;

vector<double> find_solution(double A) {
    double low = 0, high = acos(-1) / 4;
    double angle = 0;

    for (int i = 0; i < 100; ++i) {
        angle = (low + high) / 2;
        double projected_area = pow(sin(angle) + cos(angle), 2);
        if (projected_area < A) {
            low = angle;
        } else {
            high = angle;
        }
    }

    double x = 0.5 * cos(angle);
    double z = 0.5 * sin(angle);
    return {x, x, 0, -x, x, 0, 0, 0, 0.5 - z};
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(9);
    for (int t = 1; t <= T; ++t) {
        cin >> A;
        vector<double> res = find_solution(A);
        cout << "Case #" << t << ":" << endl;
        for (int i = 0; i < 9; i += 3) {
            cout << res[i] << " " << res[i + 1] << " " << res[i + 2] << endl;
        }
    }

    return 0;
}
