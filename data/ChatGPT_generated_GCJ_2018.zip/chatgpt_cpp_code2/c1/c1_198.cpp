#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

void find_cube_rotation(double A) {
    double half_side = 0.5;
    double pi = acos(-1.0);

    double angle = (A - 1) / (sqrt(2) - 1);
    double theta = angle * (pi / 4);

    std::vector<std::vector<double>> points(3, std::vector<double>(3, 0));

    points[0][0] = half_side;
    points[0][1] = half_side * cos(theta);
    points[0][2] = -half_side * sin(theta);

    points[1][0] = half_side * cos(theta);
    points[1][1] = half_side;
    points[1][2] = half_side * sin(theta);

    points[2][0] = half_side * sin(theta);
    points[2][1] = half_side * cos(theta);
    points[2][2] = half_side;

    for (const auto& point : points) {
        std::cout << std::fixed << std::setprecision(15);
        for (const auto& coord : point) {
            std::cout << coord << " ";
        }
        std::cout << std::endl;
    }
}

int main() {
    int T;
    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;
        std::cout << "Case #" << t << ":" << std::endl;
        find_cube_rotation(A);
    }

    return 0;
}
