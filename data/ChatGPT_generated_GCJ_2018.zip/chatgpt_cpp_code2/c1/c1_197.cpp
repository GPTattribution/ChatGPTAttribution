#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

vector<vector<double>> calculate_face_centers(double A) {
    double alpha = (A - 1.0) / (sqrt(2) - 1.0);
    double angle = asin(alpha);
    double p1 = 0.5 * cos(angle);
    double p2 = 0.5 * sin(angle);

    return {
        {p1, p2, 0},
        {-p1, p2, 0},
        {0, 0.5, 0}
    };
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; ++t) {
        cin >> A;

        vector<vector<double>> face_centers = calculate_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto &center : face_centers) {
            cout << center[0] << " " << center[1] << " " << center[2] << endl;
        }
    }

    return 0;
}
