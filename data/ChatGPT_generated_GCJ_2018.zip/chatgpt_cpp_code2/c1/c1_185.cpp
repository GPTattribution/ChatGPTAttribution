#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

const double PI = acos(-1);

vector<vector<double>> find_face_centers(double A) {
    double alpha = 2 * asin(A / sqrt(2) - 0.5);
    double x1 = 0.5 * cos(alpha / 2);
    double z1 = 0.5 * sin(alpha / 2);
    double x2 = 0.5 * cos(alpha / 2 + PI / 4);
    double z2 = 0.5 * sin(alpha / 2 + PI / 4);

    return {
        {x1, 0.5, z1},
        {-x2, 0.5, z2},
        {0, 0.5, 0.5}
    };
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(10);

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<vector<double>> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto& center : face_centers) {
            for (double coord : center) {
                cout << coord << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
