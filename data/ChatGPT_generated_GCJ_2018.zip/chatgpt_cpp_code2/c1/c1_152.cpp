#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPSILON = 1e-6;

void rotate_cube(double A) {
    double theta = asin(A / sqrt(2) - EPSILON);
    double cos_theta = cos(theta);
    double sin_theta = sin(theta);

    double p1_x = 0.5 * cos_theta;
    double p1_y = 0.5 * sin_theta;
    double p1_z = 0;

    double p2_x = -0.5 * cos_theta;
    double p2_y = 0.5 * sin_theta;
    double p2_z = 0;

    double p3_x = 0;
    double p3_y = 0;
    double p3_z = 0.5;

    cout << fixed << setprecision(12)
         << p1_x << " " << p1_y << " " << p1_z << endl
         << p2_x << " " << p2_y << " " << p2_z << endl
         << p3_x << " " << p3_y << " " << p3_z << endl;
}

int main() {
    int T;
    double A;
    cin >> T;

    for (int i = 1; i <= T; ++i) {
        cin >> A;
        cout << "Case #" << i << ":" << endl;
        rotate_cube(A);
    }

    return 0;
}
