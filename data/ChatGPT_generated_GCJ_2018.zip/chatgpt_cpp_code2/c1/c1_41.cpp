#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

const double EPSILON = 1e-6;

struct Point {
    double x, y, z;
};

double getAngle(const Point &p1, const Point &p2) {
    double dotProduct = p1.x * p2.x + p1.y * p2.y + p1.z * p2.z;
    double magnitudeP1 = std::sqrt(p1.x * p1.x + p1.y * p1.y + p1.z * p1.z);
    double magnitudeP2 = std::sqrt(p2.x * p2.x + p2.y * p2.y + p2.z * p2.z);
    double cosTheta = dotProduct / (magnitudeP1 * magnitudeP2);
    return std::acos(cosTheta);
}

bool isValidConfiguration(const std::vector<Point> &points, double A) {
    for (const auto &point : points) {
        double distance = std::sqrt(point.x * point.x + point.y * point.y + point.z * point.z);
        if (distance < 0.5 - EPSILON || distance > 0.5 + EPSILON) {
            return false;
        }
    }

    for (int i = 0; i < 3; ++i) {
        double angle = getAngle(points[i], points[(i + 1) % 3]);
        if (angle < M_PI_2 - EPSILON || angle > M_PI_2 + EPSILON) {
            return false;
        }
    }

    double projectedArea = std::abs(points[0].z * points[1].x - points[0].x * points[1].z) / 2;
    if (projectedArea < A - EPSILON || projectedArea > A + EPSILON) {
        return false;
    }

    return true;
}

std::vector<Point> findRotation(double A) {
    double theta = std::acos(A / std::sqrt(2));
    double rotation = theta / 2;

    std::vector<Point> points = {
        {0.5 * std::cos(rotation), 0.5 * std::sin(rotation), 0},
        {0.5 * std::cos(rotation + M_PI_2), 0.5 * std::sin(rotation + M_PI_2), 0},
        {0, 0, 0.5}
    };

    if (isValidConfiguration(points, A)) {
        return points;
    }

    return {};
}

int main() {
    int T;
    std::cin >> T;

    std::cout << std::fixed << std::setprecision(15);

    for (int i = 1; i <= T; ++i) {
        double A;
        std::cin >> A;

        std::vector<Point> points = findRotation(A);

        std::cout << "Case #" << i << ":" << std::endl;
        for (const auto &point : points) {
            std::cout << point.x << " " << point.y << " " << point.z << std::endl;
        }
    }

    return 0;
}
