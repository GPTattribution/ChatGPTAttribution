#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

constexpr double EPS = 1e-6;
constexpr double PI = acos(-1.0);

using namespace std;

vector<vector<double>> solve(double A) {
    double theta = asin(A / sqrt(2));
    double cos_theta = cos(theta);
    double sin_theta = sin(theta);

    vector<vector<double>> result(3, vector<double>(3));

    result[0][0] = 0.5;
    result[0][1] = 0;
    result[0][2] = 0;

    result[1][0] = 0;
    result[1][1] = 0.5 * cos_theta;
    result[1][2] = 0.5 * sin_theta;

    result[2][0] = 0;
    result[2][1] = -0.5 * sin_theta;
    result[2][2] = 0.5 * cos_theta;

    return result;
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(10);

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;

        vector<vector<double>> result = solve(A);

        cout << "Case #" << t << ":" << endl;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                cout << result[i][j] << (j == 2 ? "\n" : " ");
            }
        }
    }

    return 0;
}
