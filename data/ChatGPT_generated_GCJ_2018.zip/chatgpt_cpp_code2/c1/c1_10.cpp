#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

double area_to_edge_ratio(double area) {
    return sqrt(area / sqrt(2));
}

vector<vector<double>> get_face_centers(double edge_ratio) {
    return {
        { edge_ratio / 2, edge_ratio / 2, 0 },
        { -edge_ratio / 2, edge_ratio / 2, 0 },
        { 0, 0, edge_ratio / sqrt(2) }
    };
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; ++t) {
        cin >> A;

        double edge_ratio = area_to_edge_ratio(A);
        vector<vector<double>> face_centers = get_face_centers(edge_ratio);

        cout << "Case #" << t << ":" << endl;
        for (const auto &face_center : face_centers) {
            for (const auto &coord : face_center) {
                cout << coord << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
