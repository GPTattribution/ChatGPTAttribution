#include <iostream>
#include <cmath>
#include <vector>

const double EPS = 1e-6;

double get_area(double A) {
    return (A - 1) / (1.732050 - 1);
}

std::vector<std::vector<double>> get_coordinates(double area_ratio) {
    double theta = area_ratio * M_PI / 4;
    double x = 0.5 * cos(theta);
    double y = 0.5 * sin(theta);
    double z = 0.5;

    return {
        {x, y, z},
        {-x, y, z},
        {z, x, y}
    };
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; t++) {
        double A;
        std::cin >> A;

        double area_ratio = get_area(A);
        std::vector<std::vector<double>> coords = get_coordinates(area_ratio);

        std::cout.precision(10);
        std::cout << "Case #" << t << ":" << std::endl;
        for (const auto& coord : coords) {
            std::cout << coord[0] << " " << coord[1] << " " << coord[2] << std::endl;
        }
    }

    return 0;
}
