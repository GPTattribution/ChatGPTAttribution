#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

vector<vector<double>> find_face_centers(double area) {
    double alpha = acos((area - 1.0) / sqrt(2.0));
    double beta = M_PI / 4 - alpha;

    double x = 0.5 * cos(beta);
    double y = 0.5 * sin(beta);

    vector<vector<double>> face_centers = {
        {x, y, 0.0},
        {-y, x, 0.0},
        {0.0, 0.0, 0.5}
    };

    return face_centers;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; ++i) {
        double area;
        cin >> area;
        vector<vector<double>> face_centers = find_face_centers(area);

        cout << "Case #" << i << ":" << endl;
        for (const auto& face_center : face_centers) {
            for (double coordinate : face_center) {
                cout << coordinate << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
