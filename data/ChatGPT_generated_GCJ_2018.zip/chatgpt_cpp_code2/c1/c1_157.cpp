#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

vector<double> rotate(double a) {
    double theta = acos(a / sqrt(2));
    double x = 0.5 * cos(theta);
    double y = 0.5 * sin(theta);

    return {x, y, 0};
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        double a;
        cin >> a;

        vector<double> v1 = rotate(a / sqrt(2));
        vector<double> v2 = {-v1[1], v1[0], 0};
        vector<double> v3 = {0, 0, 0.5};

        cout << "Case #" << i << ":" << endl;
        cout << fixed << setprecision(15);
        cout << v1[0] << " " << v1[1] << " " << v1[2] << endl;
        cout << v2[0] << " " << v2[1] << " " << v2[2] << endl;
        cout << v3[0] << " " << v3[1] << " " << v3[2] << endl;
    }

    return 0;
}
