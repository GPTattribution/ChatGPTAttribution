#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPS = 1e-6;
const double PI = acos(-1.0);

void find_face_centers(double A, double& x1, double& y1, double& z1, double& x2, double& y2, double& z2, double& x3, double& y3, double& z3) {
    double theta = acos(A / sqrt(2.0));

    x1 = 0.5 * cos(theta);
    y1 = 0.5 * sin(theta);
    z1 = 0;

    x2 = -0.5 * sin(theta) * cos(PI / 6);
    y2 = 0.5 * sin(theta) * sin(PI / 6);
    z2 = 0.5 * cos(theta);

    x3 = -0.5 * sin(theta) * cos(-PI / 6);
    y3 = 0.5 * sin(theta) * sin(-PI / 6);
    z3 = 0.5 * cos(theta);
}

int main() {
    int T;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        double x1, y1, z1, x2, y2, z2, x3, y3, z3;
        find_face_centers(A, x1, y1, z1, x2, y2, z2, x3, y3, z3);

        cout << "Case #" << t << ":" << endl;
        cout << x1 << " " << y1 << " " << z1 << endl;
        cout << x2 << " " << y2 << " " << z2 << endl;
        cout << x3 << " " << y3 << " " << z3 << endl;
    }

    return 0;
}
