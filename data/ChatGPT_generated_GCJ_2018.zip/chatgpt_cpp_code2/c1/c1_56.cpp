#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

vector<double> find_face_centers(double A) {
    double theta = acos(A / sqrt(2));
    double half_side = 0.5;

    double x = half_side * cos(theta);
    double y = half_side * sin(theta);

    return {x, y, 0, -x, y, 0, 0, 0, half_side};
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        vector<double> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                cout << face_centers[i * 3 + j] << (j < 2 ? ' ' : '\n');
            }
        }
    }

    return 0;
}
