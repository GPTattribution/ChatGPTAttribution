#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

const double EPSILON = 1e-6;

vector<vector<double>> find_face_centers(double A) {
    double theta = acos((A - 1.0) / (sqrt(2.0) - 1.0));
    double x = 0.5 * cos(theta);
    double y = 0.5 * sin(theta);

    return {
        {x, y, 0},
        {-x, y, 0},
        {0, 0, 0.5}
    };
}

int main() {
    int T;
    double A;

    cin >> T;

    for (int t = 1; t <= T; ++t) {
        cin >> A;
        vector<vector<double>> face_centers = find_face_centers(A);

        cout.precision(15);
        cout << "Case #" << t << ":\n";
        for (const auto& fc : face_centers) {
            cout << fc[0] << " " << fc[1] << " " << fc[2] << "\n";
        }
    }

    return 0;
}
