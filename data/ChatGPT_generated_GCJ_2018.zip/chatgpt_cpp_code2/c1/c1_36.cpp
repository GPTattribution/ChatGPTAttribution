#include <iostream>
#include <cmath>

using namespace std;

struct Point {
    double x, y, z;
};

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        Point vertices[8] = {
            {0.5, 0.5, 0.5},
            {-0.5, 0.5, 0.5},
            {0.5, -0.5, 0.5},
            {0.5, 0.5, -0.5},
            {-0.5, -0.5, 0.5},
            {0.5, -0.5, -0.5},
            {-0.5, 0.5, -0.5},
            {-0.5, -0.5, -0.5}
        };

        Point normal = {0, 1, 0};
    }
    return 0;
}
