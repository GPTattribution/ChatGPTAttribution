#include <iostream>
#include <cmath>
#include <iomanip>

const double PI = acos(-1.0);

void solve(int test_case, double A) {
    double theta = asin(A / sqrt(2)) / 2;

    double p1_x = 0.5 * cos(theta);
    double p1_y = 0.5 * sin(theta);
    double p1_z = 0;

    double p2_x = -0.5 * sin(theta);
    double p2_y = 0.5 * cos(theta);
    double p2_z = 0;

    double p3_x = 0;
    double p3_y = 0;
    double p3_z = 0.5;

    std::cout << std::fixed << std::setprecision(10);
    std::cout << "Case #" << test_case << ":\n";
    std::cout << p1_x << " " << p1_y << " " << p1_z << "\n";
    std::cout << p2_x << " " << p2_y << " " << p2_z << "\n";
    std::cout << p3_x << " " << p3_y << " " << p3_z << "\n";
}

int main() {
    int T;
    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;
        solve(t, A);
    }
    return 0;
}
