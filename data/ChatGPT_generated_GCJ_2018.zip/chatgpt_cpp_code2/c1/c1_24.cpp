#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(double target_area) {
    double half_side = 0.5;
    double pi_over_4 = M_PI / 4;
    double theta = (target_area - 1) / (sqrt(2) - 1);
    double phi = asin(theta) / 2;

    double x1 = half_side * cos(phi) * cos(pi_over_4 - phi);
    double z1 = half_side * cos(phi) * sin(pi_over_4 - phi);

    double x2 = half_side * sin(phi) * cos(pi_over_4 + phi);
    double z2 = half_side * sin(phi) * sin(pi_over_4 + phi);

    cout << x1 << " " << 0 << " " << z1 << endl;
    cout << x2 << " " << 0 << " " << -z2 << endl;
    cout << 0 << " " << half_side << " " << 0 << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        cout << "Case #" << t << ":" << endl;
        cout << fixed << setprecision(15);
        solve(A);
    }
    return 0;
}
