#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void computeRotationPoints(double A) {
    double theta = (acos(A / sqrt(2)) - M_PI_4);
    double x = 0.5 * cos(theta);
    double z = 0.5 * sin(theta);

    cout << setprecision(10) << x << " " << 0.5 << " " << z << endl;
    cout << setprecision(10) << -x << " " << 0.5 << " " << -z << endl;
    cout << setprecision(10) << 0.0 << " " << 0.5 << " " << 0.5 << endl;
}

int main() {
    int T;
    double A;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        cin >> A;
        cout << "Case #" << t << ":" << endl;
        computeRotationPoints(A);
    }

    return 0;
}
