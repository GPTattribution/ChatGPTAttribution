#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

double pi = acos(-1.0);

void solve(int case_num, double A) {
    double theta = asin(A / sqrt(2)) / 2;
    double x1 = 0.5 * cos(theta);
    double z1 = 0.5 * sin(theta);
    double x2 = 0.5 * cos(pi / 4 - theta);
    double z2 = -0.5 * sin(pi / 4 - theta);

    cout << fixed << setprecision(15);
    cout << "Case #" << case_num << ":" << endl;
    cout << x1 << " 0 " << z1 << endl;
    cout << x2 << " 0 " << z2 << endl;
    cout << "0 0.5 0" << endl;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;
        solve(i, A);
    }
    return 0;
}
