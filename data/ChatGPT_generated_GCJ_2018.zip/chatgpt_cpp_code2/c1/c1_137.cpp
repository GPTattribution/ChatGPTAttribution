#include <iostream>
#include <cmath>
#include <iomanip>

const double EPSILON = 1e-6;

struct Point {
    double x, y, z;
};

Point calculate_face_center(double a, double area) {
    double theta = acos((a * a - 2 * area) / (a * a));
    double half_theta = theta / 2.0;

    Point face_center;
    face_center.x = 0.5 * sin(half_theta);
    face_center.y = 0.5 * cos(half_theta);
    face_center.z = 0.0;

    return face_center;
}

int main() {
    int t;
    std::cin >> t;

    for (int case_num = 1; case_num <= t; ++case_num) {
        double target_area;
        std::cin >> target_area;

        Point face_center1 = calculate_face_center(1, target_area);
        Point face_center2 = {-face_center1.x, face_center1.y, 0};
        Point face_center3 = {0, face_center1.y, face_center1.x};

        std::cout << std::fixed << std::setprecision(10);
        std::cout << "Case #" << case_num << ":" << std::endl;
        std::cout << face_center1.x << " " << face_center1.y << " " << face_center1.z << std::endl;
        std::cout << face_center2.x << " " << face_center2.y << " " << face_center2.z << std::endl;
        std::cout << face_center3.x << " " << face_center3.y << " " << face_center3.z << std::endl;
    }

    return 0;
}
