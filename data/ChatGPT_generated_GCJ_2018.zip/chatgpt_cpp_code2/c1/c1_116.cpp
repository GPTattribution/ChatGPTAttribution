#include <iostream>
#include <cmath>
#include <iomanip>

const double PI = std::acos(-1.0);
const double HALF_SIDE = 0.5;

void solve(int case_number, double A) {
    double angle = (A - 1.0) / (std::sqrt(2) - 1.0);
    double theta = angle * (PI / 4);

    double p1_x = HALF_SIDE * std::cos(theta);
    double p1_z = HALF_SIDE * std::sin(theta);
    double p2_x = HALF_SIDE * std::cos(PI / 2 - theta);
    double p2_z = HALF_SIDE * std::sin(PI / 2 - theta);

    std::cout << "Case #" << case_number << ":\n";
    std::cout << std::fixed << std::setprecision(10)
              << p1_x << " " << 0.0 << " " << p1_z << "\n"
              << p2_x << " " << 0.0 << " " << p2_z << "\n"
              << 0.0 << " " << 0.5 << " " << 0.0 << std::endl;
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;
        solve(t, A);
    }

    return 0;
}
