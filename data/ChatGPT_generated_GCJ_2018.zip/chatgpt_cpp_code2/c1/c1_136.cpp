#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

const double EPS = 1e-6;
const double PI = acos(-1.0);

void find_face_centers(double A, vector<vector<double>>& face_centers) {
    double angle = (A - 1) * PI / 4;
    double cos_angle = cos(angle);
    double sin_angle = sin(angle);

    face_centers = {
        {0.5 * cos_angle, 0.5 * sin_angle, 0},
        {-0.5 * sin_angle, 0.5 * cos_angle, 0},
        {0, 0, 0.5}
    };
}

int main() {
    int T;
    cin >> T;
    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        vector<vector<double>> face_centers;

        find_face_centers(A, face_centers);

        cout << "Case #" << t << ":" << endl;
        for (const auto& face_center : face_centers) {
            for (const auto& coord : face_center) {
                cout << coord << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
