#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(double A) {
double theta = acos(A / sqrt(2));
double x = 0.5 * cos(theta);
double z = 0.5 * sin(theta);
cout << fixed << setprecision(10);
cout << x << " " << 0.0 << " " << z << endl;
cout << -x << " " << 0.0 << " " << z << endl;
cout << 0.0 << " " << 0.5 << " " << 0.0 << endl;
}

int main() {
int T;
cin >> T;
for (int t = 1; t <= T; t++) {
    double A;
    cin >> A;
    cout << "Case #" << t << ":" << endl;
    solve(A);
}

return 0;
}
