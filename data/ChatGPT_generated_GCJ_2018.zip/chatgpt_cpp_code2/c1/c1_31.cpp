#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

struct Point {
    double x, y, z;
};

double calc_area(double A) {
    return (A * A) / 2.0;
}

std::vector<Point> find_face_centers(double A) {
    double angle = (A - 1.0) * M_PI_4;
    double cos_angle = cos(angle);
    double sin_angle = sin(angle);

    return {
        {0.5 * cos_angle, 0.5 * sin_angle, 0},
        {-0.5 * cos_angle, 0.5 * sin_angle, 0},
        {0, 0, 0.5}
    };
}

int main() {
    int T;
    double A;

    std::cin >> T;
    std::cout << std::fixed << std::setprecision(15);

    for (int t = 1; t <= T; ++t) {
        std::cin >> A;
        std::vector<Point> face_centers = find_face_centers(A);

        std::cout << "Case #" << t << ":" << std::endl;
        for (const Point &p : face_centers) {
            std::cout << p.x << " " << p.y << " " << p.z << std::endl;
        }
    }

    return 0;
}
