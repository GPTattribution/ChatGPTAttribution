#include <iostream>
#include <iomanip>
#include <cmath>

const double PI = 3.14159265358979323846;

void find_face_centers(double A) {
    double theta = acos(A / sqrt(2));
    double x = 0.5 * cos(theta);
    double z = 0.5 * sin(theta);

    std::cout << std::fixed << std::setprecision(15)
              << x << " 0 " << z << std::endl
              << -x << " 0 " << z << std::endl
              << "0 0.5 0" << std::endl;
}

int main() {
    int T;
    double A;

    std::cin >> T;
    for (int i = 1; i <= T; ++i) {
        std::cin >> A;
        std::cout << "Case #" << i << ":" << std::endl;
        find_face_centers(A);
    }

    return 0;
}
