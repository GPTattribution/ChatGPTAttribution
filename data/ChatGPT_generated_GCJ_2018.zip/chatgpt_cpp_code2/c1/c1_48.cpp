#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void rotate_ship(double A) {
    double theta = (acos(A / sqrt(2.0)) - M_PI_4) / 2.0;
    double c = cos(theta), s = sin(theta);
    double x1 = 0.5 * (c + s);
    double z1 = 0.5 * (c - s);

    cout << fixed << setprecision(15);
    cout << x1 << " 0.0 " << z1 << endl;
    cout << -x1 << " 0.0 " << z1 << endl;
    cout << "0.0 0.0 0.5" << endl;
}

int main() {
    int T;
    double A;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        cin >> A;
        cout << "Case #" << t << ":" << endl;
        rotate_ship(A);
    }
    return 0;
}
