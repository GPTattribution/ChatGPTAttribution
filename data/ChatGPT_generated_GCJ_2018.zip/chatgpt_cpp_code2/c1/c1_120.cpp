#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

const double EPS = 1e-9;

struct Point {
    double x, y, z;

    Point(double x = 0, double y = 0, double z = 0) : x(x), y(y), z(z) {}
};

void solve(int t, double A) {
    double a = 0.5;
    double b = A / std::sqrt(2);
    double angle = std::asin(b / a);

    Point p1(a * std::cos(angle), a * std::sin(angle), 0);
    Point p2(-a * std::sin(angle / 2), a * std::cos(angle / 2), a * std::cos(angle / 2));
    Point p3(0, a * std::cos(angle / 2), a * std::cos(angle / 2));

    std::cout << std::fixed << std::setprecision(15);
    std::cout << "Case #" << t << ":" << std::endl;
    std::cout << p1.x << " " << p1.y << " " << p1.z << std::endl;
    std::cout << p2.x << " " << p2.y << " " << p2.z << std::endl;
    std::cout << p3.x << " " << p3.y << " " << p3.z << std::endl;
}

int main() {
    int T;
    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;
        solve(t, A);
    }
    return 0;
}
