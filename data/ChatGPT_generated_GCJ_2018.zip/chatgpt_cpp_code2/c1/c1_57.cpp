#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

const double EPS = 1e-6;

void solve(int case_num, double A) {
    double theta = asin(A / sqrt(2.0));
    double cos_theta = cos(theta);
    double sin_theta = sin(theta);

    vector<vector<double>> points = {
        {0.5 * cos_theta, 0.5 * sin_theta, 0},
        {-0.5 * sin_theta, 0.5 * cos_theta, 0},
        {0, 0, 0.5}
    };

    cout << "Case #" << case_num << ":" << endl;
    for (const auto& point : points) {
        for (double coord : point) {
            cout << coord << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        solve(t, A);
    }
    return 0;
}
