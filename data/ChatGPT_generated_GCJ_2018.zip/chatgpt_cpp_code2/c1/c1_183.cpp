#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

const double PI = acos(-1);

vector<double> solve(double A) {
    double theta = asin(A / sqrt(2)) / 2;
    double c = cos(theta);
    double s = sin(theta);

    return {0.5 * (c + s), 0.5 * (c - s), 0.0,
            -0.5 * (c + s), 0.5 * (c - s), 0.0,
            0.0, 0.0, 0.5};
}

int main() {
    int T;
    cin >> T;
    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        vector<double> res = solve(A);

        cout << "Case #" << t << ":" << endl;
        for (int i = 0; i < 3; i++) {
            cout << res[i * 3] << " " << res[i * 3 + 1] << " " << res[i * 3 + 2] << endl;
        }
    }

    return 0;
}
