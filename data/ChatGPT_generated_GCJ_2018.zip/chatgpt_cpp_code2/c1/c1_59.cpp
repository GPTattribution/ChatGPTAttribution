#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

vector<vector<double>> find_face_centers(double A) {
    double a = sqrt(2) * (A - 1);
    double angle = asin(a);
    double x = 0.5 * cos(angle);
    double z = 0.5 * sin(angle);
    return {
        {x, 0.5, z},
        {-x, 0.5, z},
        {0, 0.5, 0.5}
    };
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(15);
    for (int t = 1; t <= T; ++t) {
        cin >> A;
        vector<vector<double>> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto &center : face_centers) {
            cout << center[0] << " " << center[1] << " " << center[2] << endl;
        }
    }

    return 0;
}
