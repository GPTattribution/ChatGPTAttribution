#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

vector<vector<double>> find_face_centers(double area) {
    double a = (area - 1) / (sqrt(2) - 1);
    double b = sqrt(2) * a;
    double angle = (a * a + 0.5 * 0.5 - b * b) / (a * 0.5);

    double x = 0.5 * angle;
    double y = sqrt(0.5 * 0.5 - x * x);
    double z = 0;

    return {
        {x, y, z},
        {-x, y, z},
        {0, 0, 0.5}
    };
}

int main() {
    int T;
    double A;

    cout << fixed << setprecision(15);

    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> A;
        auto face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto& center : face_centers) {
            cout << center[0] << " " << center[1] << " " << center[2] << endl;
        }
    }

    return 0;
}
