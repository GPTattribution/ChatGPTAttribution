#include <iostream>
using namespace std;

int main() {
    int T;
    cin >> T;
    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;
        int counter = 0;
        while (counter < N) {
            int guess = (A+B)/2;
            cout << guess << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                A = guess + 1;
            } else {
                B = guess - 1;
            }
            counter++;
        }
    }
    return 0;
}
