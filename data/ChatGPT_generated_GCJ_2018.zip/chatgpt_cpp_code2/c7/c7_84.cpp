#include <bits/stdc++.h>
using namespace std;

int ask(int guess) {
    cout << guess << endl;
    string response;
    cin >> response;
    if (response == "CORRECT") {
        return 0;
    } else if (response == "TOO_SMALL") {
        return -1;
    } else {
        return 1;
    }
}

int main() {
    int T;
    cin >> T;
    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;
        int l = A + 1, r = B;
        int tries = 0;
        while (l <= r && tries < N) {
            int mid = (l + r) / 2;
            int res = ask(mid);
            if (res == 0) {
                break;
            } else if (res == -1) {
                l = mid + 1;
            } else {
                r = mid - 1;
            }
            tries++;
        }
    }
    return 0;
}
