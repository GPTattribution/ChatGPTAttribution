#include <iostream>
#include <string>

using namespace std;

int main() {
  int t;
  cin >> t;
  for (int i = 1; i <= t; i++) {
    int a, b, n;
    cin >> a >> b >> n;
    while (n--) {
      int guess = (a + b + 1) / 2;
      cout << guess << endl;
      string response;
      cin >> response;
      if (response == "CORRECT") break;
      else if (response == "TOO_SMALL") a = guess;
      else if (response == "TOO_BIG") b = guess - 1;
    }
  }
  return 0;
}
