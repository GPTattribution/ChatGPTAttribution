#include <iostream>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        int A, B, N;
        cin >> A >> B >> N;

        while (N--) {
            int mid = (A + B + 1) / 2;
            cout << mid << endl;

            string response;
            cin >> response;

            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                A = mid;
            } else if (response == "TOO_BIG") {
                B = mid - 1;
            } else {
                return 1;
            }
        }
    }

    return 0;
}
