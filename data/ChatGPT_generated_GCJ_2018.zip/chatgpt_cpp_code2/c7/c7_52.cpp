#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;

    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;

        while (N--) {
            int guess = (A + B + 1) / 2;
            cout << guess << endl;

            string response;
            cin >> response;

            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                A = guess;
            } else if (response == "TOO_BIG") {
                B = guess - 1;
            }
        }
    }

    return 0;
}
