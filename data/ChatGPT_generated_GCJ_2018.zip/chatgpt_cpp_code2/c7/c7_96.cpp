#include <iostream>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int A, B, N;
        cin >> A >> B >> N;
        int guess = (A + B + 1) / 2;
        int num_guesses = 0;
        while (num_guesses < N) {
            cout << guess << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                A = guess + 1;
            } else {
                B = guess - 1;
            }
            guess = (A + B + 1) / 2;
            num_guesses++;
        }
    }
    return 0;
}
