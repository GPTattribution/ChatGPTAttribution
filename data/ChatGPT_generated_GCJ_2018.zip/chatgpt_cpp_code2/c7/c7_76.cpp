#include <iostream>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int A, B, N;
        cin >> A >> B >> N;
        for (int i = 1; i <= N; i++) {
            int mid = (A + B + 1) / 2;
            cout << mid << endl;
            string feedback;
            cin >> feedback;
            if (feedback == "CORRECT") {
                break;
            } else if (feedback == "TOO_SMALL") {
                A = mid;
            } else {
                B = mid - 1;
            }
        }
    }
    return 0;
}
