#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int A, B, N;
        cin >> A >> B >> N;

        int left = A+1, right = B;
        while (left <= right) {
            int mid = (left + right) / 2;
            cout << mid << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                left = mid+1;
            } else {
                right = mid-1;
            }
            N--;
            if (N == 0) {
                break;
            }
        }
    }
    return 0;
}
