#include <iostream>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int A, B, N;
        cin >> A >> B >> N;
        int guess = A + 1;
        while (N--) {
            cout << guess << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                A = guess;
                guess = (A + B + 1) / 2;
            } else if (response == "TOO_BIG") {
                B = guess - 1;
                guess = (A + B + 1) / 2;
            } else {
                return 0;
            }
        }
    }
    return 0;
}
