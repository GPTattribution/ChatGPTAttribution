#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    while (t--) {
        int a, b, n;
        cin >> a >> b >> n;

        while (n--) {
            int mid = (a + b + 1) / 2;
            cout << mid << endl;
            string s;
            cin >> s;
            if (s == "TOO_SMALL") {
                a = mid;
            } else if (s == "TOO_BIG") {
                b = mid - 1;
            } else {
                break;
            }
        }
    }
    return 0;
}
