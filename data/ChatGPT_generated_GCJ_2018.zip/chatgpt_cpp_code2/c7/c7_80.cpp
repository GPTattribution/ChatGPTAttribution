#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    while (t--) {
        int a, b, n;
        cin >> a >> b >> n;
        while (n--) {
            int q = (a + b + 1) / 2; 
            cout << q << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            }
            if (response == "TOO_SMALL") {
                a = q;
            } else {
                b = q - 1;
            }
        }
    }
    return 0;
}
