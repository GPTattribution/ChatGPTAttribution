#include <iostream>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int i = 0; i < T; i++) {
        int A, B, N;
        cin >> A >> B >> N;

        while (N > 0) {
            int guess = (A + B + 1) / 2;
            cout << guess << endl;

            string result;
            cin >> result;

            if (result == "CORRECT") {
                break;
            } else if (result == "TOO_SMALL") {
                A = guess;
            } else {
                B = guess - 1;
            }

            N--;
        }
    }

    return 0;
}
