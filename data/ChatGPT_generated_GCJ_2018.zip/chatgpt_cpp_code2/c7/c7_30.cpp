#include <iostream>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;
        int low = A + 1, high = B;
        while (N--) {
            int guess = (low + high) / 2;
            cout << guess << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                low = guess + 1;
            } else if (response == "TOO_BIG") {
                high = guess - 1;
            } else {
                break;
            }
        }
    }
    return 0;
}
