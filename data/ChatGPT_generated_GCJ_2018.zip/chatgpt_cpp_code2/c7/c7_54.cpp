#include <iostream>
using namespace std;

int main() {
    int T;
    cin >> T;

    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;

        int left = A + 1;
        int right = B;

        while (N--) {
            int mid = left + (right - left) / 2;
            cout << mid << endl;

            string response;
            cin >> response;

            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                left = mid + 1;
            } else if (response == "TOO_BIG") {
                right = mid - 1;
            } else {
                return 0;
            }
        }
    }

    return 0;
}
