#include <iostream>
using namespace std;

int main() {
    int T;
    cin >> T;
    while(T--) {
        int A, B, N;
        cin >> A >> B >> N;

        int lo = A + 1, hi = B;
        bool correct = false;
        while(!correct && N--) {
            int guess = (lo + hi) / 2;
            cout << guess << endl;
            string response;
            cin >> response;
            if(response == "CORRECT") {
                correct = true;
            }
            else if(response == "TOO_SMALL") {
                lo = guess + 1;
            }
            else {
                hi = guess - 1;
            }
        }
    }
    return 0;
}
