#include <iostream>

using namespace std;

int main() {
    int t;
    cin >> t;

    while (t--) {
        int a, b, n;
        cin >> a >> b >> n;

        while (n--) {
            int mid = (a + b + 1) / 2;
            cout << mid << endl;

            string result;
            cin >> result;

            if (result == "CORRECT") {
                break;
            } else if (result == "TOO_SMALL") {
                a = mid;
            } else if (result == "TOO_BIG") {
                b = mid - 1;
            } else {
                break;
            }
        }
    }

    return 0;
}
