#include <iostream>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        int A, B, N;
        cin >> A >> B >> N;

        int low = A, high = B;
        int guess = (low + high + 1) / 2;

        for (int i = 0; i < N; ++i) {
            cout << guess << endl;
            string response;
            cin >> response;

            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                low = guess;
            } else if (response == "TOO_BIG") {
                high = guess - 1;
            }

            guess = (low + high + 1) / 2;
        }

        cout << "WRONG_ANSWER" << endl;
    }

    return 0;
}
