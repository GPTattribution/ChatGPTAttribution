#include <iostream>
using namespace std;

int main() {
    int t;
    cin >> t;
    while (t--) {
        int a, b, n;
        cin >> a >> b >> n;
        while (n--) {
            int mid = (a + b + 1) / 2;
            cout << mid << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") break;
            else if (response == "TOO_SMALL") a = mid;
            else if (response == "TOO_BIG") b = mid - 1;
        }
    }
    return 0;
}
