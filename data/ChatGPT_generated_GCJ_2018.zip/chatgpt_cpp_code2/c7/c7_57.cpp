#include <iostream>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int A, B, N;
        cin >> A >> B >> N;

        int low = A + 1, high = B;
        while (true) {
            int mid = (low + high) / 2;
            cout << mid << endl;
            string result;
            cin >> result;
            if (result == "CORRECT") {
                break;
            } else if (result == "TOO_SMALL") {
                low = mid + 1;
            } else if (result == "TOO_BIG") {
                high = mid - 1;
            } else {
                break;
            }
        }
    }
    return 0;
}
