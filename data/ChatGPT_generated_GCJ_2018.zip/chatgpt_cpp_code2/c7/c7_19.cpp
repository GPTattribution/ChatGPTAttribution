#include <iostream>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;
        for (int i = 1; i <= N; i++) {
            int guess = (A + B) / 2;
            cout << guess << endl;
            string feedback;
            cin >> feedback;
            if (feedback == "CORRECT") {
                break;
            } else if (feedback == "TOO_SMALL") {
                A = guess + 1;
            } else {
                B = guess - 1;
            }
        }
    }
    return 0;
}
