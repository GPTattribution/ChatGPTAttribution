#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;

    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;

        int l = A+1, r = B, mid;
        while (N--) {
            mid = l + (r - l) / 2;
            cout << mid << endl;

            string response;
            cin >> response;

            if (response == "CORRECT") {
                break;
            }
            else if (response == "TOO_SMALL") {
                l = mid+1;
            }
            else if (response == "TOO_BIG") {
                r = mid-1;
            }
            else {
                exit(0);
            }
        }
    }

    return 0;
}
