#include <iostream>
#include <string>

using namespace std;

int main() {
    int t;
    cin >> t;

    while (t--) {
        int a, b, n;
        cin >> a >> b >> n;

        int low = a + 1;
        int high = b;
        int mid;

        while (true) {
            if (low > high) {
                cerr << "Error: low > high" << endl;
                return 1;
            }

            mid = low + (high - low) / 2;
            cout << mid << endl;

            string response;
            cin >> response;

            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                low = mid + 1;
            } else if (response == "TOO_BIG") {
                high = mid - 1;
            } else {
                cerr << "Error: invalid response" << endl;
                return 1;
            }

            n--;
            if (n == 0) {
                cerr << "Error: too many queries" << endl;
                return 1;
            }
        }
    }

    return 0;
}
