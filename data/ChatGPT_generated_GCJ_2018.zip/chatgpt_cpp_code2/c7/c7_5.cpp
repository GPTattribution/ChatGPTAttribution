#include <iostream>
#include <string>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        int A, B, N;
        cin >> A >> B >> N;
        cin.ignore();
        while (N--) {
            int guess = A + (B - A + 1) / 2; 
            cout << guess << endl;
            string response;
            getline(cin, response);
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                A = guess + 1;
            } else if (response == "TOO_BIG") {
                B = guess - 1;
            } else {
                return 1;
            }
        }
    }
    return 0;
}
