#include <iostream>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;
    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;
        while (N--) {
            int Q = (A + B + 1) / 2;
            cout << Q << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                A = Q;
            } else { 
                B = Q - 1;
            }
        }
    }
    return 0;
}
