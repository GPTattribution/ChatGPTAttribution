#include <iostream>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;

    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;

        int low = A + 1, high = B;
        while (N--) {
            int guess = (low + high) / 2;
            cout << guess << endl;

            string result;
            cin >> result;

            if (result == "CORRECT") {
                break;
            } else if (result == "TOO_SMALL") {
                low = guess + 1;
            } else {
                high = guess - 1;
            }
        }
    }

    return 0;
}
