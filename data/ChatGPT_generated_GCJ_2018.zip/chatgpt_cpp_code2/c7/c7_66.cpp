#include <iostream>
#include <cstdio>

using namespace std;

int main() {
    int T;
    cin >> T;

    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;

        int left = A+1, right = B;
        while (left <= right && N > 0) {
            int mid = (left + right) / 2;
            cout << mid << endl;
            N--;
            string result;
            cin >> result;
            if (result == "CORRECT") {
                break;
            } else if (result == "TOO_SMALL") {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
    }

    return 0;
}
