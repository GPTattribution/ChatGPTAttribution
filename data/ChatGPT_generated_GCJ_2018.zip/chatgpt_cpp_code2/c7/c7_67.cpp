#include <iostream>

using namespace std;

int main() {
    int t;
    cin >> t;
    while (t--) {
        int a, b, n;
        cin >> a >> b >> n;
        while (n--) {
            int q = (a + b + 1) / 2; 
            cout << q << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                a = q;
            } else if (response == "TOO_BIG") {
                b = q - 1;
            } else {
            }
        }
    }
    return 0;
}
