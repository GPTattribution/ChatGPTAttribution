#include <iostream>

using namespace std;

int main()
{
    int t;
    cin >> t;

    for(int i=1; i<=t; i++)
    {
        int a, b, n;
        cin >> a >> b >> n; 


        int lo = a + 1, hi = b, mid;
        while(lo <= hi)
        {
            mid = (lo + hi) / 2;
            cout << mid << endl;
            string response;
            cin >> response;
            if(response == "CORRECT")
            {
                break;
            }
            else if(response == "TOO_SMALL")
            {
                lo = mid + 1;
            }
            else if(response == "TOO_BIG")
            {
                hi = mid - 1;
            }
            else
            {
                return 0;
            }
        }
    }

    return 0;
}
