#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    while (t--) {
        int a, b, n;
        cin >> a >> b >> n;

        while (n--) {
            int m = (a + b + 1) / 2;
            cout << m << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                a = m;
            } else {
                b = m - 1;
            }
        }
    }
    return 0;
}
