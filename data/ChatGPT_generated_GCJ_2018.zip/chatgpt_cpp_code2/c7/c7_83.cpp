#include <iostream>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;

    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;

        int L = A + 1, R = B;
        bool found = false;

        while (N--) {
            int M = (L + R) / 2;
            cout << M << endl;
            string response;
            cin >> response;

            if (response == "CORRECT") {
                found = true;
                break;
            } else if (response == "TOO_SMALL") {
                L = M + 1;
            } else if (response == "TOO_BIG") {
                R = M - 1;
            }
        }

        if (!found) {
            cout << "WRONG_ANSWER" << endl;
            return 0;
        }
    }

    return 0;
}
