#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;

        int l = A + 1, r = B;
        while (N--) {
            int m = (l + r) / 2;
            cout << m << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                l = m + 1;
            } else {
                r = m - 1;
            }
        }

        fflush(stdout); 
    }
    return 0;
}
