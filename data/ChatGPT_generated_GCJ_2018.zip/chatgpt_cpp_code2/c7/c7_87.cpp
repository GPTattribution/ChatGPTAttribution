#include <iostream>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int A, B, N;
        cin >> A >> B >> N;
        int low = A + 1, high = B;
        for (int i = 1; i <= N; i++) {
            int mid = (low + high) / 2;
            cout << mid << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                low = mid + 1;
            } else if (response == "TOO_BIG") {
                high = mid - 1;
            }
        }
    }
    return 0;
}
