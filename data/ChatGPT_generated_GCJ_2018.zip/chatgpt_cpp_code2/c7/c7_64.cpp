#include <iostream>
#include <string>
using namespace std;

int main() {
    int T;
    cin >> T;
    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;
        int guess = (A + B + 1) / 2; 
        while (true) {
            cout << guess << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                A = guess + 1;
            } else if (response == "TOO_BIG") {
                B = guess - 1;
            }
            if (A > B) {
                break;
            }
            guess = (A + B + 1) / 2;
            N--;
            if (N == 0) {
                break;
            }
        }
    }
    return 0;
}
