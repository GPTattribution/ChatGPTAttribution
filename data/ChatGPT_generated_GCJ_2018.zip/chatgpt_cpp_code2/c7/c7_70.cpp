#include <iostream>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int A, B, N;
        cin >> A >> B >> N;
        int guesses = 0, lo = A, hi = B;
        while (guesses < N) {
            int mid = (lo + hi + 1) / 2;
            cout << mid << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                lo = mid;
            } else if (response == "TOO_BIG") {
                hi = mid - 1;
            }
            guesses++;
        }
        if (guesses >= N) {
            cout << "WRONG_ANSWER" << endl;
            return 0;
        }
    }
    return 0;
}
