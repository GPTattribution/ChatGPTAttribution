#include <iostream>
using namespace std;

int main() {
    int T;
    cin >> T;
    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;

        while (N--) {
            int mid = (A + B + 1) / 2; 
            cout << mid << endl;

            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                A = mid;
            } else {
                B = mid - 1;
            }
        }
    }
    return 0;
}
