#include <iostream>
#include <string>

using namespace std;

int main() {
    int T;
    cin >> T;

    while (T--) {
        int A, B, N;
        cin >> A >> B >> N;

        int low = A + 1;
        int high = B;
        int mid;

        while (true) {
            if (low > high) {
                cerr << "ERROR: Number not found!" << endl;
                exit(1);
            }

            mid = (low + high) / 2;

            cout << mid << endl;
            string response;
            cin >> response;

            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                low = mid + 1;
            } else if (response == "TOO_BIG") {
                high = mid - 1;
            } else {
                cerr << "ERROR: Invalid response from judge!" << endl;
                exit(1);
            }

            if (--N == 0) {
                cerr << "ERROR: Too many guesses!" << endl;
                exit(1);
            }
        }
    }

    return 0;
}
