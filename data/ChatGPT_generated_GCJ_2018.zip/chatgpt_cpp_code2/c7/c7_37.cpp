#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main() {
    int t, n;
    cin >> t;
    while (t--) {
        int a, b;
        cin >> a >> b >> n;
        int l = a + 1, r = b;
        bool found = false;
        while (!found && n--) {
            int m = (l + r) / 2;
            cout << m << endl;
            string s;
            cin >> s;
            if (s == "CORRECT") {
                found = true;
            } else if (s == "TOO_SMALL") {
                l = m + 1;
            } else {
                r = m - 1;
            }
        }
        if (!found) {
            exit(1);
        }
    }
    return 0;
}
