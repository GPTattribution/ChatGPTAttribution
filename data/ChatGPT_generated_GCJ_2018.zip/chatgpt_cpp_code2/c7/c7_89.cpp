#include <iostream>
#include <string>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int a, b, n;
        cin >> a >> b >> n;
        int l = a + 1, r = b;
        while (n--) {
            int m = (l + r) / 2;
            cout << m << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                l = m + 1;
            } else if (response == "TOO_BIG") {
                r = m - 1;
            } else {
                return 0;
            }
        }
    }
    return 0;
}
