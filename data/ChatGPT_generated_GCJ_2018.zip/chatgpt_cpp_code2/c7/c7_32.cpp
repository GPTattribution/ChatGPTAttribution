#include <iostream>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        int A, B, N;
        cin >> A >> B >> N;

        int left = A + 1, right = B;
        while (N--) {
            int mid = left + (right - left) / 2;
            cout << mid << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
    }
    return 0;
}
