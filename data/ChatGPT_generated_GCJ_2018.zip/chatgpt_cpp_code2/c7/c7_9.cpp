#include <iostream>
#include <string>

using namespace std;

int main() {
    int t;
    cin >> t;

    while (t--) {
        int a, b, n;
        cin >> a >> b >> n;

        int left = a + 1, right = b;
        while (n--) {
            int mid = (left + right) / 2;
            cout << mid << endl;
            string response;
            cin >> response;
            if (response == "CORRECT") {
                break;
            } else if (response == "TOO_SMALL") {
                left = mid + 1;
            } else if (response == "TOO_BIG") {
                right = mid - 1;
            } else {
                return 1;
            }
        }
    }

    return 0;
}
