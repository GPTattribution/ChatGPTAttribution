#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<int> max_kits(P, 0);
        for (int i = 0; i < N; i++) {
            sort(Q[i].begin(), Q[i].end());
            for (int j = 0; j < P; j++) {
                double upper = R[i] * 1.1;
                double lower = R[i] * 0.9;
                int k = Q[i][j] / upper;
                if (k == 0) {
                    continue;
                }
                double remaining = Q[i][j] - k * lower;
                int l = k;
                for (int m = j + 1; m < P; m++) {
                    if (Q[i][m] < remaining) {
                        remaining -= Q[i][m];
                        l++;
                    } else {
                        break;
                    }
                }
                max_kits[j] = max(max_kits[j], l);
            }
        }

        int ans = 0;
        for (int j = 0; j < P; j++) {
            ans += max_kits[j];
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
