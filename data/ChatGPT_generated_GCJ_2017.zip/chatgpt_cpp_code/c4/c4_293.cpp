#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

bool is_valid_kit(vector<int>& servings, vector<vector<int>>& packages, vector<int>& required) {
    int n = packages.size();
    vector<int> total(n, 0);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            total[j] += packages[i][servings[i]] * required[j];
        }
    }
    for (int i = 0; i < n; i++) {
        if (total[i] < 9 * servings.size() * required[i] || total[i] > 11 * servings.size() * required[i]) {
            return false;
        }
    }
    return true;
}

int count_kits(vector<vector<int>>& packages, vector<int>& required) {
    int n = packages.size();
    vector<int> servings(n, 0);
    for (int i = 0; i < n; i++) {
        servings[i] = i;
    }
    int max_kits = 0;
    do {
        bool done = false;
        for (int i = 1; i <= n; i++) {
            vector<int> cur_servings(servings.begin(), servings.begin() + i);
            if (is_valid_kit(cur_servings, packages, required)) {
                max_kits++;
            } else {
                done = true;
                break;
            }
        }
        if (done) {
            break;
        }
    } while (next_permutation(servings.begin(), servings.end()));
    return max_kits;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> required(n);
        for (int j = 0; j < n; j++) {
            cin >> required[j];
        }
        vector<vector<int>> packages(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> packages[j][k];
            }
            sort(packages[j].begin(), packages[j].end());
        }
        int max_kits = count_kits(packages, required);
        cout << "Case #" << i << ": " << max_kits << endl;
    }
    return 0;
}
