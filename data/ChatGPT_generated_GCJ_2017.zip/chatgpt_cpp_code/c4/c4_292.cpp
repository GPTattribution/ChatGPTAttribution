#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> total(n);
            int count = 0;
            bool valid = true;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    count++;
                    for (int k = 0; k < n; k++) {
                        total[k] += q[k][j];
                    }
                }
            }
            for (int j = 0; j < n; j++) {
                int required = r[j] * count;
                if (total[j] < 9 * required || total[j] > 11 * required) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, count);
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
