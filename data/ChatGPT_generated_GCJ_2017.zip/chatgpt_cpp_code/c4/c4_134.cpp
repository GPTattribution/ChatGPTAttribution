#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            bool valid = true;
            vector<int> amount(N, 0);
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < N; i++) {
                        amount[i] += Q[i][j];
                    }
                }
            }
            for (int i = 0; i < N; i++) {
                int servings = amount[i] / R[i];
                int lower = (int) (0.9 * servings + 0.5);
                int upper = (int) (1.1 * servings + 0.5);
                if (lower * R[i] > amount[i] || upper * R[i] < amount[i]) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = max(max_kits, __builtin_popcount(mask));
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
