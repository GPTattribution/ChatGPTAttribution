#include <iostream>
#include <vector>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            bool ok = true;
            vector<int> cnt(n, 0);
            for (int j = 0; j < p; j++) {
                if ((mask >> j) & 1) {
                    for (int k = 0; k < n; k++) {
                        cnt[k] += q[k][j];
                    }
                }
            }
            for (int j = 0; j < n; j++) {
                int servings = cnt[j] / r[j];
                if (cnt[j] < r[j] || servings < 1 || servings > 10) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                int num_kits = 1;
                for (int j = 0; j < n; j++) {
                    int servings = cnt[j] / r[j];
                    num_kits = min(num_kits, servings);
                }
                ans = max(ans, num_kits);
            }
        }

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
