#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool is_valid(vector<int> &ingredients, vector<int> &package, int num_servings) {
    for (int i = 0; i < ingredients.size(); i++) {
        int required = ingredients[i] * num_servings;
        int lower_bound = required * 0.9;
        int upper_bound = required * 1.1;
        if (package[i] < lower_bound || package[i] > upper_bound) {
            return false;
        }
    }
    return true;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> ingredients(N);
        for (int i = 0; i < N; i++) {
            cin >> ingredients[i];
        }
        vector<vector<int>> packages(P, vector<int>(N));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> packages[j][i];
            }
        }
        int result = 0;
        for (int i = 0; i < P; i++) {
            for (int j = 1; j <= 100; j++) {
                if (is_valid(ingredients, packages[i], j)) {
                    result = max(result, j);
                    break;
                }
            }
        }
        cout << "Case #" << t << ": " << result << endl;
    }
    return 0;
}
