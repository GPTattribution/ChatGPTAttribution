#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            cin >> r[i];
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> total(n);
            int num_packages = 0;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    num_packages++;
                    for (int i = 0; i < n; i++) {
                        total[i] += q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < n; i++) {
                int lower_bound = ceil(0.9 * r[i] * num_packages);
                int upper_bound = floor(1.1 * r[i] * num_packages);
                if (total[i] < lower_bound || total[i] > upper_bound) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = max(max_kits, num_packages);
            }
        }
        cout << "Case #" << case_num << ": " << max_kits << endl;
    }
    return 0;
}
