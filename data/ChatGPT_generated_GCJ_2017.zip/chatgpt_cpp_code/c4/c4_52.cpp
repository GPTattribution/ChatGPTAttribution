#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int x = 1; x <= t; ++x) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int i = 0; i < n; ++i) {
            cin >> r[i];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < p; ++j) {
                cin >> q[i][j];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << p); ++mask) {
            vector<int> total(n);
            int cnt = 0;
            for (int j = 0; j < p; ++j) {
                if ((mask >> j) & 1) {
                    ++cnt;
                    for (int i = 0; i < n; ++i) {
                        total[i] += q[i][j];
                    }
                }
            }
            bool ok = true;
            for (int i = 0; i < n; ++i) {
                if (total[i] < r[i] * cnt * 9 / 10 || total[i] > r[i] * cnt * 11 / 10) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, cnt);
            }
        }

        cout << "Case #" << x << ": " << ans << endl;
    }

    return 0;
}
