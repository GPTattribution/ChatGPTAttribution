#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;

int T, N, P;
int R[MAXN], Q[MAXN][MAXP];

bool can_make(int servings, vector<int>& quantities) {
    for (int i = 0; i < N; i++) {
        int min_qty = (R[i] * servings * 9 + 10) / 10;
        int max_qty = (R[i] * servings * 11) / 10;
        if (quantities[i] < min_qty || quantities[i] > max_qty) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    int max_kits = 0;
    for (int mask = 0; mask < (1 << P); mask++) {
        vector<int> quantities(N);
        int num_packages = 0;
        for (int j = 0; j < P; j++) {
            if (mask & (1 << j)) {
                for (int i = 0; i < N; i++) {
                    quantities[i] += Q[i][j];
                }
                num_packages++;
            }
        }
        int lo = 0, hi = 100000000;
        while (lo < hi) {
            int mid = (lo + hi + 1) / 2;
            if (can_make(mid, quantities)) {
                lo = mid;
            } else {
                hi = mid - 1;
            }
        }
        max_kits = max(max_kits, num_packages * lo);
    }
    return max_kits;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
