#include <bits/stdc++.h>
using namespace std;

int T, N, P, num, cnt, sum, l, r, mid, ans;
int a[55], b[55][55];

bool cmp(int x, int y) {
    return x > y;
}

bool check(int x) {
    int tmp[55];
    memcpy(tmp, a, sizeof(a));
    for (int i = 0; i < N; i++) {
        tmp[i] *= x;
    }
    sort(tmp, tmp + N, cmp);
    sort(b[0], b[0] + P, cmp);
    for (int i = 0; i < N; i++) {
        int k = 0;
        for (int j = 0; j < P; j++) {
            if (b[i][j] >= tmp[i] * 0.9 && b[i][j] <= tmp[i] * 1.1) {
                b[i][j] = -1;
                k++;
                break;
            }
        }
        if (!k) {
            return false;
        }
    }
    return true;
}

int main() {
    cin >> T;
    for (int C = 1; C <= T; C++) {
        cin >> N >> P;
        for (int i = 0; i < N; i++) {
            cin >> a[i];
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> b[i][j];
            }
        }
        l = 0, r = 1000000, ans = 0;
        while (l <= r) {
            mid = (l + r) / 2;
            if (check(mid)) {
                ans = mid;
                l = mid + 1;
            } else {
                r = mid - 1;
            }
        }
        cout << "Case #" << C << ": " << ans << endl;
    }
    return 0;
}
