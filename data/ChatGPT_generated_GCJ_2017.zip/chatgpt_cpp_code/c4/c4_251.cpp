#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace std;

const int MAX_N = 50;
const int MAX_P = 50;
const double EPSILON = 1e-9;

int N, P;
vector<int> R;
vector<vector<int>> Q;

bool isValidKit(const vector<int>& kit) {
    for (int i = 0; i < N; i++) {
        double total = 0;
        for (int j = 0; j < P; j++) {
            total += kit[j] * Q[i][j];
        }
        double required = R[i] * kit.back();
        if (total < required * 0.9 || total > required * 1.1) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    R.resize(N);
    Q.resize(N, vector<int>(P));
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    vector<int> kit(P, 0);
    kit.back() = 1;
    int max_kits = 0;
    while (true) {
        if (isValidKit(kit)) {
            max_kits = max(max_kits, kit.back());
        }
        int i = P - 2;
        while (i >= 0 && kit[i] == kit.back()) {
            i--;
        }
        if (i < 0) {
            break;
        }
        kit[i]++;
        for (int j = i + 1; j < P; j++) {
            kit[j] = kit[i];
        }
    }
    return max_kits;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
