#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        vector<int> indices(N);
        for (int i = 0; i < P; ++i) {
            bool found_kit = true;
            int min_kits = numeric_limits<int>::max();
            for (int j = 0; j < N; ++j) {
                int q = Q[j][i];
                int r = R[j];
                int min_q = ceil(0.9 * r * indices[j]);
                int max_q = floor(1.1 * r * indices[j]);
                if (q < min_q || q > max_q) {
                    found_kit = false;
                    break;
                }
                int num_kits = q / r;
                if (num_kits < min_kits) {
                    min_kits = num_kits;
                }
            }
            if (found_kit && min_kits > max_kits) {
                max_kits = min_kits;
            }
            for (int j = N - 1; j >= 0; --j) {
                int q = Q[j][i];
                int r = R[j];
                if (q < floor(0.9 * r * indices[j])) {
                    break;
                }
                indices[j]++;
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
