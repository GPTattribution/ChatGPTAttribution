#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;

int T, N, P;
int R[MAXN], Q[MAXN][MAXP];

int main() {
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        cin >> N >> P;
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
        }
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
            sort(Q[i], Q[i]+P);
        }
        int ans = 0;
        for (int k = 1; k <= 10000; ++k) {
            vector<int> rem(N, P-1);
            bool ok = true;
            for (int i = 0; i < N; ++i) {
                int lb = k * R[i] / 110;
                int ub = (k * R[i] + 109) / 90;
                while (rem[i] >= 0 && Q[i][rem[i]] > ub) --rem[i];
                if (rem[i] < 0 || Q[i][rem[i]] < lb) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ++ans;
                for (int i = 0; i < N; ++i) {
                    --rem[i];
                }
            } else {
                break;
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
