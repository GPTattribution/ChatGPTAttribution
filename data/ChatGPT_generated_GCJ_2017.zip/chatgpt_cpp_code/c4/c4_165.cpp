#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;

        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> total(N, 0);
            int count = 0;

            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    count++;

                    for (int i = 0; i < N; i++) {
                        total[i] += Q[i][j];
                    }
                }
            }

            bool valid = true;

            for (int i = 0; i < N; i++) {
                double ratio = 100.0 * total[i] / (count * R[i]);

                if (ratio < 90.0 || ratio > 110.0) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                ans = max(ans, count);
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
