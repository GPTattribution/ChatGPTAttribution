#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int i = 0; i < P; i++) {
            vector<int> package(N);
            for (int j = 0; j < N; j++) {
                package[j] = Q[j][i];
            }
            bool valid = true;
            for (int servings = 1; valid; servings++) {
                vector<int> required(N);
                for (int j = 0; j < N; j++) {
                    required[j] = servings * R[j];
                }
                bool package_used = false;
                for (int j = 0; j < N; j++) {
                    double lower = required[j] * 0.9;
                    double upper = required[j] * 1.1;
                    auto it = lower_bound(package.begin(), package.end(), lower);
                    if (it == package.end() || *it > upper) {
                        valid = false;
                        break;
                    }
                    package_used = true;
                    package.erase(it);
                }
                if (package_used) {
                    ans++;
                } else {
                    break;
                }
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
