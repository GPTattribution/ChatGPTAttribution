#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;
const double MIN_PERCENT = 0.9, MAX_PERCENT = 1.1;

int n, p, r[MAXN], q[MAXN][MAXN];
bool used[MAXN][MAXN];

bool can_make_kit(int num_servings, const vector<int>& amounts) {
    for (int i = 0; i < n; i++) {
        double needed_amount = (double)num_servings * r[i];
        double min_amount = needed_amount * MIN_PERCENT;
        double max_amount = needed_amount * MAX_PERCENT;
        if (amounts[i] < min_amount || amounts[i] > max_amount) {
            return false;
        }
    }
    return true;
}

int dfs(int i, vector<int>& amounts) {
    if (i == n) {
        int num_servings = INT_MAX;
        for (int j = 0; j < n; j++) {
            int servings = amounts[j] / r[j];
            num_servings = min(num_servings, servings);
        }
        int ans = 0;
        for (int j = 1; j <= num_servings; j++) {
            if (can_make_kit(j, amounts)) {
                ans++;
            }
        }
        return ans;
    }
    int ans = 0;
    for (int j = 0; j < p; j++) {
        if (!used[i][j]) {
            used[i][j] = true;
            amounts[i] += q[i][j];
            ans = max(ans, dfs(i+1, amounts));
            amounts[i] -= q[i][j];
            used[i][j] = false;
        }
    }
    ans = max(ans, dfs(i+1, amounts));
    return ans;
}

int solve() {
    cin >> n >> p;
    for (int i = 0; i < n; i++) {
        cin >> r[i];
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < p; j++) {
            cin >> q[i][j];
            used[i][j] = false;
        }
    }
    vector<int> amounts(n, 0);
    return dfs(0, amounts);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int ans = solve();
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
