#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int m = 1; ; ++m) {
            vector<int> max_qty(N, -1);
            vector<int> min_qty(N, 1e9);
            bool ok = true;
            for (int i = 0; i < N; ++i) {
                for (int j = 0; j < P; ++j) {
                    int qty = m * R[i];
                    if (Q[i][j] >= 0.9 * qty && Q[i][j] <= 1.1 * qty) {
                        max_qty[i] = max(max_qty[i], Q[i][j]);
                        min_qty[i] = min(min_qty[i], Q[i][j]);
                    } else {
                        ok = false;
                        break;
                    }
                }
                if (!ok) break;
            }
            if (ok) {
                int cnt = 1;
                for (int i = 0; i < N; ++i) {
                    cnt *= (max_qty[i] / R[i] - min_qty[i] / R[i] + 1);
                }
                ans = max(ans, cnt);
            } else {
                break;
            }
        }
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
