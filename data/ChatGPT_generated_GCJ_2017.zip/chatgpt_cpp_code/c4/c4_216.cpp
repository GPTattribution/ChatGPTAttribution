#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<int> indices(N, 0);
        int max_kits = 0;
        while (true) {
            int servings = INT_MAX;
            for (int i = 0; i < N; i++) {
                int total = 0;
                for (int j = 0; j < P; j++) {
                    if (j == indices[i]) {
                        total += Q[i][j];
                    }
                }
                servings = min(servings, total / R[i]);
            }

            bool valid = true;
            for (int i = 0; i < N; i++) {
                int total = 0;
                for (int j = 0; j < P; j++) {
                    if (j == indices[i]) {
                        total += Q[i][j];
                    }
                }
                if (total < servings * R[i] * 0.9 || total > servings * R[i] * 1.1) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                max_kits = max(max_kits, servings);
            }

            int i = N - 1;
            while (i >= 0 && indices[i] == P - 1) {
                indices[i] = 0;
                i--;
            }
            if (i < 0) {
                break;
            }
            indices[i]++;
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
