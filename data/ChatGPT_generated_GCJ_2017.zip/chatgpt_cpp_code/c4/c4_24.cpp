#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<int> package_indices(P);
        for (int i = 0; i < P; i++) {
            package_indices[i] = i;
        }

        int max_kits = 0;
        do {
            int servings = 1;
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int amount = Q[i][package_indices[0]];
                for (int j = 1; j < P; j++) {
                    amount += Q[i][package_indices[j]];
                }
                int min_amount = (servings * R[i] * 9 + 5) / 10;
                int max_amount = (servings * R[i] * 11) / 10;
                if (amount < min_amount || amount > max_amount) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = max(max_kits, servings);
            }
        } while (next_permutation(package_indices.begin(), package_indices.end()));

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
