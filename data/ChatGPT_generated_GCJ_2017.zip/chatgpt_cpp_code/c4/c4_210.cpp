#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n), min_amounts(n), max_amounts(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
            min_amounts[i] = (9 * r[i] + 10 * (p - 1)) / (10 * p); 
            max_amounts[i] = (11 * r[i]) / (10 * p);
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        for (int i = 0; i < n; i++) {
            sort(q[i].begin(), q[i].end());
        }
        int num_kits = 0;
        for (int i = 0; i < p; i++) {
            bool valid_kit = true;
            int min_servings = 1e9, max_servings = 0;
            for (int j = 0; j < n; j++) {
                int amount = q[j][i];
                if (amount < min_amounts[j] || amount > max_amounts[j]) {
                    valid_kit = false;
                    break;
                }
                int servings = amount / r[j];
                min_servings = min(min_servings, servings);
                max_servings = max(max_servings, servings);
            }
            if (valid_kit && min_servings <= max_servings) {
                num_kits++;
                for (int j = 0; j < n; j++) {
                    q[j][i] = -1;
                }
            }
        }
        cout << "Case #" << case_num << ": " << num_kits << endl;
    }
    return 0;
}
