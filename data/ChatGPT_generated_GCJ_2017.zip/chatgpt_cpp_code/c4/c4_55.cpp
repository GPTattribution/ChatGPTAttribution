#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> quantities(N);
            for (int j = 0; j < P; j++) {
                if ((mask >> j) & 1) {
                    for (int i = 0; i < N; i++) {
                        quantities[i] += Q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                double percent = (double) quantities[i] / (R[i] * (double) (1 << 20));
                if (percent < 0.9 || percent > 1.1) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, __builtin_popcount(mask));
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
