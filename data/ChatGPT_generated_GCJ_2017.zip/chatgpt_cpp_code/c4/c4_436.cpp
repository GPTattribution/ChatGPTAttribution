#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin>>t;
    for(int k=1;k<=t;k++)
    {
        int n,p;
        cin>>n>>p;
        int r[n];
        for(int i=0;i<n;i++)
            cin>>r[i];
        int q[n][p];
        for(int i=0;i<n;i++)
            for(int j=0;j<p;j++)
                cin>>q[i][j];
        vector<int> perm(n);
        for(int i=0;i<n;i++)
            perm[i]=i;
        int max_kits=0;
        do
        {
            for(int s=0;s<(1<<n);s++)
            {
                int kits=1;
                int total[n]={0};
                for(int i=0;i<n;i++)
                {
                    int j=perm[i];
                    if(s&(1<<i))
                    {
                        int max_qty=0;
                        for(int k=0;k<p;k++)
                            max_qty=max(max_qty,q[j][k]);
                        total[j]+=max_qty;
                        if(total[j]>r[j]*110/100)
                            break;
                        kits*=p;
                        if(total[j]<r[j]*90/100)
                            kits=0;
                    }
                    else
                    {
                        int min_qty=1e9;
                        for(int k=0;k<p;k++)
                            min_qty=min(min_qty,q[j][k]);
                        total[j]+=min_qty;
                        if(total[j]>r[j]*110/100)
                            break;
                        if(total[j]<r[j]*90/100)
                            kits=0;
                    }
                }
                if(kits!=0)
                    max_kits=max(max_kits,kits);
            }
        }while(next_permutation(perm.begin(),perm.end()));
        cout<<"Case #"<<k<<": "<<max_kits<<"\n";
    }
    return 0;
}
