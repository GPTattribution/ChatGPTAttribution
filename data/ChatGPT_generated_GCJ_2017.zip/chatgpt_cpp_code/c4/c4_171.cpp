#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50, MAXP = 50;

int N, P;
int R[MAXN];
int Q[MAXN][MAXP];

bool check(int s, int servings) {
    for (int i = 0; i < N; i++) {
        double total = 0;
        for (int j = 0; j < P; j++) {
            total += (double) Q[i][j] * servings / Q[s][j];
        }
        if (total < R[i] * 0.9 || total > R[i] * 1.1) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    int ans = 0;
    for (int i = 0; i < N; i++) {
        for (int servings = 1; ; servings++) {
            if (check(i, servings)) {
                ans = max(ans, servings);
            } else {
                break;
            }
        }
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
