#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

vector<vector<int>> packages;
vector<int> required;
vector<int> current;
int num_ingredients;
int num_packages;
int max_kits;

void backtrack(int ingredient) {
    if (ingredient == num_ingredients) {
        int min_servings = INT_MAX;
        for (int i = 0; i < num_ingredients; i++) {
            int servings = round((double)current[i] / (double)required[i]);
            if (servings < min_servings) {
                min_servings = servings;
            }
            double lower_limit = required[i] * 0.9;
            double upper_limit = required[i] * 1.1;
            if (current[i] < lower_limit * min_servings ||
                current[i] > upper_limit * min_servings) {
                return;
            }
        }
        max_kits++;
        return;
    }

    for (int i = 0; i < num_packages; i++) {
        current[ingredient] = packages[ingredient][i];
        backtrack(ingredient + 1);
        current[ingredient] = 0;
    }
}

int main() {
    int num_cases;
    cin >> num_cases;

    for (int casenum = 1; casenum <= num_cases; casenum++) {
        cin >> num_ingredients >> num_packages;

        required.resize(num_ingredients);
        for (int i = 0; i < num_ingredients; i++) {
            cin >> required[i];
        }

        packages.resize(num_ingredients);
        for (int i = 0; i < num_ingredients; i++) {
            packages[i].resize(num_packages);
            for (int j = 0; j < num_packages; j++) {
                cin >> packages[i][j];
            }
            sort(packages[i].begin(), packages[i].end());
        }

        max_kits = 0;
        current.resize(num_ingredients);
        backtrack(0);

        cout << "Case #" << casenum << ": " << max_kits << endl;

        packages.clear();
        required.clear();
        current.clear();
    }

    return 0;
}
