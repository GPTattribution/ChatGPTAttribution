#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<int> max_kits(p, 0);
        int num_kits = 0;
        for (int k = 0; k < p; k++) {
            vector<int> packages;
            for (int j = 0; j < n; j++) {
                packages.push_back(q[j][k]);
            }
            sort(packages.begin(), packages.end());
            int min_servings = (int)ceil((double)packages[0] / r[0]);
            int max_servings = (int)floor((double)packages[packages.size() - 1] / r[n - 1]);
            for (int servings = min_servings; servings <= max_servings; servings++) {
                bool valid = true;
                int min_quantity = servings * r[0];
                int max_quantity = servings * r[n - 1];
                for (int j = 0; j < n; j++) {
                    int min_qj = (int)ceil((double)min_quantity / r[j]) * 9 / 10;
                    int max_qj = (int)floor((double)max_quantity / r[j]) * 11 / 10;
                    auto it = lower_bound(packages.begin(), packages.end(), min_qj);
                    if (it == packages.end() || *it > max_qj) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    num_kits++;
                    for (int j = 0; j < n; j++) {
                        auto it = lower_bound(packages.begin(), packages.end(), servings * r[j] * 9 / 10);
                        int index = it - packages.begin();
                        max_kits[index] = max(max_kits[index], servings);
                    }
                }
            }
        }
        int max_num_kits = 0;
        for (int k = 0; k < p; k++) {
            max_num_kits += max_kits[k];
        }
        cout << "Case #" << i << ": " << max_num_kits << endl;
    }
    return 0;
}
