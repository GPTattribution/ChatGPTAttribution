#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int max_kits = 0;
        for (int x = 0; x < p; x++) {
            for (int y = 0; y < p; y++) {
                if (n == 1) {
                    int servings = q[0][x] / r[0];
                    if (q[0][x] >= servings * r[0] * 0.9 && q[0][x] <= servings * r[0] * 1.1) {
                        max_kits = max(max_kits, servings);
                    }
                } else {
                    int servings = min(q[0][x] / r[0], q[1][y] / r[1]);
                    if (q[0][x] >= servings * r[0] * 0.9 && q[0][x] <= servings * r[0] * 1.1 &&
                        q[1][y] >= servings * r[1] * 0.9 && q[1][y] <= servings * r[1] * 1.1) {
                        for (int z = 0; z < p; z++) {
                            if (z != x && z != y) {
                                int remaining_servings = min(q[0][z] / r[0], q[1][z] / r[1]);
                                if (remaining_servings * r[0] * 0.9 > q[0][z] ||
                                    remaining_servings * r[0] * 1.1 < q[0][z] ||
                                    remaining_servings * r[1] * 0.9 > q[1][z] ||
                                    remaining_servings * r[1] * 1.1 < q[1][z]) {
                                    break;
                                }
                                servings += remaining_servings;
                            }
                            if (z == p - 1) {
                                max_kits = max(max_kits, servings);
                            }
                        }
                    }
                }
            }
        }

        cout << "Case #" << i << ": " << max_kits << endl;
    }

    return 0;
}
