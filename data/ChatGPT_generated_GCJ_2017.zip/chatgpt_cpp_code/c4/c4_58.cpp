#include <bits/stdc++.h>
using namespace std;

const int MAXN = 55;
const double EPS = 1e-9;

int T, N, P;
int R[MAXN];
int Q[MAXN][MAXN];

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> P;
        for (int i = 1; i <= N; i++) {
            cin >> R[i];
        }
        for (int i = 1; i <= N; i++) {
            for (int j = 1; j <= P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << N); mask++) {
            vector<int> qty;
            int servings = INT_MAX;
            for (int i = 1; i <= N; i++) {
                if ((mask >> (i - 1)) & 1) {
                    int min_qty = INT_MAX, max_qty = 0;
                    for (int j = 1; j <= P; j++) {
                        if (Q[i][j] >= R[i] && Q[i][j] <= R[i] * 1.1 + EPS) {
                            min_qty = min(min_qty, Q[i][j]);
                            max_qty = max(max_qty, Q[i][j]);
                        }
                    }
                    if (min_qty == INT_MAX) {
                        qty.clear();
                        break;
                    }
                    qty.push_back(min_qty);
                    qty.push_back(max_qty);
                    servings = min(servings, max_qty / R[i]);
                }
            }
            if (qty.size() > 0) {
                int cnt = 0;
                for (int i = 0; i < qty.size(); i += 2) {
                    cnt += qty[i + 1] / (qty[i] * servings);
                }
                ans = max(ans, cnt);
            }
        }
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
