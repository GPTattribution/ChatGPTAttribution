#include <iostream>
#include <vector>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << N); ++mask) {
            int servings = -1;
            bool ok = true;
            for (int i = 0; i < N; ++i) {
                if (mask & (1 << i)) {
                    int min_qty = R[i] * 9;
                    int max_qty = R[i] * 11;
                    int total_qty = 0;
                    for (int j = 0; j < P; ++j) {
                        if (Q[i][j] >= min_qty && Q[i][j] <= max_qty) {
                            total_qty += Q[i][j];
                        }
                    }
                    if (total_qty == 0) {
                        ok = false;
                        break;
                    }
                    int curr_servings = total_qty / R[i];
                    if (servings == -1) {
                        servings = curr_servings;
                    } else if (curr_servings != servings) {
                        ok = false;
                        break;
                    }
                }
            }
            if (ok && servings != -1) {
                ans = max(ans, servings);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
