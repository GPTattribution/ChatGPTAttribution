#include <bits/stdc++.h>
using namespace std;

const int MAXN = 55;
const double eps = 1e-9;

int n, p, q[MAXN][MAXN], r[MAXN];

bool can_make(int servings, vector<int> amounts) {
    for (int i = 0; i < n; i++) {
        double needed = (double)servings * r[i];
        double total = 0;
        for (int j = 0; j < p; j++) {
            if (amounts[j * n + i] < needed * 0.9 || amounts[j * n + i] > needed * 1.1) {
                continue;
            }
            total += amounts[j * n + i];
        }
        if (total < needed * 0.9 || total > needed * 1.1) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> n >> p;
    for (int i = 0; i < n; i++) {
        cin >> r[i];
    }
    for (int i = 0; i < p; i++) {
        for (int j = 0; j < n; j++) {
            cin >> q[i][j];
        }
    }
    int ans = 0;
    for (int mask = 0; mask < (1 << (n * p)); mask++) {
        vector<int> amounts(n * p);
        int cnt = 0;
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < n; j++) {
                if (mask & (1 << (i * n + j))) {
                    amounts[i * n + j] = q[i][j];
                    cnt++;
                }
            }
        }
        int lo = 1, hi = 1e9;
        while (lo < hi) {
            int mid = (lo + hi + 1) / 2;
            if (can_make(mid, amounts)) {
                lo = mid;
            } else {
                hi = mid - 1;
            }
        }
        ans = max(ans, cnt / n * lo);
    }
    return ans;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int ans = solve();
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
