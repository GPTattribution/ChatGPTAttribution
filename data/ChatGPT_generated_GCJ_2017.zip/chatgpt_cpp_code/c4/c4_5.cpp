#include <bits/stdc++.h>
using namespace std;

bool cmp(int a, int b){
    return a>b;
}

int main() {
    int T;
    cin>>T;
    for(int i=1; i<=T; i++){
        int n, p;
        cin>>n>>p;
        int r[n];
        for(int j=0; j<n; j++){
            cin>>r[j];
        }
        int q[n][p];
        for(int j=0; j<n; j++){
            for(int k=0; k<p; k++){
                cin>>q[j][k];
            }
        }
        int num=0;
        for(int j=0; j<p; j++){
            int a[n];
            for(int k=0; k<n; k++){
                a[k]=q[k][j];
            }
            sort(a, a+n, cmp);
            int sum=0;
            for(int k=0; k<n; k++){
                sum+=a[k];
                if(sum<r[k]*0.9 || sum>r[k]*1.1){
                    break;
                }
                if(k==n-1){
                    num++;
                }
            }
        }
        cout<<"Case #"<<i<<": "<<num<<endl;
    }
    return 0;
}
