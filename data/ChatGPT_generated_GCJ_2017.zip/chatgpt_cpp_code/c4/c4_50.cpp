#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> tot(n);
            int num = 0;
            bool ok = true;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    num++;
                    for (int k = 0; k < n; k++) {
                        tot[k] += q[k][j];
                    }
                }
            }
            for (int j = 0; j < n; j++) {
                if (tot[j] < r[j] * num * 9 / 10 ||
                    tot[j] > r[j] * num * 11 / 10) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, num);
            }
        }
        cout << "Case #" << i << ": " << ans << "\n";
    }
    return 0;
}
