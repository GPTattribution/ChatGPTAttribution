#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n), q(p * n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
            for (int k = 0; k < p; k++) {
                cin >> q[j * p + k];
            }
        }
        vector<int> max_servings(p, 0);
        for (int j = 0; j < n; j++) {
            sort(q.begin() + j * p, q.begin() + (j + 1) * p);
            for (int k = 0; k < p; k++) {
                int max_qty = (int)(1.1 * r[j] * (k + 1) + 0.5);
                int min_qty = (int)(0.9 * r[j] * (k + 1) + 0.5);
                if (q[j * p + k] >= min_qty && q[j * p + k] <= max_qty) {
                    max_servings[k]++;
                } else {
                    break;
                }
            }
        }
        int ans = 0;
        for (int j = 0; j < p; j++) {
            if (max_servings[j] == n) {
                ans++;
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
