#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> available(n, 0);
            for (int i = 0; i < p; i++) {
                if (mask & (1 << i)) {
                    for (int j = 0; j < n; j++) {
                        available[j] += q[j][i];
                    }
                }
            }
            int kits = 0;
            bool valid = true;
            for (;;) {
                for (int i = 0; i < n; i++) {
                    if (available[i] < r[i]) {
                        valid = false;
                        break;
                    }
                    available[i] -= r[i];
                }
                if (valid) {
                    kits++;
                } else {
                    break;
                }
            }
            max_kits = max(max_kits, kits);
        }
        cout << "Case #" << case_num << ": " << max_kits << endl;
    }
    return 0;
}
