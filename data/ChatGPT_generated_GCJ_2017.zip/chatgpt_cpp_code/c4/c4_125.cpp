#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<int> indexes(n);
        for (int j = 0; j < n; j++) {
            indexes[j] = j;
        }
        int max_kits = 0;
        do {
            int kits = 0;
            vector<int> amounts(n, 0);
            for (int j = 0; j < p; j++) {
                bool valid = true;
                for (int k = 0; k < n; k++) {
                    int idx = indexes[k];
                    int amount = q[idx][j];
                    int needed = r[idx];
                    if (amount < needed * 9 || amount > needed * 11) {
                        valid = false;
                        break;
                    }
                    amounts[idx] += amount;
                }
                if (valid) {
                    int min_servings = amounts[0] / r[0];
                    for (int k = 1; k < n; k++) {
                        int servings = amounts[k] / r[k];
                        if (servings < min_servings) {
                            min_servings = servings;
                        }
                    }
                    kits += min_servings;
                    for (int k = 0; k < n; k++) {
                        amounts[k] -= min_servings * r[k];
                    }
                }
            }
            max_kits = max(max_kits, kits);
        } while (next_permutation(indexes.begin(), indexes.end()));
        cout << "Case #" << i << ": " << max_kits << endl;
    }
    return 0;
}
