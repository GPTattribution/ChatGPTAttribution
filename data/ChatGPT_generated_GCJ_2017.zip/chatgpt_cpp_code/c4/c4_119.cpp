#include <iostream>
#include <vector>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int max_kits = 0;
        for (int k = 1; k <= 1000000; k++) {
            bool valid = true;
            for (int j = 0; j < n; j++) {
                double min_qty = r[j] * k * 0.9;
                double max_qty = r[j] * k * 1.1;
                bool found = false;
                for (int l = 0; l < p; l++) {
                    if (q[j][l] >= min_qty && q[j][l] <= max_qty) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = k;
            }
        }
        cout << "Case #" << i << ": " << max_kits << endl;
    }
    return 0;
}
