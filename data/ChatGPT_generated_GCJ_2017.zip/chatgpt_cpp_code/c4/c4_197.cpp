#include <iostream>
#include <vector>

using namespace std;

bool can_form_kit(const vector<int>& quantities, const vector<int>& required,
                  int servings) {
    for (int i = 0; i < quantities.size(); i++) {
        int min_qty = required[i] * servings * 9 / 10;
        int max_qty = required[i] * servings * 11 / 10;  
        if (quantities[i] < min_qty || quantities[i] > max_qty) {
            return false;
        }
    }
    return true;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> required(N);
        for (int i = 0; i < N; i++) {
            cin >> required[i];
        }
        vector<vector<int>> quantities(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> quantities[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> total_quantities(N, 0);
            int num_selected = 0;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    num_selected++;
                    for (int i = 0; i < N; i++) {
                        total_quantities[i] += quantities[i][j];
                    }
                }
            }
            for (int servings = 1; ; servings++) {
                if (can_form_kit(total_quantities, required, servings)) {
                    max_kits = max(max_kits, num_selected);
                } else if (servings * total_quantities[0] > required[0] * P) {
                    break;
                }
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
