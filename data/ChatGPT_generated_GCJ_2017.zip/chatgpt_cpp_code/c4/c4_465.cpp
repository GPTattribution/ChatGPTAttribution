#include <bits/stdc++.h>
using namespace std;

#define ll long long

int main()
{
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++)
    {
        int n, p;
        cin >> n >> p;

        vector<int> r(n), min_qty(p), max_qty(p);

        for (int j = 0; j < n; j++)
            cin >> r[j];

        for (int j = 0; j < n; j++)
            for (int k = 0; k < p; k++)
            {
                int x;
                cin >> x;
                min_qty[k] = x * 90 / r[j];
                max_qty[k] = x * 110 / r[j];
            }

        int ans = 0;

        for (int j = 0; j < p; j++)
            for (int k = j; k < p; k++)
            {
                bool flag = true;

                for (int l = 0; l < n; l++)
                {
                    int min_ingredient_qty = r[l] * (j == 0 ? 1 : max_qty[j - 1]);
                    int max_ingredient_qty = r[l] * min_qty[k];

                    bool found = false;

                    for (int m = 0; m < p; m++)
                        if (min_ingredient_qty <= m && m <= max_ingredient_qty)
                            found = true;

                    if (!found)
                    {
                        flag = false;
                        break;
                    }
                }

                if (flag)
                    ans = max(ans, k - j + 1);
            }

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
