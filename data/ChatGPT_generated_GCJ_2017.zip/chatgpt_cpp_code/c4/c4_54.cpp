#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int max_kits = 0;

        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> quantities(n, 0);
            int num_kits = 0;

            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    num_kits++;
                    for (int k = 0; k < n; k++) {
                        quantities[k] += q[k][j];
                    }
                }
            }

            bool valid = true;

            for (int j = 0; j < n; j++) {
                int required = r[j] * num_kits;
                double lower_limit = required * 0.9;
                double upper_limit = required * 1.1;

                if (quantities[j] < lower_limit || quantities[j] > upper_limit) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                max_kits = max(max_kits, num_kits);
            }
        }

        cout << "Case #" << i << ": " << max_kits << endl;
    }

    return 0;
}
