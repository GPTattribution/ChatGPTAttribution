#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        vector<int> indices(N);
        while (true) {
            int servings = -1;
            for (int k = 1; k <= 100; k++) {
                bool valid = true;
                for (int i = 0; i < N; i++) {
                    double total = 0;
                    for (int j = 0; j < P; j++) {
                        if ((i == 0 && k*R[i] < Q[i][indices[j]]*0.9) ||
                            (i == 0 && k*R[i] > Q[i][indices[j]]*1.1)) {
                            valid = false;
                            break;
                        }
                        double ratio = (double)Q[i][indices[j]] / R[i];
                        total += ratio;
                    }
                    if (!valid) {
                        break;
                    }
                    if (servings == -1) {
                        servings = floor(total / k);
                    } else if (servings != floor(total / k)) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    max_kits = max(max_kits, k);
                }
            }
            bool carry = true;
            for (int i = N - 1; i >= 0; i--) {
                if (carry) {
                    indices[i]++;
                    if (indices[i] == P) {
                        indices[i] = 0;
                        carry = true;
                    } else {
                        carry = false;
                        break;
                    }
                }
            }
            if (carry) {
                break;
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
