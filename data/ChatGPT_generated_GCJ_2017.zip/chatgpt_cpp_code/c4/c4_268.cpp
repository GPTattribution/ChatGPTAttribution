#include<bits/stdc++.h>
#define ll long long
using namespace std;

int main(){
    int t;
    cin>>t;
    for(int i=1;i<=t;i++){
        int n,p;
        cin>>n>>p;
        vector<int> r(n),s(n*p);
        for(int j=0;j<n;j++)
            cin>>r[j];
        for(int j=0;j<n*p;j++)
            cin>>s[j];

        vector<vector<int>> possible(p,vector<int>(n,0));

        for(int j=0;j<p;j++){
            for(int k=0;k<n;k++){
                if(s[j*n+k]>=0.9*r[k]*p && s[j*n+k]<=1.1*r[k]*p)
                    possible[j][k]=1;
                else
                    possible[j][k]=0;
            }
        }

        int ans=0;
        for(int mask=0;mask<(1<<p);mask++){
            vector<int> cnt(n,0);
            int servings=0;
            for(int j=0;j<p;j++){
                if(mask&(1<<j)){
                    servings++;
                    for(int k=0;k<n;k++)
                        cnt[k]+=possible[j][k];
                }
            }
            bool valid=true;
            for(int k=0;k<n;k++){
                if(cnt[k]==0 || cnt[k]!=servings){
                    valid=false;
                    break;
                }
            }
            if(valid)
                ans=max(ans,servings);
        }
        cout<<"Case #"<<i<<": "<<ans<<endl;
    }
    return 0;
}
