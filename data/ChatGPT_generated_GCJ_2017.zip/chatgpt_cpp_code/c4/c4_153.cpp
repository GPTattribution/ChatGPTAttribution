#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const double TOL = 1e-6;

int N, P;
int R[MAXN];
int Q[MAXN][MAXP];
int used[MAXP];

bool can_make(int servings) {
    vector<pair<double, int>> excess;
    for (int i = 0; i < N; i++) {
        double required = servings * (double)R[i];
        double available = 0.0;
        for (int j = 0; j < P; j++) {
            if (!used[j]) {
                available += (double)Q[i][j];
            }
        }
        double e = available / required;
        if (e < 0.9 - TOL || e > 1.1 + TOL) {
            return false;
        }
        excess.emplace_back(e, i);
    }
    sort(excess.begin(), excess.end());
    int idx = 0;
    for (int i = 0; i < N; i++) {
        double required = servings * (double)R[i];
        while (excess[idx].first + TOL < 1.0 && excess[idx].first * required <= Q[excess[idx].second][used[excess[idx].second]]) {
            Q[excess[idx].second][used[excess[idx].second]] -= excess[idx].first * required;
            used[excess[idx].second]++;
            if (used[excess[idx].second] == P) {
                return true;
            }
            excess[idx].first = Q[excess[idx].second][used[excess[idx].second]] / required;
            idx++;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
        sort(Q[i], Q[i] + P);
    }
    int ans = 0;
    while (can_make(ans + 1)) {
        ans++;
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        fill(used, used + MAXP, 0);
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
