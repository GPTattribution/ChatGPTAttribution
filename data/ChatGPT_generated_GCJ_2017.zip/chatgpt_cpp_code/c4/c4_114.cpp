#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int max_kits = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> tot(n);
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    for (int k = 0; k < n; k++) {
                        tot[k] += q[k][j];
                    }
                }
            }
            int kits = 1e9;
            for (int j = 0; j < n; j++) {
                kits = min(kits, tot[j] / r[j]);
            }
            for (int j = 0; j < n; j++) {
                if (tot[j] < kits * r[j] * 0.9 || tot[j] > kits * r[j] * 1.1) {
                    kits = 0;
                    break;
                }
            }
            max_kits = max(max_kits, kits);
        }

        cout << "Case #" << i << ": " << max_kits << endl;
    }
    return 0;
}
