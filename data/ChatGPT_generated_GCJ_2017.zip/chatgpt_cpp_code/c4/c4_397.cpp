#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        for (int i = 0; i < P; i++) {
            for (int j = 0; j < P; j++) {
                if (i == j) {
                    continue;
                }
                bool valid = true;
                int servings = 1;
                for (int k = 0; k < N; k++) {
                    int required = servings * R[k];
                    int actual = Q[k][i] + Q[k][j];
                    if (actual < 0.9 * required || actual > 1.1 * required) {
                        valid = false;
                        break;
                    }
                    servings = actual / R[k];
                }
                if (valid) {
                    max_kits = max(max_kits, servings);
                }
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
