#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const double EPSILON = 1e-9;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << (N * P)); mask++) {
            vector<int> total_quantity(N);
            int total_kits = 0;
            bool valid = true;
            for (int j = 0; j < P; j++) {
                for (int i = 0; i < N; i++) {
                    int index = i * P + j;
                    if (mask & (1 << index)) {
                        total_quantity[i] += Q[i][j];
                    }
                }
            }
            for (int i = 0; i < N; i++) {
                int min_quantity = R[i] * total_kits * 9 / 10;
                int max_quantity = R[i] * total_kits * 11 / 10;
                int actual_quantity = total_quantity[i];
                if (actual_quantity < min_quantity || actual_quantity > max_quantity) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int kits = total_kits;
                for (int i = 0; i < N; i++) {
                    int quantity_per_serving = R[i];
                    int max_serving = total_quantity[i] / (quantity_per_serving * 9 / 10);
                    int min_serving = total_quantity[i] / (quantity_per_serving * 11 / 10) + (total_quantity[i] % (quantity_per_serving * 11 / 10) > EPSILON);
                    kits = (i == 0) ? min(max_serving, min_serving) : min(kits, min(max_serving, min_serving));
                }
                max_kits = max(max_kits, kits);
            }
            total_kits++;
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
