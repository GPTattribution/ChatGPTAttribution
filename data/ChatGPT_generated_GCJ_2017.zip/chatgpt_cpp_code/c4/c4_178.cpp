#include <iostream>
#include <vector>

using namespace std;

bool isValidKit(const vector<vector<int>>& packages, const vector<int>& required, const vector<int>& amounts) {
    for (int i = 0; i < required.size(); i++) {
        double min_amount = required[i] * 0.9;
        double max_amount = required[i] * 1.1;
        double total_amount = 0.0;
        for (int j = 0; j < amounts.size(); j++) {
            total_amount += packages[i][j] * amounts[j];
        }
        if (total_amount < min_amount || total_amount > max_amount) {
            return false;
        }
    }
    return true;
}

int getMaxKits(const vector<vector<int>>& packages, const vector<int>& required) {
    int n = packages[0].size();
    vector<int> amounts(required.size());
    for (int i = 0; i < n; i++) {
        amounts[0] = i + 1;
        int max_kits = i;
        for (int j = 1; j < n; j++) {
            for (int k = 0; k <= i; k++) {
                amounts[j] = k + 1;
                if (isValidKit(packages, required, amounts)) {
                    max_kits++;
                }
            }
        }
        if (max_kits == i) {
            return i;
        }
    }
    return n;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> required(N);
        for (int i = 0; i < N; i++) {
            cin >> required[i];
        }
        vector<vector<int>> packages(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> packages[i][j];
            }
        }
        int max_kits = getMaxKits(packages, required);
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
