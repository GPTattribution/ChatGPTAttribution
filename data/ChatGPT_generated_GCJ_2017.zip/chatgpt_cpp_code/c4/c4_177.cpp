#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const int MAXQ = 1e6 + 5;

int T, N, P;
int R[MAXN], Q[MAXN][MAXP];
int dp[2][MAXQ];

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> P;

        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        memset(dp, 0, sizeof(dp));
        for (int i = 0; i < P; i++) {
            for (int j = 0; j <= 110 * R[0]; j++) {
                if (j >= 90 * R[0] && j <= 110 * R[0]) {
                    dp[0][j] = 1;
                } else {
                    dp[0][j] = 0;
                }
            }
            for (int k = 1; k < N; k++) {
                for (int j = 0; j <= 110 * R[k]; j++) {
                    dp[k % 2][j] = 0;
                    for (int l = max(0, j - 110 * R[k]); l <= min(110 * R[k], j + 90 * R[k]); l++) {
                        if (dp[(k - 1) % 2][l] && (l + Q[k][i] >= 90 * R[k + 1]) && (l + Q[k][i] <= 110 * R[k + 1])) {
                            dp[k % 2][l + Q[k][i]] = 1;
                        }
                    }
                }
            }

            int res = 0;
            for (int j = 90 * R[N - 1]; j <= 110 * R[N - 1]; j++) {
                if (dp[(N - 1) % 2][j]) {
                    res = j / R[N - 1];
                }
            }

            if (i == 0) {
                cout << "Case #" << t << ": " << res << endl;
            } else {
                cout << res << endl;
            }
        }
    }
    return 0;
}
