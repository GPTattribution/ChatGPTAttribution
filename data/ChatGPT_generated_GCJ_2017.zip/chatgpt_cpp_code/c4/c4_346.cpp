#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
            sort(q[j].begin(), q[j].end());
        }
        int ans = 0;
        for (int j = 0; j < p; j++) {
            vector<int> amounts(n);
            amounts[0] = q[0][j];
            int k = 1;
            while (k < n) {
                int l = lower_bound(q[k].begin(), q[k].end(), ceil(amounts[0] * 1.0 / r[0] * r[k])) - q[k].begin();
                if (l == p || q[k][l] > floor(amounts[0] * 1.0 / r[0] * r[k]) * 1.1) {
                    break;
                }
                amounts[k] = q[k][l];
                k++;
            }
            if (k == n) {
                int servings = min_element(amounts.begin(), amounts.end()) - amounts.begin();
                ans += (amounts[servings] * 1.0 / r[servings]) / servings;
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
