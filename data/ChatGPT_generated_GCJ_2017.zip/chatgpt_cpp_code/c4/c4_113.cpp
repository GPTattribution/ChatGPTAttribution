#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int i = 0; i < P; i++) {
            vector<int> chosen(N);
            chosen[0] = i;
            int servings = Q[0][i] / R[0];
            bool valid = true;
            for (int j = 1; j < N; j++) {
                valid = false;
                for (int k = 0; k < P; k++) {
                    int required = servings * R[j];
                    if (Q[j][k] >= required * 9 && Q[j][k] <= required * 11) {
                        chosen[j] = k;
                        valid = true;
                        break;
                    }
                }
                if (!valid) break;
            }
            if (valid) {
                int kits = 1;
                vector<bool> used(P);
                used[i] = true;
                for (int j = 1; j < N; j++) {
                    used[chosen[j]] = true;
                    if (chosen[j] != i) kits++;
                }
                for (int j = 0; j < P; j++) {
                    if (!used[j]) {
                        int servings = Q[0][j] / R[0];
                        valid = true;
                        for (int k = 1; k < N; k++) {
                            int required = servings * R[k];
                            if (Q[k][j] < required * 9 || Q[k][j] > required * 11) {
                                valid = false;
                                break;
                            }
                        }
                        if (valid) kits++;
                    }
                }
                ans = max(ans, kits);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
