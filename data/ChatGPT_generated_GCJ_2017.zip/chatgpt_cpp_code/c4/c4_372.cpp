#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> amount(n);
            int servings = 0;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    for (int k = 0; k < n; k++) {
                        amount[k] += q[k][j];
                    }
                    servings++;
                }
            }
            bool ok = true;
            for (int j = 0; j < n; j++) {
                double min_amount = r[j] * servings * 0.9;
                double max_amount = r[j] * servings * 1.1;
                if (amount[j] < min_amount || amount[j] > max_amount) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, servings);
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
