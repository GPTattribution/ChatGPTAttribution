#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const int INF = 1e9;

int N, P;
int R[MAXN];
int Q[MAXP][MAXN];

int get_max_kits() {
  int max_kits = 0;
  for (int mask = 0; mask < (1 << N); ++mask) {
    bool ok = true;
    int min_kits = INF;
    for (int j = 0; j < P; ++j) {
      int kits = INF;
      for (int i = 0; i < N; ++i) {
        if (!(mask & (1 << i))) continue;
        int lb = (R[i] * 90LL + 99) / 100;
        int ub = (R[i] * 110LL) / 100;      
        if (Q[j][i] < lb || Q[j][i] > ub) {
          ok = false;
          break;
        }
        kits = min(kits, Q[j][i] / R[i]);
      }
      if (!ok) break;
      min_kits = min(min_kits, kits);
    }
    if (ok) {
      int kits = 0;
      for (int j = 0; j < P; ++j) {
        int cur_kits = INF;
        for (int i = 0; i < N; ++i) {
          if (!(mask & (1 << i))) continue;
          cur_kits = min(cur_kits, Q[j][i] / (R[i] * min_kits));
        }
        kits += cur_kits;
      }
      max_kits = max(max_kits, kits);
    }
  }
  return max_kits;
}

int main() {
  int T; cin >> T;
  for (int t = 1; t <= T; ++t) {
    cin >> N >> P;
    for (int i = 0; i < N; ++i) cin >> R[i];
    for (int i = 0; i < P; ++i) {
      for (int j = 0; j < N; ++j) {
        cin >> Q[i][j];
      }
    }
    int ans = get_max_kits();
    cout << "Case #" << t << ": " << ans << "\n";
  }
  return 0;
}
