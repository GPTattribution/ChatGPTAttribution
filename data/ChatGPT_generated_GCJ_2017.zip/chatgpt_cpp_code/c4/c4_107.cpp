#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            if (__builtin_popcount(mask) != P) {
                continue;
            }

            bool valid = true;
            int servings = numeric_limits<int>::max();
            for (int i = 0; i < N; i++) {
                int total = 0;
                for (int j = 0; j < P; j++) {
                    if (mask & (1 << j)) {
                        total += Q[i][j];
                    }
                }
                int target = R[i];
                for (int j = 0; j < servings; j++) {
                    int low = (j * target * 90 + 99) / 100;
                    int high = (j * target * 110) / 100;
                    if (low <= total && total <= high) {
                        servings = j;
                        break;
                    }
                }
                if (servings == numeric_limits<int>::max()) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = max(max_kits, servings);
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
