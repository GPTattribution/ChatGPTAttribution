#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<int> indices(P);
        for (int i = 0; i < P; i++) {
            indices[i] = i;
        }

        int max_kits = 0;

        do {
            bool valid = true;
            int min_serve = numeric_limits<int>::max();
            int max_serve = 0;

            for (int i = 0; i < N; i++) {
                int sum = 0;
                for (int j = 0; j < P; j++) {
                    sum += Q[i][indices[j]];
                }
                int serve = sum / R[i];
                if (sum % R[i] != 0) {
                    serve++;
                }
                if (serve < min_serve) {
                    min_serve = serve;
                }
                if (serve > max_serve) {
                    max_serve = serve;
                }
                if (sum < min_serve * 9 * R[i] / 10 || sum > max_serve * 11 * R[i] / 10) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                int kits = min_serve;
                if (min_serve != max_serve) {
                    kits = max_serve;
                }
                max_kits = max(max_kits, kits);
            }

        } while (next_permutation(indices.begin(), indices.end()));

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
