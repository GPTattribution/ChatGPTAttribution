#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
            sort(Q[i].begin(), Q[i].end());
        }
        int ans = 0;
        for (int i = 0; i < P; i++) {
            vector<int> used(N, 0);
            int servings = 0;
            for (int j = 0; j < N; j++) {
                int lo = (R[j] * servings + 99) / 100; 
                int hi = (R[j] * servings + 110) / 100;
                int k = upper_bound(Q[j].begin(), Q[j].end(), hi) - Q[j].begin();
                if (k == 0) break;
                k--;
                while (used[k]) {
                    k--;
                    if (k < 0) break;
                }
                if (k < 0) break;
                int amt = Q[j][k];
                if (amt < lo || amt > hi) break;
                used[k] = 1;
                servings = max(servings, (int) ceil(100.0 * amt / R[j]));
                if (j == N-1) ans++;
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
