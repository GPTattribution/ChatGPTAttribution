#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool can_make_kit(vector<int>& packages, vector<int>& required, int num_servings) {
    int n = packages.size();
    for (int i = 0; i < n; i++) {
        int min_amount = (90 * required[i] * num_servings + 99) / 100; 
        int max_amount = (110 * required[i] * num_servings) / 100;
        if (packages[i] < min_amount || packages[i] > max_amount) {
            return false;
        }
    }
    return true;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> required(N);
        for (int i = 0; i < N; i++) {
            cin >> required[i];
        }
        vector<vector<int>> packages(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> packages[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> selected(P, 0);
            for (int i = 0; i < P; i++) {
                if ((mask & (1 << i)) != 0) {
                    selected[i] = 1;
                }
            }
            vector<int> packages_sum(N, 0);
            int num_selected = 0;
            for (int i = 0; i < P; i++) {
                if (selected[i]) {
                    num_selected++;
                    for (int j = 0; j < N; j++) {
                        packages_sum[j] += packages[j][i];
                    }
                }
            }
            int min_servings = (num_selected * 100 - 1) / 110;
            int max_servings = (num_selected * 100) / 90;
            for (int k = min_servings; k <= max_servings; k++) {
                if (can_make_kit(packages_sum, required, k)) {
                    max_kits = max(max_kits, k);
                }
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
