#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<int> min_serves(p, INT_MAX);
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                int min_grams = (int) ceil((double) r[j] * 0.9 / q[j][k]);
                int max_grams = (int) floor((double) r[j] * 1.1 / q[j][k]);
                min_serves[k] = min(min_serves[k], max_grams);
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            int serves = INT_MAX;
            int grams = 0;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    serves = min(serves, min_serves[j]);
                    grams += q[0][j];
                }
            }
            if (serves != INT_MAX) {
                ans = max(ans, serves);
            }
        }
        cout << "Case #" << i << ": " << ans << "\n";
    }
    return 0;
}
