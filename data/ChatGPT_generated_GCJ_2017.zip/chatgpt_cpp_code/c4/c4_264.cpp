#include <bits/stdc++.h>
using namespace std;

int T, N, P;
int R[50];
int Q[50][50];

int main() {
  cin >> T;
  for (int t = 1; t <= T; t++) {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
      cin >> R[i];
      for (int j = 0; j < P; j++) {
        cin >> Q[i][j];
      }
    }

    int ans = 0;
    for (int mask = 0; mask < (1 << P); mask++) {
      bool ok = true;
      vector<int> count(N, 0);
      int servings = INT_MAX;

      for (int j = 0; j < P; j++) {
        if ((mask >> j) & 1) {
          for (int i = 0; i < N; i++) {
            count[i] += Q[i][j];
          }
        }
      }

      for (int i = 0; i < N; i++) {
        int c = count[i];
        int r = R[i];

        int s1 = c / (r * 110 / 100);
        int s2 = (c + r * 10 / 100 - 1) / (r * 10 / 100);

        if (s1 != s2) {
          ok = false;
          break;
        }

        servings = min(servings, s1);
      }

      if (ok) {
        ans = max(ans, servings);
      }
    }

    cout << "Case #" << t << ": " << ans << "\n";
  }
  return 0;
}
