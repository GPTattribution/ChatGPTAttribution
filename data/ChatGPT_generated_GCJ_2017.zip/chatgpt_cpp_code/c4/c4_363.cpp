#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<int> max_kits(p);
        for (int j = 0; j < p; j++) {
            vector<int> servings;
            for (int k = 0; k < (1 << n); k++) {
                int total_weight = 0;
                int total_servings = 0;
                bool valid = true;
                for (int l = 0; l < n; l++) {
                    if (k & (1 << l)) {
                        total_weight += q[l][j];
                        total_servings += r[l];
                        if (q[l][j] < r[l] * 9 || q[l][j] > r[l] * 11) {
                            valid = false;
                            break;
                        }
                    }
                }
                if (valid && total_weight >= total_servings * 9 && total_weight <= total_servings * 11) {
                    servings.push_back(total_servings);
                }
            }
            if (servings.empty()) {
                max_kits[j] = 0;
            } else {
                sort(servings.begin(), servings.end());
                int count = 1;
                int max_count = 1;
                int max_s = servings[0];
                for (int k = 1; k < servings.size(); k++) {
                    if (servings[k] == max_s) {
                        count++;
                    } else {
                        if (count > max_count) {
                            max_count = count;
                            max_s = servings[k - 1];
                        }
                        count = 1;
                    }
                }
                if (count > max_count) {
                    max_count = count;
                    max_s = servings.back();
                }
                max_kits[j] = max_count;
            }
        }
        int max_total_kits = 0;
        for (int j = 0; j < (1 << p); j++) {
            int total_kits = 1;
            int total_weight = 0;
            for (int k = 0; k < p; k++) {
                if (j & (1 << k)) {
                    total_kits *= max_kits[k];
                    for (int l = 0; l < n; l++) {
                        total_weight += q[l][k];
                    }
                }
            }
            if (total_weight >= total_kits * accumulate(r.begin(), r.end(), 0) * 9 &&
                total_weight <= total_kits * accumulate(r.begin(), r.end(), 0) * 11) {
                max_total_kits = max(max_total_kits, total_kits);
            }
        }
        cout << "Case #" << i << ": " << max_total_kits << endl;
    }
    return 0;
}
