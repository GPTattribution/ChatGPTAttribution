#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
            sort(Q[i].begin(), Q[i].end());
        }

        int max_kits = 0;
        for (int i = 0; i < P; i++) {
            int servings = Q[0][i] / R[0];
            int j = 1;
            while (j < N && Q[j][0] < servings * R[j] * 0.9) {
                j++;
            }
            if (j == N) {
                continue;
            }
            int k = P - 1;
            while (k >= 0 && Q[N-1][k] > servings * R[N-1] * 1.1) {
                k--;
            }
            if (k == -1) {
                continue;
            }
            int kits = min(k - i + 1, P);
            for (j = 1; j < N; j++) {
                int lb = lower_bound(Q[j].begin(), Q[j].end(), servings * R[j] * 0.9) - Q[j].begin();
                int ub = upper_bound(Q[j].begin(), Q[j].end(), servings * R[j] * 1.1) - Q[j].begin() - 1;
                if (lb > ub || ub < i || lb >= i + P) {
                    kits = 0;
                    break;
                }
                kits = min(kits, ub - i + 1);
            }
            max_kits = max(max_kits, kits);
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
