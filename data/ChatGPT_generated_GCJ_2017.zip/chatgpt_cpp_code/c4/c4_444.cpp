#include<bits/stdc++.h>
using namespace std;
int main() {
    int t;
    cin >> t;
    for(int i=1;i<=t;i++) {
        int n,p;
        cin >> n >> p;
        vector<int> r(n);
        for(int j=0;j<n;j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n,vector<int>(p));
        for(int j=0;j<n;j++) {
            for(int k=0;k<p;k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for(int mask=0;mask<(1<<n);mask++) {
            bool valid = true;
            vector<int> package_sum(p,0);
            for(int j=0;j<n;j++) {
                if(mask & (1<<j)) {
                    for(int k=0;k<p;k++) {
                        package_sum[k] += q[j][k];
                    }
                }
            }
            for(int k=0;k<p;k++) {
                int sum = 0;
                for(int j=0;j<n;j++) {
                    if(mask & (1<<j)) {
                        sum += q[j][k];
                    }
                }
                double low = (double)r[k] * 0.9, high = (double)r[k] * 1.1;
                if(sum < low * p || sum > high * p) {
                    valid = false;
                    break;
                }
            }
            if(valid) {
                ans = max(ans, __builtin_popcount(mask));
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
