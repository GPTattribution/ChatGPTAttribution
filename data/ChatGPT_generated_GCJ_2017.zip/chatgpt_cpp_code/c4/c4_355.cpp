#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<vector<int>> packages;
        for (int i = 0; i < P; i++) {
            vector<int> p(N);
            for (int j = 0; j < N; j++) {
                p[j] = Q[j][i];
            }
            packages.push_back(p);
        }
        int max_kits = 0;
        for (int i = 0; i < (1 << P); i++) {
            vector<int> counts(N);
            int total_servings = 0;
            for (int j = 0; j < P; j++) {
                if (i & (1 << j)) {
                    for (int k = 0; k < N; k++) {
                        counts[k] += packages[j][k];
                    }
                    total_servings++;
                }
            }
            bool valid = true;
            for (int j = 0; j < N; j++) {
                int needed = R[j] * total_servings;
                int lower = ceil(0.9 * needed);
                int upper = floor(1.1 * needed);
                if (counts[j] < lower || counts[j] > upper) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = max(max_kits, total_servings);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
