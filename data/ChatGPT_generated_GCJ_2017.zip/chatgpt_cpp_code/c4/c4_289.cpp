#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int case_num = 1; case_num <= t; ++case_num) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int i = 0; i < n; ++i) {
            cin >> r[i];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < p; ++j) {
                cin >> q[i][j];
            }
            sort(q[i].begin(), q[i].end());
        }

        int num_kits = 0;
        vector<int> indices(n);
        iota(indices.begin(), indices.end(), 0);
        do {
            for (int i = 0; i < p; ++i) {
                vector<int> package_weights(n);
                for (int j : indices) {
                    package_weights[j] = q[j][i];
                }
                int num_servings = package_weights[0] / r[0];
                for (int j = 1; j < n; ++j) {
                    num_servings = min(num_servings, package_weights[j] / r[j]);
                }
                if (num_servings >= 1 && num_servings <= 100) {
                    bool valid = true;
                    for (int j = 0; j < n; ++j) {
                        double min_weight = num_servings * r[j] * 0.9;
                        double max_weight = num_servings * r[j] * 1.1;
                        if (package_weights[j] < min_weight || package_weights[j] > max_weight) {
                            valid = false;
                            break;
                        }
                    }
                    if (valid) {
                        ++num_kits;
                        for (int j : indices) {
                            q[j][i] = -1;
                        }
                        break;
                    }
                }
            }
        } while (next_permutation(indices.begin(), indices.end()));

        cout << "Case #" << case_num << ": " << num_kits << "\n";
    }

    return 0;
}
