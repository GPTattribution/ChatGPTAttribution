#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        for (int i = 0; i < P; i++) {
            vector<int> amounts(N);
            for (int j = 0; j < N; j++) {
                amounts[j] = Q[j][i];
            }
            sort(amounts.begin(), amounts.end());
            for (int j = 1; j <= 100; j++) {
                int servings = j;
                vector<int> needed(N);
                for (int k = 0; k < N; k++) {
                    needed[k] = servings * R[k];
                }
                bool valid = true;
                for (int k = 0; k < N; k++) {
                    double lower = needed[k] * 0.9;
                    double upper = needed[k] * 1.1;
                    if (amounts[k] < lower || amounts[k] > upper) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    max_kits = max(max_kits, servings);
                }
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
