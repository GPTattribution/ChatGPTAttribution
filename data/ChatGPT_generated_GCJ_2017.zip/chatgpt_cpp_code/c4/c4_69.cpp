#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> max_servings(P);
        for (int i = 0; i < P; i++) {
            vector<int> possible_servings;
            for (int j = 0; j < N; j++) {
                int lower = (90 * R[j] * i + 99 * N) / (100 * N * Q[j][i]);
                int upper = (110 * R[j] * i) / (100 * N * Q[j][i]);
                if (lower > upper) {
                    possible_servings.clear();
                    break;
                }
                possible_servings.push_back(lower);
                if (lower != upper) {
                    possible_servings.push_back(upper);
                }
            }
            if (!possible_servings.empty()) {
                max_servings[i] = *min_element(possible_servings.begin(), possible_servings.end());
            }
        }
        int max_kits = accumulate(max_servings.begin(), max_servings.end(), 0) / N;
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
