#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define all(v) v.begin(), v.end()
#define pb push_back
#define fi first
#define se second

const int MAXN = 50;
const int MAXP = 50;

int T, N, P;
int R[MAXN+5], Q[MAXN+5][MAXP+5];
vector<int> possibleServing[MAXN*MAXP+5];

void solve(int tc) {
    cin >> N >> P;
    for (int i = 1; i <= N; i++) {
        cin >> R[i];
    }
    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= P; j++) {
            cin >> Q[i][j];
        }
    }
    for (int i = 1; i <= P; i++) {
        for (int j = 1; j <= P; j++) {
            int sum = 0;
            bool valid = true;
            for (int k = 1; k <= N; k++) {
                int need = R[k]*j;
                int have = Q[k][i];
                if (have < 9*need/10 || have > 11*need/10) {
                    valid = false;
                    break;
                }
                sum += have;
            }
            if (valid) {
                possibleServing[sum].pb(j);
            }
        }
    }
    int ans = 0;
    for (int i = 1; i <= N*P; i++) {
        sort(all(possibleServing[i]));
        for (int j = 0; j < possibleServing[i].size(); j++) {
            if (j == 0 || possibleServing[i][j] != possibleServing[i][j-1]) {
                ans++;
            }
        }
    }
    cout << "Case #" << tc << ": " << ans << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cin >> T;
    for (int tc = 1; tc <= T; tc++) {
        solve(tc);
        for (int i = 1; i <= N*P; i++) {
            possibleServing[i].clear();
        }
    }
    return 0;
}
