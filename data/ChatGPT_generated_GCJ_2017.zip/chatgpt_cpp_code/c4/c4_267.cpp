#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        for (int i = 0; i < P; i++) {
            vector<int> amounts(N);
            for (int j = 0; j < N; j++) {
                amounts[j] = Q[j][i];
            }
            bool valid = true;
            int min_kits = 1e9;
            for (int k = 1; k <= 100; k++) {
                bool ok = true;
                for (int j = 0; j < N; j++) {
                    double required = k * static_cast<double>(R[j]);
                    double low = required * 0.9;
                    double high = required * 1.1;
                    auto it = lower_bound(amounts.begin(), amounts.end(), static_cast<int>(low));
                    if (it == amounts.end() || *it > high) {
                        ok = false;
                        break;
                    }
                    amounts.erase(it);
                }
                if (ok) {
                    valid = true;
                    min_kits = min(min_kits, k);
                } else {
                    break;
                }
            }
            if (valid) {
                max_kits += min_kits;
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
