#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> max_servings(P, 0);
        int max_kits = 0;
        bool done = false;
        while (!done) {
            int min_servings = 1000000000;
            for (int i = 0; i < P; i++) {
                int servings = Q[0][i] / R[0];
                for (int j = 1; j < N; j++) {
                    servings = min(servings, Q[j][max_servings[j]] / R[j]);
                }
                min_servings = min(min_servings, servings);
            }
            if (min_servings == 0) {
                done = true;
            } else {
                int num_kits = 0;
                for (int i = 0; i < P; i++) {
                    int servings = Q[0][i] / R[0];
                    for (int j = 1; j < N; j++) {
                        servings = min(servings, Q[j][max_servings[j]] / R[j]);
                    }
                    int num_servings = servings * N;
                    if (num_servings >= 9 * min_servings && num_servings <= 11 * min_servings) {
                        num_kits++;
                        for (int j = 0; j < N; j++) {
                            max_servings[j]++;
                        }
                    }
                }
                if (num_kits == 0) {
                    done = true;
                } else {
                    max_kits += num_kits;
                }
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
