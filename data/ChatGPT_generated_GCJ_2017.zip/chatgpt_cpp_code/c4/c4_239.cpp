#include <bits/stdc++.h>
using namespace std;

const int MAXN = 55;
const int MAXP = 55;

int N, P, R[MAXN], Q[MAXN][MAXP];

bool is_valid(int servings, int mask) {
    for (int i = 0; i < N; i++) {
        int sum = 0;
        for (int j = 0; j < P; j++) {
            if ((mask & (1 << j)) && Q[i][j] >= R[i] * servings * 9 && Q[i][j] <= R[i] * servings * 11) {
                sum += Q[i][j];
            }
        }
        if (sum < R[i] * servings * 9 || sum > R[i] * servings * 11) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    int ans = 0;
    for (int mask = 0; mask < (1 << P); mask++) {
        int low = 1e9, high = 0;
        for (int servings = 1; ; servings++) {
            if (!is_valid(servings, mask)) {
                break;
            }
            low = min(low, servings);
            high = max(high, servings);
        }
        if (low <= high) {
            ans += 1;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    Q[0][j] = -1;
                }
            }
        }
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
