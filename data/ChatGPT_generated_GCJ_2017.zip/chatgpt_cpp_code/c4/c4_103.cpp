#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;
const double EPS = 1e-9;

int N, P;
int R[MAXN];
int Q[MAXN][MAXN];
vector<int> packages[MAXN];

bool is_valid(int servings, vector<int>& used) {
    vector<int> need(N, 0);
    for (int i = 0; i < N; i++) {
        for (int j : used) {
            need[i] += Q[i][j];
        }
        need[i] *= servings;
    }
    for (int i = 0; i < N; i++) {
        double low = R[i] * 0.9 * servings;
        double high = R[i] * 1.1 * servings;
        if (need[i] < low || need[i] > high) {
            return false;
        }
    }
    return true;
}

int dfs(int idx, vector<int>& used) {
    if (idx == N) {
        int lo = 1, hi = 1e9;
        while (is_valid(hi, used)) {
            lo = hi;
            hi *= 2;
        }
        while (lo < hi) {
            int mid = (lo + hi + 1) / 2;
            if (is_valid(mid, used)) {
                lo = mid;
            } else {
                hi = mid - 1;
            }
        }
        return lo;
    } else {
        int ans = 0;
        for (int j : packages[idx]) {
            used.push_back(j);
            ans = max(ans, dfs(idx + 1, used));
            used.pop_back();
        }
        return ans;
    }
}

void solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
            if (Q[i][j] >= R[i] * 0.9 && Q[i][j] <= R[i] * 1.1) {
                packages[i].push_back(j);
            }
        }
    }
    vector<int> used;
    int ans = dfs(0, used);
    cout << ans << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ": ";
        solve();
    }
    return 0;
}
