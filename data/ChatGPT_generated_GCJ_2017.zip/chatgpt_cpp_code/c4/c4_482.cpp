#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin>>t;
    for(int i=1;i<=t;i++)
    {
        int n,p;
        cin>>n>>p;
        vector<int> r(n);
        vector<vector<int>> q(n,vector<int>(p));
        for(int j=0;j<n;j++)
            cin>>r[j];
        for(int j=0;j<n;j++)
            for(int k=0;k<p;k++)
                cin>>q[j][k];

        vector<int> max_servings(1<<n,-1);

        for(int mask=0;mask<(1<<n);mask++)
        {
            int total_quantity = 0;
            for(int j=0;j<n;j++)
            {
                if(mask & (1<<j))
                {
                    int max_quantity = -1;
                    for(int k=0;k<p;k++)
                    {
                        if(q[j][k] >= r[j]*0.9 && q[j][k] <= r[j]*1.1)
                            max_quantity = max(max_quantity,q[j][k]);
                    }
                    if(max_quantity == -1)
                        break;
                    total_quantity += max_quantity;
                }
            }
            if(total_quantity > 0)
            {
                int servings = total_quantity/min(r);
                max_servings[mask] = servings;
            }
        }

        vector<int> dp(1<<n,-1);

        dp[0] = 0;

        for(int mask=0;mask<(1<<n);mask++)
        {
            for(int submask=mask;submask>0;submask=(submask-1)&mask)
            {
                if(max_servings[submask] != -1)
                {
                    int remaining_mask = mask^submask;
                    int servings = max_servings[submask];
                    dp[mask] = max(dp[mask],dp[remaining_mask]+servings);
                }
            }
        }

        cout<<"Case #"<<i<<": "<<dp[(1<<n)-1]<<endl;
    }
    return 0;
}
