#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<int> max_kits(P, 0);

        for (int mask = 0; mask < (1 << P); mask++) {
            bool valid = true;
            int min_kits = INT_MAX;
            vector<int> total(N, 0);

            for (int j = 0; j < P; j++) {
                if ((mask >> j) & 1) {
                    for (int i = 0; i < N; i++) {
                        total[i] += Q[i][j];
                    }
                }
            }

            for (int i = 0; i < N; i++) {
                int needed = R[i];
                for (int j = 0; j < P; j++) {
                    if ((mask >> j) & 1) {
                        needed -= Q[i][j];
                    }
                }
                if (needed > total[i] * 11 / 10 || needed < total[i] * 9 / 10) {
                    valid = false;
                    break;
                }
                if (total[i] > 0) {
                    int kits = (total[i] * 10) / (R[i] * 9);
                    if (kits == 0) {
                        kits = 1;
                    }
                    min_kits = min(min_kits, kits);
                }
            }

            if (valid) {
                max_kits[mask] = min_kits;
            }
        }

        vector<int> dp(1 << P, 0);
        for (int mask = 0; mask < (1 << P); mask++) {
            for (int submask = mask; submask > 0; submask = (submask - 1) & mask) {
                if (max_kits[submask] > 0) {
                    dp[mask] = max(dp[mask], dp[mask ^ submask] + max_kits[submask]);
                }
            }
        }

        cout << "Case #" << t << ": " << dp[(1 << P) - 1] << endl;
    }

    return 0;
}
