#include <bits/stdc++.h>
using namespace std;

const int MAXN = 55;
const int MAXP = 55;

int T, N, P;
int R[MAXN], Q[MAXN][MAXP];

bool is_valid(int servings, const vector<int>& used) {
    for (int i = 0; i < N; i++) {
        double tot = 0;
        for (int j : used) {
            tot += Q[i][j];
        }
        if (tot < servings * R[i] * 0.9 || tot > servings * R[i] * 1.1) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    vector<int> used(P);
    for (int i = 0; i < P; i++) {
        used[i] = i;
    }
    int ans = 0;
    do {
        for (int servings = 1; ; servings++) {
            if (!is_valid(servings, used)) {
                ans += servings - 1;
                break;
            }
        }
    } while (next_permutation(used.begin(), used.end()));
    return ans;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
