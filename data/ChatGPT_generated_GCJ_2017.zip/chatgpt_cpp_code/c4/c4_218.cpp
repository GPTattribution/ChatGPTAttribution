#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> num_kits(P, 0);
        int max_num_kits = 0;
        for (int i = 0; i < P; i++) {
            vector<int> max_serving(N);
            for (int j = 0; j < N; j++) {
                max_serving[j] = (Q[j][i] * 110) / R[j];
                max_serving[j] = min(max_serving[j], P);
            }
            sort(max_serving.begin(), max_serving.end());
            int num_kits_i = 0;
            for (int j = 1; j <= P; j++) {
                int min_serving = j * 100;
                int max_serving_j = max_serving[N-1];
                for (int k = N-1; k >= 0 && max_serving[k] >= min_serving; k--) {
                    max_serving_j = min(max_serving_j, max_serving[k]);
                }
                if (max_serving_j >= min_serving) {
                    num_kits_i = j;
                }
            }
            num_kits[i] = num_kits_i;
        }
        for (int i = 0; i < P; i++) {
            for (int j = i+1; j < P; j++) {
                if (num_kits[i] == num_kits[j]) {
                    vector<int> serving(N);
                    for (int k = 0; k < N; k++) {
                        serving[k] = (Q[k][i] + Q[k][j]) / (num_kits[i] * R[k]);
                    }
                    bool valid = true;
                    for (int k = 0; k < N; k++) {
                        if (serving[k] < 9 || serving[k] > 11) {
                            valid = false;
                            break;
                        }
                    }
                    if (valid) {
                        num_kits[i] = 0;
                        num_kits[j] = 0;
                        max_num_kits += num_kits[i] + num_kits[j] + 1;
                    }
                }
            }
        }
        for (int i = 0; i < P; i++) {
            if (num_kits[i] > 0) {
                max_num_kits += num_kits[i];
            }
        }
        cout << "Case #" << t << ": " << max_num_kits << endl;
    }
    return 0;
}
