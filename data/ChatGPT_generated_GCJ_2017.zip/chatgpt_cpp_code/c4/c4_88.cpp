#include <iostream>
#include <vector>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int x = 1; x <= t; x++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> chosen(p);
            for (int i = 0; i < p; i++) {
                if (mask & (1 << i)) {
                    chosen[i] = 1;
                }
            }
            bool valid = true;
            for (int i = 0; i < n; i++) {
                int total = 0;
                for (int j = 0; j < p; j++) {
                    if (chosen[j]) {
                        total += q[i][j];
                    }
                }
                if (total < 9 * r[i] || total > 11 * r[i]) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int servings = 1e9;
                for (int i = 0; i < n; i++) {
                    int total = 0;
                    for (int j = 0; j < p; j++) {
                        if (chosen[j]) {
                            total += q[i][j];
                        }
                    }
                    servings = min(servings, total / r[i]);
                }
                ans = max(ans, servings);
            }
        }
        cout << "Case #" << x << ": " << ans << endl;
    }
    return 0;
}
