#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n), low(n), high(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
            low[j] = (9 * r[j] + 10) / 10;
            high[j] = (11 * r[j] + 9) / 10;
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << (n * p)); mask++) {
            int servings = INT_MAX;
            vector<int> qty(n, 0);
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < p; k++) {
                    if (mask & (1 << (j * p + k))) {
                        qty[j] += q[j][k];
                    }
                }
                servings = min(servings, qty[j] / r[j]);
            }
            if (servings >= 1) {
                bool valid = true;
                for (int j = 0; j < n; j++) {
                    if (qty[j] < servings * low[j] || qty[j] > servings * high[j]) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    ans = max(ans, servings);
                }
            }
        }
        cout << "Case #" << i << ": " << ans << "\n";
    }
    return 0;
}
