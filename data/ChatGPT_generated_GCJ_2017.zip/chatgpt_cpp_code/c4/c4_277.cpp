#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

bool can_make_kit(const vector<int>& recipe, const vector<vector<int>>& packages, int num_servings) {
    int num_ingredients = recipe.size();
    vector<int> max_amounts(num_ingredients), min_amounts(num_ingredients);
    for (int i = 0; i < num_ingredients; i++) {
        double amount_per_serving = recipe[i];
        max_amounts[i] = (int) (amount_per_serving * num_servings * 1.1);
        min_amounts[i] = (int) (amount_per_serving * num_servings * 0.9);
    }
    for (int j = 0; j < packages[0].size(); j++) {
        vector<int> amounts(num_ingredients);
        for (int i = 0; i < num_ingredients; i++) {
            amounts[i] = packages[i][j];
        }
        if (all_of(amounts.begin(), amounts.end(), [&](int a) { return a >= min_amounts[0] && a <= max_amounts[0]; })) {
            return true;
        }
    }
    return false;
}

int max_num_kits(const vector<int>& recipe, const vector<vector<int>>& packages) {
    int num_ingredients = recipe.size();
    int num_packages = packages[0].size();
    int max_num = 0;
    for (int servings = 1; ; servings++) {
        if (!can_make_kit(recipe, packages, servings)) {
            break;
        }
        int num = 0;
        vector<int> used(num_packages);
        for (int i = 0; i < num_ingredients; i++) {
            for (int j = 0; j < num_packages; j++) {
                double amount_per_serving = recipe[i];
                int max_amount = (int) (amount_per_serving * servings * 1.1);
                int min_amount = (int) (amount_per_serving * servings * 0.9);
                if (packages[i][j] >= min_amount && packages[i][j] <= max_amount && !used[j]) {
                    used[j] = true;
                    num++;
                    break;
                }
            }
        }
        max_num = max(max_num, num / num_ingredients);
    }
    return max_num;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> recipe(n);
        for (int j = 0; j < n; j++) {
            cin >> recipe[j];
        }
        vector<vector<int>> packages(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> packages[j][k];
            }
        }
        int max_num = max_num_kits(recipe, packages);
        cout << "Case #" << i << ": " << max_num << endl;
    }
    return 0;
}
