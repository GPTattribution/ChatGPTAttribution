#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<vector<int>> packages;
        for (int i = 0; i < P; i++) {
            vector<int> cur(N);
            for (int j = 0; j < N; j++) {
                cur[j] = Q[j][i];
            }
            packages.push_back(cur);
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> counts(N);
            int servings = 0;
            for (int i = 0; i < P; i++) {
                if ((mask >> i) & 1) {
                    servings++;
                    for (int j = 0; j < N; j++) {
                        counts[j] += packages[i][j];
                    }
                }
            }

            bool ok = true;
            for (int j = 0; j < N; j++) {
                int lower = (R[j] * servings * 9 + 5) / 10;
                int upper = (R[j] * servings * 11 + 5) / 10;
                if (counts[j] < lower || counts[j] > upper) {
                    ok = false;
                    break;
                }
            }

            if (ok) {
                ans = max(ans, servings);
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
