#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> total(N);
            int num_kits = 0;
            bool valid = true;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    num_kits++;
                    for (int i = 0; i < N; i++) {
                        total[i] += Q[i][j];
                    }
                }
            }
            for (int i = 0; i < N; i++) {
                if (total[i] < R[i] * num_kits * 9 / 10 || total[i] > R[i] * num_kits * 11 / 10) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = max(max_kits, num_kits);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
