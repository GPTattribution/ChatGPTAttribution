#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            bool valid = true;
            vector<int> S(N);
            for (int i = 0; i < P; i++) {
                if (mask & (1 << i)) {
                    for (int j = 0; j < N; j++) {
                        S[j] += Q[j][i];
                    }
                }
            }
            for (int j = 0; j < N; j++) {
                if (S[j] < R[j] * 9 / 10 || S[j] > R[j] * 11 / 10) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int k = 0;
                for (int j = 0; j < N; j++) {
                    k = max(k, (S[j] + R[j] - 1) / R[j]);
                }
                ans = max(ans, k);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
