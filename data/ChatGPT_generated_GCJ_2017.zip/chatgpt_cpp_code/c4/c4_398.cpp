#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> indices(N, 0);
        int max_kits = 0;
        while (true) {
            bool valid = true;
            int servings = -1;
            for (int i = 0; i < N; i++) {
                int total = 0;
                for (int j = 0; j < P; j++) {
                    if (j == indices[i]) {
                        total += Q[i][j];
                    }
                }
                if (total < 9 * R[i] || total > 11 * R[i]) {
                    valid = false;
                    break;
                }
                int cur_servings = total / R[i];
                if (servings == -1) {
                    servings = cur_servings;
                } else if (cur_servings != servings) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits++;
            }
            bool done = false;
            for (int i = N - 1; i >= 0; i--) {
                indices[i]++;
                if (indices[i] == P) {
                    indices[i] = 0;
                } else {
                    done = true;
                    break;
                }
            }
            if (!done) {
                break;
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
