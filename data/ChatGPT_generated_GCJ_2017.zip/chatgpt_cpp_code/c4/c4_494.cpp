#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> cnt(N);
            int servings = INT_MAX;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < N; i++) {
                        cnt[i] += Q[i][j];
                    }
                    servings = min(servings, Q[0][j] / R[0]);
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int required = R[i] * servings;
                int lower = required * 9;
                int upper = required * 11;
                if (cnt[i] < lower || cnt[i] > upper) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, __builtin_popcount(mask));
            }
        }
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
