#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        vector<int> indices(N);
        for (int i = 0; i < N; i++) {
            indices[i] = i;
        }
        do {
            int servings = Q[indices[0]][0] / R[indices[0]];
            for (int i = 0; i < N; i++) {
                servings = min(servings, Q[indices[i]][0] / R[indices[i]]);
            }
            int valid = 0;
            for (int s = servings; s >= 1; s--) {
                bool ok = true;
                for (int i = 0; i < N && ok; i++) {
                    double sum = 0;
                    for (int j = 0; j < P; j++) {
                        if (Q[indices[i]][j] >= s * R[indices[i]] * 0.9 && Q[indices[i]][j] <= s * R[indices[i]] * 1.1) {
                            sum += Q[indices[i]][j];
                        }
                    }
                    if (sum < s * R[indices[i]] * 0.9 || sum > s * R[indices[i]] * 1.1) {
                        ok = false;
                    }
                }
                if (ok) {
                    valid = s;
                    break;
                }
            }
            ans += valid;
        } while (next_permutation(indices.begin(), indices.end()));
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
