#include <iostream>
#include <vector>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N), min_amt(N), max_amt(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            min_amt[i] = R[i] * 9 / 10;
            max_amt[i] = R[i] * 11 / 10;
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << (N * P)); mask++) {
            vector<int> amt(N);
            int servings = 0;
            bool valid = true;
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < P; j++) {
                    if ((mask >> (i * P + j)) & 1) {
                        amt[i] += Q[i][j];
                    }
                }
                if (amt[i] < min_amt[i] || amt[i] > max_amt[i]) {
                    valid = false;
                    break;
                }
                servings = amt[i] / R[i];
            }
            if (valid) {
                int kits = servings;
                for (int i = 0; i < N; i++) {
                    kits = min(kits, amt[i] / R[i]);
                }
                ans = max(ans, kits);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
