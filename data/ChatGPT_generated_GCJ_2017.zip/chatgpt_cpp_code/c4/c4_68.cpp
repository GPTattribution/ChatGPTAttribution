#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> cnt(n, 0);
            int servings = INT_MAX;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    for (int k = 0; k < n; k++) {
                        cnt[k] += q[k][j];
                    }
                    servings = min(servings, q[0][j] / r[0]);
                }
            }
            bool ok = true;
            for (int j = 0; j < n; j++) {
                if (cnt[j] < servings * r[j] * 9 / 10 ||
                    cnt[j] > servings * r[j] * 11 / 10) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, __builtin_popcount(mask));
            }
        }
        cout << "Case #" << i << ": " << ans << "\n";
    }
    return 0;
}
