#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<vector<int>> indices(N, vector<int>(P));
        vector<int> num_packages(P, 0);
        iota(num_packages.begin(), num_packages.end(), 0);
        int max_kits = 0;
        do {
            int kits = 0;
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int total_grams = 0;
                for (int j = 0; j < P; j++) {
                    total_grams += Q[i][indices[i][j]];
                }
                int min_grams = 9 * R[i];
                int max_grams = 11 * R[i];
                if (total_grams < min_grams || total_grams > max_grams) {
                    valid = false;
                    break;
                }
                kits = max(kits, total_grams / R[i]);
            }
            if (valid) {
                max_kits = max(max_kits, kits);
            }
        } while (next_permutation(num_packages.begin(), num_packages.end()));
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
