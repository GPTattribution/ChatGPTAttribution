#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        vector<int> max_servings(p, 0);
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                int min_amount = r[j] * 9 / 10;
                int max_amount = r[j] * 11 / 10;
                if (q[j][k] >= min_amount && q[j][k] <= max_amount) {
                    max_servings[k] = min(max_servings[k], q[j][k] / r[j]);
                }
            }
        }

        int ans = 0;
        for (int j = 0; j < (1 << p); j++) {
            int servings = 0;
            for (int k = 0; k < p; k++) {
                if (j & (1 << k)) {
                    servings += max_servings[k];
                }
            }
            bool valid = true;
            for (int k = 0; k < n; k++) {
                int amount = 0;
                for (int l = 0; l < p; l++) {
                    if (j & (1 << l)) {
                        amount += q[k][l];
                    }
                }
                if (amount < r[k] * servings * 9 / 10 || amount > r[k] * servings * 11 / 10) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, servings);
            }
        }

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
