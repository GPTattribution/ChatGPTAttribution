#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const int MAXQ = 1000000;

int R[MAXN], Q[MAXN][MAXP];
int memo[MAXN*MAXQ + 1];

int solve(int N, int P) {
    memset(memo, -1, sizeof(memo));
    memo[0] = 0;

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            for (int k = N*MAXQ; k >= Q[i][j]; k--) {
                if (memo[k - Q[i][j]] >= 0) {
                    memo[k] = max(memo[k], memo[k - Q[i][j]] + 1);
                }
            }
        }
    }

    int ans = 0;
    for (int k = 1; k <= N*MAXQ; k++) {
        if (memo[k] >= 0 && memo[k] <= ans) {
            continue;
        }
        bool valid = true;
        int remaining = k;
        for (int i = 0; i < N; i++) {
            int needed = R[i]*memo[k];
            int total = 0;
            for (int j = 0; j < P; j++) {
                total += max(0, min(Q[i][j], remaining/P));
            }
            if (total < needed*9/10 || total > needed*11/10) {
                valid = false;
                break;
            }
            remaining -= needed;
        }
        if (valid) {
            ans = memo[k];
        }
    }

    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = solve(N, P);
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
