#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50, MAXP = 50;

int N, P;
int R[MAXN], Q[MAXN][MAXP];

bool check(int servings, const vector<int>& idx) {
    for (int i = 0; i < N; i++) {
        int total = 0;
        for (int j : idx) {
            total += Q[i][j];
        }
        int required = servings * R[i];
        if (total < required * 9 || total > required * 11) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    vector<int> idx(P);
    for (int i = 0; i < P; i++) {
        idx[i] = i;
    }
    int ans = 0;
    do {
        for (int servings = 1; ; servings++) {
            if (!check(servings, idx)) {
                ans = max(ans, servings - 1);
                break;
            }
        }
    } while (next_permutation(idx.begin(), idx.end()));
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
