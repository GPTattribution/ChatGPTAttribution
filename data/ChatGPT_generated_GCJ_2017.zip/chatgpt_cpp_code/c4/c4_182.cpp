#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<vector<int>> possible_kits;
        for (int mask = 0; mask < (1 << P); mask++) {
            bool valid = true;
            vector<int> kit(N, 0);
            for (int i = 0; i < P; i++) {
                if ((mask >> i) & 1) {
                    for (int j = 0; j < N; j++) {
                        kit[j] += Q[j][i];
                    }
                }
            }
            for (int i = 0; i < N; i++) {
                int low = ceil(R[i] * 0.9);
                int high = floor(R[i] * 1.1);
                if (kit[i] < low || kit[i] > high) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                possible_kits.push_back(kit);
            }
        }
        int ans = 0;
        for (int i = 0; i < possible_kits.size(); i++) {
            int min_servings = 1e9;
            for (int j = 0; j < N; j++) {
                min_servings = min(min_servings, possible_kits[i][j] / R[j]);
            }
            ans = max(ans, min_servings);
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
