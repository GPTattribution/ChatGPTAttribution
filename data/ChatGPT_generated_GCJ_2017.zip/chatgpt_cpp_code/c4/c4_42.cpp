#include <iostream>
#include <vector>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int caseNum = 1; caseNum <= t; caseNum++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }

        int numKits = 0;
        for (int i = 0; i < p; i++) {
            bool valid = true;
            vector<int> amount(n);
            for (int j = 0; j < n; j++) {
                amount[j] = q[j][i];
            }
            while (valid) {
                for (int j = 0; j < n; j++) {
                    int lower = (r[j] * 90 + 99) / 100;
                    int upper = (r[j] * 110) / 100; 
                    if (amount[j] < lower || amount[j] > upper) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    numKits++;
                    for (int j = 0; j < n; j++) {
                        amount[j] -= r[j];
                    }
                }
            }
        }

        cout << "Case #" << caseNum << ": " << numKits << endl;
    }
    return 0;
}
