#include <bits/stdc++.h>
using namespace std;

const int MAXN = 55;
const double EPS = 1e-9;

int T, N, P;
int R[MAXN];
int Q[MAXN][MAXN];

bool canMake(int servings, vector<int>& q) {
    for (int i = 0; i < N; i++) {
        double minWeight = R[i] * servings * 0.9;
        double maxWeight = R[i] * servings * 1.1;
        if (q[i] < minWeight || q[i] > maxWeight) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    int maxKits = 0;
    for (int mask = 0; mask < (1 << P); mask++) {
        vector<int> q(N, 0);
        int servings = 0;
        for (int j = 0; j < P; j++) {
            if (mask & (1 << j)) {
                servings++;
                for (int i = 0; i < N; i++) {
                    q[i] += Q[i][j];
                }
            }
        }
        if (canMake(servings, q)) {
            maxKits = max(maxKits, servings);
        }
    }
    return maxKits;
}

int main() {
    cin >> T;
    for (int i = 1; i <= T; i++) {
        int ans = solve();
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
