#include <bits/stdc++.h>
using namespace std;

const int MAXN = 55;
const double EPS = 1e-6;

int N, P;
int R[MAXN];
int Q[MAXN][MAXN];
int best[MAXN];

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> P;
        for (int i = 1; i <= N; i++) {
            cin >> R[i];
        }
        for (int i = 1; i <= N; i++) {
            for (int j = 1; j <= P; j++) {
                cin >> Q[i][j];
            }
        }
        memset(best, 0, sizeof(best));
        for (int mask = 0; mask < (1 << P); mask++) {
            int cnt = 0;
            vector<int> amt(N + 1);
            for (int i = 1; i <= N; i++) {
                double lo = 1e18, hi = 0;
                for (int j = 1; j <= P; j++) {
                    if (mask & (1 << (j - 1))) {
                        lo = min(lo, (double) Q[i][j] / (R[i] * 1.1));
                        hi = max(hi, (double) Q[i][j] / (R[i] * 0.9));
                    }
                }
                if (hi - lo >= EPS) {
                    continue;
                }
                amt[i] = (int) (lo * R[i] + EPS);
                cnt++;
            }
            if (cnt == N) {
                int prod = 1;
                for (int i = 1; i <= N; i++) {
                    prod *= amt[i];
                }
                for (int i = 1; i <= N; i++) {
                    best[i] = max(best[i], amt[i]);
                }
            }
        }
        int ans = 0;
        for (int i = 1; i <= N; i++) {
            ans = max(ans, best[i]);
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
