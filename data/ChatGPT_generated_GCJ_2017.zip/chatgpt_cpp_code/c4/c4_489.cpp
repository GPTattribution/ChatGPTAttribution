#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        vector<int> indices(N);
        for (int i = 0; i < N; i++) {
            indices[i] = i;
        }
        do {
            for (int k = 1; k <= 100; k++) {
                vector<int> counts(P);
                bool ok = true;
                for (int i = 0; i < N; i++) {
                    int j = indices[i];
                    int q = Q[j][counts[j]];
                    int r = R[j] * k;
                    if (q < 9 * r / 10 || q > 11 * r / 10) {
                        ok = false;
                        break;
                    }
                    counts[j]++;
                }
                if (ok) {
                    ans++;
                } else {
                    break;
                }
            }
        } while (next_permutation(indices.begin(), indices.end()));
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
