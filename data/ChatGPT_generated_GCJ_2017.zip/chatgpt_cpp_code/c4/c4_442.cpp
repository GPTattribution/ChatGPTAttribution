#include <iostream>
#include <algorithm>
#include <vector>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
            sort(q[j].begin(), q[j].end());
        }
        int ans = 0;
        for (int j = 0; j < p; j++) {
            vector<int> qt(n);
            qt[0] = q[0][j];
            int max_serve = qt[0] / r[0];
            for (int k = 1; k < n; k++) {
                int ub = qt[k-1] * 11 / 10 / r[k];
                int lb = qt[k-1] * 9 / 10 / r[k];
                auto it = lower_bound(q[k].begin(), q[k].end(), lb);
                if (it == q[k].end() || *it > ub * r[k]) {
                    break;
                }
                qt[k] = *it;
                max_serve = min(max_serve, qt[k] / r[k]);
            }
            ans += max_serve > 0;
            for (int k = 1; k < p; k++) {
                if (q[0][k] * 10 < qt[0] * 9) {
                    continue;
                }
                vector<int> qt(n);
                qt[0] = q[0][k];
                int max_serve = qt[0] / r[0];
                for (int l = 1; l < n; l++) {
                    int ub = qt[l-1] * 11 / 10 / r[l];
                    int lb = qt[l-1] * 9 / 10 / r[l];
                    auto it = lower_bound(q[l].begin(), q[l].end(), lb);
                    if (it == q[l].end() || *it > ub * r[l]) {
                        break;
                    }
                    qt[l] = *it;
                    max_serve = min(max_serve, qt[l] / r[l]);
                }
                ans += max_serve > 0;
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
