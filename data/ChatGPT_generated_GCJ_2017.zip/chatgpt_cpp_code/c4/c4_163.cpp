#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int case_no = 1; case_no <= t; case_no++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }

        int max_kits = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> quantity(n);
            int num_packages = 0;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    num_packages++;
                    for (int i = 0; i < n; i++) {
                        quantity[i] += q[i][j];
                    }
                }
            }

            bool valid = true;
            for (int i = 0; i < n; i++) {
                int min_quantity = r[i] * num_packages * 9 / 10;
                int max_quantity = r[i] * num_packages * 11 / 10;
                if (quantity[i] < min_quantity || quantity[i] > max_quantity) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                max_kits = max(max_kits, num_packages);
            }
        }

        cout << "Case #" << case_no << ": " << max_kits << endl;
    }

    return 0;
}
