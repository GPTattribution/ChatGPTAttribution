#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int MAX_N = 50;
const int MAX_P = 50;

int N, P;
int R[MAX_N];
int Q[MAX_N][MAX_P];

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        cin >> N >> P;

        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        vector<int> indices(N, 0);
        while (true) {
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int total = 0;
                for (int j = 0; j < P; j++) {
                    if (Q[i][j] >= indices[i] * R[i] * 9 / 10 &&
                        Q[i][j] <= indices[i] * R[i] * 11 / 10) {
                        total += Q[i][j];
                    }
                }
                if (total < indices[i] * R[i] ||
                    total > indices[i] * R[i] * 11 / 10) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans++;
            }

            int i = 0;
            while (i < N && ++indices[i] == P) {
                indices[i] = 0;
                i++;
            }
            if (i == N) {
                break;
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
