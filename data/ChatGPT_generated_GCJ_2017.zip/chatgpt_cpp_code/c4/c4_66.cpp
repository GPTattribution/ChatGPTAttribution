#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int x = 1; x <= t; x++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        vector<int> idx(n);
        for (int i = 0; i < n; i++) {
            idx[i] = i;
        }
        int ans = 0;
        do {
            int cnt = 0;
            vector<int> rem(p);
            for (int i = 0; i < n; i++) {
                int j = idx[i];
                int mini = 1e9, maxi = -1e9;
                for (int k = 0; k < p; k++) {
                    mini = min(mini, q[j][k]);
                    maxi = max(maxi, q[j][k]);
                }
                mini = (mini * 10 + 11 * r[j] - 1) / (11 * r[j]);
                maxi = (maxi * 10) / (9 * r[j]);
                if (maxi < mini) {
                    cnt = -1;
                    break;
                }
                cnt += mini;
                for (int k = 0; k < p; k++) {
                    rem[k] += q[j][k];
                }
            }
            if (cnt == -1) {
                continue;
            }
            sort(rem.begin(), rem.end());
            int tot = 0;
            while (cnt > 0) {
                int j = rem.back();
                rem.pop_back();
                tot += j;
                cnt--;
            }
            ans = max(ans, tot);
        } while (next_permutation(idx.begin(), idx.end()));
        cout << "Case #" << x << ": " << ans << endl;
    }
    return 0;
}
