#include <iostream>
#include <vector>
using namespace std;

int n, p;
vector<int> r;
vector<vector<int>> q;
int ans;

void solve(int i, vector<int> used, vector<int> rem) {
    if (i == n) {
        int servings = *min_element(used.begin(), used.end());
        for (int j = 0; j < n; j++) {
            double min_amt = r[j] * servings * 0.9;
            double max_amt = r[j] * servings * 1.1;
            if (rem[j] < min_amt || rem[j] > max_amt) {
                return; 
            }
        }
        ans = max(ans, servings);
        return;
    }
    for (int j = 0; j < p; j++) {
        used[i] = q[i][j];
        rem[i] = q[i][j];
        solve(i+1, used, rem);
        used[i] = 0;
        rem[i] = 0;
    }
}

int main() {
    int t;
    cin >> t;
    for (int x = 1; x <= t; x++) {
        cin >> n >> p;
        r.resize(n);
        q.resize(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
            q[i].resize(p);
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        ans = 0;
        vector<int> used(n), rem(n);
        solve(0, used, rem);
        cout << "Case #" << x << ": " << ans << endl;
    }
    return 0;
}
