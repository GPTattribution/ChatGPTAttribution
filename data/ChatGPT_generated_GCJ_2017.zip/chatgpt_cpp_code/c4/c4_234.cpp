#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

const double EPS = 1e-9;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; ++i) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; ++j) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; ++j) {
            for (int k = 0; k < p; ++k) {
                cin >> q[j][k];
            }
        }
        vector<int> max_kits(p, 0);
        for (int j = 0; j < p; ++j) {
            vector<double> ratios;
            for (int k = 0; k < n; ++k) {
                ratios.push_back(double(q[k][j]) / double(r[k]));
            }
            sort(ratios.begin(), ratios.end());
            int max_k = 0;
            for (int k = 1; k <= p; ++k) {
                double target_ratio = double(k) * ratios[0];
                if (target_ratio > ratios[n-1] + EPS) {
                    break;
                }
                int count = 0;
                for (int l = 0; l < n; ++l) {
                    int index = upper_bound(ratios.begin(), ratios.end(), target_ratio + EPS) - ratios.begin();
                    if (index == 0 || ratios[index-1] < target_ratio - EPS || ratios[index-1] > target_ratio + EPS) {
                        break;
                    }
                    int amount = int(ceil(double(k) * r[l]));
                    if (q[l][j] < amount || q[l][j] > int(floor(double(k) * r[l] * 1.1 + EPS))) {
                        break;
                    }
                    ++count;
                }
                max_k = max(max_k, count);
            }
            max_kits[j] = max_k;
        }
        int ans = 0;
        for (int j = 0; j < p; ++j) {
            ans += max_kits[j];
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
