#include<bits/stdc++.h>
using namespace std;

const int N=60,M=1010;

int T,n,p,ans,res,num[N][M];
int tot[N],need[N];
bool used[M];

bool judge(int k){
    memset(tot,0,sizeof tot);
    int s=0;
    for(int i=0;i<n;i++)
        for(int j=0;j<p;j++)
            if(!used[j]&&num[i][j]>=need[i]*k*0.9&&num[i][j]<=need[i]*k*1.1){
                used[j]=1;
                tot[i]++;
                break;
            }
    for(int i=0;i<n;i++) s+=tot[i];
    if(s==n*k) return 1;
    return 0;
}

void dfs(int x){
    if(x==p){
        int l=0,r=p/n,mid,ans=0;
        while(l<=r){
            memset(used,0,sizeof used);
            mid=(l+r)>>1;
            if(judge(mid)) l=mid+1,ans=mid;
            else r=mid-1;
        }
        res=max(res,ans);
        return ;
    }
    dfs(x+1);
    used[x]=1;
    dfs(x+1);
    used[x]=0;
}

int main(){
    cin>>T;
    for(int cases=1;cases<=T;cases++){
        cin>>n>>p;
        res=0;
        for(int i=0;i<n;i++) cin>>need[i];
        for(int i=0;i<n;i++)
            for(int j=0;j<p;j++)
                cin>>num[i][j];
        dfs(0);
        cout<<"Case #"<<cases<<": "<<res<<endl;
    }
    return 0;
}
