#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

bool can_make_kits(vector<vector<int>>& q, vector<int>& r, vector<int>& cnt, int servings) {
    int n = r.size();
    for (int i = 0; i < n; i++) {
        vector<int> pkg;
        for (int j = 0; j < cnt[i]; j++) {
            pkg.push_back(q[i][j]);
        }
        sort(pkg.begin(), pkg.end());
        int need = r[i] * servings;
        int l = 0, r = pkg.size() - 1;
        bool ok = false;
        while (l <= r) {
            int mid = (l + r) / 2;
            if (pkg[mid] >= need * 0.9 && pkg[mid] <= need * 1.1) {
                ok = true;
                pkg.erase(pkg.begin() + mid);
                break;
            } else if (pkg[mid] < need * 0.9) {
                l = mid + 1;
            } else {
                r = mid - 1;
            }
        }
        if (!ok) {
            return false;
        }
    }
    return true;
}

void solve() {
    int n, p;
    cin >> n >> p;
    vector<int> r(n);
    for (int i = 0; i < n; i++) {
        cin >> r[i];
    }
    vector<vector<int>> q(n, vector<int>(p));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < p; j++) {
            cin >> q[i][j];
        }
    }
    vector<int> cnt(p, p);
    int ans = 0;
    while (true) {
        int servings = -1;
        for (int s = 1; s <= 1000000; s++) {
            if (can_make_kits(q, r, cnt, s)) {
                servings = s;
            } else {
                break;
            }
        }
        if (servings == -1) {
            break;
        }
        ans++;
        for (int i = 0; i < n; i++) {
            int need = r[i] * servings;
            for (int j = 0; j < p; j++) {
                if (q[i][j] >= need * 0.9 && q[i][j] <= need * 1.1) {
                    q[i][j] = -1;
                    cnt[j]--;
                    break;
                }
            }
        }
    }
    cout << ans << endl;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        cout << "Case #" << i << ": ";
        solve();
    }
    return 0;
}
