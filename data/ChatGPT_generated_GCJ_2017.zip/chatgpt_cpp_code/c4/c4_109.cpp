#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> indices(N);
        for (int i = 0; i < N; i++) {
            indices[i] = i;
        }
        int maxKits = 0;
        do {
            bool valid = true;
            int servings = 0;
            for (int i = 0; i < P; i++) {
                int numServings = INT_MAX;
                for (int j = 0; j < N; j++) {
                    int qty = Q[indices[j]][i];
                    if (qty < R[indices[j]] * 0.9 || qty > R[indices[j]] * 1.1) {
                        valid = false;
                        break;
                    }
                    numServings = min(numServings, qty / R[indices[j]]);
                }
                if (valid) {
                    servings += numServings;
                } else {
                    break;
                }
            }
            if (valid) {
                maxKits = max(maxKits, servings);
            }
        } while (next_permutation(indices.begin(), indices.end()));
        cout << "Case #" << t << ": " << maxKits << endl;
    }
    return 0;
}
