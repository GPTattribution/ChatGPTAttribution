#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); ++mask) {
            bool valid = true;
            vector<int> S(N, 0);
            int servings = INT_MAX;
            for (int j = 0; j < P; ++j) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < N; ++i) {
                        S[i] += Q[i][j];
                    }
                    servings = min(servings, *min_element(S.begin(), S.end()) / R[0]);
                }
            }
            if (servings == INT_MAX) continue;
            for (int i = 0; i < N; ++i) {
                int lower = servings * R[i] * 9 / 10;
                int upper = servings * R[i] * 11 / 10;
                if (S[i] < lower || S[i] > upper) {
                    valid = false;
                    break;
                }
            }
            if (valid) ans = max(ans, servings);
        }
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
