#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; ++i) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; ++j) {
            cin >> r[j];
            for (int k = 0; k < p; ++k) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << n); ++mask) {
            int serv = INT_MAX;
            bool valid = true;
            for (int j = 0; j < n; ++j) {
                if (mask & (1 << j)) {
                    int mn = INT_MAX, mx = INT_MIN;
                    for (int k = 0; k < p; ++k) {
                        if (q[j][k] >= r[j] * 9 / 10 && q[j][k] <= r[j] * 11 / 10) {
                            mn = min(mn, q[j][k]);
                            mx = max(mx, q[j][k]);
                        }
                    }
                    if (mn == INT_MAX) {
                        valid = false;
                        break;
                    }
                    serv = min(serv, mx / r[j]);
                }
            }
            if (valid) {
                ans = max(ans, serv);
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
