#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N), total(P);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                int Q;
                cin >> Q;
                total[j] += Q;
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> count(N);
            int servings = 1;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < N; i++) {
                        count[i] += total[j*N+i];
                    }
                    servings++;
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                double needed = (double) servings * R[i];
                double min = needed * 0.9, max = needed * 1.1;
                if (count[i] < min || count[i] > max) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, servings);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
