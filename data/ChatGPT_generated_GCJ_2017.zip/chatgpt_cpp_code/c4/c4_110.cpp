#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool can_make_kit(int n, const vector<int>& r, const vector<vector<int>>& packages, const vector<int>& quantities, int s) {
    for (int i = 0; i < n; i++) {
        double lower = r[i] * s * 0.9;
        double upper = r[i] * s * 1.1;
        double total = 0;
        for (int j = 0; j < quantities.size(); j++) {
            total += packages[i][j] * quantities[j];
        }
        if (total < lower || total > upper) {
            return false;
        }
    }
    return true;
}

void form_kits(int n, const vector<int>& r, const vector<vector<int>>& packages, vector<int>& quantities, int& max_kits, int s = 0) {
    if (s > 0 && !can_make_kit(n, r, packages, quantities, s)) {
        return;
    }
    if (s > 0) {
        max_kits = max(max_kits, s);
    }
    if (s == 0 || can_make_kit(n, r, packages, quantities, s+1)) {
        for (int j = 0; j < quantities.size(); j++) {
            quantities[j]++;
            form_kits(n, r, packages, quantities, max_kits, s+1);
            quantities[j]--;
        }
    }
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> packages(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> packages[j][k];
            }
        }
        vector<int> quantities(p, 0);
        int max_kits = 0;
        form_kits(n, r, packages, quantities, max_kits);
        cout << "Case #" << i << ": " << max_kits << endl;
    }
    return 0;
}
