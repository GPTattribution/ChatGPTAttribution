#include <bits/stdc++.h>
using namespace std;

#define ll long long

int main() {
    int t;
    cin >> t;
    for (int test = 1; test <= t; test++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        vector<int> idx(n);
        iota(idx.begin(), idx.end(), 0);
        ll ans = 0;
        do {
            for (int k = 1; k <= 100; k++) {
                bool ok = true;
                int need = k;
                for (int i = 0; i < n && ok; i++) {
                    int have = 0;
                    for (int j = 0; j < p; j++) {
                        if (idx[j] == i) {
                            have += q[i][j];
                        }
                    }
                    if (have < need * r[i] * 9 / 10 || have > need * r[i] * 11 / 10) {
                        ok = false;
                    }
                }
                if (ok) {
                    ans = max(ans, (ll)k);
                }
            }
        } while (next_permutation(idx.begin(), idx.end()));
        cout << "Case #" << test << ": " << ans << "\n";
    }
    return 0;
}
