#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<vector<int>> packages;
        for (int i = 0; i < P; i++) {
            vector<int> pkg(N);
            bool ok = true;
            for (int j = 0; j < N; j++) {
                pkg[j] = Q[j][i];
                double factor = (double) pkg[j] / R[j];
                if (factor < 0.9 || factor > 1.1) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                packages.push_back(pkg);
            }
        }

        int max_kits = 0;
        for (vector<int>& pkg : packages) {
            int kits = 1e9;
            for (int j = 0; j < N; j++) {
                kits = min(kits, pkg[j] / R[j]);
            }
            max_kits = max(max_kits, kits);
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
