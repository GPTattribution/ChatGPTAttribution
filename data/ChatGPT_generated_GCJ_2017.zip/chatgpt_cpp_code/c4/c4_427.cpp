#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> total(N);
            int num_packages = 0;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    num_packages++;
                    for (int i = 0; i < N; i++) {
                        total[i] += Q[i][j];
                    }
                }
            }
            int min_servings = 1e9;
            for (int i = 0; i < N; i++) {
                int servings = total[i] / R[i];
                if (total[i] % R[i] != 0) {
                    servings++;
                }
                if (servings == 0) {
                    min_servings = 0;
                    break;
                }
                int lower_bound = (int)(R[i] * 0.9);
                int upper_bound = (int)(R[i] * 1.1);
                if (total[i] < lower_bound * servings || total[i] > upper_bound * servings) {
                    min_servings = 0;
                    break;
                }
                min_servings = min(min_servings, servings);
            }
            if (min_servings > 0) {
                max_kits = max(max_kits, num_packages / N);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
