#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int x = 1; x <= t; x++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> total(n);
            int count = 0;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    count++;
                    for (int i = 0; i < n; i++) {
                        total[i] += q[i][j];
                    }
                }
            }
            bool ok = true;
            for (int i = 0; i < n; i++) {
                if (total[i] < r[i] * count * 9 / 10 || total[i] > r[i] * count * 11 / 10) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, count);
            }
        }
        cout << "Case #" << x << ": " << ans << "\n";
    }
    return 0;
}
