#include <iostream>
#include <vector>

using namespace std;

const double MIN_RATIO = 0.9;
const double MAX_RATIO = 1.1;

int count_valid_kits(int n, int p, const vector<int>& r, const vector<vector<int>>& q) {
    int max_kits = 0;

    vector<int> indices(n, 0);
    while (true) {
        int servings = INT_MAX;
        for (int i = 0; i < n; i++) {
            double total_weight = q[i][indices[i]];
            double ratio = total_weight / r[i];
            if (ratio < MIN_RATIO || ratio > MAX_RATIO) {
                servings = 0;
                break;
            }
            int required_weight = r[i] * servings;
            while (total_weight < required_weight * MIN_RATIO) {
                indices[i]++;
                if (indices[i] >= p) {
                    servings = 0;
                    break;
                }
                total_weight += q[i][indices[i]];
            }
            if (servings == 0) {
                break;
            }
            servings = min(servings, (int) (total_weight / (r[i] * MIN_RATIO)));
        }

        if (servings > 0) {
            max_kits++;
            for (int i = 0; i < n; i++) {
                q[i][indices[i]] = -1;
                indices[i]++;
            }
        } else {
            break;
        }
    }

    return max_kits;
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int max_kits = count_valid_kits(n, p, r, q);
        cout << "Case #" << i << ": " << max_kits << endl;
    }

    return 0;
}
