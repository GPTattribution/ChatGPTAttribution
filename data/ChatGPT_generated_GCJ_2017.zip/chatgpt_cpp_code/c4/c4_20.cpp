#include <bits/stdc++.h>
using namespace std;

int T, N, P;
int R[55], Q[55][55];

bool check(int x) {
    int sum[55];
    memset(sum, 0, sizeof(sum));
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            sum[j] += Q[i][j];
        }
        sort(sum, sum + P);
        int num = 0;
        for (int j = 0; j < P; j++) {
            if (sum[j] >= x * 0.9 * R[i] && sum[j] <= x * 1.1 * R[i]) {
                num++;
                for (int k = i; k < N; k++) {
                    sum[j] -= Q[k][j];
                }
            }
        }
        if (num < x) {
            return false;
        }
    }
    return true;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> P;
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int l = 0, r = 1000;
        while (l < r) {
            int mid = (l + r + 1) / 2;
            if (check(mid)) {
                l = mid;
            } else {
                r = mid - 1;
            }
        }
        cout << "Case #" << t << ": " << l << endl;
    }
    return 0;
}
