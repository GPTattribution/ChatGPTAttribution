#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const int MAXQ = 1000000;

int T, N, P, R[MAXN+5], Q[MAXN+5][MAXP+5];
bool used[MAXP+5];

bool is_valid(int num_kits) {
    memset(used, false, sizeof(used));
    for (int i = 0; i < N; i++) {
        vector<int> q_vec;
        for (int j = 0; j < P; j++) {
            if (!used[j]) {
                q_vec.push_back(Q[i][j]);
            }
        }
        sort(q_vec.begin(), q_vec.end());
        int total_grams = 0;
        for (int j = 0; j < num_kits; j++) {
            int grams = q_vec.back();
            q_vec.pop_back();
            total_grams += grams;
            if (grams < R[i]*9*num_kits/10 || grams > R[i]*11*num_kits/10) {
                return false;
            }
        }
        if (total_grams < R[i]*9*num_kits || total_grams > R[i]*11*num_kits) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    int lo = 0, hi = MAXQ;
    while (lo < hi) {
        int mid = (lo + hi + 1) / 2;
        if (is_valid(mid)) {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }
    return lo;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
