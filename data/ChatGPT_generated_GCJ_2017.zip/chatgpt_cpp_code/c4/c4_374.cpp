#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << (n * p)); mask++) {
            int servings = INT_MAX;
            vector<int> cnt(p);
            for (int j = 0; j < n; j++) {
                int need = r[j];
                for (int k = 0; k < p; k++) {
                    if ((mask >> (j * p + k)) & 1) {
                        cnt[k]++;
                        need -= q[j][k];
                    }
                }
                if (need > 0) {
                    servings = 0;
                    break;
                }
            }
            if (servings > 0) {
                servings = INT_MAX;
                for (int k = 0; k < p; k++) {
                    if (cnt[k] == 0) continue;
                    servings = min(servings, q[0][k] / cnt[k]);
                }
                if (servings >= 1 && servings <= 100) {
                    ans = max(ans, servings);
                }
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
