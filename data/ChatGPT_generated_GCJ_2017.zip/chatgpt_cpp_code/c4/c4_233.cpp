#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> total(N, 0);
            int count = 0;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    count++;
                    for (int i = 0; i < N; i++) {
                        total[i] += Q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int min_amount = ceil(0.9 * R[i] * count);
                int max_amount = floor(1.1 * R[i] * count);
                if (total[i] < min_amount || total[i] > max_amount) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = max(max_kits, count);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
