#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> indices(N);
        for (int i = 0; i < N; i++) {
            indices[i] = i;
        }
        int max_kits = 0;
        do {
            bool valid = true;
            int min_servings = numeric_limits<int>::max();
            for (int k = 0; k < P; k++) {
                int servings = numeric_limits<int>::max();
                for (int i = 0; i < N; i++) {
                    int j = indices[i];
                    int q = Q[j][k];
                    int r = R[j];
                    if (q < 0.9 * r * min_servings || q > 1.1 * r * min_servings) {
                        valid = false;
                        break;
                    }
                    servings = min(servings, q / r);
                }
                if (valid) {
                    max_kits += servings;
                    min_servings = min(min_servings, servings);
                } else {
                    break;
                }
            }
        } while (next_permutation(indices.begin(), indices.end()));
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
