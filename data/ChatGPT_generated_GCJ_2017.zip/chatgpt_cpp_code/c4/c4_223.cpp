#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>
using namespace std;

const int MAX_N = 50;
const int MAX_P = 50;
const int MAX_Q = 1e6;

int T, N, P;
int R[MAX_N], Q[MAX_N][MAX_P];
vector<int> possible_serves[MAX_Q + 1];

void solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }

    for (int serve = 1; serve <= MAX_Q; serve++) {
        bool possible = false;
        for (int mask = 0; mask < (1 << N); mask++) {
            int total_weight = 0;
            for (int i = 0; i < N; i++) {
                if (mask & (1 << i)) {
                    total_weight += R[i] * serve;
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                if (!(mask & (1 << i))) {
                    bool found = false;
                    for (int j = 0; j < P; j++) {
                        if (Q[i][j] >= total_weight / serve * 0.9 &&
                            Q[i][j] <= total_weight / serve * 1.1) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        valid = false;
                        break;
                    }
                }
            }
            if (valid) {
                possible_serves[serve].push_back(mask);
                possible = true;
            }
        }
        if (!possible) {
            possible_serves[serve].push_back(-1);
        }
    }

    int ans = 0;
    for (int serve = 1; serve <= MAX_Q; serve++) {
        vector<bool> used(P, false);
        int cnt = 0;
        for (int mask : possible_serves[serve]) {
            if (mask == -1) {
                continue;
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                if (!(mask & (1 << i))) {
                    bool found = false;
                    for (int j = 0; j < P; j++) {
                        if (!used[j] && Q[i][j] >= R[i] * serve * 0.9 &&
                            Q[i][j] <= R[i] * serve * 1.1) {
                            used[j] = true;
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        valid = false;
                        break;
                    }
                }
            }
            if (valid) {
                cnt++;
            }
            for (int i = 0; i < P; i++) {
                used[i] = false;
            }
        }
        ans = max(ans, cnt);
    }

    static int case_num = 0;
    cout << "Case #" << ++case_num << ": " << ans << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> T;
    for (int t = 1; t <= T; t++) {
        solve();
    }

    return 0;
}
