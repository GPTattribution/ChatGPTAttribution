#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int tc = 1; tc <= t; tc++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> cnt(n);
            for (int j = 0; j < p; j++) {
                if ((mask >> j) & 1) {
                    for (int i = 0; i < n; i++) {
                        cnt[i] += q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < n; i++) {
                double lower = r[i] * 0.9 * cnt[i] / 100.0;
                double upper = r[i] * 1.1 * cnt[i] / 100.0;
                if (cnt[i] < lower || cnt[i] > upper) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int num_servings = *min_element(cnt.begin(), cnt.end()) / accumulate(r.begin(), r.end(), 0);
                ans = max(ans, num_servings);
            }
        }
        cout << "Case #" << tc << ": " << ans << endl;
    }
    return 0;
}
