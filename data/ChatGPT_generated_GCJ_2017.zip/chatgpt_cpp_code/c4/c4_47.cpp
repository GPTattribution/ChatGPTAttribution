#include <bits/stdc++.h>
#define ll long long
#define mod 1000000007
#define pb push_back
#define pii pair<int,int>
#define mp make_pair
#define fi first
#define se second
#define INF 0x3f3f3f3f

using namespace std;

int main(){
    int t;
    cin>>t;
    for(int cas=1;cas<=t;cas++){
        int n,p;
        cin>>n>>p;
        vector<int> r(n),amt(p,n);
        for(int i=0;i<n;i++) cin>>r[i];
        for(int i=0;i<n;i++)
            for(int j=0;j<p;j++){
                int x;
                cin>>x;
                amt[j][i]=x;
            }
        int ans=0;
        for(int msk=0;msk<(1<<n);msk++){
            int cnt=0;
            vector<int> chosen;
            for(int i=0;i<n;i++)
                if((msk>>i)&1) chosen.pb(i);
            for(int j=0;j<p;j++){
                bool ok=true;
                for(int i=0;i<chosen.size();i++){
                    int idx=chosen[i];
                    if(amt[j][idx]<r[idx] || amt[j][idx]>r[idx]*1.1){
                        ok=false;
                        break;
                    }
                }
                if(ok) cnt++;
            }
            ans=max(ans,cnt);
        }
        cout<<"Case #"<<cas<<": "<<ans<<"\n";
    }
    return 0;
}
