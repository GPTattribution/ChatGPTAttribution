#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int test_case = 1; test_case <= t; test_case++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n), low(n), high(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
            low[i] = (9 * r[i] + 10) / 10;
            high[i] = (11 * r[i] - 1) / 10;
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << (n * p)); mask++) {
            vector<int> cnt(n);
            int servings = 0;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < p; j++) {
                    int bit = i * p + j;
                    if ((mask & (1 << bit)) != 0) {
                        cnt[i]++;
                        servings += q[i][j];
                    }
                }
            }
            bool ok = true;
            for (int i = 0; i < n; i++) {
                if (cnt[i] == 0) {
                    ok = false;
                    break;
                }
                if (q[i][0] < low[i] * cnt[i] || q[i][p - 1] > high[i] * cnt[i]) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, servings / r[0]);
            }
        }
        cout << "Case #" << test_case << ": " << ans << endl;
    }
    return 0;
}
