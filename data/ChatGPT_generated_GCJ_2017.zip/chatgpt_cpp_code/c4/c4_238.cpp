#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        vector<int> indices(P);
        for (int i = 0; i < P; i++) {
            indices[i] = i;
        }
        do {
            int kits = 0;
            vector<int> remaining(N);
            for (int i = 0; i < N; i++) {
                remaining[i] = Q[i][indices[0]];
            }
            bool valid = true;
            while (valid) {
                int min_servings = 1000000;
                for (int i = 0; i < N; i++) {
                    min_servings = min(min_servings, remaining[i] / R[i]);
                }
                if (min_servings == 0) {
                    break;
                }
                valid = false;
                for (int i = 0; i < N; i++) {
                    double required = min_servings * R[i];
                    double lower_bound = required * 0.9;
                    double upper_bound = required * 1.1;
                    if (remaining[i] >= lower_bound && remaining[i] <= upper_bound) {
                        valid = true;
                        remaining[i] -= required;
                    } else {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    kits++;
                }
            }
            max_kits = max(max_kits, kits);
        } while (next_permutation(indices.begin(), indices.end()));
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
