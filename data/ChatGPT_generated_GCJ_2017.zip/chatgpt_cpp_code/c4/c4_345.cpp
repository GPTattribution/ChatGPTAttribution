#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;

int T, N, P;
int R[MAXN], Q[MAXN][MAXP];

bool check(int servings, int mask) {
    for (int i = 0; i < N; i++) {
        double total = 0;
        for (int j = 0; j < P; j++) {
            if ((mask >> j) & 1) {
                total += Q[i][j];
            }
        }
        double needed = (double) R[i] * servings;
        if (total < 0.9 * needed || total > 1.1 * needed) {
            return false;
        }
    }
    return true;
}

void solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    int ans = 0;
    for (int mask = 0; mask < (1 << P); mask++) {
        int lo = 1, hi = 1000000;
        while (lo < hi) {
            int mid = (lo + hi + 1) / 2;
            if (check(mid, mask)) {
                lo = mid;
            } else {
                hi = mid - 1;
            }
        }
        ans = max(ans, lo);
    }
    cout << ans << endl;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ": ";
        solve();
    }
    return 0;
}
