#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int ans = 0;
        vector<int> used(p);

        for (int servings = 1; ; servings++) {
            bool found = true;
            for (int j = 0; j < n; j++) {
                bool ingredient_found = false;
                for (int k = 0; k < p; k++) {
                    if (used[k]) {
                        continue;
                    }
                    double ratio = (double) q[j][k] / (double) (servings * r[j]);
                    if (ratio >= 0.9 && ratio <= 1.1) {
                        ingredient_found = true;
                        used[k] = 1;
                        break;
                    }
                }
                if (!ingredient_found) {
                    found = false;
                    break;
                }
            }
            if (found) {
                ans++;
            } else {
                break;
            }
        }

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
