#include <iostream>
#include <vector>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; ++i) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int j = 0; j < N; ++j) {
            cin >> R[j];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int j = 0; j < N; ++j) {
            for (int k = 0; k < P; ++k) {
                cin >> Q[j][k];
            }
        }
        int num_kits = 0;
        for (int servings = 1; ; ++servings) {
            bool found_kit = true;
            for (int j = 0; j < N; ++j) {
                double min_amount = servings * R[j] * 0.9;
                double max_amount = servings * R[j] * 1.1;
                double package_amount = 0;
                for (int k = 0; k < P; ++k) {
                    package_amount += Q[j][k];
                }
                double used_amount = 0;
                for (int k = 0; k < P; ++k) {
                    int amount_to_use = min(package_amount, max_amount - used_amount);
                    if (amount_to_use < min_amount) {
                        found_kit = false;
                        break;
                    }
                    used_amount += amount_to_use;
                    package_amount -= amount_to_use;
                }
                if (!found_kit) {
                    break;
                }
            }
            if (found_kit) {
                ++num_kits;
            } else {
                break;
            }
        }
        cout << "Case #" << i << ": " << num_kits << endl;
    }
    return 0;
}
