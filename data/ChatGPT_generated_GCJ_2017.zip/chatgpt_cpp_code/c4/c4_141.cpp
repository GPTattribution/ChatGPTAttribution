#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N), Q(P * N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i * P + j];
            }
        }
        vector<int> kits;
        for (int i = 0; i < P; i++) {
            for (int j = 0; j < P; j++) {
                if (i == j) {
                    continue;
                }
                int max_kits = 0;
                for (int k = 0; k < P; k++) {
                    int servings = Q[i * N] / R[0];
                    int limit_min = servings * 9 * R[0];
                    int limit_max = servings * 11 * R[0];
                    if (Q[k * N] >= limit_min && Q[k * N] <= limit_max) {
                        servings = min(servings, Q[k * N] / R[N - 1]);
                        for (int l = 1; l < N - 1; l++) {
                            int limit_min = servings * 9 * R[l];
                            int limit_max = servings * 11 * R[l];
                            if (Q[i * N + l] < limit_min || Q[i * N + l] > limit_max || Q[j * N + l] < limit_min || Q[j * N + l] > limit_max) {
                                servings = 0;
                                break;
                            }
                        }
                        max_kits = max(max_kits, servings);
                    }
                }
                for (int k = 0; k < max_kits; k++) {
                    kits.push_back((Q[i * N] + Q[j * N] + k * R[N - 1]) / (R[N - 1] * (k + 1)));
                }
            }
        }
        sort(kits.begin(), kits.end());
        kits.erase(unique(kits.begin(), kits.end()), kits.end());
        cout << "Case #" << t << ": " << kits.size() << endl;
    }
    return 0;
}
