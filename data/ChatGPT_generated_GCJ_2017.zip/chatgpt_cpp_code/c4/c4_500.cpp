#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int MAXN = 50;
const int MAXP = 50;

int T, N, P;
int R[MAXN];
int Q[MAXN][MAXP];

bool check(int S, vector<int>& cnt) {
    for (int i = 0; i < N; i++) {
        int sum = 0;
        for (int j = 0; j < P; j++) {
            sum += Q[i][j] * cnt[j];
        }
        if (sum < R[i] * S * 9 / 10 || sum > R[i] * S * 11 / 10) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    vector<int> cnt(P);
    for (int i = 0; i < P; i++) {
        cnt[i] = i;
    }
    int ans = 0;
    do {
        for (int S = 1; ; S++) {
            if (!check(S, cnt)) {
                ans = max(ans, S - 1);
                break;
            }
        }
    } while (next_permutation(cnt.begin(), cnt.end()));
    return ans;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
