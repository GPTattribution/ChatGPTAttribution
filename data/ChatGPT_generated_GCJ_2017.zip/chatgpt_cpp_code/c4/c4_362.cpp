#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            bool valid = true;
            vector<int> s(n, 0);
            int servings = INT_MAX;

            for (int j = 0; j < p; j++) {
                if ((mask >> j) & 1) {
                    for (int k = 0; k < n; k++) {
                        s[k] += q[k][j];
                    }
                }
            }

            for (int j = 0; j < n; j++) {
                int cur_servings = s[j] / r[j];
                if (cur_servings == 0 || s[j] % r[j] != 0) {
                    valid = false;
                    break;
                }
                servings = min(servings, cur_servings);
            }

            if (valid && servings >= 1 && servings <= 10) {
                ans = max(ans, servings);
            }
        }

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
