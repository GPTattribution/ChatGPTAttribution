#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> total(N);
            int count = 0;
            bool valid = true;

            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    count++;
                    for (int i = 0; i < N; i++) {
                        total[i] += Q[i][j];
                    }
                }
            }

            for (int i = 0; i < N; i++) {
                int lower = R[i] * count * 9;
                int upper = R[i] * count * 11;
                if (total[i] < lower || total[i] > upper) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                max_kits = max(max_kits, count);
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
