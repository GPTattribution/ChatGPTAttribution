#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> total(N);
            int num_packages = 0;
            for (int i = 0; i < P; i++) {
                if (mask & (1 << i)) {
                    num_packages++;
                    for (int j = 0; j < N; j++) {
                        total[j] += Q[j][i];
                    }
                }
            }

            bool valid = true;
            for (int i = 0; i < N; i++) {
                int required = R[i] * num_packages;
                int lower_bound = floor(required * 0.9);
                int upper_bound = ceil(required * 1.1);
                if (total[i] < lower_bound || total[i] > upper_bound) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                max_kits = max(max_kits, num_packages);
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
