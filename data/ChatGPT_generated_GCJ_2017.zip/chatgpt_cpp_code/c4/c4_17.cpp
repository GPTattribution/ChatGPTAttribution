#include <bits/stdc++.h>
using namespace std;

int T, N, P, R[55], Q[55][55];

bool check(int x) {
    int y[55];
    memset(y, 0, sizeof(y));
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            if (Q[i][j] >= R[i] * x / 100 && Q[i][j] <= R[i] * x / 100 * 11 / 10) {
                y[i] = Q[i][j];
                break;
            }
        }
        if (!y[i]) {
            return false;
        }
    }
    int z = INT_MAX;
    for (int i = 0; i < N; i++) {
        z = min(z, y[i] / R[i]);
    }
    return z;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> P;
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int l = 0, r = INT_MAX, ans = 0;
        while (l <= r) {
            int mid = (l + r) / 2;
            int x = check(mid);
            if (x) {
                ans = x;
                l = mid + 1;
            } else {
                r = mid - 1;
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
