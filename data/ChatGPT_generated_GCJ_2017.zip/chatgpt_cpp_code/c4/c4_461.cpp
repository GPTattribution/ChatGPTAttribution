#include <bits/stdc++.h>
using namespace std;

const int MAXN = 55;
const double eps = 1e-9;

int n, p;
int r[MAXN], q[MAXN][MAXN];

bool check(int servings, vector<int>& cnt) {
    for (int i = 0; i < n; i++) {
        double total = 0.0;
        for (int j = 0; j < p; j++) {
            total += q[i][j] * cnt[j];
        }
        if (total < servings * r[i] * 0.9 - eps || total > servings * r[i] * 1.1 + eps) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> n >> p;
    for (int i = 0; i < n; i++) {
        cin >> r[i];
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < p; j++) {
            cin >> q[i][j];
        }
    }
    vector<int> cnt(p);
    for (int i = 0; i < p; i++) {
        cnt[i] = 0;
    }
    int ans = 0;
    while (true) {
        int servings = INT_MAX;
        for (int i = 0; i < n; i++) {
            servings = min(servings, (int)(q[i][cnt[0]] / r[i]));
        }
        if (servings == 0) {
            break;
        }
        while (check(servings, cnt)) {
            ans++;
            for (int i = 0; i < p; i++) {
                cnt[i]++;
            }
        }
    }
    return ans;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int ans = solve();
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
