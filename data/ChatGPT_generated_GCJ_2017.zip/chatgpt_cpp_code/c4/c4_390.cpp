#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int case_num = 1; case_num <= t; case_num++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            bool valid = true;
            vector<int> s(n, 0);
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < n; i++) {
                        s[i] += q[i][j];
                    }
                }
            }
            for (int i = 0; i < n; i++) {
                if (s[i] < r[i] * 9 / 10 || s[i] > r[i] * 11 / 10) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int kits = INT_MAX;
                for (int i = 0; i < n; i++) {
                    kits = min(kits, s[i] / r[i]);
                }
                ans = max(ans, kits);
            }
        }

        cout << "Case #" << case_num << ": " << ans << endl;
    }

    return 0;
}
