#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
            sort(Q[i].begin(), Q[i].end());
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> sum(N);
            int count = 0;
            for (int j = 0; j < P; j++) {
                if ((mask & (1 << j)) != 0) {
                    count++;
                    for (int i = 0; i < N; i++) {
                        sum[i] += Q[i][j];
                    }
                }
            }
            int max_servings = 1e9;
            for (int i = 0; i < N; i++) {
                int servings = (sum[i] * 100 + R[i] * 5) / (R[i] * 10);
                if (servings == 0) {
                    max_servings = 0;
                    break;
                }
                max_servings = min(max_servings, servings);
            }
            if (max_servings > 0 && max_servings <= count) {
                ans = max(ans, count);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
