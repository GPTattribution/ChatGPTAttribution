#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int N = 55, M = 1005;

int T, n, p;
int r[N];
int q[N][M];

bool cmp(int x, int y) {
    return x > y;
}

bool check(int num) {
    int need[N];
    for (int i = 0; i < n; i++) {
        need[i] = num * r[i];
    }
    sort(need, need + n);
    sort(q[0], q[0] + p);
    for (int i = 0; i < p; i++) {
        int j = 0;
        for (int k = 0; k < n; k++) {
            while (j < p && q[k][j] < need[k] * 0.9) j++;
            if (j == p) return false;
            need[k] -= q[k][j];
            j++;
        }
    }
    return true;
}

int main() {
    cin >> T;
    for (int i = 1; i <= T; i++) {
        cin >> n >> p;
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
            sort(q[j], q[j] + p, cmp);
        }
        int l = 0, r = 1e9;
        while (l < r) {
            int mid = l + r + 1 >> 1;
            if (check(mid)) l = mid;
            else r = mid - 1;
        }
        cout << "Case #" << i << ": " << l << endl;
    }
    return 0;
}
