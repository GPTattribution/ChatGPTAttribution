#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int MAXN = 50;
const int MAXP = 50;

int T, N, P;
int R[MAXN], Q[MAXN][MAXP];

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }

    int ans = 0;
    for (int mask = 0; mask < (1 << P); mask++) {
        vector<int> S(N);
        int servings = 0;
        for (int j = 0; j < P; j++) {
            if (mask & (1 << j)) {
                servings++;
                for (int i = 0; i < N; i++) {
                    S[i] += Q[i][j];
                }
            }
        }
        bool valid = true;
        for (int i = 0; i < N; i++) {
            int needed = R[i] * servings;
            bool found = false;
            for (int j = 0; j < P; j++) {
                if (!(mask & (1 << j)) && Q[i][j] >= 0.9 * needed && Q[i][j] <= 1.1 * needed) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                valid = false;
                break;
            }
        }
        if (valid) {
            ans = max(ans, servings);
        }
    }

    return ans;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
