#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }
        vector<vector<int>> packages;
        for (int i = 0; i < P; ++i) {
            vector<int> package;
            for (int j = 0; j < N; ++j) {
                package.push_back(Q[j][i]);
            }
            packages.push_back(package);
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); ++mask) {
            vector<int> total(N);
            int count = 0;
            for (int i = 0; i < P; ++i) {
                if (mask & (1 << i)) {
                    for (int j = 0; j < N; ++j) {
                        total[j] += packages[i][j];
                    }
                    ++count;
                }
            }
            bool valid = true;
            for (int j = 0; j < N; ++j) {
                if (total[j] < R[j] * count * 9 / 10 || total[j] > R[j] * count * 11 / 10) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = max(max_kits, count);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
