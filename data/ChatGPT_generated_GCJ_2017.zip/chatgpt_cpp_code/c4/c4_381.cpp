#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        for (int mask = 0; mask < (1 << (N * P)); mask++) {
            vector<int> counts(N, 0);
            int servings = 0;
            bool valid = true;

            for (int i = 0; i < N * P; i++) {
                if ((mask >> i) & 1) {
                    int ingredient = i % N;
                    int package = i / N;
                    counts[ingredient] += Q[ingredient][package];
                }
            }

            for (int i = 0; i < N; i++) {
                double min_weight = R[i] * servings * 0.9;
                double max_weight = R[i] * servings * 1.1;
                if (counts[i] < min_weight || counts[i] > max_weight) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                max_kits = max(max_kits, servings);
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
