#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }

        vector<int> num_choices(p, 0);
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < n; j++) {
                if (q[j][i] >= 0.9 * r[j] * p && q[j][i] <= 1.1 * r[j] * p) {
                    num_choices[i]++;
                }
            }
        }

        int num_kits = 0;
        for (int i = 0; i < p; i++) {
            for (int j = i + 1; j < p; j++) {
                for (int k = j + 1; k < p; k++) {
                    if (num_choices[i] > 0 && num_choices[j] > 0 && num_choices[k] > 0) {
                        num_kits++;
                        num_choices[i]--;
                        num_choices[j]--;
                        num_choices[k]--;
                    }
                }
            }
        }

        cout << "Case #" << case_num << ": " << num_kits << endl;
    }
    return 0;
}
