#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << (n * p)); mask++) {
            vector<int> count(p);
            vector<int> total(n);
            int index = 0;
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < p; k++) {
                    if ((mask >> index) & 1) {
                        count[k]++;
                        total[j] += q[j][k];
                    }
                    index++;
                }
            }
            bool valid = true;
            for (int j = 0; j < n; j++) {
                int min_needed = r[j] * count[0];
                int max_needed = (r[j] * count[0] * 11) / 10;
                for (int k = 0; k < p; k++) {
                    if (total[j] >= min_needed && total[j] <= max_needed) {
                        break;
                    }
                    if (k == p - 1) {
                        valid = false;
                    } else {
                        min_needed = max_needed + 1;
                        max_needed = (r[j] * count[k+1] * 11) / 10;
                    }
                }
                if (!valid) {
                    break;
                }
            }
            if (valid) {
                int kits = count[0];
                for (int j = 1; j < p; j++) {
                    kits = min(kits, count[j]);
                }
                max_kits = max(max_kits, kits);
            }
        }
        cout << "Case #" << i << ": " << max_kits << endl;
    }
    return 0;
}
