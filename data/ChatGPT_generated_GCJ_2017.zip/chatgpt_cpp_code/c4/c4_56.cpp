#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int i = 0; i < P; i++) {
            vector<int> servings(N);
            int min_servings = 1000000000;
            int max_servings = 0;
            for (int j = 0; j < N; j++) {
                servings[j] = Q[j][i] / R[j];
                min_servings = min(min_servings, servings[j]);
                max_servings = max(max_servings, servings[j]);
            }
            for (int servings = min_servings; servings <= max_servings; servings++) {
                bool valid = true;
                for (int j = 0; j < N; j++) {
                    double min_amt = R[j] * servings * 0.9;
                    double max_amt = R[j] * servings * 1.1;
                    if (Q[j][i] < min_amt || Q[j][i] > max_amt) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    ans++;
                    break;
                }
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
