#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int x = 1; x <= t; x++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> cnt(n);
            int servings = 1;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < n; i++) {
                        cnt[i] += q[i][j];
                    }
                    servings++;
                }
            }
            bool valid = true;
            for (int i = 0; i < n; i++) {
                int required = servings * r[i];
                int lower = (required * 9 + 10) / 10;
                int upper = (required * 11) / 10;
                if (cnt[i] < lower || cnt[i] > upper) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, servings);
            }
        }
        cout << "Case #" << x << ": " << ans << endl;
    }
    return 0;
}
