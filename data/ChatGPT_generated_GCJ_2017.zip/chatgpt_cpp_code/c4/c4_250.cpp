#include<bits/stdc++.h>
using namespace std;

int main(){
    int t; cin >> t;
    for(int tt = 1; tt <= t; tt++){
        int n, p; cin >> n >> p;
        vector<int> r(n), mn(n), mx(n);
        for(int i = 0; i < n; i++) cin >> r[i];
        vector<vector<int>> q(n, vector<int>(p));
        for(int i = 0; i < n; i++){
            for(int j = 0; j < p; j++){
                cin >> q[i][j];
                mn[i] = (j == 0) ? q[i][j] : min(mn[i], q[i][j]);
                mx[i] = (j == 0) ? q[i][j] : max(mx[i], q[i][j]);
            }
        }
        int ans = 0;
        for(int mask = 0; mask < (1<<n); mask++){
            int servings = INT_MAX;
            bool valid = true;
            for(int i = 0; i < n; i++){
                if((mask>>i)&1){
                    int amt = INT_MAX;
                    for(int j = 0; j < p; j++){
                        if(q[i][j] >= r[i] * 0.9 && q[i][j] <= r[i] * 1.1){
                            amt = min(amt, q[i][j]);
                            break;
                        }
                    }
                    if(amt == INT_MAX){
                        valid = false;
                        break;
                    }
                    servings = min(servings, amt/r[i]);
                }
            }
            if(valid) ans = max(ans, servings);
        }
        cout << "Case #" << tt << ": " << ans << endl;
    }
    return 0;
}
