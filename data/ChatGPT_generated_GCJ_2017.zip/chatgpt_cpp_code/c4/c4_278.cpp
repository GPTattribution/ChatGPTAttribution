#include <iostream>
#include <vector>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n), q(p*n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
            for (int k = 0; k < p; k++) {
                cin >> q[k*n+j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << (n*p)); mask++) {
            vector<int> sum(n);
            int cnt = 0;
            for (int j = 0; j < p*n; j++) {
                if ((mask & (1 << j)) != 0) {
                    sum[j%n] += q[j];
                    cnt++;
                }
            }
            bool valid = true;
            for (int j = 0; j < n; j++) {
                int target = r[j] * cnt;
                if (sum[j] < 9 * target || sum[j] > 11 * target) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, cnt);
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
