#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << N); ++mask) {
            vector<int> total_weight(P);
            int num_kits = 0;
            for (int i = 0; i < N; ++i) {
                if (mask & (1 << i)) {
                    for (int j = 0; j < P; ++j) {
                        total_weight[j] += Q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int j = 0; j < P; ++j) {
                int min_weight = 0, max_weight = 0;
                for (int i = 0; i < N; ++i) {
                    if (mask & (1 << i)) {
                        min_weight += ceil(0.9 * R[i]);
                        max_weight += floor(1.1 * R[i]);
                    }
                }
                if (total_weight[j] < min_weight || total_weight[j] > max_weight) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int num_servings = 0;
                for (int i = 0; i < N; ++i) {
                    if (mask & (1 << i)) {
                        num_servings = total_weight[0] / R[i];
                        break;
                    }
                }
                num_kits = num_servings;
                for (int i = 0; i < N; ++i) {
                    if (mask & (1 << i)) {
                        num_kits = min(num_kits, total_weight[i] / R[i]);
                    }
                }
            }
            max_kits = max(max_kits, num_kits);
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
