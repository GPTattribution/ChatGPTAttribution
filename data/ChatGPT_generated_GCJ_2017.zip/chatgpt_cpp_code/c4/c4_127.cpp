#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPS = 1e-9;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> perm(N);
        for (int i = 0; i < N; i++) {
            perm[i] = i;
        }
        int max_kits = 0;
        do {
            for (int k = 1; k <= 100; k++) {
                vector<int> amounts(N);
                bool valid = true;
                for (int i = 0; i < N; i++) {
                    int j = perm[i];
                    int sum = 0;
                    for (int l = 0; l < P; l++) {
                        sum += Q[j][l];
                    }
                    double req = (double) k * R[j];
                    double lo = 0.9 * req;
                    double hi = 1.1 * req;
                    bool found = false;
                    for (int l = 0; l < P; l++) {
                        if (Q[j][l] >= lo && Q[j][l] <= hi) {
                            amounts[j] += Q[j][l];
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    int kits = k;
                    for (int i = 0; i < N; i++) {
                        kits = min(kits, amounts[i] / R[i]);
                    }
                    max_kits = max(max_kits, kits);
                }
            }
        } while (next_permutation(perm.begin(), perm.end()));
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
