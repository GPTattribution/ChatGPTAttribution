#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
            sort(q[j].begin(), q[j].end());
        }

        int kits = 0;
        vector<int> indices(n, 0);
        while (true) {
            bool valid = true;
            int servings = q[0][indices[0]] / r[0];
            for (int j = 1; j < n; j++) {
                int min_qty = r[j] * servings * 0.9;
                int max_qty = r[j] * servings * 1.1;
                while (indices[j] < p && q[j][indices[j]] < min_qty) {
                    indices[j]++;
                }
                if (indices[j] == p || q[j][indices[j]] > max_qty) {
                    valid = false;
                    break;
                }
            }
            if (!valid) {
                break;
            }
            kits++;
            for (int j = 0; j < n; j++) {
                indices[j]++;
            }
        }

        cout << "Case #" << i << ": " << kits << endl;
    }

    return 0;
}
