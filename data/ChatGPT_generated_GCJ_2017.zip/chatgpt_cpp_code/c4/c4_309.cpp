#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

const int MAX_N = 50;
const int MAX_P = 50;
const double PERCENTAGE_LOW = 0.9;
const double PERCENTAGE_HIGH = 1.1;

int N, P;
vector<int> R;
vector<vector<int>> Q;

bool can_make(int num_servings, const vector<int>& total) {
    for (int i = 0; i < N; i++) {
        double lower = R[i] * num_servings * PERCENTAGE_LOW;
        double upper = R[i] * num_servings * PERCENTAGE_HIGH;
        if (total[i] < lower || total[i] > upper) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    R.resize(N);
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    Q.resize(N);
    for (int i = 0; i < N; i++) {
        Q[i].resize(P);
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }

    vector<vector<int>> all_combinations;
    for (int i = 0; i < P; i++) {
        vector<int> combination(N, 0);
        combination[0] = i;
        all_combinations.push_back(combination);
    }
    while (true) {
        bool done = true;
        for (int i = 0; i < N; i++) {
            if (all_combinations.back()[i] != P-1) {
                done = false;
                break;
            }
        }
        if (done) {
            break;
        }
        vector<int> next_combination(N, 0);
        for (int i = N-1; i >= 0; i--) {
            next_combination[i] = all_combinations.back()[i];
            if (next_combination[i] == P-1) {
                next_combination[i] = 0;
            } else {
                next_combination[i]++;
                break;
            }
        }
        all_combinations.push_back(next_combination);
    }

    int max_kits = 0;
    for (const auto& combination : all_combinations) {
        vector<int> total(N, 0);
        for (int i = 0; i < N; i++) {
            total[i] = Q[i][combination[i]];
        }
        int left = 1;
        int right = P;
        while (left < right) {
            int mid = (left + right + 1) / 2;
            if (can_make(mid, total)) {
                left = mid;
            } else {
                right = mid - 1;
            }
        }
        max_kits += left;
    }
    return max_kits;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int result = solve();
        cout << "Case #" << t << ": " << result << endl;
    }
    return 0;
}
