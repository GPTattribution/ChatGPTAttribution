#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int MAX_N = 50;
const int MAX_P = 50;
const double MIN_PERCENTAGE = 0.9;
const double MAX_PERCENTAGE = 1.1;

int N, P;
int R[MAX_N];
int Q[MAX_N][MAX_P];

bool is_valid_kit(vector<int>& qtys, int servings) {
    for (int i = 0; i < N; i++) {
        double required_qty = (double)servings * R[i];
        double min_qty = required_qty * MIN_PERCENTAGE;
        double max_qty = required_qty * MAX_PERCENTAGE;
        auto it = lower_bound(qtys.begin(), qtys.end(), min_qty);
        if (it == qtys.end() || *it > max_qty) {
            return false;
        }
        qtys.erase(it);
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
        sort(Q[i], Q[i] + P);
    }
    int max_kits = 0;
    for (int servings = 1; ; servings++) {
        vector<int> qtys;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                qtys.push_back(Q[i][j]);
            }
        }
        int kits = 0;
        while (is_valid_kit(qtys, servings)) {
            kits++;
        }
        if (kits == 0) {
            break;
        }
        max_kits += kits;
    }
    return max_kits;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
