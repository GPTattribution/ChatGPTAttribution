#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        vector<int> indices(N, 0);

        while (true) {
            bool valid = true;
            int servings = INT_MAX;

            for (int i = 0; i < N; i++) {
                int amount = Q[i][indices[i]];
                double ratio = (double)amount / (double)R[i];
                if (ratio < 0.9 || ratio > 1.1) {
                    valid = false;
                    break;
                }
                servings = min(servings, (int)floor(ratio));
            }

            if (valid) {
                max_kits++;
            }

            int i = N - 1;
            while (i >= 0 && indices[i] == P - 1) {
                indices[i] = 0;
                i--;
            }
            if (i < 0) {
                break;
            }
            indices[i]++;
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
