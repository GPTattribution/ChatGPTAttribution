#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n), min_amt(p), max_amt(p);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                int amt;
                cin >> amt;
                min_amt[k] = (int) (amt * 0.9 / r[j] + 0.999999);
                max_amt[k] = (int) (amt * 1.1 / r[j]);
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> amt(n);
            int servings = 0;
            bool valid = true;
            for (int k = 0; k < p; k++) {
                if (mask & (1 << k)) {
                    for (int j = 0; j < n; j++) {
                        amt[j] += min_amt[k * n + j];
                    }
                    servings++;
                }
            }
            for (int j = 0; j < n; j++) {
                if (amt[j] < r[j] || amt[j] > max_amt[j]) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, servings);
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
