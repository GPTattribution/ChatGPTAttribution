#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int max_kits = 0;
        for (int k = 1; k <= 10000; k++) {
            vector<int> available(p, 0);
            for (int j = 0; j < n; j++) {
                for (int l = 0; l < p; l++) {
                    if (q[j][l] >= r[j] * k * 9 && q[j][l] <= r[j] * k * 11) {
                        available[l]++;
                        break;
                    }
                }
            }
            if (count(available.begin(), available.end(), 0) > 0) {
                break;
            }
            max_kits = k;
        }

        cout << "Case #" << i << ": " << max_kits << endl;
    }

    return 0;
}
