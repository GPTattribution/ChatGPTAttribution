#include<bits/stdc++.h>
using namespace std;

int main() {
    int t, n, p, i, j, k, cnt, flag;
    long long r[51], q[51][51], req, mn, mx;
    cin>>t;
    for(i=1;i<=t;i++) {
        cin>>n>>p;
        for(j=0;j<n;j++) {
            cin>>r[j];
        }
        for(j=0;j<n;j++) {
            for(k=0;k<p;k++) {
                cin>>q[j][k];
            }
        }
        cnt = 0;
        for(j=0;j<p;j++) {
            flag = 1;
            for(k=1;k<(1<<n);k++) {
                req = 0;
                mn = LLONG_MAX;
                mx = LLONG_MIN;
                for(int l=0;l<n;l++) {
                    if(k&(1<<l)) {
                        req += r[l];
                        mn = min(mn, q[l][j]*100ll/r[l]);
                        mx = max(mx, q[l][j]*100ll/r[l]);
                    }
                }
                if(req>=mn*100ll && req<=mx*110ll) {
                    flag = 0;
                    break;
                }
            }
            cnt += (flag==0);
        }
        cout<<"Case #"<<i<<": "<<cnt<<endl;
    }
    return 0;
}
