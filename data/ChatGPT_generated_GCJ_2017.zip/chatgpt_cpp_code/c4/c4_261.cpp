#include <bits/stdc++.h>
using namespace std;

#define rep(i, n) for (int i = 0; i < (n); ++i)
#define all(x) begin(x), end(x)

void solve() {
    int n, p;
    cin >> n >> p;
    vector<int> r(n);
    rep(i, n) cin >> r[i];
    vector<vector<int>> q(n, vector<int>(p));
    rep(i, n) rep(j, p) cin >> q[i][j];

    int ans = 0;
    for (int mask = 0; mask < (1 << p); ++mask) {
        vector<int> tot(n);
        int count = 0;
        rep(j, p) {
            if (mask & (1 << j)) {
                rep(i, n) tot[i] += q[i][j];
                ++count;
            }
        }
        bool ok = true;
        rep(i, n) {
            int need = r[i] * count;
            int lo = need - need / 10, hi = need + need / 10;
            if (tot[i] < lo || tot[i] > hi) {
                ok = false;
                break;
            }
        }
        if (ok) ans = max(ans, count);
    }
    cout << ans << '\n';
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;
    rep(i, T) {
        cout << "Case #" << i+1 << ": ";
        solve();
    }

    return 0;
}
