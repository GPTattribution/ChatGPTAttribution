#include <iostream>
#include <vector>

using namespace std;

bool isValid(int servings, const vector<int>& req, const vector<vector<int>>& packages) {
    int n = req.size();
    for (int i = 0; i < n; i++) {
        double low = 0.9 * servings * req[i];
        double high = 1.1 * servings * req[i];
        double total = 0.0;
        for (int j = 0; j < packages[i].size(); j++) {
            total += packages[i][j];
        }
        if (total < low || total > high) {
            return false;
        }
    }
    return true;
}

int getMaxKits(int n, int p, const vector<int>& req, const vector<vector<int>>& packages) {
    int maxKits = 0;
    for (int i = 1; i <= 10000; i++) {
        int kits = 0;
        for (int j = 0; j < p; j++) {
            if (isValid(i, req, packages[j])) {
                kits++;
            }
        }
        maxKits = max(maxKits, kits);
    }
    return maxKits;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> req(n);
        vector<vector<int>> packages(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            cin >> req[j];
            for (int k = 0; k < p; k++) {
                cin >> packages[j][k];
            }
        }
        int maxKits = getMaxKits(n, p, req, packages);
        cout << "Case #" << i << ": " << maxKits << endl;
    }
    return 0;
}
