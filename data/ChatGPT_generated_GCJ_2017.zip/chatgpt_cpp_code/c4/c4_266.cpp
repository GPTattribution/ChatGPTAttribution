#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const double MIN_RATIO = 0.9;
const double MAX_RATIO = 1.1;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int max_kits = 0;
        for (int k = 1; k <= 1000; k++) {
            vector<int> need(n);
            for (int j = 0; j < n; j++) {
                need[j] = r[j] * k;
            }
            bool valid = true;
            for (int j = 0; j < n; j++) {
                sort(q[j].begin(), q[j].end());
                double lower_bound = need[j] * MIN_RATIO;
                double upper_bound = need[j] * MAX_RATIO;
                bool found = false;
                for (int l = 0; l < p; l++) {
                    if (q[j][l] >= lower_bound && q[j][l] <= upper_bound) {
                        found = true;
                        q[j][l] = -1;
                        break;
                    }
                }
                if (!found) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = k;
            } else {
                break;
            }
        }
        cout << "Case #" << i << ": " << max_kits << endl;
    }
    return 0;
}
