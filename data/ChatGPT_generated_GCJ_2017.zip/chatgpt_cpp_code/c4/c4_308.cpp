#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<vector<int>> combos;
        vector<int> indices(N, 0);
        while (true) {
            vector<int> combo(N);
            for (int i = 0; i < N; i++) {
                combo[i] = Q[i][indices[i]];
            }
            combos.push_back(combo);
            int i = N - 1;
            while (i >= 0 && indices[i] == P - 1) {
                indices[i] = 0;
                i--;
            }
            if (i < 0) {
                break;
            }
            indices[i]++;
        }
        int max_kits = 0;
        for (vector<int> combo : combos) {
            bool valid = true;
            int min_servings = INT_MAX, max_servings = 0;
            for (int i = 0; i < N; i++) {
                int servings = ceil((double)combo[i] / R[i]);
                double lower_bound = 0.9 * servings * R[i];
                double upper_bound = 1.1 * servings * R[i];
                if (combo[i] < lower_bound || combo[i] > upper_bound) {
                    valid = false;
                    break;
                }
                min_servings = min(min_servings, servings);
                max_servings = max(max_servings, servings);
            }
            if (valid && min_servings <= max_servings) {
                max_kits = max(max_kits, max_servings - min_servings + 1);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
