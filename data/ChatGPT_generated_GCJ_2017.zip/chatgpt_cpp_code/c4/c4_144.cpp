#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n), q_sum(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
            for (int k = 0; k < p; k++) {
                int q;
                cin >> q;
                q_sum[j] += q;
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << n); mask++) {
            vector<int> q_used(n);
            int servings = 0;
            for (int j = 0; j < n; j++) {
                if (mask & (1 << j)) {
                    int q = q_sum[j];
                    int serving_q = r[j] * p;
                    if (q < serving_q * 9 / 10 || q > serving_q * 11 / 10) {
                        servings = 0;
                        break;
                    }
                    servings = min(servings == 0 ? q / serving_q : q_used[j] / serving_q, q / serving_q);
                    q_used[j] = servings * serving_q;
                }
            }
            max_kits = max(max_kits, servings);
        }
        cout << "Case #" << i << ": " << max_kits << endl;
    }
    return 0;
}
