#include <bits/stdc++.h>
using namespace std;

const int N = 55, M = 1005;

int T, n, p, r[N], q[N][M];

bool check(int x) {
    int cnt[N];
    memset(cnt, 0, sizeof cnt);
    for (int i = 0; i < n; i++) {
        int sum = 0;
        for (int j = 0; j < p; j++) {
            if (q[i][j] >= r[i] * x * 0.9 && q[i][j] <= r[i] * x * 1.1) {
                sum += q[i][j];
                cnt[j]++;
                if (sum >= r[i] * x) break;
            }
        }
        if (sum < r[i] * x) return false;
    }
    int res = 0;
    for (int i = 0; i < p; i++) {
        if (cnt[i] == n) res++;
    }
    return res;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> n >> p;
        for (int i = 0; i < n; i++) cin >> r[i];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) cin >> q[i][j];
            sort(q[i], q[i] + p);
        }
        int l = 0, r = 1e9, ans = 0;
        while (l <= r) {
            int mid = (l + r) >> 1;
            if (check(mid)) {
                l = mid + 1;
                ans = mid;
            } else {
                r = mid - 1;
            }
        }
        cout << "Case #" << t << ": " << check(ans) << endl;
    }
    return 0;
}
