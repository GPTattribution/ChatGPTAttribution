#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << (N*P)); ++mask) {
            vector<int> cnt(N, 0);
            int servings = 0;
            bool valid = true;
            for (int i = 0; i < N*P; ++i) {
                if (mask & (1 << i)) {
                    int r = i / P;
                    int q = i % P;
                    cnt[r] += Q[r][q];
                    if (cnt[r] > R[r] * (servings+1) * 1.1) {
                        valid = false;
                        break;
                    }
                    if (i % P == P-1) {
                        servings += min({cnt[0]/R[0], cnt[1]/R[1], cnt[2]/R[2]});
                        cnt[0] -= servings * R[0];
                        cnt[1] -= servings * R[1];
                        cnt[2] -= servings * R[2];
                    }
                }
            }
            if (valid) {
                ans = max(ans, servings);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
