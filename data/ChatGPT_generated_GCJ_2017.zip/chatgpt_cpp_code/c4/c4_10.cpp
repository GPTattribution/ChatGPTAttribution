#include <bits/stdc++.h>
using namespace std;

int T, N, P, r[55], q[55][55];
bool flag;

bool check(int x) {
    int sum[55];
    memset(sum, 0, sizeof(sum));
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            sum[i] += q[i][j];
            if (sum[i] >= r[i] * x * 0.9 && sum[i] <= r[i] * x * 1.1) break;
            if (j == P - 1) return false;
        }
    }
    return true;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> P;
        for (int i = 0; i < N; i++) cin >> r[i];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < P; j++) cin >> q[i][j];
        int l = 0, r = 1000000000, ans = 0;
        while (l <= r) {
            int mid = (l + r) / 2;
            if (check(mid)) {
                ans = mid;
                l = mid + 1;
            } else
                r = mid - 1;
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
