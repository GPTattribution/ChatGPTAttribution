#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> S(N);
            int cnt = 0;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    cnt++;
                    for (int i = 0; i < N; i++) {
                        S[i] += Q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                if (S[i] < R[i] * 9 * cnt || S[i] > R[i] * 11 * cnt) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, cnt);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
