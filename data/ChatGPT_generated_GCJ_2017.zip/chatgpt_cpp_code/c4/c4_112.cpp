#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const int MAXQ = 1000000;

int T, N, P;
int R[MAXN];
int Q[MAXN][MAXP];

int countKits(int servings) {
    vector<int> max_quantity(N);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            int min_qty = (servings * R[i] * 9 + 10 * Q[i][j] - 1) / (10 * Q[i][j]);
            int max_qty = (servings * R[i] * 11) / (10 * Q[i][j]);
            max_quantity[i] = max(max_quantity[i], min(max_qty, P));
        }
    }
    int res = 0;
    for (int i = 0; i < (1 << N); i++) {
        vector<int> quantity(N);
        for (int j = 0; j < N; j++) {
            if ((i >> j) & 1) {
                quantity[j] = max_quantity[j];
            }
        }
        bool valid = true;
        for (int j = 0; j < N; j++) {
            int sum = 0;
            for (int k = 0; k < P; k++) {
                if (quantity[j] <= k) break;
                sum += Q[j][k];
            }
            if (sum < servings * R[j]) {
                valid = false;
                break;
            }
        }
        if (valid) {
            int count = P;
            for (int j = 0; j < N; j++) {
                if ((i >> j) & 1) {
                    count = min(count, quantity[j]);
                }
            }
            res = max(res, count);
        }
    }
    return res;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> P;
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
            sort(Q[i], Q[i] + P);
        }
        int res = 0;
        for (int servings = 1; ; servings++) {
            int count = countKits(servings);
            if (count == 0) break;
            res += count;
        }
        cout << "Case #" << t << ": " << res << endl;
    }
    return 0;
}
