#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;

int R[MAXN];
int Q[MAXN][MAXP];

bool valid(int k, vector<int>& cnt) {
    for (int i = 0; i < cnt.size(); i++) {
        int lb = (R[i] * k * 9 + 5) / 10;
        int ub = (R[i] * k * 11 + 5) / 10;
        if (cnt[i] < lb || cnt[i] > ub) {
            return false;
        }
    }
    return true;
}

int solve(int N, int P) {
    for (int i = 0; i < N; i++) {
        cin >> R[i];
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    int ans = 0;
    vector<int> cnt(N);
    for (int k = 1; ; k++) {
        bool found = false;
        for (int mask = 0; mask < (1 << (N * P)); mask++) {
            int cur = mask;
            for (int i = 0; i < N; i++) {
                cnt[i] = 0;
                for (int j = 0; j < P; j++) {
                    if (cur & 1) {
                        cnt[i] += Q[i][j];
                    }
                    cur >>= 1;
                }
            }
            if (valid(k, cnt)) {
                found = true;
                ans++;
                break;
            }
        }
        if (!found) {
            break;
        }
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        cout << "Case #" << t << ": " << solve(N, P) << endl;
    }
    return 0;
}
