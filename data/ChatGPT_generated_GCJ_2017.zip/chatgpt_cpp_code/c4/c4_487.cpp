#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> count(N);
            bool valid = true;

            for (int j = 0; j < P; j++) {
                if ((mask >> j) & 1) {
                    for (int i = 0; i < N; i++) {
                        count[i] += Q[i][j];
                    }
                }
            }

            for (int i = 0; i < N; i++) {
                int low = (R[i] * 90 + 99) / 100;
                int high = (R[i] * 110) / 100;

                if (count[i] < low || count[i] > high) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                int kit_count = 1;
                for (int i = 0; i < N; i++) {
                    int servings = count[i] / R[i];
                    kit_count = min(kit_count, servings);
                }
                ans = max(ans, kit_count);
            }
        }

        cout << "Case #" << t << ": " << ans << "\n";
    }

    return 0;
}
