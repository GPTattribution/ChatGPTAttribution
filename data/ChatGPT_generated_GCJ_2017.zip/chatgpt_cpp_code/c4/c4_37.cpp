#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        vector<int> indices(N);
        iota(indices.begin(), indices.end(), 0);
        do {
            for (int i = 0; i < P; i++) {
                int servings = Q[indices[0]][i] / R[indices[0]];
                bool valid = true;
                for (int j = 1; j < N; j++) {
                    int amount = servings * R[indices[j]];
                    if (Q[indices[j]][i] < amount * 9 / 10 || Q[indices[j]][i] > amount * 11 / 10) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    ans++;
                    break;
                }
            }
        } while (next_permutation(indices.begin(), indices.end()));

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
