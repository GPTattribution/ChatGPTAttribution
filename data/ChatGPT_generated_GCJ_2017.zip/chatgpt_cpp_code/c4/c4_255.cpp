#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<int> kits(p, 0);
        int ans = 0;
        for (int servings = 1; ; servings++) {
            bool done = true;
            vector<int> needed(n, servings);
            for (int j = 0; j < n; j++) {
                sort(q[j].begin(), q[j].end());
                int sum = 0;
                for (int k = 0; k < p; k++) {
                    if (q[j][k] >= 0.9 * needed[j] && q[j][k] <= 1.1 * needed[j]) {
                        sum += q[j][k];
                    }
                }
                if (sum < needed[j]) {
                    done = false;
                    break;
                }
            }
            if (!done) {
                break;
            }
            ans++;
            for (int j = 0; j < n; j++) {
                sort(q[j].begin(), q[j].end());
                int sum = 0;
                for (int k = 0; k < p; k++) {
                    if (q[j][k] >= 0.9 * needed[j] && q[j][k] <= 1.1 * needed[j]) {
                        sum += q[j][k];
                        q[j][k] = -1; 
                        break;
                    }
                }
                kits[k] = sum;
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
