#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;

int T;
int N, P;
int R[MAXN], Q[MAXN][MAXP];

bool can_make_kits(int servings) {
    for (int i = 0; i < N; i++) {
        double min_grams = (double) R[i] * servings * 0.9;
        double max_grams = (double) R[i] * servings * 1.1;
        double sum_grams = 0;
        for (int j = 0; j < P; j++) {
            sum_grams += Q[i][j];
            if (Q[i][j] >= min_grams && Q[i][j] <= max_grams) {
                return true;
            }
        }
        if (sum_grams < min_grams || sum_grams > max_grams) {
            return false;
        }
    }
    return true;
}

void solve_case(int case_num) {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    int ans = 0;
    for (int servings = 1; ; servings++) {
        if (!can_make_kits(servings)) {
            break;
        }
        ans++;
    }
    cout << "Case #" << case_num << ": " << ans << endl;
}

int main() {
    cin >> T;
    for (int i = 1; i <= T; i++) {
        solve_case(i);
    }
    return 0;
}
