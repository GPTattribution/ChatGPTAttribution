#include <bits/stdc++.h>
using namespace std;
const int MAXN=1000+10;
int T,n,m,p[MAXN],q[MAXN][MAXN],cnt,ans;
bool cmp(int a,int b)
{
    return a>b;
}
bool check(int x)
{
    for (int i=0;i<n;i++)
    {
        int tot=0;
        for (int j=0;j<m;j++)
            if (q[j][i]>=x*0.9&&q[j][i]<=x*1.1)
                tot++;
        if (tot<cnt)
            return false;
    }
    return true;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    cin>>T;
    for (int i=1;i<=T;i++)
    {
        ans=0;
        cin>>n>>m;
        for (int j=0;j<n;j++)
            cin>>p[j];
        sort(p,p+n,cmp);
        for (int j=0;j<m;j++)
            for (int k=0;k<n;k++)
                cin>>q[j][k];
        int l=0,r=m/n*p[0];
        while (l<=r)
        {
            int mid=(l+r)>>1;
            cnt=mid;
            if (check(p[0]*mid))
            {
                ans=mid;
                l=mid+1;
            }
            else
                r=mid-1;
        }
        cout<<"Case #"<<i<<": "<<ans<<'\n';
    }
    return 0;
}
