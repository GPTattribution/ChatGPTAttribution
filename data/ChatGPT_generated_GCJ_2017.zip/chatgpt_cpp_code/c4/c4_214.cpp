#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

bool can_make_kits(int n, int p, vector<int>& r, vector<vector<int>>& q, int num_servings) {
    vector<int> package_weights(p);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < p; j++) {
            package_weights[j] = q[i][j];
        }
        sort(package_weights.begin(), package_weights.end());
        int total_weight = 0;
        for (int j = 0; j < num_servings; j++) {
            total_weight += package_weights[p-1-j];
        }
        int required_weight = r[i] * num_servings;
        if (total_weight < required_weight * 0.9 || total_weight > required_weight * 1.1) {
            return false;
        }
    }
    return true;
}

int find_max_num_kits(int n, int p, vector<int>& r, vector<vector<int>>& q) {
    int max_num_kits = 0;
    for (int num_servings = 1; ; num_servings++) {
        if (!can_make_kits(n, p, r, q, num_servings)) {
            break;
        }
        max_num_kits = num_servings;
    }
    return max_num_kits;
}

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int max_num_kits = find_max_num_kits(n, p, r, q);
        cout << "Case #" << case_num << ": " << max_num_kits << endl;
    }
    return 0;
}
