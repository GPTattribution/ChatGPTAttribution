#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

const double eps = 1e-9;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        vector<int> indices(N);
        for (int i = 0; i < N; i++) {
            indices[i] = i;
        }
        do {
            for (int k = 1; ; k++) {
                bool can_make = true;
                vector<double> min_ratio(N), max_ratio(N);
                for (int i = 0; i < N; i++) {
                    int j = indices[i];
                    double min_amount = k * R[j] * 0.9;
                    double max_amount = k * R[j] * 1.1;
                    double total_amount = 0;
                    for (int l = 0; l < P; l++) {
                        total_amount += Q[j][l];
                    }
                    if (total_amount < min_amount - eps || total_amount > max_amount + eps) {
                        can_make = false;
                        break;
                    }
                    min_ratio[i] = min_amount / total_amount;
                    max_ratio[i] = max_amount / total_amount;
                }
                if (!can_make) {
                    break;
                }
                double kit_min_ratio = *max_element(min_ratio.begin(), min_ratio.end());
                double kit_max_ratio = *min_element(max_ratio.begin(), max_ratio.end());
                if (kit_min_ratio - eps <= kit_max_ratio) {
                    ans++;
                } else {
                    break;
                }
            }
        } while (next_permutation(indices.begin(), indices.end()));

        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
