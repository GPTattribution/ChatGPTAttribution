#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n), count(p);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<int> indices(n);
        for (int j = 0; j < n; j++) {
            indices[j] = j;
        }
        int ans = 0;
        do {
            for (int j = 0; j < p; j++) {
                int servings = q[indices[0]][j] / r[0];
                bool ok = true;
                for (int k = 1; k < n; k++) {
                    int required = servings * r[k];
                    if (q[indices[k]][j] < 0.9 * required || q[indices[k]][j] > 1.1 * required) {
                        ok = false;
                        break;
                    }
                }
                if (ok) {
                    ans++;
                    count[j]++;
                    break;
                }
            }
        } while (next_permutation(indices.begin(), indices.end()));
        cout << "Case #" << i << ": " << ans << "\n";
    }
    return 0;
}
