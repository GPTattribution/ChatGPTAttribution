#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        for (int k = 1; ; k++) {
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int min_amount = ceil(k * R[i] * 0.9);
                int max_amount = floor(k * R[i] * 1.1);

                int min_package = 1e9, max_package = 0;
                for (int j = 0; j < P; j++) {
                    if (Q[i][j] >= min_amount && Q[i][j] <= max_amount) {
                        min_package = min(min_package, Q[i][j]);
                        max_package = max(max_package, Q[i][j]);
                    }
                }

                if (min_package == 1e9 || max_package == 0) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                max_kits++;
                for (int i = 0; i < N; i++) {
                    int min_amount = ceil(k * R[i] * 0.9);
                    int max_amount = floor(k * R[i] * 1.1);
                    for (int j = 0; j < P; j++) {
                        if (Q[i][j] >= min_amount && Q[i][j] <= max_amount) {
                            Q[i][j] = 0;
                        }
                    }
                }
            } else {
                break;
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
