#include <bits/stdc++.h>
using namespace std;

int T, N, P, R[55], Q[55][55];

bool check(int x) {
    int sum[55];
    memset(sum, 0, sizeof sum);
    for (int i = 0; i < N; i++)
        for (int j = 0; j < P; j++)
            sum[i] += Q[i][j];
    for (int i = 0; i < N; i++) {
        int lo = R[i] * x * 9 / 10, hi = R[i] * x * 11 / 10;
        if (sum[i] < lo || sum[i] > hi)
            return false;
    }
    return true;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> P;
        for (int i = 0; i < N; i++) cin >> R[i];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < P; j++)
                cin >> Q[i][j];
        int l = 0, r = 1e9, ans = 0;
        while (l <= r) {
            int mid = (l + r) >> 1;
            if (check(mid)) {
                ans = mid;
                l = mid + 1;
            } else
                r = mid - 1;
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
