#include<bits/stdc++.h>
using namespace std;

int T, n, p;
int r[55];
int q[55][55];

bool check(int x) {
    int a[55];
    memset(a, 0, sizeof(a));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < p; j++) {
            if (q[i][j] >= r[i] * x * 0.9 && q[i][j] <= r[i] * x * 1.1) {
                a[i] = q[i][j];
                break;
            }
        }
        if (!a[i]) return false;
    }
    return true;
}

int main() {
    cin >> T;
    for (int i = 1; i <= T; i++) {
        cin >> n >> p;
        for (int j = 0; j < n; j++) cin >> r[j];
        for (int j = 0; j < n; j++)
            for (int k = 0; k < p; k++)
                cin >> q[j][k];
        int l = 0, r = 100000, ans = 0;
        while (l <= r) {
            int mid = (l + r) / 2;
            if (check(mid)) {
                ans = mid;
                l = mid + 1;
            } else r = mid - 1;
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
