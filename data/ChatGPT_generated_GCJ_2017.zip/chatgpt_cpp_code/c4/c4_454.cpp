#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int case_num = 1; case_num <= T; case_num++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        for (int i = 0; i < P; i++) {
            vector<int> chosen(P);
            chosen[i] = 1;

            if (count(chosen.begin(), chosen.end(), 1) == P) {
                int servings = 1;
                for (int j = 0; j < N; j++) {
                    int min_amount = servings * R[j] * 9;
                    int max_amount = servings * R[j] * 11;

                    int total_amount = 0;
                    for (int k = 0; k < P; k++) {
                        if (chosen[k]) {
                            total_amount += Q[j][k];
                        }
                    }
                    if (total_amount < min_amount || total_amount > max_amount) {
                        break;
                    }

                    if (j == N-1) {
                        max_kits++;
                    }
                }
            }

            else {
                for (int j = i+1; j < P; j++) {
                    chosen[j] = 1;
                    max_kits = max(max_kits, [&]() {
                        int result = 0;
                        result += count(chosen.begin(), chosen.end(), 1) == P;
                        return result + main();
                    }());
                    chosen[j] = 0;
                }
            }

            chosen[i] = 0;
        }

        cout << "Case #" << case_num << ": " << max_kits << endl;
    }

    return 0;
}
