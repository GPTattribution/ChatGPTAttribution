#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const double MIN_RAT = 0.9;
const double MAX_RAT = 1.1;

int N, P, R[MAXN+5];
int Q[MAXN+5][MAXP+5];
int ans, kit[MAXN+5];

void search(int id, int used) {
    if (id == N) {
        ans = max(ans, used);
        return;
    }
    for (int i = 0; i < P; i++) {
        double rat = (double) Q[id][i] / R[id];
        if (rat >= MIN_RAT && rat <= MAX_RAT) {
            kit[id] = i;
            search(id + 1, used + 1);
            kit[id] = -1;
        }
    }
    search(id + 1, used);
}

void solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    ans = 0;
    memset(kit, -1, sizeof(kit));
    search(0, 0);
    cout << ans << endl;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ": ";
        solve();
    }
    return 0;
}
