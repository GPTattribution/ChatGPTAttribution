#include <bits/stdc++.h>
using namespace std;

int t, n, p;
int r[55], q[55][55];

bool check(int num) {
    for (int i = 0; i < n; i++) {
        int cnt = 0;
        for (int j = 0; j < p; j++) {
            if (q[j][i] >= (int)(0.9 * r[i] * num) && q[j][i] <= (int)(1.1 * r[i] * num)) cnt++;
        }
        if (cnt < num) return false;
    }
    return true;
}

int main() {
    cin >> t;
    for (int i = 1; i <= t; i++) {
        cin >> n >> p;
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        for (int j = 0; j < p; j++) {
            for (int k = 0; k < n; k++) {
                cin >> q[j][k];
            }
        }
        int l = 0, r = (int)1e6;
        while (l < r) {
            int mid = (l + r + 1) >> 1;
            if (check(mid)) l = mid;
            else r = mid - 1;
        }
        cout << "Case #" << i << ": " << l << endl;
    }
    return 0;
}
