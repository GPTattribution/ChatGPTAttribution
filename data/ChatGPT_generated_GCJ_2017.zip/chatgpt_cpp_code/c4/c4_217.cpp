#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const double MIN_PERCENT = 0.9;
const double MAX_PERCENT = 1.1;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        for (int k = 0; k < (1 << (N * P)); k++) {
            vector<int> counts(N, 0);
            int bits_set = 0;
            for (int i = 0; i < N * P; i++) {
                if ((k & (1 << i)) != 0) {
                    int j = i / P;
                    counts[j] += Q[j][i % P];
                    bits_set++;
                }
            }
            bool valid = true;
            int min_kits = INT_MAX;
            for (int i = 0; i < N; i++) {
                double lower = R[i] * bits_set * MIN_PERCENT;
                double upper = R[i] * bits_set * MAX_PERCENT;
                if (counts[i] < lower || counts[i] > upper) {
                    valid = false;
                    break;
                }
                min_kits = min(min_kits, counts[i] / R[i]);
            }
            if (valid) {
                max_kits = max(max_kits, min_kits);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
