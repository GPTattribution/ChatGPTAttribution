#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<int> max_serves(p, 0);
        for (int j = 0; j < n; j++) {
            sort(q[j].begin(), q[j].end());
            for (int k = 0; k < p; k++) {
                int max_qty = floor((double)q[j][k] / (double)r[j] * 1.1);
                int min_qty = ceil((double)q[j][k] / (double)r[j] * 0.9);
                int max_s = upper_bound(q[j].begin(), q[j].end(), max_qty * r[j]) - q[j].begin();
                int min_s = lower_bound(q[j].begin(), q[j].end(), min_qty * r[j]) - q[j].begin();
                max_serves[k] = max(max_serves[k], max_s - min_s);
            }
        }
        int ans = 0;
        for (int j = 0; j < p; j++) {
            ans += max_serves[j];
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
