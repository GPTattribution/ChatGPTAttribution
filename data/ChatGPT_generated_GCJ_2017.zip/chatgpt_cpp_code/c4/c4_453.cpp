#include <iostream>
#include <vector>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; ++i)
            cin >> R[i];
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i)
            for (int j = 0; j < P; ++j)
                cin >> Q[i][j];
        int ans = 0;
        for (int mask = 0; mask < (1 << (N * P)); ++mask) {
            vector<int> cnt(N, 0), rem(N, 0);
            for (int i = 0; i < N * P; ++i) {
                if ((mask >> i) & 1) {
                    int r = i / P, c = i % P;
                    cnt[r] += 1;
                    rem[r] += Q[r][c];
                }
            }
            bool ok = true;
            for (int i = 0; i < N; ++i) {
                if (cnt[i] != P) {
                    ok = false;
                    break;
                }
                int lo = (9 * R[i] * P + 10 * rem[i] - 1) / (10 * rem[i]);
                int hi = (11 * R[i] * P) / (10 * rem[i]);
                if (lo > hi) {
                    ok = false;
                    break;
                }
            }
            if (ok)
                ans = max(ans, __builtin_popcount(mask));
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
