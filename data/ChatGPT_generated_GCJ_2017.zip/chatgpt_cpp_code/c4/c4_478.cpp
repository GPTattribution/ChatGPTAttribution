#include <iostream>
#include <vector>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> A(N);
            int servings = 0;
            for (int j = 0; j < P; j++) {
                if ((mask >> j) & 1) {
                    servings++;
                    for (int i = 0; i < N; i++) {
                        A[i] += Q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int lower = R[i] * servings * 9 / 10;
                int upper = R[i] * servings * 11 / 10;
                if (A[i] < lower || A[i] > upper) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, servings);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
