#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;

int R[MAXN], Q[MAXN][MAXN];

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> used(P);
            for (int i = 0; i < P; i++) {
                if (mask & (1 << i)) {
                    for (int j = 0; j < N; j++) {
                        used[i] += Q[j][i];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int total = 0;
                for (int j = 0; j < P; j++) {
                    if (mask & (1 << j)) {
                        total += Q[i][j];
                    }
                }
                if (total < 9 * R[i] || total > 11 * R[i]) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int servings = INT_MAX;
                for (int i = 0; i < N; i++) {
                    servings = min(servings, used[i] / R[i]);
                }
                ans = max(ans, servings);
            }
        }
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
