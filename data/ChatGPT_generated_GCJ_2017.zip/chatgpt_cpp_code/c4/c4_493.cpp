#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int tc = 1; tc <= t; tc++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> sum(n);
            int count = 0;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    count++;
                    for (int i = 0; i < n; i++) {
                        sum[i] += q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < n; i++) {
                double lower = r[i] * count * 0.9;
                double upper = r[i] * count * 1.1;
                if (sum[i] < lower || sum[i] > upper) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, count);
            }
        }
        cout << "Case #" << tc << ": " << ans << endl;
    }
    return 0;
}
