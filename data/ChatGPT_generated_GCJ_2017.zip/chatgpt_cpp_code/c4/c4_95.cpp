#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> package_weights(N);
            int num_kits = 0;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < N; i++) {
                        package_weights[i] += Q[i][j];
                    }
                    num_kits++;
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int total_weight = package_weights[i];
                int min_weight = R[i] * num_kits * 9 / 10;
                int max_weight = R[i] * num_kits * 11 / 10;
                if (total_weight < min_weight || total_weight > max_weight) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, num_kits);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
