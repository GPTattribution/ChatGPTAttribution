#include<bits/stdc++.h>
using namespace std;

int T, n, p, t, cnt, a[55][55];
int r[55];
bool flag;

bool check(int x) {
    for(int i=0; i<n; i++) {
        flag = false;
        for(int j=0; j<p; j++) {
            if(a[i][j] >= x * 0.9 && a[i][j] <= x * 1.1) {
                flag = true;
                break;
            }
        }
        if(!flag)
            return false;
    }
    return true;
}

int main() {
    cin >> T;
    for(t=1; t<=T; t++) {
        cin >> n >> p;
        cnt = 0;
        for(int i=0; i<n; i++) {
            cin >> r[i];
        }
        for(int i=0; i<n; i++) {
            for(int j=0; j<p; j++) {
                cin >> a[i][j];
            }
        }
        int l=0, r=1e9, ans=0;
        while(l<=r) {
            int mid = (l + r) / 2;
            if(check(mid)) {
                ans = mid;
                l = mid + 1;
            }
            else
                r = mid - 1;
        }
        for(int i=0; i<n; i++) {
            for(int j=0; j<p; j++) {
                if(a[i][j] >= ans * 0.9 && a[i][j] <= ans * 1.1) {
                    cnt++;
                    break;
                }
            }
        }
        cout << "Case #" << t << ": " << cnt / n << endl;
    }
    return 0;
}
