#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; ++case_num) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; ++i) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < p; ++j) {
                cin >> q[i][j];
            }
        }
        int max_kits = 0;
        for (int i = 0; i < p; ++i) {
            vector<int> kit(n);
            for (int j = 0; j < n; ++j) {
                kit[j] = q[j][i];
            }
            bool valid_kit = true;
            for (int j = 0; j < n; ++j) {
                int min_qty = (int)(r[j] * 0.9 + 0.5);
                int max_qty = (int)(r[j] * 1.1 + 0.5);
                if (kit[j] < min_qty || kit[j] > max_qty) {
                    valid_kit = false;
                    break;
                }
            }
            if (valid_kit) {
                int kits = 1;
                vector<int> remaining(p, 1);
                remaining[i] = 0;
                for (int j = 0; j < n; ++j) {
                    int qty = kit[j];
                    bool found = false;
                    for (int k = 0; k < p; ++k) {
                        if (remaining[k] && q[j][k] >= qty * 0.9 && q[j][k] <= qty * 1.1) {
                            remaining[k] = 0;
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        valid_kit = false;
                        break;
                    }
                    ++kits;
                }
                if (valid_kit) {
                    max_kits = max(max_kits, kits);
                }
            }
        }
        cout << "Case #" << case_num << ": " << max_kits << endl;
    }
    return 0;
}
