#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;

int T, N, P;
int R[MAXN], Q[MAXN][MAXP];

bool check(int servings, const vector<int>& amounts) {
    for (int i = 0; i < N; i++) {
        double total = 0;
        for (int j = 0; j < P; j++) {
            total += amounts[i*P+j];
        }
        double required = 1.0 * servings * R[i];
        double lower = 0.9 * required;
        double upper = 1.1 * required;
        if (total < lower || total > upper) {
            return false;
        }
    }
    return true;
}

void solve(int testcase) {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    int maxServings = 0;
    for (int servings = 1; ; servings++) {
        vector<int> amounts(N*P);
        int total = 0;
        for (int i = 0; i < N; i++) {
            bool ok = false;
            for (int j = 0; j < P; j++) {
                if (1.1 * servings * R[i] >= Q[i][j] && 0.9 * servings * R[i] <= Q[i][j]) {
                    amounts[i*P+j] = Q[i][j];
                    ok = true;
                    break;
                }
            }
            if (!ok) {
                total = -1;
                break;
            }
            total += amounts[i*P];
        }
        if (total == -1) {
            break;
        }
        if (check(servings, amounts)) {
            maxServings += 1;
        } else {
            break;
        }
    }
    cout << "Case #" << testcase << ": " << maxServings << endl;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        solve(t);
    }
    return 0;
}
