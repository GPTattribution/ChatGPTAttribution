#include<bits/stdc++.h>
using namespace std;

int n, p;
int R[50];
int Q[50][50];

bool valid(int servings, int* used) {
    for(int i = 0; i < n; i++) {
        double need = (double)servings * R[i];
        double have = 0.0;
        for(int j = 0; j < p; j++) {
            if(used[j] & (1 << i)) {
                have += Q[i][j];
            }
        }
        double pct = have / need;
        if(pct < 0.9 || pct > 1.1) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> n >> p;
    for(int i = 0; i < n; i++) {
        cin >> R[i];
    }
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < p; j++) {
            cin >> Q[i][j];
        }
    }

    int ans = 0;
    for(int mask = 0; mask < (1 << p); mask++) {
        int servings = -1;
        int used[p] = {0};
        for(int j = 0; j < p; j++) {
            if(mask & (1 << j)) {
                for(int i = 0; i < n; i++) {
                    used[j] |= (1 << i);
                }
                if(servings == -1) {
                    servings = Q[0][j] / R[0];
                } else {
                    servings = min(servings, Q[0][j] / R[0]);
                }
            }
        }
        if(servings == -1) continue;
        if(valid(servings, used)) {
            int cnt = 1;
            for(int j = mask+1; j < (1 << p); j++) {
                int servings2 = -1;
                int used2[p] = {0};
                for(int k = 0; k < p; k++) {
                    if(j & (1 << k)) {
                        for(int i = 0; i < n; i++) {
                            used2[k] |= (1 << i);
                        }
                        if(servings2 == -1) {
                            servings2 = Q[0][k] / R[0];
                        } else {
                            servings2 = min(servings2, Q[0][k] / R[0]);
                        }
                    }
                }
                if(servings2 == servings && valid(servings, used2)) {
                    cnt++;
                    mask |= j;
                }
            }
            ans = max(ans, cnt);
        }
    }

    return ans;
}

int main() {
    int t;
    cin >> t;
    for(int i = 1; i <= t; i++) {
        int ans = solve();
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
