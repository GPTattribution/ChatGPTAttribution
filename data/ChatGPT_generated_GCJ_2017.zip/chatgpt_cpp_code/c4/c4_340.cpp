#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int max_kits = 0;

        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> servings(p);
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    for (int k = 0; k < n; k++) {
                        servings[k] += q[k][j];
                    }
                }
            }

            int min_servings = *min_element(servings.begin(), servings.end());
            int max_servings = *max_element(servings.begin(), servings.end());
            bool valid = true;
            for (int j = 0; j < n; j++) {
                if (servings[j] < 9 * r[j] || servings[j] > 11 * r[j]) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                int num_kits = min_servings / max_servings;
                max_kits = max(max_kits, num_kits);
            }
        }

        cout << "Case #" << i << ": " << max_kits << endl;
    }

    return 0;
}
