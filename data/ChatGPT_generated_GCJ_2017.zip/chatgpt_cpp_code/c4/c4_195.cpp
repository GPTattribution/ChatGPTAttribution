#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << (N * P)); mask++) {
            vector<int> count(N, 0);
            int prod = 1;
            for (int i = 0; i < N * P; i++) {
                if ((mask >> i) & 1) {
                    int ing = i / P;
                    int pkg = i % P;
                    count[ing]++;
                    prod *= Q[ing][pkg];
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                double needed = R[i] * prod;
                double lower = needed * 0.9;
                double upper = needed * 1.1;
                if (*max_element(count.begin(), count.end()) > P || *min_element(count.begin(), count.end()) < 1) {
                    valid = false;
                    break;
                }
                if (Q[i][0] < lower || Q[i][P-1] > upper) {
                    valid = false;
                    break;
                }
                bool found = false;
                for (int j = 0; j < P; j++) {
                    if (Q[i][j] >= lower && Q[i][j] <= upper) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, accumulate(count.begin(), count.end(), 1, multiplies<int>()));
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
