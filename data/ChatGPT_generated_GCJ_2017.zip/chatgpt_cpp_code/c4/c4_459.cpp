#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n), q(p);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> packages(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> packages[j][k];
            }
            sort(packages[j].begin(), packages[j].end());
        }
        int ans = 0;
        for (int servings = 1; ; servings++) {
            bool valid = true;
            for (int j = 0; j < n; j++) {
                int total_quantity = servings * r[j];
                int low_quantity = total_quantity * 9 / 10;
                int high_quantity = total_quantity * 11 / 10;
                auto it = lower_bound(packages[j].begin(), packages[j].end(), low_quantity);
                if (it == packages[j].end() || *it > high_quantity) {
                    valid = false;
                    break;
                }
            }
            if (!valid) {
                break;
            }
            ans++;
            for (int j = 0; j < n; j++) {
                int total_quantity = servings * r[j];
                int low_quantity = total_quantity * 9 / 10;
                int high_quantity = total_quantity * 11 / 10;
                auto it = lower_bound(packages[j].begin(), packages[j].end(), low_quantity);
                int index = it - packages[j].begin();
                q[index] -= total_quantity;
                if (q[index] < 0) {
                    valid = false;
                    break;
                }
            }
            if (!valid) {
                break;
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
