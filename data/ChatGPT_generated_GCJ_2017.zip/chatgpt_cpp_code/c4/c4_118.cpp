#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            bool valid = true;
            vector<int> total(n);
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < n; i++) {
                        total[i] += q[i][j];
                    }
                }
            }
            for (int i = 0; i < n; i++) {
                int min_amt = r[i] * total[i] * 9;
                int max_amt = r[i] * total[i] * 11;
                if (max_amt < 100 * r[i] || min_amt > 110 * r[i]) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int kits = 1;
                for (int i = 0; i < n; i++) {
                    kits = min(kits, total[i] / r[i]);
                }
                max_kits = max(max_kits, kits);
            }
        }
        cout << "Case #" << case_num << ": " << max_kits << endl;
    }
    return 0;
}
