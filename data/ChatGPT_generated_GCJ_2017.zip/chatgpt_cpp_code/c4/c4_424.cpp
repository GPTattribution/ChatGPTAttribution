#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

bool can_form_kits(const vector<int>& reqs, const vector<vector<int>>& pkgs, int servings) {
    int n = reqs.size();
    vector<pair<double, double>> range(n);
    for (int i = 0; i < n; i++) {
        double r = (double) reqs[i] * servings;
        range[i] = make_pair(r * 0.9, r * 1.1);
    }
    for (int j = 0; j < pkgs[0].size(); j++) {
        bool valid = true;
        for (int i = 0; i < n; i++) {
            double rmin = range[i].first;
            double rmax = range[i].second;
            double p = pkgs[i][j];
            if (p < rmin || p > rmax) {
                valid = false;
                break;
            }
        }
        if (valid) {
            return true;
        }
    }
    return false;
}

int max_num_kits(int n, int p, const vector<int>& reqs, const vector<vector<int>>& pkgs) {
    int lo = 0, hi = 10000000;
    while (lo < hi) {
        int mid = (lo + hi + 1) / 2;
        if (can_form_kits(reqs, pkgs, mid)) {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }
    return lo;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> reqs(n);
        vector<vector<int>> pkgs(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            cin >> reqs[j];
            for (int k = 0; k < p; k++) {
                cin >> pkgs[j][k];
            }
        }
        int ans = max_num_kits(n, p, reqs, pkgs);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
