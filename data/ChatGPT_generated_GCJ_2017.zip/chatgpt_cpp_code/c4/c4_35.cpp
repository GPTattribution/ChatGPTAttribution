#include<bits/stdc++.h>
using namespace std;

const int MAXN = 55;
const int MAXP = 55;

int n, p, R[MAXN], Q[MAXN][MAXP];
bool valid[MAXN];

bool check(int x) {
    memset(valid, false, sizeof(valid));
    valid[0] = true;
    for (int i = 1; i <= p; i++) {
        for (int j = 0; j < n; j++) {
            if (Q[j][i] < R[j] * x * 9 / 10 || Q[j][i] > R[j] * x * 11 / 10) {
                break;
            }
            if (j == n - 1) {
                valid[i] = true;
            }
        }
    }
    vector<int> dp(p + 1, -1);
    dp[0] = 0;
    for (int i = 1; i <= p; i++) {
        for (int j = i; j >= 1; j--) {
            if (valid[i - j + 1]) {
                dp[i] = max(dp[i], dp[j - 1] + 1);
            }
        }
    }
    return dp[p] >= 0;
}

void solve(int case_num) {
    cin >> n >> p;
    for (int i = 0; i < n; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < n; i++) {
        for (int j = 1; j <= p; j++) {
            cin >> Q[i][j];
        }
    }
    int l = 0, r = 1e9, ans = 0;
    while (l <= r) {
        int mid = (l + r) / 2;
        if (check(mid)) {
            ans = mid;
            l = mid + 1;
        } else {
            r = mid - 1;
        }
    }
    cout << "Case #" << case_num << ": " << ans << endl;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        solve(i);
    }
    return 0;
}
