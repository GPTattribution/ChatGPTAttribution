#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int cas = 1; cas <= t; cas++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> sum(n);
            int count = 0;
            for (int i = 0; i < p; i++) {
                if (mask & (1 << i)) {
                    count++;
                    for (int j = 0; j < n; j++) {
                        sum[j] += q[j][i];
                    }
                }
            }
            bool ok = true;
            for (int j = 0; j < n; j++) {
                if (sum[j] < r[j] * count * 9 / 10 ||
                    sum[j] > r[j] * count * 11 / 10) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, count);
            }
        }
        cout << "Case #" << cas << ": " << ans << "\n";
    }
    return 0;
}
