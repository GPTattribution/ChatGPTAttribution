#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAX_N = 50;
const int MAX_P = 50;
const int MAX_Q = 1000000;

int R[MAX_N];
int Q[MAX_N][MAX_P];
int memo[(1 << MAX_N)];

int count_bits(int x) {
    int count = 0;
    while (x > 0) {
        if (x & 1) {
            count++;
        }
        x >>= 1;
    }
    return count;
}

bool is_valid(int n, int m, int mask, int servings) {
    for (int i = 0; i < n; i++) {
        int total_qty = 0;
        for (int j = 0; j < m; j++) {
            if ((mask & (1 << j)) == 0) {
                continue;
            }
            total_qty += Q[i][j];
        }
        int required_qty = servings * R[i];
        if (total_qty < 0.9 * required_qty || total_qty > 1.1 * required_qty) {
            return false;
        }
    }
    return true;
}

int solve(int n, int m, int mask) {
    int& res = memo[mask];
    if (res != -1) {
        return res;
    }
    res = 0;
    for (int servings = 1; ; servings++) {
        if (!is_valid(n, m, mask, servings)) {
            break;
        }
        int next_mask = 0;
        for (int j = 0; j < m; j++) {
            if ((mask & (1 << j)) && count_bits(next_mask) < servings) {
                next_mask |= (1 << j);
            }
        }
        res = max(res, 1 + solve(n, m, next_mask));
    }
    return res;
}

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n, m;
        cin >> n >> m;
        for (int i = 0; i < n; i++) {
            cin >> R[i];
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                cin >> Q[i][j];
            }
        }
        memset(memo, -1, sizeof(memo));
        cout << "Case #" << case_num << ": " << solve(n, m, (1 << m) - 1) << endl;
    }
    return 0;
}
