#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int caseNum = 1; caseNum <= T; caseNum++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int maxKits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            bool valid = true;
            vector<int> total(N);
            int numKits = 0;
            for (int j = 0; j < P; j++) {
                if ((mask & (1 << j)) == 0) {
                    continue;
                }
                numKits++;
                for (int i = 0; i < N; i++) {
                    total[i] += Q[i][j];
                }
            }
            for (int i = 0; i < N; i++) {
                double lowerBound = R[i] * numKits * 0.9;
                double upperBound = R[i] * numKits * 1.1;
                if (total[i] < lowerBound || total[i] > upperBound) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                maxKits = max(maxKits, numKits);
            }
        }

        cout << "Case #" << caseNum << ": " << maxKits << endl;
    }

    return 0;
}
