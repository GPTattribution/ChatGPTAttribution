#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<vector<int>> packages;
        for (int i = 0; i < P; i++) {
            vector<int> current(N);
            bool valid = true;
            for (int j = 0; j < N; j++) {
                int lower_bound = (R[j] * 9 + 10) * i;
                int upper_bound = (R[j] * 11 - 1) * i;
                for (int k = 0; k < P; k++) {
                    if (Q[j][k] >= lower_bound && Q[j][k] <= upper_bound) {
                        current[j] = Q[j][k];
                        break;
                    }
                    if (k == P - 1) {
                        valid = false;
                    }
                }
            }
            if (valid) {
                packages.push_back(current);
            }
        }

        int max_kits = 0;
        vector<bool> used(packages.size());
        for (int i = 0; i < packages.size(); i++) {
            if (used[i]) {
                continue;
            }
            int servings = 1;
            used[i] = true;
            for (int j = i + 1; j < packages.size(); j++) {
                if (used[j]) {
                    continue;
                }
                bool match = true;
                for (int k = 0; k < N; k++) {
                    int lower_bound = (R[k] * 9 + 10) * servings;
                    int upper_bound = (R[k] * 11 - 1) * servings;
                    if (packages[i][k] + packages[j][k] < lower_bound || packages[i][k] + packages[j][k] > upper_bound) {
                        match = false;
                        break;
                    }
                }
                if (match) {
                    servings++;
                    used[j] = true;
                }
            }
            max_kits += 1;
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
