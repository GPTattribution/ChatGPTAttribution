#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool check(vector<int>& quantities, vector<int>& recipe, int servings) {
    int n = quantities.size();
    for (int i = 0; i < n; i++) {
        int min_qty = recipe[i] * servings * 9 / 10;
        int max_qty = recipe[i] * servings * 11 / 10;
        if (quantities[i] < min_qty || quantities[i] > max_qty) {
            return false;
        }
    }
    return true;
}

void solve(int case_num) {
    int n, p;
    cin >> n >> p;

    vector<int> recipe(n);
    for (int i = 0; i < n; i++) {
        cin >> recipe[i];
    }

    vector<vector<int>> quantities(n, vector<int>(p));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < p; j++) {
            cin >> quantities[i][j];
        }
    }

    int max_kits = 0;
    for (int mask = 0; mask < (1 << (n * p)); mask++) {
        vector<int> chosen(n * p);
        int k = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                if ((mask >> k) & 1) {
                    chosen[k] = quantities[i][j];
                }
                k++;
            }
        }
        int kits = 0;
        for (int servings = 1; ; servings++) {
            if (check(chosen, recipe, servings)) {
                kits++;
            } else {
                break;
            }
        }
        max_kits = max(max_kits, kits);
    }

    cout << "Case #" << case_num << ": " << max_kits << endl;
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        solve(i);
    }

    return 0;
}
