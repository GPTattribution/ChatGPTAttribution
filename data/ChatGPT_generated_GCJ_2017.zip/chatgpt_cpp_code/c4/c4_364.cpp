#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> amount(n);
            int numServings = 0;
            for (int j = 0; j < p; j++) {
                if ((mask >> j) & 1) {
                    for (int k = 0; k < n; k++) {
                        amount[k] += q[k][j];
                    }
                    numServings++;
                }
            }
            bool valid = true;
            for (int j = 0; j < n; j++) {
                double needed = (double) r[j] * numServings;
                double lowerBound = 0.9 * needed;
                double upperBound = 1.1 * needed;
                if (amount[j] < lowerBound || amount[j] > upperBound) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, numServings);
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
