#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> qty(n);
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < n; i++) {
                        qty[i] += q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < n; i++) {
                int low = (r[i] * 90 + 99) / 100;
                int high = (r[i] * 110) / 100;
                if (qty[i] < low || qty[i] > high) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int servings = INT_MAX;
                for (int i = 0; i < n; i++) {
                    servings = min(servings, qty[i] / r[i]);
                }
                ans = max(ans, servings);
            }
        }
        cout << "Case #" << case_num << ": " << ans << endl;
    }
    return 0;
}
