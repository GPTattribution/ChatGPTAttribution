#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        for (int i = 0; i < P; i++) {
            vector<int> indices(N, 0);
            indices[0] = i;
            int servings = Q[0][i] / R[0];

            while (true) {
                bool valid = true;
                for (int j = 1; j < N; j++) {
                    int sum = 0;
                    for (int k = 0; k < N; k++) {
                        sum += Q[k][indices[k]] * servings / R[k];
                    }
                    int target = Q[j][indices[j]] * servings / R[j];
                    if (sum < target * 9 || sum > target * 11) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    max_kits = max(max_kits, servings);
                }

                int j = N - 1;
                while (j >= 0 && indices[j] == P - 1) {
                    indices[j] = 0;
                    servings = Q[0][indices[0]] / R[0];
                    j--;
                }
                if (j < 0) {
                    break;
                }
                indices[j]++;
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
