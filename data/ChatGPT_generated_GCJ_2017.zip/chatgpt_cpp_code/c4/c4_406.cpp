#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int x = 1; x <= t; x++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n), min_qty(n), max_qty(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
            min_qty[i] = (int) ceil(r[i] * 0.9);
            max_qty[i] = (int) floor(r[i] * 1.1);
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << n); mask++) {
            int qty = INT_MAX;
            bool valid = true;
            for (int i = 0; i < n; i++) {
                if ((mask >> i) & 1) {
                    int curr_qty = 0;
                    for (int j = 0; j < p; j++) {
                        if (q[i][j] >= min_qty[i] && q[i][j] <= max_qty[i]) {
                            curr_qty += q[i][j];
                        }
                    }
                    if (curr_qty == 0) {
                        valid = false;
                        break;
                    }
                    qty = min(qty, curr_qty);
                }
            }
            if (valid) {
                int num_kits = 0;
                for (int i = 0; i < n; i++) {
                    if ((mask >> i) & 1) {
                        num_kits = max(num_kits, (int) ceil(qty / (double) r[i]));
                    }
                }
                ans = max(ans, num_kits);
            }
        }
        cout << "Case #" << x << ": " << ans << "\n";
    }
    return 0;
}
