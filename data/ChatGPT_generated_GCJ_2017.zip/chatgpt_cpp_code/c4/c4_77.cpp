#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
            sort(q[j].begin(), q[j].end());
        }
        int ans = 0;
        for (int j = 0; j < p; j++) {
            vector<int> cur(n);
            cur[0] = q[0][j];
            int maxs = cur[0] / r[0] * 11 / 10;
            int mins = cur[0] / r[0] * 9 / 10;
            bool valid = true;
            for (int k = 1; k < n; k++) {
                int lb = lower_bound(q[k].begin(), q[k].end(), mins) - q[k].begin();
                int ub = upper_bound(q[k].begin(), q[k].end(), maxs) - q[k].begin();
                if (lb == p || q[k][lb] > maxs || ub == 0 || q[k][ub - 1] < mins) {
                    valid = false;
                    break;
                }
                cur[k] = q[k][lb];
                maxs = max(maxs, cur[k] / r[k] * 11 / 10);
                mins = max(mins, cur[k] / r[k] * 9 / 10);
            }
            if (valid) {
                ans++;
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
