#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        for (int i = 0; i < P; i++) {
            vector<int> servings(P);
            servings[0] = Q[0][i] / R[0];
            for (int j = 1; j < N; j++) {
                servings[j] = Q[j][i] / R[j];
            }
            int max_servings = *min_element(servings.begin(), servings.end());

            bool valid = true;
            for (int j = 0; j < N; j++) {
                int min_amount = max(90 * R[j] * max_servings, 100 * Q[j][i]);
                int max_amount = min(110 * R[j] * max_servings, 100 * Q[j][i]);
                if (min_amount > Q[j][i] || max_amount < Q[j][i]) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                max_kits = max(max_kits, max_servings);
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
