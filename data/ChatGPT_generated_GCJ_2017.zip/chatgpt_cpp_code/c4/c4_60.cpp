#include<bits/stdc++.h>
using namespace std;

#define ll long long

const int MAXN = 50 + 5;

int T, n, p;
int r[MAXN], q[MAXN][MAXN];

bool check(int x) {
    int cnt = 0;
    for (int i = 1; i <= p; i++) {
        ll l = 0, h = 1e18, mid;
        bool flag = true;
        for (int j = 1; j <= n; j++) {
            if (q[j][i] < x * r[j] * 9 / 10) {
                flag = false;
                break;
            }
            if (q[j][i] > x * r[j] * 11 / 10) {
                h = 0;
                break;
            }
            h = min(h, (ll)q[j][i] / r[j] / x);
        }
        if (flag && l <= h) {
            cnt += (int)h - l + 1;
        }
    }
    return cnt >= x;
}

void solve() {
    cin >> n >> p;
    for (int i = 1; i <= n; i++) {
        cin >> r[i];
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= p; j++) {
            cin >> q[i][j];
        }
    }
    int l = 0, h = 1e9, ans = 0;
    while (l <= h) {
        int mid = (l + h) >> 1;
        if (check(mid)) {
            l = mid + 1;
            ans = mid;
        } else {
            h = mid - 1;
        }
    }
    cout << ans << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    cin >> T;
    for (int i = 1; i <= T; i++) {
        cout << "Case #" << i << ": ";
        solve();
    }
    return 0;
}
