#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin>>t;
    for(int i=1;i<=t;i++)
    {
        int n,p;
        cin>>n>>p;
        vector<int> r(n);
        for(int j=0;j<n;j++)
            cin>>r[j];
        vector<vector<int>> q(n,vector<int>(p));
        for(int j=0;j<n;j++)
            for(int k=0;k<p;k++)
                cin>>q[j][k];

        vector<int> kits;
        for(int mask=0;mask<(1<<p);mask++)
        {
            vector<int> cnt(n);
            int total=0;
            for(int j=0;j<p;j++)
            {
                if((mask>>j)&1)
                {
                    for(int k=0;k<n;k++)
                        cnt[k]+=q[k][j];
                    total++;
                }
            }
            bool valid=true;
            for(int j=0;j<n;j++)
            {
                int min_needed=(total*r[j]*9+5)/10;
                int max_needed=(total*r[j]*11)/10;
                if(cnt[j]<min_needed || cnt[j]>max_needed)
                {
                    valid=false;
                    break;
                }
            }
            if(valid)
                kits.push_back(total);
        }
        sort(kits.begin(),kits.end(),greater<int>());
        int ans=0;
        vector<bool> used(p,false);
        for(int k: kits)
        {
            int cnt=0;
            for(int j=0;j<p;j++)
            {
                if(!used[j])
                {
                    cnt++;
                    if(cnt==k)
                    {
                        ans++;
                        cnt=0;
                        used[j]=true;
                    }
                }
            }
        }
        cout<<"Case #"<<i<<": "<<ans<<"\n";
    }
    return 0;
}
