#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

const double EPSILON = 1e-6;

bool is_valid_kit(const vector<int>& required, const vector<int>& packages, const int servings) {
    for (int i = 0; i < required.size(); i++) {
        double min_amount = required[i] * servings * 0.9;
        double max_amount = required[i] * servings * 1.1;
        if (packages[i] < min_amount || packages[i] > max_amount) {
            return false;
        }
    }
    return true;
}

int max_kits(const vector<int>& required, const vector<vector<int>>& packages) {
    int num_ingredients = required.size();
    int num_packages = packages[0].size();

    int ans = 0;
    for (int servings = 1; ; servings++) {
        bool can_make_kit = true;
        for (int i = 0; i < num_ingredients; i++) {
            bool has_package = false;
            for (int j = 0; j < num_packages; j++) {
                if (packages[i][j] >= required[i] * servings * 0.9 && packages[i][j] <= required[i] * servings * 1.1) {
                    has_package = true;
                    break;
                }
            }
            if (!has_package) {
                can_make_kit = false;
                break;
            }
        }
        if (can_make_kit) {
            ans++;
        } else {
            break;
        }
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> required(N);
        vector<vector<int>> packages(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            cin >> required[i];
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> packages[i][j];
            }
        }
        int ans = max_kits(required, packages);
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
