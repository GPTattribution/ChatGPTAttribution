#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    for(int caseNum = 1; caseNum <= t; caseNum++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        vector<vector<int>> q(n, vector<int>(p));
        for(int i = 0; i < n; i++) {
            cin >> r[i];
            for(int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for(int mask = 0; mask < (1 << p); mask++) {
            bool valid = true;
            vector<int> counts(n, 0);
            for(int j = 0; j < p; j++) {
                if(mask & (1 << j)) {
                    for(int i = 0; i < n; i++) {
                        counts[i] += q[i][j];
                    }
                }
            }
            for(int i = 0; i < n; i++) {
                double needed = r[i] * (double)counts[i] * 0.9;
                double limit = r[i] * (double)counts[i] * 1.1;
                if(counts[i] < ceil(needed) || counts[i] > floor(limit)) {
                    valid = false;
                    break;
                }
            }
            if(valid) {
                int kitCount = 0;
                for(int i = 0; i < n; i++) {
                    kitCount = max(kitCount, counts[i] / r[i]);
                }
                ans = max(ans, kitCount);
            }
        }
        cout << "Case #" << caseNum << ": " << ans << endl;
    }
    return 0;
}
