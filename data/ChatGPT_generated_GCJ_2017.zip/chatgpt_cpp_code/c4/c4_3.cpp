#include<bits/stdc++.h>
using namespace std;
int t,n,p,r[55],q[55][55],k[55],ans;
bool cmp(int a,int b){
    return a>b;
}
bool check(int x){
    int sum[55];
    memset(sum,0,sizeof sum);
    for(int i=0;i<n;i++){
        for(int j=0;j<p;j++){
            if(q[i][j]<r[i]*x*0.9||q[i][j]>r[i]*x*1.1)continue;
            sum[i]+=q[i][j];
            if(sum[i]>=r[i]*x)break;
        }
        if(sum[i]<r[i]*x)return false;
    }
    return true;
}
int main(){
    cin>>t;
    for(int c=1;c<=t;c++){
        cin>>n>>p;
        for(int i=0;i<n;i++)cin>>r[i];
        for(int i=0;i<n;i++)
            for(int j=0;j<p;j++)
                cin>>q[i][j];
        for(int i=0;i<n;i++)sort(q[i],q[i]+p,cmp);
        int l=0,r=1e9;
        while(l<r){
            int mid=(l+r+1)/2;
            if(check(mid))l=mid;
            else r=mid-1;
        }
        cout<<"Case #"<<c<<": "<<l<<endl;
    }
    return 0;
}
