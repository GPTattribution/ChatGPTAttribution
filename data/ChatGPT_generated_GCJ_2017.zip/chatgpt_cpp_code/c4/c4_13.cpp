#include <bits/stdc++.h>
using namespace std;

const int N = 55, M = 1005;

int t, n, p, ans;
int a[N], b[M];

bool cmp(int a, int b) {
    return a > b;
}

bool check(int x, int y) {
    return y * 100 >= a[x] * 90 && y * 100 <= a[x] * 110;
}

void dfs(int x, int k) {
    if (x == n) {
        ans = max(ans, k);
        return;
    }
    for (int i = 0; i < p; i++) {
        if (check(x, b[i + k * p])) {
            dfs(x + 1, k - 1);
        }
    }
}

int main() {
    cin >> t;
    for (int i = 1; i <= t; i++) {
        cin >> n >> p;
        for (int j = 0; j < n; j++) {
            cin >> a[j];
        }
        for (int j = 0; j < n * p; j++) {
            cin >> b[j];
        }
        sort(b, b + n * p, cmp);
        ans = 0;
        dfs(0, p);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
