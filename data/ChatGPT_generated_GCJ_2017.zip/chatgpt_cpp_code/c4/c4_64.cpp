#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> total(N);
            int count = 0;
            for (int i = 0; i < P; i++) {
                if ((mask >> i) & 1) {
                    count++;
                    for (int j = 0; j < N; j++) {
                        total[j] += Q[j][i];
                    }
                }
            }
            bool ok = true;
            for (int i = 0; i < N; i++) {
                int lower = ceil(0.9 * R[i] * count);
                int upper = floor(1.1 * R[i] * count);
                if (total[i] < lower || total[i] > upper) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, count);
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
