#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;

        for (int i = 0; i < P; i++) {
            for (int j = 0; j < P; j++) {
                bool valid = true;
                int servings = 1;
                for (int k = 0; k < N; k++) {
                    int amount = Q[k][i] + Q[k][j];
                    double lower_bound = R[k] * servings * 0.9;
                    double upper_bound = R[k] * servings * 1.1;
                    if (amount < lower_bound || amount > upper_bound) {
                        valid = false;
                        break;
                    }
                    servings *= ceil((double)amount / R[k] / servings);
                }
                if (valid) {
                    max_kits = max(max_kits, servings);
                }
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
