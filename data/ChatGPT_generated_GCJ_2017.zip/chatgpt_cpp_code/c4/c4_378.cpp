#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int max_kits = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            bool valid = true;
            vector<int> total(n, 0);
            for (int k = 0; k < p; k++) {
                if (mask & (1 << k)) {
                    for (int j = 0; j < n; j++) {
                        total[j] += q[j][k];
                    }
                }
            }
            for (int j = 0; j < n; j++) {
                int need = r[j] * p;
                if (total[j] < 9 * need / 10 || total[j] > 11 * need / 10) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int kits = 0;
                while (true) {
                    bool can_make_kit = true;
                    for (int j = 0; j < n; j++) {
                        int need = r[j];
                        if (total[j] < 9 * need / 10 || total[j] > 11 * need / 10) {
                            can_make_kit = false;
                            break;
                        }
                    }
                    if (can_make_kit) {
                        kits++;
                        for (int j = 0; j < n; j++) {
                            total[j] -= r[j];
                        }
                    } else {
                        break;
                    }
                }
                max_kits = max(max_kits, kits);
            }
        }

        cout << "Case #" << i << ": " << max_kits << endl;
    }

    return 0;
}
