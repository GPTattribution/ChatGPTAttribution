#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;

int T, N, P;
int R[MAXN];
int Q[MAXN][MAXP];

bool can_make(int servings, const vector<int>& counts) {
    for (int i = 0; i < N; i++) {
        int total = 0;
        for (int j = 0; j < P; j++) {
            total += min(Q[i][j], (servings * R[i] + 10 - 1) / 10);
        }
        if (total < counts[i]) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }

    int ans = 0;
    for (int servings = 1; ; servings++) {
        vector<int> counts(N);
        for (int i = 0; i < N; i++) {
            int total = 0;
            for (int j = 0; j < P; j++) {
                total += min(Q[i][j], (servings * R[i] + 10 - 1) / 10);
            }
            counts[i] = total;
        }
        if (counts[0] == 0) {
            break;
        }
        while (can_make(servings, counts)) {
            ans++;
            for (int i = 0; i < N; i++) {
                counts[i] -= min(Q[i][counts[i] / servings], (servings * R[i] + 10 - 1) / 10);
            }
        }
    }
    return ans;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << "\n";
    }

    return 0;
}
