#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; ++case_num) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; ++i) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < p; ++j) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        vector<int> indices(p);
        for (int i = 0; i < p; ++i) {
            indices[i] = i;
        }
        do {
            int servings = 1e9;
            bool valid = true;
            for (int i = 0; i < n; ++i) {
                int total = 0;
                for (int j = 0; j < p; ++j) {
                    if (j >= n) break; 
                    total += q[j][indices[j]];
                }
                servings = min(servings, total / r[i]);
                int required_min = r[i] * servings * 9 / 10;
                int required_max = r[i] * servings * 11 / 10;
                for (int j = 0; j < p; ++j) {
                    if (j >= n) break;
                    int qty = q[j][indices[j]];
                    if (qty < required_min || qty > required_max) {
                        valid = false;
                        break;
                    }
                }
                if (!valid) {
                    break;
                }
            }
            if (valid) {
                ans = max(ans, servings);
            }
        } while (next_permutation(indices.begin(), indices.end()));
        cout << "Case #" << case_num << ": " << ans << endl;
    }
    return 0;
}
