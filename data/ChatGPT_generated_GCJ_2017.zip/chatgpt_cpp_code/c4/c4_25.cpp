#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;
const double EPS = 1e-9;

int R[MAXN], Q[MAXN][MAXN];

bool check(int n, int* R, int* cnt, int* q) {
    for (int i = 0; i < n; ++i) {
        double l = R[i] * cnt[i] * 0.9;
        double r = R[i] * cnt[i] * 1.1;
        if (q[i] < l + EPS || q[i] > r - EPS) {
            return false;
        }
    }
    return true;
}

int solve(int n, int* R, int p, int Q[MAXN][MAXN]) {
    int cnt[MAXN];
    memset(cnt, 0, sizeof(cnt));
    for (int i = 0; i < p; ++i) {
        int mx = 0;
        for (int j = 0; j < n; ++j) {
            mx = max(mx, Q[j][i]);
        }
        for (int j = 0; j < n; ++j) {
            if (Q[j][i] * 1.1 >= R[j] * mx * 0.9) {
                cnt[j]++;
            }
        }
    }
    int res = 0;
    while (check(n, R, cnt, Q[res])) {
        res++;
    }
    return res;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int n, p;
        cin >> n >> p;
        for (int i = 0; i < n; ++i) {
            cin >> R[i];
        }
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < p; ++j) {
                cin >> Q[i][j];
            }
        }
        int ans = solve(n, R, p, Q);
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
