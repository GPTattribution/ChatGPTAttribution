#include <bits/stdc++.h>
using namespace std;

int T, N, P;
int R[55], Q[55][55];

bool can_make(int num_kits) {
    vector<int> amount(N);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            amount[i] += Q[i][j];
        }
        amount[i] /= P;
        amount[i] *= num_kits;
    }
    for (int i = 0; i < N; i++) {
        int low = (R[i] * 9 * num_kits + 5 * 10 * P) / (10 * 10 * P);
        int high = (R[i] * 11 * num_kits + 5 * 10 * P) / (10 * 10 * P);
        if (amount[i] < low || amount[i] > high) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    int ans = 0;
    for (int num_kits = 1; ; num_kits++) {
        if (!can_make(num_kits)) {
            break;
        }
        ans = num_kits;
    }
    return ans;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
