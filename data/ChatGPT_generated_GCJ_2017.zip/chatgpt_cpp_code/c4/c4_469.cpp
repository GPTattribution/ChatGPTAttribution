#include <iostream>
#include <vector>

using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const int MAXQ = 1000000;

int N, P;
int R[MAXN];
int Q[MAXN][MAXP];
vector<int> valid_kits;

bool is_valid(int kit_size) {
    for (int i = 0; i < N; i++) {
        int total_ingredient = 0;
        for (int j = 0; j < P; j++) {
            total_ingredient += min(Q[i][j], (kit_size * R[i] * 110 + 99) / 100);
        }
        if (total_ingredient < kit_size * R[i] * 9 || total_ingredient > kit_size * R[i] * 11) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    valid_kits.clear();
    for (int i = 1; i <= MAXQ; i++) {
        if (is_valid(i)) {
            valid_kits.push_back(i);
        }
    }
    return valid_kits.size();
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
