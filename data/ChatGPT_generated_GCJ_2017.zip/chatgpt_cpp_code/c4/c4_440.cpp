#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int test_case = 1; test_case <= t; ++test_case) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; ++i) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < p; ++j) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); ++mask) {
            vector<int> cnt(n, 0);
            int servings = INT_MAX;
            for (int i = 0; i < p; ++i) {
                if (mask & (1 << i)) {
                    for (int j = 0; j < n; ++j) {
                        cnt[j] += q[j][i];
                    }
                    servings = min(servings, q[0][i] / r[0]);
                }
            }
            bool ok = true;
            for (int i = 0; i < n; ++i) {
                if (cnt[i] < r[i] * servings * 9 / 10 || cnt[i] > r[i] * servings * 11 / 10) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, __builtin_popcount(mask));
            }
        }
        cout << "Case #" << test_case << ": " << ans << endl;
    }
    return 0;
}
