#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int ans = 0;
        for (int m = 1; m <= 1000000; m++) {
            vector<int> possible;
            for (int j = 0; j < n; j++) {
                int lo = r[j] * m * 9 / 10;
                int hi = r[j] * m * 11 / 10;
                bool found = false;
                for (int k = 0; k < p; k++) {
                    if (q[j][k] >= lo && q[j][k] <= hi) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    possible.clear();
                    break;
                } else {
                    possible.push_back(j);
                }
            }
            if (!possible.empty()) {
                int num_kits = 0;
                vector<int> used(p, 0);
                for (int j : possible) {
                    for (int k = 0; k < p; k++) {
                        if (q[j][k] >= r[j] * m * 9 / 10 && q[j][k] <= r[j] * m * 11 / 10) {
                            used[k] = 1;
                        }
                    }
                }
                for (int k = 0; k < p; k++) {
                    num_kits += used[k];
                }
                ans = max(ans, num_kits);
            }
        }

        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
