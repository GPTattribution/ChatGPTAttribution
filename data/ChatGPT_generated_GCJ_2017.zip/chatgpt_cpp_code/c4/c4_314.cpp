#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

const double EPS = 1e-9;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << (n * p)); mask++) {
            vector<int> chosen(p);
            int cnt = 0;
            for (int j = 0; j < n; j++) {
                double total = 0;
                for (int k = 0; k < p; k++) {
                    if (mask & (1 << (j * p + k))) {
                        chosen[k] = 1;
                        total += q[j][k];
                    }
                }
                if (total < r[j] - EPS || total > r[j] * 1.1 + EPS) {
                    goto nxt;
                }
                cnt++;
            }
            for (int k = 0; k < p; k++) {
                if (!chosen[k]) {
                    continue;
                }
                for (int j = 0; j < n; j++) {
                    if (mask & (1 << (j * p + k))) {
                        chosen[k] = 0;
                        break;
                    }
                }
            }
            ans = max(ans, cnt);
            nxt:;
        }

        cout << "Case #" << i << ": " << ans << "\n";
    }

    return 0;
}
