#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<vector<int>> combinations;
        for (int i = 0; i < P; i++) {
            vector<int> current(N);
            bool isValid = true;
            for (int j = 0; j < N; j++) {
                int amount = Q[j][i];
                if (amount < 0.9 * R[j] || amount > 1.1 * R[j]) {
                    isValid = false;
                    break;
                }
                current[j] = amount / R[j];
            }
            if (isValid) {
                combinations.push_back(current);
            }
        }

        int ans = 0;
        for (vector<int> c : combinations) {
            ans = max(ans, *min_element(c.begin(), c.end()));
        }

        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
