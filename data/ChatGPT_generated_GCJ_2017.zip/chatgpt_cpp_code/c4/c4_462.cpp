#include <iostream>
#include <vector>

using namespace std;

bool possible(int n, int p, const vector<int>& r, const vector<vector<int>>& q, int servings) {
    for (int i = 0; i < n; i++) {
        int required = r[i] * servings;
        int min_amount = 1000000000;
        int max_amount = 0;
        for (int j = 0; j < p; j++) {
            min_amount = min(min_amount, q[i][j]);
            max_amount = max(max_amount, q[i][j]);
        }
        if (min_amount * 1.1 < required || max_amount * 0.9 > required) {
            return false;
        }
    }
    return true;
}

int solve(int n, int p, const vector<int>& r, const vector<vector<int>>& q) {
    int lo = 0, hi = 100000000;
    while (lo < hi) {
        int mid = (lo + hi + 1) / 2;
        if (possible(n, p, r, q, mid)) {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }
    return lo;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = solve(n, p, r, q);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
