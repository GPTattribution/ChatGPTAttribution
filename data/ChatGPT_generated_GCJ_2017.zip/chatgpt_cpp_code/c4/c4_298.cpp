#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        for (int i = 0; i < P; i++) {
            vector<int> servings;
            for (int j = 0; j < N; j++) {
                servings.push_back((Q[j][i] * 100) / R[j]);
            }
            int max_servings = *min_element(servings.begin(), servings.end());
            int count = 0;
            for (int j = 0; j < N; j++) {
                int lower_bound = (max_servings * R[j] * 90) / 100;
                int upper_bound = (max_servings * R[j] * 110) / 100;
                if (Q[j][i] >= lower_bound && Q[j][i] <= upper_bound) {
                    count++;
                }
            }
            if (count == N) {
                ans++;
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
