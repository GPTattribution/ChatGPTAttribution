#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            cin >> r[j];
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << (n * p)); mask++) {
            int servings = INT_MAX;
            vector<int> amt(n, 0);
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < p; k++) {
                    int bit = (mask >> (j * p + k)) & 1;
                    if (bit) {
                        amt[j] += q[j][k];
                    }
                }
                servings = min(servings, amt[j] / r[j]);
            }
            if (servings == INT_MAX) {
                continue;
            }
            int count = 0;
            for (int j = 0; j < n; j++) {
                int lower = servings * r[j] * 9 / 10;
                int upper = servings * r[j] * 11 / 10;
                if (amt[j] < lower || amt[j] > upper) {
                    count = 0;
                    break;
                }
                count++;
            }
            ans = max(ans, count);
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
