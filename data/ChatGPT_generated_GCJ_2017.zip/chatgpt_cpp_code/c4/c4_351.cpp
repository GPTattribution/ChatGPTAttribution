#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        for (int k = 0; k < (1 << P); k++) {
            bool valid = true;
            vector<int> total(N);
            int num_kits = 0;
            for (int i = 0; i < P; i++) {
                if ((k >> i) & 1) {
                    num_kits++;
                    for (int j = 0; j < N; j++) {
                        total[j] += Q[j][i];
                    }
                }
            }
            for (int j = 0; j < N; j++) {
                int min_total = (num_kits * R[j] * 9 + 10) / 10;
                int max_total = (num_kits * R[j] * 11) / 10;
                if (total[j] < min_total || total[j] > max_total) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = max(max_kits, num_kits);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
