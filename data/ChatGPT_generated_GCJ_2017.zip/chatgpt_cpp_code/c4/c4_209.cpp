#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << (N * P)); mask++) {
            vector<int> used(P);
            int servings = 1;
            for (int i = 0; i < N; i++) {
                int total = 0, best = 0;
                for (int j = 0; j < P; j++) {
                    int idx = i * P + j;
                    if (mask & (1 << idx)) {
                        used[j]++;
                        total += Q[i][j];
                        best = max(best, Q[i][j]);
                    }
                }
                if (total < R[i] * servings || total > R[i] * servings * 11 / 10) {
                    break;
                }
                servings = total / R[i];
                if (total % R[i] > R[i] * 1.1 - best) {
                    servings++;
                }
            }
            if (mask == (1 << (N * P)) - 1) {
                ans = max(ans, *min_element(used.begin(), used.end()));
            } else {
                ans = max(ans, *min_element(used.begin(), used.end()) - 1);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
