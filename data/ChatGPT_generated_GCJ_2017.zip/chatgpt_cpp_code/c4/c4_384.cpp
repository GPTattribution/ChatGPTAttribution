#include <bits/stdc++.h>
using namespace std;

const int MAXN = 55;
const int MAXP = 55;

int R[MAXN], Q[MAXN][MAXP];
int N, P;

bool isValidKit(const vector<int>& kit) {
    for (int i = 0; i < N; i++) {
        int sum = 0;
        for (int j = 0; j < P; j++) {
            sum += Q[i][j] * kit[j];
        }
        int required = R[i] * kit.back();
        if (sum < 9 * required || sum > 11 * required) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }

    int ans = 0;
    for (int mask = 0; mask < (1 << P); mask++) {
        vector<int> kit(P, 1);
        for (int j = 0; j < P; j++) {
            if (mask & (1 << j)) {
                kit[j]++;
            }
        }
        if (isValidKit(kit)) {
            ans = max(ans, kit.back());
        }
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
