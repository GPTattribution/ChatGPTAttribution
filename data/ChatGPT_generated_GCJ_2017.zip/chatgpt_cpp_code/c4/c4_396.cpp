#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        vector<int> indices(N);
        for (int i = 0; i < P; i++) {
            for (int j = 0; j < N; j++) {
                indices[j] = i;
            }
            for (int servings = 1; ; servings++) {
                vector<int> total(N);
                for (int j = 0; j < N; j++) {
                    total[j] = servings * R[j];
                }
                bool ok = true;
                for (int j = 0; j < N; j++) {
                    int sum = 0;
                    for (int k = 0; k < N; k++) {
                        sum += Q[k][indices[k]];
                    }
                    if (sum < 9 * total[j] || sum > 11 * total[j]) {
                        ok = false;
                        break;
                    }
                }
                if (ok) {
                    ans++;
                } else {
                    break;
                }
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
