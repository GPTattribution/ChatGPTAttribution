#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<vector<int>> package_combinations;
        for (int i = 0; i < P; i++) {
            vector<int> combination(N, i);
            package_combinations.push_back(combination);
        }
        for (int k = 2; k <= N; k++) {
            vector<vector<int>> new_combinations;
            for (vector<int>& c1 : package_combinations) {
                for (int i = c1.back() + 1; i < P; i++) {
                    vector<int> c2(c1);
                    c2.push_back(i);
                    new_combinations.push_back(c2);
                }
            }
            package_combinations.insert(package_combinations.end(), new_combinations.begin(), new_combinations.end());
        }
        int max_kits = 0;
        for (vector<int>& combination : package_combinations) {
            vector<int> amounts(N);
            for (int i = 0; i < N; i++) {
                amounts[i] = Q[i][combination[i]];
            }
            sort(amounts.begin(), amounts.end());
            int servings = 0;
            for (int i = 0; i < N; i++) {
                servings = max(servings, (int)(amounts[i] * 1.1 / R[i]));
            }
            int kits = 0;
            for (int i = 0; i < N; i++) {
                int required = servings * R[i];
                int available = amounts[i];
                if (available >= required * 0.9 && available <= required * 1.1) {
                    kits++;
                } else {
                    break;
                }
            }
            max_kits = max(max_kits, kits);
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
