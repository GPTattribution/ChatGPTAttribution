#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n), mn(n), mx(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
            mn[j] = r[j] * 9 / 10;
            mx[j] = r[j] * 11 / 10;
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << (n * p)); mask++) {
            vector<int> cnt(p);
            for (int j = 0; j < n; j++) {
                int sum = 0;
                for (int k = 0; k < p; k++) {
                    if (mask & (1 << (j * p + k))) {
                        cnt[k]++;
                        sum += q[j][k];
                    }
                }
                if (sum < mn[j] || sum > mx[j]) {
                    goto skip;
                }
            }
            int res = p;
            for (int k = 0; k < p; k++) {
                if (cnt[k] == 0) {
                    res--;
                }
            }
            ans = max(ans, res);
            skip:;
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
