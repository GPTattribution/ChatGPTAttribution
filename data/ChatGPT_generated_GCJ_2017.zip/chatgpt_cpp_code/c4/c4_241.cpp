#include <iostream>
#include <vector>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;

        for (int i = 0; i < P; i++) {
            for (int j = 0; j < P; j++) {
                if (i == j) continue; 

                int servings = 1;
                bool valid = true;

                for (int k = 0; k < N; k++) {
                    int total = Q[k][i] + Q[k][j];
                    if (total < R[k]*servings*0.9 || total > R[k]*servings*1.1) {
                        valid = false;
                        break;
                    }
                }

                while (valid) {
                    max_kits++;
                    servings++;

                    valid = false;
                    for (int k = 0; k < N; k++) {
                        int total = Q[k][i] + Q[k][j];
                        if (total >= R[k]*servings*0.9 && total <= R[k]*servings*1.1) {
                            valid = true;
                        } else {
                            valid = false;
                            break;
                        }
                    }
                }
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
