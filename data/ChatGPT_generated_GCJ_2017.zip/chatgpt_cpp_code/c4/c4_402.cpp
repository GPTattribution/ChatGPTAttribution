#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const double EPS = 1e-9;

int N, P;
int R[MAXN];
int Q[MAXN][MAXP];
vector<int> possibleServings;

bool canMakeKits(int servings) {
    vector<double> amount(P);
    for (int i = 0; i < N; i++) {
        double needed = servings * R[i];
        bool found = false;
        for (int j = 0; j < P; j++) {
            if (Q[i][j] >= needed * 0.9 && Q[i][j] <= needed * 1.1) {
                amount[j] = needed;
                found = true;
                break;
            }
        }
        if (!found) {
            return false;
        }
    }
    return true;
}

int countValidKits() {
    int maxKits = 0;
    for (int servings : possibleServings) {
        if (canMakeKits(servings)) {
            maxKits = servings;
        } else {
            break;
        }
    }
    return maxKits;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> P;
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        possibleServings.clear();
        for (int i = 1; i <= 1000; i++) {
            if (canMakeKits(i)) {
                possibleServings.push_back(i);
            }
        }
        cout << "Case #" << t << ": " << countValidKits() << endl;
    }
    return 0;
}
