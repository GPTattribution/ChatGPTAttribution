#include <bits/stdc++.h>
using namespace std;

int t, n, p, r[55], q[55][55];

int check(int x) {
    int cnt[55] = {0};
    for (int i = 0; i < n; i++) {
        int minv = INT_MAX, maxv = 0;
        for (int j = 0; j < p; j++) {
            int num = q[i][j];
            int low = (int)(0.9 * r[i] * x), high = (int)(1.1 * r[i] * x);
            if (num >= low && num <= high) {
                cnt[j] = 1;
                minv = min(minv, num);
                maxv = max(maxv, num);
            }
        }
        int k = 0;
        for (int j = 0; j < p; j++) {
            if (cnt[j]) {
                if (q[i][j] != minv && q[i][j] != maxv) cnt[j] = 0;
                else k++;
            }
        }
        if (k < x) return 0;
        int s = 0;
        for (int j = 0; j < p; j++) {
            if (cnt[j]) {
                if (q[i][j] == minv) {
                    if (s + (x - k) <= p - k) s += x - k;
                    else return 0;
                } else {
                    if (s + 1 <= p - k) s++;
                    else return 0;
                }
            }
        }
    }
    return 1;
}

int main() {
    cin >> t;
    for (int c = 1; c <= t; c++) {
        cin >> n >> p;
        for (int i = 0; i < n; i++) cin >> r[i];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) cin >> q[i][j];
            sort(q[i], q[i] + p);
        }
        int l = 0, r = p / n, ans = 0;
        while (l <= r) {
            int mid = (l + r) / 2;
            if (check(mid)) {
                ans = mid;
                l = mid + 1;
            } else r = mid - 1;
        }
        cout << "Case #" << c << ": " << ans << endl;
    }
    return 0;
}
