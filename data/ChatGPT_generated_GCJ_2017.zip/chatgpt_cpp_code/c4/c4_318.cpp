#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50, MAXP = 50;
const double EPS = 1e-7;

int N, P;
int R[MAXN], Q[MAXN][MAXP];

bool is_valid(int num_servings, const vector<int>& selected) {
    vector<double> qty(N, 0.0);
    for (int i = 0; i < N; i++) {
        for (int j : selected) {
            qty[i] += Q[i][j];
        }
        qty[i] /= num_servings;
        if (qty[i] < R[i] * 0.9 || qty[i] > R[i] * 1.1) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    vector<int> selected(P);
    for (int i = 0; i < P; i++) {
        selected[i] = i;
    }
    int ans = 0;
    do {
        for (int num_servings = 1; ; num_servings++) {
            if (!is_valid(num_servings, selected)) {
                ans = max(ans, num_servings - 1);
                break;
            }
        }
    } while (next_permutation(selected.begin(), selected.end()));
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
