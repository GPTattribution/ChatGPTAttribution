#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
            sort(q[j].begin(), q[j].end());
        }

        int ans = 0;
        for (int k = 0; k < p; k++) {
            bool ok = true;
            vector<int> amounts(n);
            for (int j = 0; j < n; j++) {
                int low = (int) ceil(r[j] * 0.9 / q[j][k]);
                int high = (int) floor(r[j] * 1.1 / q[j][k]);
                if (low > high) {
                    ok = false;
                    break;
                }
                amounts[j] = q[j][k];
            }
            if (!ok) {
                continue;
            }
            int kits = 1;
            while (true) {
                bool stop = true;
                for (int j = 0; j < n; j++) {
                    if (amounts[j] < r[j] * kits * 0.9 || amounts[j] > r[j] * kits * 1.1) {
                        stop = false;
                        break;
                    }
                }
                if (stop) {
                    ans++;
                    break;
                }
                for (int j = 0; j < n; j++) {
                    if (amounts[j] < r[j] * kits * 0.9) {
                        amounts[j] = q[j][upper_bound(q[j].begin(), q[j].end(), amounts[j]) - q[j].begin()];
                    } else if (amounts[j] > r[j] * kits * 1.1) {
                        amounts[j] = q[j][lower_bound(q[j].begin(), q[j].end(), amounts[j]) - q[j].begin() - 1];
                    }
                }
                kits++;
            }
        }

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
