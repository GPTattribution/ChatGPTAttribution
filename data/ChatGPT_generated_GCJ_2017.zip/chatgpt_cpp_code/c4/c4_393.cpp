#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        vector<int> max_serves(p, 0);
        int max_kits = 0;

        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> serves(p, 0);
            int num_kits = 0;
            bool valid = true;

            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    num_kits++;

                    for (int k = 0; k < n; k++) {
                        serves[k] += q[k][j];
                    }
                }
            }

            for (int j = 0; j < n; j++) {
                int min_amt = r[j] * num_kits * 9;
                int max_amt = r[j] * num_kits * 11;

                int total_amt = 0;
                for (int k = 0; k < p; k++) {
                    if (mask & (1 << k)) {
                        total_amt += q[j][k];
                    }
                }

                if (total_amt < min_amt || total_amt > max_amt) {
                    valid = false;
                    break;
                }
            }

            if (valid && num_kits > max_kits) {
                max_kits = num_kits;
                max_serves = serves;
            }
        }

        cout << "Case #" << i << ": " << max_kits << endl;
    }

    return 0;
}
