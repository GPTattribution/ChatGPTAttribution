#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> cnt(n);
            int servings = INT_MAX;
            for (int j = 0; j < p; j++) {
                if ((mask >> j) & 1) {
                    for (int k = 0; k < n; k++) {
                        cnt[k] += q[k][j];
                    }
                    servings = min(servings, q[0][j] / r[0]);
                }
            }
            bool valid = true;
            for (int j = 0; j < n; j++) {
                int lower = r[j] * servings * 9;
                int upper = r[j] * servings * 11;
                if (cnt[j] < lower || cnt[j] > upper) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, __builtin_popcount(mask));
            }
        }

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
