#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int x = 1; x <= t; x++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            bool valid = true;
            vector<int> s(n);
            for (int i = 0; i < p; i++) {
                if (mask & (1 << i)) {
                    for (int j = 0; j < n; j++) {
                        s[j] += q[j][i];
                    }
                }
            }
            for (int i = 0; i < n; i++) {
                if (s[i] < r[i] * 9 / 10 || s[i] > r[i] * 11 / 10) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int num = INT_MAX;
                for (int i = 0; i < n; i++) {
                    num = min(num, s[i] / r[i]);
                }
                ans = max(ans, num);
            }
        }
        cout << "Case #" << x << ": " << ans << endl;
    }
    return 0;
}
