#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const int INF = 1e9;

int T, N, P;
int R[MAXN], Q[MAXN][MAXP];
int dp[1 << MAXN];

int main() {
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        cin >> N >> P;
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 1; mask < (1 << N); ++mask) {
            int cnt = 0;
            vector<pair<int, int>> v;
            for (int i = 0; i < N; ++i) {
                if (mask & (1 << i)) {
                    v.push_back(make_pair(R[i], i));
                    ++cnt;
                }
            }
            sort(v.begin(), v.end());
            int ptr = 0;
            for (int i = 0; i < P; ++i) {
                int cur = 0;
                for (auto p : v) {
                    cur = max(cur, (Q[p.second][i] * 110 + p.first * 100 - 1) / (p.first * 100));
                    if (Q[p.second][i] * 100 < cur * p.first * 90 || Q[p.second][i] * 100 > cur * p.first * 110) {
                        cur = -1;
                        break;
                    }
                }
                if (cur != -1) {
                    dp[i] = max(dp[i], dp[ptr] + cur);
                }
                while (ptr < i && dp[ptr] == dp[i]) {
                    ++ptr;
                }
            }
            ans = max(ans, dp[P - 1]);
            for (int i = 0; i < P; ++i) {
                dp[i] = 0;
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
