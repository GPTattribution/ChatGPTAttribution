#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const int INF = 1e9;

int N, P;
int R[MAXN];
int Q[MAXN][MAXP];
int dp[100001];

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> P;
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        memset(dp, -1, sizeof(dp));
        dp[0] = 0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                for (int k = 100000; k >= 0; k--) {
                    if (dp[k] >= 0) {
                        int servings = (k + R[i] - 1) / R[i];
                        int min_qty = servings * R[i] * 9 / 10;
                        int max_qty = servings * R[i] * 11 / 10;
                        if (Q[i][j] >= min_qty && Q[i][j] <= max_qty) {
                            dp[k + servings] = max(dp[k + servings], dp[k] + 1);
                        }
                    }
                }
            }
        }
        int ans = 0;
        for (int i = 0; i <= 100000; i++) {
            ans = max(ans, dp[i]);
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
