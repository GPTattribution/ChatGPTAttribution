#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        vector<int> used(P);
        for (int i = 0; i < N; i++) {
            sort(Q[i].begin(), Q[i].end()); 
            int idx = 0;
            while (idx < P && Q[i][idx] < R[i] * 0.9) {
                idx++;
            }
            while (idx < P && Q[i][idx] < R[i] * 1.1) {
                if (!used[idx]) {
                    used[idx] = 1;
                    ans++;
                    break;
                }
                idx++;
            }
            if (idx == P && ans < i+1) {
                break;
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
