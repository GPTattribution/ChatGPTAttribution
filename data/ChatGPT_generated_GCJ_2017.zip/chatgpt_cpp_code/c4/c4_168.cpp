#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
            sort(Q[i].begin(), Q[i].end());
        }

        int ans = 0;
        for (int i = 0; i < P; i++) {
            vector<int> servings(N);
            int max_servings = 0;
            for (int j = 0; j < N; j++) {
                int lower = (R[j] * 90 + 99) / 100;
                int upper = (R[j] * 110) / 100;
                auto it = lower_bound(Q[j].begin(), Q[j].end(), lower);
                if (it == Q[j].end() || *it > upper) {
                    max_servings = 0;
                    break;
                }
                int idx = it - Q[j].begin();
                servings[j] = *it;
                max_servings = max(max_servings, (Q[j][idx] * 10) / R[j]);
            }
            ans += max_servings;
            for (int j = 0; j < N; j++) {
                auto it = lower_bound(Q[j].begin(), Q[j].end(), servings[j]);
                Q[j].erase(it);
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
