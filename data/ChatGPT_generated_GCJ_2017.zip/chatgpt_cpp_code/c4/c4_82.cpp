#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<int> max_servings(1 << n, 0);
        for (int mask = 0; mask < (1 << n); mask++) {
            int servings = 1e9;
            for (int j = 0; j < n; j++) {
                if (mask & (1 << j)) {
                    servings = min(servings, q[j][0] / r[j]);
                }
            }
            for (int j = 0; j < n; j++) {
                if (mask & (1 << j)) {
                    int remaining = servings * r[j];
                    for (int k = 0; k < p; k++) {
                        if (q[j][k] >= remaining * 9 / 10 && q[j][k] <= remaining * 11 / 10) {
                            remaining = 0;
                            break;
                        }
                    }
                    if (remaining > 0) {
                        servings = ceil((double) q[j][0] / r[j]);
                    }
                }
            }
            max_servings[mask] = servings;
        }
        vector<int> dp(1 << n, 0);
        for (int mask = 1; mask < (1 << n); mask++) {
            for (int submask = mask; submask > 0; submask = (submask - 1) & mask) {
                int other_mask = mask ^ submask;
                if (max_servings[submask] > 0 && dp[other_mask] + max_servings[submask] > dp[mask]) {
                    dp[mask] = dp[other_mask] + max_servings[submask];
                }
            }
        }
        cout << "Case #" << i << ": " << dp[(1 << n) - 1] << endl;
    }
    return 0;
}
