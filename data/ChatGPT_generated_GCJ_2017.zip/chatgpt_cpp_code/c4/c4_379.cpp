#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

bool is_valid_kit(const vector<int>& required, const vector<int>& packages)
{
    int n = required.size();
    for (int i = 0; i < n; i++) {
        int min_qty = 9 * required[i] / 10;
        int max_qty = 11 * required[i] / 10;
        auto it = lower_bound(packages.begin(), packages.end(), min_qty);
        if (it == packages.end() || *it > max_qty) {
            return false;
        }
        packages.erase(it);
    }
    return true;
}

void solve_case(int case_num)
{
    int n, p;
    cin >> n >> p;

    vector<int> required(n);
    for (int i = 0; i < n; i++) {
        cin >> required[i];
    }

    vector<vector<int>> packages(n, vector<int>(p));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < p; j++) {
            cin >> packages[i][j];
        }
        sort(packages[i].begin(), packages[i].end());
    }

    int max_kits = 0;
    vector<int> indices(n);
    iota(indices.begin(), indices.end(), 0);
    do {
        vector<int> current_packages(p);
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < n; j++) {
                current_packages[j] = packages[indices[j]][i];
            }
            if (is_valid_kit(required, current_packages)) {
                max_kits++;
            } else {
                break;
            }
        }
    } while (next_permutation(indices.begin(), indices.end()));

    cout << "Case #" << case_num << ": " << max_kits << endl;
}

int main()
{
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        solve_case(i);
    }
    return 0;
}
