#include <iostream>
#include <vector>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << N); ++mask) {
            bool valid = true;
            int servings = 1;
            for (int i = 0; i < N; ++i) {
                if (mask & (1 << i)) {
                    int min_qty = (R[i] * servings * 9 + 5) / 10;
                    int max_qty = (R[i] * servings * 11) / 10;
                    bool found = false;
                    for (int j = 0; j < P; ++j) {
                        if (Q[i][j] >= min_qty && Q[i][j] <= max_qty) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        valid = false;
                        break;
                    }
                } else {
                    servings *= 2;
                }
            }
            if (valid) {
                ans = max(ans, servings);
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
