#include <iostream>
#include <vector>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int case_num = 1; case_num <= t; ++case_num) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int i = 0; i < n; ++i) {
            cin >> r[i];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < p; ++j) {
                cin >> q[i][j];
            }
        }

        for (int i = 0; i < n; ++i) {
            sort(q[i].begin(), q[i].end());
        }

        int max_kits = 0;
        for (int i = 0; i < p; ++i) {
            int servings = q[0][i] / r[0];
            if (servings == 0) {
                continue;
            }
            int min_qty = servings * r[0] * 9 / 10;
            int max_qty = servings * r[0] * 11 / 10;
            bool valid = true;
            for (int j = 1; j < n && valid; ++j) {
                auto it = lower_bound(q[j].begin(), q[j].end(), min_qty);
                while (it != q[j].end() && *it <= max_qty) {
                    if (*it >= servings * r[j] * 9 / 10 && *it <= servings * r[j] * 11 / 10) {
                        ++it;
                        continue;
                    }
                    ++it;
                }
                if (it == q[j].begin() || !valid) {
                    valid = false;
                }
            }
            if (valid) {
                ++max_kits;
                for (int j = 0; j < n; ++j) {
                    auto it = lower_bound(q[j].begin(), q[j].end(), servings * r[j]);
                    q[j].erase(it);
                }
                --i;
            }
        }

        cout << "Case #" << case_num << ": " << max_kits << endl;
    }

    return 0;
}
