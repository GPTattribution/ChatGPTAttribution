#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<vector<int>> package_combinations(P, vector<int>(N));
        vector<int> indices(P);
        iota(indices.begin(), indices.end(), 0);

        int max_kits = 0;

        do {
            int servings = 1;
            for (int i = 0; i < N; i++) {
                int total_amount = 0;
                for (int j = 0; j < P; j++) {
                    if (j >= servings) break;
                    total_amount += Q[i][indices[j]];
                }
                if (total_amount < 0.9 * servings * R[i] || total_amount > 1.1 * servings * R[i]) {
                    break;
                }
                servings *= (total_amount / R[i]);
            }
            max_kits = max(max_kits, servings);
        } while (next_permutation(indices.begin(), indices.end()));

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
