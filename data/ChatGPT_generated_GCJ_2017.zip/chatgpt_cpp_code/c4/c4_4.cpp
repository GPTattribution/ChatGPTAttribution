#include <bits/stdc++.h>
using namespace std;

int T, n, p;
int r[55];
int q[55][55];

bool check(int k) {
    for (int i = 0; i < n; i++) {
        int minn = r[i] * k * 0.9, maxx = r[i] * k * 1.1;
        bool flag = false;
        for (int j = 0; j < p; j++) {
            if (q[i][j] >= minn && q[i][j] <= maxx) {
                flag = true;
                break;
            }
        }
        if (!flag) return false;
    }
    return true;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> n >> p;
        for (int i = 0; i < n; i++) cin >> r[i];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < p; j++) cin >> q[i][j];
        int l = 0, r = 1000000000, ans = 0;
        while (l <= r) {
            int mid = (l + r) / 2;
            if (check(mid)) {
                ans = mid;
                l = mid + 1;
            } else {
                r = mid - 1;
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
