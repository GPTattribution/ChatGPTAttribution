#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAXN = 55;
const int MAXP = 55;

int N, P;
int R[MAXN], Q[MAXN][MAXP];
int dp[100005];

int solve() {
    int total = 1;
    for (int i = 0; i < N; i++) {
        total *= P;
    }
    int ans = 0;
    for (int mask = 0; mask < total; mask++) {
        vector<int> indices;
        int temp = mask;
        for (int i = 0; i < N; i++) {
            indices.push_back(temp % P);
            temp /= P;
        }
        bool valid = true;
        int servings = 1e9;
        for (int i = 0; i < N; i++) {
            int weight = Q[i][indices[i]];
            if (weight < R[i] * 9 / 10 || weight > R[i] * 11 / 10) {
                valid = false;
                break;
            }
            servings = min(servings, weight / R[i]);
        }
        if (valid) {
            ans = max(ans, dp[servings] + 1);
        }
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> P;
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        memset(dp, 0, sizeof(dp));
        dp[0] = 1;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                int weight;
                cin >> weight;
                for (int k = 100000; k >= 0; k--) {
                    if (k + weight / R[i] <= 100000) {
                        dp[k + weight / R[i]] |= dp[k];
                    }
                }
            }
        }
        cout << "Case #" << t << ": " << solve() << endl;
    }
    return 0;
}
