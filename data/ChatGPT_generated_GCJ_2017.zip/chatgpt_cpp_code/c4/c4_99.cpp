#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> possible_kits;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> total_grams(N);
            int num_packages = 0;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    num_packages++;
                    for (int i = 0; i < N; i++) {
                        total_grams[i] += Q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int low = (R[i] * num_packages * 9 + 5) / 10;
                int high = (R[i] * num_packages * 11) / 10;
                if (total_grams[i] < low || total_grams[i] > high) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                possible_kits.push_back(num_packages);
            }
        }
        int max_kits = 0;
        for (int k : possible_kits) {
            max_kits = max(max_kits, __builtin_popcount(k));
        }
        cout << "Case #" << t << ": " << max_kits << "\n";
    }
    return 0;
}
