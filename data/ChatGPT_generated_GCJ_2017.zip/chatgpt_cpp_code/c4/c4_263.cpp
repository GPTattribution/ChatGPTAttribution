#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<int> max_kits(p);
        for (int j = 0; j < p; j++) {
            int max_kit = 0;
            for (int k = 0; k < (1 << n); k++) {
                int total_grams = 0;
                bool valid = true;
                for (int l = 0; l < n; l++) {
                    if ((k & (1 << l)) != 0) {
                        total_grams += q[l][j];
                        if (q[l][j] < r[l] * 9 / 10 || q[l][j] > r[l] * 11 / 10) {
                            valid = false;
                            break;
                        }
                    }
                }
                if (valid && total_grams >= r[0] && total_grams <= r[0] * p * 11 / 10) {
                    int kit = total_grams / r[0];
                    max_kit = max(max_kit, kit);
                }
            }
            max_kits[j] = max_kit;
        }
        int ans = 0;
        sort(max_kits.begin(), max_kits.end(), greater<int>());
        for (int j = 0; j < p; j++) {
            if (max_kits[j] == 0) {
                break;
            }
            ans++;
            for (int k = j + 1; k < p; k++) {
                if (max_kits[k] % max_kits[j] == 0) {
                    max_kits[k] = 0;
                }
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
