#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }
        vector<int> indices(N);
        for (int i = 0; i < N; ++i) {
            indices[i] = i;
        }
        int maxKits = 0;
        do {
            bool valid = true;
            int kits = 0;
            vector<int> amounts(N, 0);
            for (int j = 0; j < P; ++j) {
                for (int i : indices) {
                    amounts[i] += Q[i][j];
                }
                int minKits = INT_MAX;
                for (int i = 0; i < N; ++i) {
                    int numServings = amounts[i] / R[i];
                    if (numServings == 0) {
                        valid = false;
                        break;
                    }
                    int lowerBound = numServings * 9 / 10;
                    int upperBound = numServings * 11 / 10;
                    if (amounts[i] < lowerBound * R[i] || amounts[i] > upperBound * R[i]) {
                        valid = false;
                        break;
                    }
                    minKits = min(minKits, numServings);
                }
                if (!valid) {
                    break;
                }
                kits += minKits;
                for (int i = 0; i < N; ++i) {
                    amounts[i] -= minKits * R[i];
                }
            }
            if (valid) {
                maxKits = max(maxKits, kits);
            }
        } while (next_permutation(indices.begin(), indices.end()));
        cout << "Case #" << t << ": " << maxKits << endl;
    }
    return 0;
}
