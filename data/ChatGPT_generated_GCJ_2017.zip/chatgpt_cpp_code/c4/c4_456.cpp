#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N), min_qty(N), max_qty(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            min_qty[i] = R[i] * 9 / 10;
            max_qty[i] = R[i] * 11 / 10;
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
            sort(Q[i].begin(), Q[i].end());
        }
        int max_kits = 0;
        vector<int> indices(N, 0);
        while (indices[0] < P) {
            bool valid = true;
            vector<int> qty(N);
            for (int i = 0; i < N; i++) {
                qty[i] = Q[i][indices[i]];
                if (qty[i] < min_qty[i] || qty[i] > max_qty[i]) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits++;
                for (int i = 0; i < N; i++) {
                    indices[i]++;
                }
            } else {
                int i = N - 1;
                while (i >= 0 && indices[i] == P - 1) {
                    indices[i] = 0;
                    i--;
                }
                if (i < 0) {
                    break;
                }
                indices[i]++;
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
