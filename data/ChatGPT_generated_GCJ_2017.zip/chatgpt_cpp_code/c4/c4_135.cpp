#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<int> max_kits(p, 0);
        for (int k = 0; k < p; k++) {
            vector<int> possible_kits;
            for (int s = 1; s <= 10; s++) {
                bool can_make = true;
                for (int j = 0; j < n; j++) {
                    double needed = s * r[j];
                    double min_amount = needed * 0.9;
                    double max_amount = needed * 1.1;
                    if (q[j][k] < min_amount || q[j][k] > max_amount) {
                        can_make = false;
                        break;
                    }
                }
                if (can_make) {
                    possible_kits.push_back(s);
                }
            }
            if (!possible_kits.empty()) {
                max_kits[k] = *max_element(possible_kits.begin(), possible_kits.end());
            }
        }
        int max_num_kits = *min_element(max_kits.begin(), max_kits.end());
        cout << "Case #" << i << ": " << max_num_kits << endl;
    }
    return 0;
}
