#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;
const double EPS = 1e-9;

int T, N, P, R[MAXN];
int Q[MAXN][MAXN];
bool used[MAXN];

bool is_valid(int num_kits) {
    for (int i = 0; i < N; i++) {
        double low = R[i] * num_kits * 0.9;
        double high = R[i] * num_kits * 1.1;
        bool found = false;
        for (int j = 0; j < P; j++) {
            if (!used[j] && Q[i][j] >= low + EPS && Q[i][j] <= high + EPS) {
                found = true;
                used[j] = true;
                break;
            }
        }
        if (!found) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    memset(used, false, sizeof(used));
    int ans = 0;
    for (int num_kits = 1; ; num_kits++) {
        if (!is_valid(num_kits)) {
            break;
        }
        ans = num_kits;
    }
    return ans;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
