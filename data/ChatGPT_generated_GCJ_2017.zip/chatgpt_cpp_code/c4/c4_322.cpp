#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << N); mask++) {
            bool ok = true;
            vector<int> rem(P);
            for (int i = 0; i < N; i++) {
                if (mask & (1 << i)) {
                    for (int j = 0; j < P; j++) {
                        rem[j] += Q[i][j];
                    }
                }
            }
            for (int i = 0; i < P; i++) {
                int tot = 0;
                for (int j = 0; j < N; j++) {
                    if (mask & (1 << j)) {
                        tot += R[j] * 100;
                    }
                }
                if (rem[i] < tot * 9 || rem[i] > tot * 11) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                int cnt = 0;
                for (int i = 0; i < P; i++) {
                    int tot = 1e9;
                    for (int j = 0; j < N; j++) {
                        if (mask & (1 << j)) {
                            tot = min(tot, rem[i] / (R[j] * 100));
                        }
                    }
                    cnt = max(cnt, tot);
                }
                ans = max(ans, cnt);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
