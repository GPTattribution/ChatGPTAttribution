#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        vector<int> indices(N, 0);
        bool done = false;

        while (!done) {
            int min_servings = INT_MAX;
            int max_servings = INT_MIN;
            for (int i = 0; i < N; i++) {
                int package = Q[i][indices[i]];
                int servings = package / R[i];
                if (servings * R[i] < 9 * package || servings * R[i] > 11 * package) {
                    min_servings = 0;
                    break;
                }
                min_servings = min(min_servings, servings);
                max_servings = max(max_servings, servings);
            }
            if (min_servings > 0) {
                max_kits++;
            }

            for (int i = N - 1; i >= 0; i--) {
                if (indices[i] < P - 1) {
                    indices[i]++;
                    break;
                } else {
                    indices[i] = 0;
                    if (i == 0) {
                        done = true;
                    }
                }
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
