#include <bits/stdc++.h>
using namespace std;

const int MAXN = 55;
int T, N, P, R[MAXN], Q[MAXN][MAXN];

bool possible(int servings, vector<int>& quantities) {
    for (int i = 0; i < N; i++) {
        int total = 0;
        for (int j = 0; j < P; j++) {
            total += Q[i][j];
        }
        int required = servings * R[i];
        int min_required = required * 9 / 10;
        int max_required = required * 11 / 10;
        if (total < min_required || total > max_required) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    int max_servings = 0;
    for (int servings = 1; ; servings++) {
        vector<int> quantities(N, 0);
        int max_quantity = 0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                if (Q[i][j] >= servings * R[i] * 9 / 10 && Q[i][j] <= servings * R[i] * 11 / 10) {
                    quantities[i] += Q[i][j];
                    max_quantity = max(max_quantity, Q[i][j]);
                    break;
                }
            }
        }
        if (max_quantity == 0) {
            break;
        }
        if (possible(servings, quantities)) {
            max_servings += 1;
        }
    }
    return max_servings;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
