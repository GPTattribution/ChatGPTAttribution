#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const int MAXQ = 1000000;

int T, N, P;
int R[MAXN], Q[MAXN][MAXP];
int dp[MAXQ+1];

void solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }

    memset(dp, -1, sizeof(dp));
    dp[0] = 0;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            for (int k = MAXQ; k >= 0; k--) {
                if (dp[k] >= 0) {
                    int nk = min(MAXQ, k * 11 / 10);
                    int serv = (k + R[i] - 1) / R[i];
                    if (serv <= P && Q[i][serv-1] >= j+1) {
                        dp[nk] = max(dp[nk], dp[k] + 1);
                    }
                }
            }
        }
    }

    cout << dp[MAXQ] << endl;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ": ";
        solve();
    }
    return 0;
}
