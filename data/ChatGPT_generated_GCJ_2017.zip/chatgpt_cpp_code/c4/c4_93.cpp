#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> possible_kits;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> amounts(N);
            int count = 0;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    count++;
                    for (int i = 0; i < N; i++) {
                        amounts[i] += Q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int required = R[i] * count;
                int lower = required * 9 / 10;
                int upper = required * 11 / 10;
                if (amounts[i] < lower || amounts[i] > upper) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                possible_kits.push_back(count);
            }
        }
        int result = *max_element(possible_kits.begin(), possible_kits.end());
        cout << "Case #" << t << ": " << result << endl;
    }
    return 0;
}
