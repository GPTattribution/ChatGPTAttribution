#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int servings = 1; ; servings++) {
            vector<int> max_qty(N, 0);
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < P; j++) {
                    max_qty[i] = max(max_qty[i], Q[i][j]);
                }
            }
            bool valid = false;
            for (int i = 0; i < (1 << N); i++) {
                vector<int> qty(N, 0);
                int total_qty = 0;
                for (int j = 0; j < N; j++) {
                    if (i & (1 << j)) {
                        int needed_qty = servings * R[j];
                        if (max_qty[j] < needed_qty * 9 / 10 || max_qty[j] > needed_qty * 11 / 10) {
                            break;
                        }
                        qty[j] = max_qty[j];
                        total_qty += qty[j];
                    }
                    if (j == N - 1 && total_qty >= servings * 9 * accumulate(R.begin(), R.end(), 0) / 10 && total_qty <= servings * 11 * accumulate(R.begin(), R.end(), 0) / 10) {
                        valid = true;
                        ans++;
                    }
                }
            }
            if (!valid) {
                break;
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
