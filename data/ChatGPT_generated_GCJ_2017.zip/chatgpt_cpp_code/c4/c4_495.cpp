#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> qty(N, 0);
            int num_selected = 0;

            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < N; i++) {
                        qty[i] += Q[i][j];
                    }
                    num_selected++;
                }
            }

            bool valid = true;
            for (int i = 0; i < N; i++) {
                double min_qty = R[i] * num_selected * 0.9;
                double max_qty = R[i] * num_selected * 1.1;
                if (qty[i] < floor(min_qty) || qty[i] > ceil(max_qty)) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                max_kits = max(max_kits, num_selected);
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
