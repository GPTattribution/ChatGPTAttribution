#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        vector<int> indices(N, 0);

        while (true) {
            bool valid = true;

            for (int i = 0; i < N; i++) {
                if (Q[i][indices[i]] < R[i]*9/10 || Q[i][indices[i]] > R[i]*11/10) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                ans++;
                for (int i = 0; i < N; i++) {
                    indices[i]++;
                    if (indices[i] == P) {
                        break;
                    }
                }
            } else {
                int min_index = min_element(Q[0].begin(), Q[0].end()) - Q[0].begin();
                for (int i = 1; i < N; i++) {
                    min_index = max(min_index, (int)(lower_bound(Q[i].begin(), Q[i].end(), Q[i][indices[i-1]]) - Q[i].begin()));
                }
                if (min_index == P) {
                    break;
                }
                for (int i = 0; i < N; i++) {
                    indices[i] = min_index;
                }
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
