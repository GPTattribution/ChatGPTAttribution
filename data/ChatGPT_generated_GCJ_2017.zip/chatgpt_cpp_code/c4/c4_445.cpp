#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<vector<int>> valid_kits;
        for (int k = 1; ; k++) {
            vector<int> remaining(P);
            for (int j = 0; j < P; j++) {
                for (int i = 0; i < N; i++) {
                    remaining[j] += Q[i][j];
                }
            }
            vector<int> servings(P);
            bool ok = true;
            for (int j = 0; j < P; j++) {
                int required = k * R[j];
                int lower = (90 * required + 99) / 100;
                int upper = (110 * required) / 100;
                if (remaining[j] < lower || remaining[j] > upper) {
                    ok = false;
                    break;
                }
                servings[j] = remaining[j] / R[j];
            }
            if (!ok) {
                break;
            }
            valid_kits.push_back(servings);
            for (int j = 0; j < P; j++) {
                for (int i = 0; i < N; i++) {
                    remaining[j] -= servings[j] * R[i];
                }
            }
        }
        cout << "Case #" << t << ": " << valid_kits.size() << endl;
    }
    return 0;
}
