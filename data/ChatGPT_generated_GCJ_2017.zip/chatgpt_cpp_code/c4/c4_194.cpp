#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        for (int i = 0; i < P; i++) {
            vector<int> amounts(N);
            for (int j = 0; j < N; j++) {
                amounts[j] = Q[j][i];
            }

            bool possible = true;
            for (int k = 1; k <= 100 && possible; k++) {
                int target = k * 100;
                vector<int> need(N);
                for (int j = 0; j < N; j++) {
                    need[j] = R[j] * target;
                }

                bool found = true;
                for (int j = 0; j < N && found; j++) {
                    int lower = (int) ceil(0.9 * need[j]);
                    int upper = (int) floor(1.1 * need[j]);
                    bool has = false;
                    for (int l = 0; l < P && !has; l++) {
                        if (amounts[j] >= lower && amounts[j] <= upper) {
                            has = true;
                            amounts[j] = 0;
                        }
                    }
                    found &= has;
                }

                if (found) {
                    ans++;
                } else {
                    possible = false;
                }
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
