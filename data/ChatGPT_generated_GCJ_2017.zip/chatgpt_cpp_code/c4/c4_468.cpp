#include <iostream>
#include <vector>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << (n * p)); mask++) {
            int servings = -1;
            vector<int> used(p * n, false);
            for (int i = 0; i < n; i++) {
                int sum = 0;
                for (int j = 0; j < p; j++) {
                    int idx = i * p + j;
                    if ((mask & (1 << idx)) != 0) {
                        used[idx] = true;
                        sum += q[i][j];
                    }
                }
                int s = sum / r[i];
                if (servings == -1) {
                    servings = s;
                } else if (s != servings) {
                    servings = -2;
                    break;
                }
                if (s == 0 || sum < servings * r[i] * 0.9 || sum > servings * r[i] * 1.1) {
                    servings = -2;
                    break;
                }
            }
            if (servings >= 0) {
                ans++;
                for (int i = 0; i < n * p; i++) {
                    if (used[i]) {
                        mask ^= (1 << i);
                    }
                }
            }
        }
        cout << "Case #" << case_num << ": " << ans << endl;
    }
    return 0;
}
