#include<bits/stdc++.h>
using namespace std;
#define int long long

const int MAXN = 50;
int T, N, P, R[MAXN + 5], Q[MAXN + 5][MAXN + 5], DP[(1 << MAXN) + 5];

int count_bits(int n) {
    int res = 0;
    while (n > 0) {
        res++;
        n -= n & -n;
    }
    return res;
}

void solve() {
    cin >> N >> P;
    for (int i = 1; i <= N; i++) cin >> R[i];
    for (int i = 1; i <= N; i++)
        for (int j = 1; j <= P; j++)
            cin >> Q[i][j];
    memset(DP, -1, sizeof(DP));
    DP[0] = 0;
    for (int mask = 0; mask < (1 << N); mask++) {
        if (DP[mask] == -1) continue;
        int cnt = count_bits(mask) + 1;
        for (int i = 1; i <= N; i++) {
            if (mask & (1 << (i - 1))) continue;
            bool ok = false;
            for (int j = 1; j <= P; j++) {
                if (Q[i][j] >= 90 * cnt * R[i] && Q[i][j] <= 110 * cnt * R[i]) {
                    ok = true;
                    break;
                }
            }
            if (ok) {
                int new_mask = mask | (1 << (i - 1));
                DP[new_mask] = max(DP[new_mask], DP[mask] + 1);
            }
        }
    }
    cout << DP[(1 << N) - 1] << endl;
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cout << "Case #" << t << ": ";
        solve();
    }
    return 0;
}
