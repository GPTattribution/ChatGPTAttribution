#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAXN = 50;
const int MAXP = 50;

int N, P;
int R[MAXN], Q[MAXN][MAXP];
bool vis[MAXN][MAXP];

bool check(int servings, const vector<int>& idx) {
    for (int i = 0; i < N; i++) {
        int req = R[i] * servings;
        int total = 0;
        for (int j : idx) {
            total += Q[i][j];
        }
        if (total < 9 * req || total > 11 * req) {
            return false;
        }
    }
    return true;
}

int dfs(int i, vector<int>& idx) {
    if (i == N) {
        vector<int> servings;
        for (int j = 0; j < P; j++) {
            if (vis[0][j]) {
                int cnt = 1;
                while (check(cnt, idx)) {
                    cnt++;
                }
                servings.push_back(cnt - 1);
            }
        }
        int ans = 0;
        for (int s : servings) {
            ans = max(ans, s);
        }
        return ans;
    } else {
        int ans = 0;
        for (int j = 0; j < P; j++) {
            if (!vis[i][j]) {
                vis[i][j] = true;
                idx.push_back(j);
                ans = max(ans, dfs(i + 1, idx));
                idx.pop_back();
                vis[i][j] = false;
            }
        }
        return ans;
    }
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    vector<int> idx;
    memset(vis, 0, sizeof(vis));
    return dfs(0, idx);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
