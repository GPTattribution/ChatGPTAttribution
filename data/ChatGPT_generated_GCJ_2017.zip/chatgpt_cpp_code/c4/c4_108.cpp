#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            bool valid = true;
            vector<int> total(N);
            for (int j = 0; j < P; j++) {
                if ((mask >> j) & 1) {
                    for (int i = 0; i < N; i++) {
                        total[i] += Q[i][j];
                    }
                }
            }
            for (int i = 0; i < N; i++) {
                int servings = total[i] / R[i];
                int lower = (int) ceil(0.9 * servings);
                int upper = (int) floor(1.1 * servings);
                if (lower > upper) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int kits = 1;
                for (int i = 0; i < N; i++) {
                    int servings = total[i] / R[i];
                    kits *= (int) floor(1.1 * servings) - (int) ceil(0.9 * servings) + 1;
                }
                max_kits = max(max_kits, kits);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
