#include <iostream>
#include <vector>

using namespace std;

const double LOWER_LIMIT = 0.9, UPPER_LIMIT = 1.1;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        for (int i = 0; i < P; i++) {
            vector<int> amt(N);
            int servings = 0;

            for (int j = 0; j < N; j++) {
                amt[j] = Q[j][i];
                servings = max(servings, (amt[j] + R[j] - 1) / R[j]);
            }

            bool valid = true;

            for (int j = 0; j < N; j++) {
                double lower = LOWER_LIMIT * R[j] * servings;
                double upper = UPPER_LIMIT * R[j] * servings;

                if (amt[j] < lower || amt[j] > upper) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                ans++;
                for (int j = 0; j < N; j++) {
                    Q[j][i] = -1;
                }
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
