#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> indices(N);
        for (int i = 0; i < N; i++) {
            indices[i] = i;
        }
        int max_kits = 0;
        do {
            for (int k = 1; ; k++) {
                int servings = k;
                bool ok = true;
                for (int i : indices) {
                    vector<int>& q = Q[i];
                    double sum = 0.0;
                    for (int j = 0; j < P; j++) {
                        sum += q[j];
                    }
                    double target = 1.0 * servings * R[i];
                    double min_target = 0.9 * target;
                    double max_target = 1.1 * target;
                    bool found = false;
                    for (int j = 0; j < P; j++) {
                        double x = q[j];
                        if (min_target <= x && x <= max_target) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        ok = false;
                        break;
                    }
                }
                if (!ok) {
                    max_kits = max(max_kits, k-1);
                    break;
                } else if (servings > max_kits) {
                    max_kits = servings;
                }
            }
        } while (next_permutation(indices.begin(), indices.end()));
        cout << "Case #" << t << ": " << max_kits << "\n";
    }
    return 0;
}
