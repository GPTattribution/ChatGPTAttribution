#include <iostream>
#include <vector>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N), maxQty(N, 0), minQty(N, 1000000000);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                int Qij;
                cin >> Qij;
                maxQty[i] = max(maxQty[i], Qij);
                minQty[i] = min(minQty[i], Qij);
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << N); mask++) {
            int qty = 1000000000, servings = 0;
            for (int i = 0; i < N; i++) {
                if (mask & (1 << i)) {
                    qty = min(qty, maxQty[i]);
                    servings += R[i];
                } else {
                    qty = min(qty, minQty[i]);
                }
            }
            if (servings <= qty * 110 && servings >= qty * 90) {
                int kits = qty * P;
                for (int i = 0; i < N; i++) {
                    if (!(mask & (1 << i))) {
                        kits = min(kits, maxQty[i] / qty);
                    }
                }
                ans = max(ans, kits);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
