#include <bits/stdc++.h>
using namespace std;

int T, N, P, r[55], q[55][55], cnt;
bool cmp(int a, int b) {
    return a > b;
}

bool check(int x) {
    int a[55];
    for (int i = 0; i < N; i++) {
        int c = 0;
        for (int j = 0; j < P; j++) {
            if (q[i][j] >= r[i] * x * 0.9 && q[i][j] <= r[i] * x * 1.1) {
                a[i] = q[i][j];
                c++;
                break;
            }
        }
        if (!c) return false;
    }
    sort(a, a + N, cmp);
    int s = 0;
    for (int i = 0; i < N; i++)
        s = (s + a[i] - r[i] * x) / (r[i] * 0.1);
        return !s;
}

int main() {
cin >> T;
for (int t = 1; t <= T; t++) {
    cin >> N >> P;
    for (int i = 0; i < N; i++) cin >> r[i];
    for (int i = 0; i < N; i++)
        for (int j = 0; j < P; j++) cin >> q[i][j];
    int l = 0, h = 1e9;
    while (l < h) {
        int mid = (l + h + 1) / 2;
    if (check(mid))
        l = mid;
    else
        h = mid - 1;
    }
    cout << "Case #" << t << ": " << l << endl;
  }
  return 0;
}
