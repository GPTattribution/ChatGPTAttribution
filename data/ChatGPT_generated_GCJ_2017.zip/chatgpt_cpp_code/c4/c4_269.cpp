#include <iostream>
#include <vector>

using namespace std;

const int MAX_N = 50;
const int MAX_P = 50;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> total(N);
            int count = 0;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    count++;
                    for (int i = 0; i < N; i++) {
                        total[i] += Q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int low = (R[i] * count * 9 + 10) / 11;
                int high = (R[i] * count * 11) / 10;
                if (total[i] < low || total[i] > high) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, count);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
