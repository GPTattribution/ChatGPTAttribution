#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int test = 1; test <= t; test++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << n); mask++) {
            bool ok = true;
            vector<int> amount(p);
            for (int i = 0; i < n; i++) {
                if (mask & (1 << i)) {
                    for (int j = 0; j < p; j++) {
                        amount[j] += q[i][j];
                    }
                }
            }
            for (int j = 0; j < p; j++) {
                if (amount[j] < 9 * accumulate(r.begin(), r.end(), 0) / 10 ||
                    amount[j] > 11 * accumulate(r.begin(), r.end(), 0) / 10) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                int servings = *min_element(amount.begin(), amount.end()) / accumulate(r.begin(), r.end(), 0);
                ans = max(ans, servings);
            }
        }

        cout << "Case #" << test << ": " << ans << endl;
    }

    return 0;
}
