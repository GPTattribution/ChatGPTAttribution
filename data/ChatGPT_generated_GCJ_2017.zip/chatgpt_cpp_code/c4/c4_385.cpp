#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <iomanip>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> package_sum(N);
            int count = 0;

            for (int j = 0; j < P; j++) {
                if ((mask >> j) & 1) {
                    count++;
                    for (int i = 0; i < N; i++) {
                        package_sum[i] += Q[i][j];
                    }
                }
            }

            bool valid = true;
            for (int i = 0; i < N; i++) {
                double lower_bound = R[i] * count * 0.9;
                double upper_bound = R[i] * count * 1.1;
                if (package_sum[i] < lower_bound || package_sum[i] > upper_bound) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                ans = max(ans, count);
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
