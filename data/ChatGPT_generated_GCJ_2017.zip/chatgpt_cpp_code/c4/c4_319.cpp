#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            cin >> r[j];
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << (n * p)); mask++) {
            vector<int> sum(n);
            int prod = 1;
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < p; k++) {
                    if ((mask >> (j * p + k)) & 1) {
                        sum[j] += q[j][k];
                    }
                }
                if (sum[j] < r[j] * 9 || sum[j] > r[j] * 11) {
                    prod = 0;
                    break;
                }
                prod *= (sum[j] / r[j]);
            }
            ans = max(ans, prod);
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
