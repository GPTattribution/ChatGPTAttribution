#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;
const double RANGE = 0.1;

int T, N, P, R[MAXN];
int Q[MAXN][MAXP];
int ans;

bool check(vector<int> cnt) {
    for (int i = 0; i < N; ++i) {
        int total = 0;
        for (int j = 0; j < P; ++j) {
            total += cnt[j] * Q[i][j];
        }
        if (total < R[i] * cnt.back() * 0.9 || total > R[i] * cnt.back() * 1.1) {
            return false;
        }
    }
    return true;
}

void dfs(vector<int>& cnt, int cur) {
    if (cur == P) {
        if (check(cnt)) {
            ans = max(ans, cnt.back());
        }
        return;
    }
    for (int i = 0; i <= cnt[0]; ++i) {
        cnt[cur] = i;
        dfs(cnt, cur + 1);
    }
}

void solve() {
    cin >> N >> P;
    for (int i = 0; i < N; ++i) {
        cin >> R[i];
    }
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < P; ++j) {
            cin >> Q[i][j];
        }
    }
    vector<int> cnt(P + 1);
    cnt.back() = 1;
    ans = 0;
    dfs(cnt, 0);
    cout << ans << endl;
}

int main() {
    cin >> T;
    for (int i = 1; i <= T; ++i) {
        cout << "Case #" << i << ": ";
        solve();
    }
    return 0;
}
