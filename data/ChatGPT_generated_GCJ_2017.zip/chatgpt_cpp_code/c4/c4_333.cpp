#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }
        vector<int> max_kits(P);
        for (int j = 0; j < P; ++j) {
            int max_kit = 0;
            for (int k = 1; k <= 10000; ++k) {
                bool valid = true;
                for (int i = 0; i < N; ++i) {
                    double needed = static_cast<double>(k * R[i]);
                    double low = needed * 0.9;
                    double high = needed * 1.1;
                    auto it = lower_bound(Q[i].begin(), Q[i].end(), static_cast<int>(low));
                    if (it == Q[i].end() || *it > high) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    max_kit = k;
                } else {
                    break;
                }
            }
            max_kits[j] = max_kit;
        }
        int max_num_kits = 0;
        sort(max_kits.begin(), max_kits.end());
        for (int j = 0; j < P; ++j) {
            if (max_kits[j] == 0) {
                break;
            }
            int num_kits = 1;
            for (int k = j + 1; k < P; ++k) {
                if (max_kits[k] == 0) {
                    break;
                }
                if (max_kits[k] == max_kits[j]) {
                    ++num_kits;
                }
            }
            max_num_kits = max(max_num_kits, num_kits);
        }
        cout << "Case #" << t << ": " << max_num_kits << endl;
    }
    return 0;
}
