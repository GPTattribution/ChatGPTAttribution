#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const double lowerBound = 0.9;
const double upperBound = 1.1;

int solve() {
    int n, p;
    cin >> n >> p;
    vector<int> R(n);
    for (int i = 0; i < n; i++) {
        cin >> R[i];
    }
    vector<vector<int>> Q(n, vector<int>(p));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < p; j++) {
            cin >> Q[i][j];
        }
        sort(Q[i].begin(), Q[i].end());
    }

    int maxKits = 0;
    for (int mask = 0; mask < (1 << p); mask++) {
        vector<int> sum(n, 0);
        int count = 0;
        for (int j = 0; j < p; j++) {
            if ((mask >> j) & 1) {
                count++;
                for (int i = 0; i < n; i++) {
                    sum[i] += Q[i][j];
                }
            }
        }

        bool isValid = true;
        for (int i = 0; i < n; i++) {
            double required = static_cast<double>(R[i] * count);
            double lower = required * lowerBound;
            double upper = required * upperBound;
            if (sum[i] < lower || sum[i] > upper) {
                isValid = false;
                break;
            }
        }

        if (isValid) {
            maxKits = max(maxKits, count);
        }
    }

    return maxKits;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
