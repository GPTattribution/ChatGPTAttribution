#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<vector<int>> packages;
        for (int j = 0; j < p; j++) {
            vector<int> package(n);
            for (int k = 0; k < n; k++) {
                package[k] = q[k][j];
            }
            packages.push_back(package);
        }
        int max_kits = 0;
        for (int j = 0; j < (1 << p); j++) {
            vector<int> counts(n);
            int total_weight = 0;
            for (int k = 0; k < p; k++) {
                if (j & (1 << k)) {
                    total_weight += accumulate(packages[k].begin(), packages[k].end(), 0);
                    for (int l = 0; l < n; l++) {
                        counts[l] += packages[k][l];
                    }
                }
            }
            bool valid = true;
            for (int k = 0; k < n; k++) {
                double min_weight = r[k] * counts[k] * 0.9;
                double max_weight = r[k] * counts[k] * 1.1;
                if (counts[k] == 0 || total_weight < min_weight || total_weight > max_weight) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = max(max_kits, __builtin_popcount(j));
            }
        }
        cout << "Case #" << i << ": " << max_kits << endl;
    }
    return 0;
}
