#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            bool ok = true;
            vector<int> cnt(N);
            int servings = -1;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < N; i++) {
                        cnt[i] += Q[i][j];
                    }
                    if (servings == -1) {
                        servings = Q[0][j] / R[0];
                    } else if (Q[0][j] / R[0] != servings) {
                        ok = false;
                        break;
                    }
                }
            }
            if (!ok) continue;
            for (int i = 0; i < N; i++) {
                if (cnt[i] < R[i] * servings * 9 / 10 || cnt[i] > R[i] * servings * 11 / 10) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, __builtin_popcount(mask));
            }
        }
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
