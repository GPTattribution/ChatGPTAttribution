#include <iostream>
#include <vector>

using namespace std;

bool is_valid(int servings, const vector<int>& recipe, const vector<vector<int>>& packages) {
    int n = recipe.size();
    for (int i = 0; i < n; i++) {
        int total = 0;
        for (int j = 0; j < packages[i].size(); j++) {
            total += packages[i][j];
        }
        int needed = recipe[i] * servings;
        if (total < needed * 9 / 10 || total > needed * 11 / 10) {
            return false;
        }
    }
    return true;
}

int solve_case() {
    int n, p;
    cin >> n >> p;

    vector<int> recipe(n);
    for (int i = 0; i < n; i++) {
        cin >> recipe[i];
    }

    vector<vector<int>> packages(n, vector<int>(p));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < p; j++) {
            cin >> packages[i][j];
        }
    }

    int max_kits = 0;
    for (int servings = 1; ; servings++) {
        if (!is_valid(servings, recipe, packages)) {
            break;
        }
        max_kits = servings;
    }

    return max_kits;
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int ans = solve_case();
        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
