#include <iostream>
#include <vector>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int maxKits = 0;
        for (int j = 0; j < p; j++) {
            for (int k = 1; ; k++) {
                bool valid = true;
                for (int l = 0; l < n; l++) {
                    int minAmount = r[l] * k * 9 / 10;
                    int maxAmount = r[l] * k * 11 / 10;
                    if (q[l][j] < minAmount || q[l][j] > maxAmount) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    maxKits++;
                } else {
                    break;
                }
            }
        }

        cout << "Case #" << i << ": " << maxKits << endl;
    }

    return 0;
}
