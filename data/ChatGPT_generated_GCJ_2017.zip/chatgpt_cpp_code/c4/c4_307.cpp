#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const double EPS = 1e-9;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        vector<int> indices(N);
        for (int i = 0; i < N; ++i) {
            indices[i] = i;
        }
        do {
            bool valid = true;
            int num_kits = 0;
            vector<int> amounts(N);
            while (true) {
                bool can_make = true;
                for (int i = 0; i < N; ++i) {
                    double total_amount = R[indices[i]] * num_kits;
                    double min_amount = total_amount * 0.9 - EPS;
                    double max_amount = total_amount * 1.1 + EPS;
                    double package_amount = 0.0;
                    for (int j = 0; j < P; ++j) {
                        package_amount += Q[indices[i]][j];
                        if (package_amount >= max_amount) {
                            package_amount = max_amount;
                            break;
                        }
                    }
                    if (package_amount < min_amount) {
                        can_make = false;
                        break;
                    }
                    amounts[indices[i]] = package_amount;
                }
                if (!can_make) {
                    break;
                }
                ++num_kits;
            }
            ans = max(ans, num_kits - 1);
        } while (next_permutation(indices.begin(), indices.end()));
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
