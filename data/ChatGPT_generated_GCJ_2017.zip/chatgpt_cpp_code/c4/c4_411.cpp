#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<int> indices(N, 0);
        int num_kits = 0;
        while (true) {
            int servings = numeric_limits<int>::max();
            for (int i = 0; i < N; i++) {
                servings = min(servings, Q[i][indices[i]] / R[i]);
            }

            if (servings == 0) {
                break;
            }

            bool valid = true;
            for (int i = 0; i < N; i++) {
                int lower_bound = R[i] * servings * 9;
                int upper_bound = R[i] * servings * 11;
                if (Q[i][indices[i]] < lower_bound || Q[i][indices[i]] > upper_bound) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                for (int i = 0; i < N; i++) {
                    Q[i][indices[i]] -= R[i] * servings;
                    if (Q[i][indices[i]] == 0) {
                        indices[i]++;
                    }
                }
                num_kits++;
            } else {
                indices[0]++;
            }

            if (indices[0] == P) {
                break;
            }
        }

        cout << "Case #" << t << ": " << num_kits << endl;
    }

    return 0;
}
