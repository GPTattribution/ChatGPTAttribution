#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int i = 0; i < P; i++) {
            int amount = Q[0][i];
            for (int j = 0; j < P; j++) {
                amount += Q[1][j];
                bool ok = true;
                for (int k = 0; k < N; k++) {
                    int need = R[k] * amount;
                    bool found = false;
                    for (int l = 0; l < P; l++) {
                        if (Q[k][l] >= 0.9 * need && Q[k][l] <= 1.1 * need) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        ok = false;
                        break;
                    }
                }
                if (ok) {
                    ans++;
                }
                amount -= Q[1][j];
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
