#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<int> max_kits(p);
        for (int j = 0; j < p; j++) {
            vector<int> amounts(n);
            for (int k = 0; k < n; k++) {
                amounts[k] = q[k][j];
            }
            sort(amounts.begin(), amounts.end());
            int max_serves = floor(1.1 * amounts[0] / r[0]);
            int min_serves = ceil(0.9 * amounts[n-1] / r[n-1]);
            int max_kits_for_package = 0;
            for (int k = max_serves; k >= min_serves; k--) {
                bool valid = true;
                for (int l = 0; l < n; l++) {
                    int required_amount = r[l] * k;
                    int idx = lower_bound(amounts.begin(), amounts.end(), required_amount) - amounts.begin();
                    if (idx == n || amounts[idx] > 1.1 * required_amount) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    max_kits_for_package = k;
                    break;
                }
            }
            max_kits[j] = max_kits_for_package;
        }
        int ans = *min_element(max_kits.begin(), max_kits.end());
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
