#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        vector<vector<int>> combos;
        vector<int> curr(n);
        function<void(int)> generate_combos = [&](int idx) {
            if (idx == n) {
                combos.push_back(curr);
                return;
            }
            for (int k = 0; k < p; k++) {
                curr[idx] = k;
                generate_combos(idx+1);
            }
        };
        generate_combos(0);

        int max_kits = 0;
        for (vector<int>& combo : combos) {
            vector<int> min_amounts(n), max_amounts(n);
            for (int j = 0; j < n; j++) {
                int total_amount = 0;
                for (int k = 0; k < p; k++) {
                    if (combo[j] == k) {
                        total_amount += q[j][k];
                    }
                }
                min_amounts[j] = ceil(0.9 * total_amount / r[j]);
                max_amounts[j] = floor(1.1 * total_amount / r[j]);
            }

            int max_servings = *min_element(max_amounts.begin(), max_amounts.end());
            int min_servings = *max_element(min_amounts.begin(), min_amounts.end());
            if (max_servings >= min_servings) {
                max_kits = max(max_kits, max_servings - min_servings + 1);
            }
        }

        cout << "Case #" << i << ": " << max_kits << endl;
    }

    return 0;
}
