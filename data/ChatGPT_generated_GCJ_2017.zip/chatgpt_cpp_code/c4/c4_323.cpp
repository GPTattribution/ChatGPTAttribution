#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << (n * p)); mask++) {
            vector<int> cnt(p);
            int servings = INT_MAX;
            for (int j = 0; j < n; j++) {
                int cur = 0;
                for (int k = 0; k < p; k++) {
                    if (mask & (1 << (j * p + k))) {
                        cur += q[j][k];
                        cnt[k]++;
                    }
                }
                servings = min(servings, cur / r[j]);
            }

            bool valid = true;
            for (int k = 0; k < p; k++) {
                if (cnt[k] == 0 || cnt[k] > servings * 110 / q.size() || cnt[k] < servings * 90 / q.size()) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                ans = max(ans, servings);
            }
        }

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
