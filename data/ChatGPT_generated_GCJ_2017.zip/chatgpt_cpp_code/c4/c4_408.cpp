#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            bool valid = true;
            vector<int> cnt(n);
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    for (int k = 0; k < n; k++) {
                        cnt[k] += q[k][j];
                    }
                }
            }
            for (int j = 0; j < n; j++) {
                int need = r[j] * p;
                int low = need * 9;
                int high = need * 11;
                if (cnt[j] < low || cnt[j] > high) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int num_kits = 0x3f3f3f3f;
                for (int j = 0; j < n; j++) {
                    int need = r[j] * p;
                    num_kits = min(num_kits, cnt[j] / need);
                }
                ans = max(ans, num_kits);
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
