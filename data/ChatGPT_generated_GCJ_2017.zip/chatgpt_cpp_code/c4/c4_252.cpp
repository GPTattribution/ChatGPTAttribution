#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int servings = 1; ; servings++) {
            bool ok = true;
            for (int j = 0; j < n && ok; j++) {
                double min_qty = r[j] * servings * 0.9;
                double max_qty = r[j] * servings * 1.1;
                auto it = min_element(q[j].begin(), q[j].end(),
                    [&](int x, int y) {
                        return abs(x - r[j] * servings) < abs(y - r[j] * servings);
                    });
                if (*it < min_qty || *it > max_qty) {
                    ok = false;
                } else {
                    q[j].erase(it);
                    p--;
                }
            }
            if (ok) {
                ans++;
            } else {
                break;
            }
            if (p == 0) {
                break;
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
