#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; ++i) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); ++mask) {
            vector<int> total(N);
            for (int j = 0; j < P; ++j) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < N; ++i) {
                        total[i] += Q[i][j];
                    }
                }
            }
            int servings = 1e9;
            for (int i = 0; i < N; ++i) {
                servings = min(servings, total[i] / R[i]);
            }
            if (servings > 0) {
                bool valid = true;
                for (int i = 0; i < N && valid; ++i) {
                    int required = servings * R[i];
                    int min_amount = required * 90 / 100;
                    int max_amount = required * 110 / 100;
                    valid &= (total[i] >= min_amount && total[i] <= max_amount);
                }
                if (valid) {
                    ans = max(ans, __builtin_popcount(mask));
                }
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
