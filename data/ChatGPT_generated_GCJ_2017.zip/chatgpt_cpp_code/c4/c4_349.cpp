#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> counts;
        for (int i = 0; i < P; i++) {
            int count = 0;
            bool valid = true;
            for (int j = 0; j < N; j++) {
                int r = R[j];
                int q = Q[j][i];
                int min_q = (int) (0.9 * r + 0.5);
                int max_q = (int) (1.1 * r + 0.5);
                if (q < min_q || q > max_q) {
                    valid = false;
                    break;
                }
                int servings = q / r;
                count = max(count, servings);
            }
            if (valid) {
                counts.push_back(count);
            }
        }
        sort(counts.rbegin(), counts.rend());
        int max_kits = 0;
        int remaining = P;
        for (int count : counts) {
            int kits = min(remaining, count);
            max_kits += kits;
            remaining -= kits;
            if (remaining == 0) {
                break;
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
