#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const double EPS = 1e-6;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            bool valid = true;
            vector<int> counts(N);
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    for (int i = 0; i < N; i++) {
                        counts[i] += Q[i][j];
                    }
                }
            }
            for (int i = 0; i < N; i++) {
                double needed = R[i];
                for (int j = 0; j < P; j++) {
                    if (mask & (1 << j)) {
                        needed -= Q[i][j];
                    }
                }
                double lower = needed * 0.9;
                double upper = needed * 1.1;
                if (counts[i] < lower - EPS || counts[i] > upper + EPS) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                int kit = 0;
                for (int i = 0; i < N; i++) {
                    double needed = R[i];
                    for (int j = 0; j < P; j++) {
                        if (mask & (1 << j)) {
                            needed -= Q[i][j];
                        }
                    }
                    kit = max(kit, (int) (counts[i] / needed));
                }
                ans = max(ans, kit);
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
