#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<vector<int>> packages;
        vector<int> indices(N, 0);
        while (true) {
            bool valid = true;
            int servings = -1;
            for (int i = 0; i < N; i++) {
                int total = 0;
                for (int j = 0; j < P; j++) {
                    total += Q[i][indices[i]+j];
                }
                int min_grams = ceil(R[i]*0.9);
                int max_grams = floor(R[i]*1.1);
                if (total < min_grams || total > max_grams) {
                    valid = false;
                    break;
                }
                if (servings == -1) {
                    servings = total / R[i];
                } else if (total / R[i] != servings) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                packages.push_back(indices);
            }
            int i = N-1;
            while (i >= 0 && indices[i] == P-1) {
                indices[i] = 0;
                i--;
            }
            if (i < 0) {
                break;
            }
            indices[i]++;
        }
        int max_kits = 0;
        for (vector<int>& p : packages) {
            int kits = 1e9;
            for (int i = 0; i < N; i++) {
                kits = min(kits, Q[i][p[i]+P-1] / (servings*R[i]));
            }
            max_kits = max(max_kits, kits);
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
