#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;

    for (int test = 1; test <= t; ++test) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int i = 0; i < n; ++i) {
            cin >> r[i];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < p; ++j) {
                cin >> q[i][j];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << p); ++mask) {
            vector<int> total(n, 0);
            int cnt = 0;
            for (int j = 0; j < p; ++j) {
                if (mask & (1 << j)) {
                    ++cnt;
                    for (int i = 0; i < n; ++i) {
                        total[i] += q[i][j];
                    }
                }
            }
            bool ok = true;
            for (int i = 0; i < n; ++i) {
                if (total[i] < 9 * r[i] * cnt || total[i] > 11 * r[i] * cnt) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, cnt);
            }
        }

        cout << "Case #" << test << ": " << ans << "\n";
    }

    return 0;
}
