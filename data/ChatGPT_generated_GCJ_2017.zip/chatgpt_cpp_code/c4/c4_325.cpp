#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> have(n);
            int cnt = 0;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    cnt++;
                    for (int k = 0; k < n; k++) {
                        have[k] += q[k][j];
                    }
                }
            }
            bool ok = true;
            for (int j = 0; j < n; j++) {
                if (have[j] < r[j] || have[j] > 11 * r[j] / 10) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, cnt);
            }
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
