#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

bool is_within_range(int ingredient_weight, int package_weight) {
    double lower_bound = 0.9 * ingredient_weight;
    double upper_bound = 1.1 * ingredient_weight;
    return package_weight >= lower_bound && package_weight <= upper_bound;
}

int get_max_num_kits(int n, int p, vector<int>& r, vector<vector<int>>& q) {
    vector<pair<int, vector<int>>> ingredients;
    for (int i = 0; i < n; i++) {
        vector<int> packages(q[i].begin(), q[i].end());
        sort(packages.begin(), packages.end());
        ingredients.push_back({r[i], packages});
    }
    int num_kits = 0;
    while (true) {
        bool has_enough_packages = true;
        for (auto& [ingredient_weight, packages] : ingredients) {
            if (packages.empty() || !is_within_range(ingredient_weight, packages.back())) {
                has_enough_packages = false;
                break;
            }
        }
        if (!has_enough_packages) {
            break;
        }
        for (auto& [_, packages] : ingredients) {
            packages.pop_back();
        }
        num_kits++;
    }
    return num_kits;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        int max_num_kits = get_max_num_kits(n, p, r, q);
        cout << "Case #" << i << ": " << max_num_kits << endl;
    }
    return 0;
}
