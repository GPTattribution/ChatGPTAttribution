#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<vector<int>> packages;
        vector<int> current(P);
        function<void(int)> generate = [&](int i) {
            if (i == P) {
                packages.push_back(current);
                return;
            }
            for (int j = 0; j < P; j++) {
                current[i] = j;
                generate(i+1);
            }
        };
        generate(0);
        int max_kits = 0;
        for (const auto& p : packages) {
            bool valid = true;
            vector<int> amounts(N);
            for (int i = 0; i < N; i++) {
                int sum = 0, min_sum = 0, max_sum = 0;
                for (int j : p) {
                    sum += Q[i][j];
                }
                min_sum = 9 * R[i] * p.size() / 10;
                max_sum = 11 * R[i] * p.size() / 10;
                if (sum < min_sum || sum > max_sum) {
                    valid = false;
                    break;
                }
                amounts[i] = sum;
            }
            if (valid) {
                int num_kits = 1e9;
                for (int i = 0; i < N; i++) {
                    num_kits = min(num_kits, amounts[i] / R[i]);
                }
                max_kits = max(max_kits, num_kits);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
