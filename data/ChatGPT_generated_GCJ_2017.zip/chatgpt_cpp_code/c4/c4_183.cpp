#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const double EPSILON = 1e-9;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> counts(P);
        int max_kits = 0;
        for (int i = 0; i < P; i++) {
            counts[i] = 0;
        }
        while (true) {
            int min_count = *min_element(counts.begin(), counts.end());
            int max_count = *max_element(counts.begin(), counts.end());
            int min_ingredient = -1;
            double min_ratio = 1.0 + EPSILON;
            for (int i = 0; i < N; i++) {
                int required = R[i] * (min_count + 1);
                double ratio = 1.0 * Q[i][0] / required;
                if (ratio < min_ratio) {
                    min_ratio = ratio;
                    min_ingredient = i;
                }
            }
            if (min_ratio > 1.0 - EPSILON) {
                break;
            }
            int max_ingredient = -1;
            double max_ratio = 0.0;
            for (int i = 0; i < N; i++) {
                int required = R[i] * (max_count + 1);
                double ratio = 1.0 * Q[i][P - 1] / required;
                if (ratio > max_ratio) {
                    max_ratio = ratio;
                    max_ingredient = i;
                }
            }
            int max_serves = R[max_ingredient] * (max_count + 1);
            int min_serves = R[min_ingredient] * (min_count + 1);
            if (max_ratio >= 1.0 - EPSILON && max_serves >= min_serves * (1.0 + EPSILON)) {
                counts[P - 1]++;
                max_kits++;
            } else {
                int j = P - 1;
                while (j >= 0 && (counts[j] == P - 1 || (j > 0 && counts[j] == counts[j - 1]))) {
                    j--;
                }
                if (j < 0) {
                    break;
                }
                counts[j]++;
                fill(counts.begin() + j + 1, counts.end(), 0);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
