#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int test_case = 1; test_case <= t; ++test_case) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; ++i) {
            cin >> r[i];
            for (int j = 0; j < p; ++j) {
                cin >> q[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << (n * p)); ++mask) {
            vector<int> package_count(n * p);
            for (int i = 0; i < n * p; ++i) {
                if (mask & (1 << i)) {
                    package_count[i] = 1;
                }
            }
            int num_kits = 0;
            vector<int> total_quantity(n, 0);
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < p; ++j) {
                    if (package_count[i * p + j]) {
                        total_quantity[i] += q[i][j];
                    }
                }
            }
            bool valid = true;
            while (valid) {
                valid = false;
                int min_kits = 1000000000;
                for (int i = 0; i < n; ++i) {
                    if (total_quantity[i] < r[i]) {
                        valid = true;
                        break;
                    }
                    int kits = total_quantity[i] / r[i];
                    min_kits = min(min_kits, kits);
                }
                if (valid) {
                    for (int i = 0; i < n; ++i) {
                        if (total_quantity[i] >= r[i] * min_kits) {
                            total_quantity[i] -= r[i] * min_kits;
                        } else {
                            total_quantity[i] = 0;
                        }
                    }
                    num_kits += min_kits;
                }
            }
            max_kits = max(max_kits, num_kits);
        }
        cout << "Case #" << test_case << ": " << max_kits << endl;
    }
    return 0;
}
