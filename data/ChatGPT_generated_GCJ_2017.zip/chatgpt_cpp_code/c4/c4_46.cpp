#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> count(N);
            int servings = 1;
            for (int j = 0; j < P; j++) {
                if ((mask >> j) & 1) {
                    for (int i = 0; i < N; i++) {
                        count[i] += Q[i][j];
                    }
                    servings++;
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int need = servings * R[i];
                bool found = false;
                for (int j = 0; j < P; j++) {
                    if ((mask >> j) & 1) {
                        if (Q[i][j] >= need * 9 && Q[i][j] <= need * 11) {
                            found = true;
                            break;
                        }
                    }
                }
                if (!found) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, servings);
            }
        }
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
