#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<vector<int>> indices(N);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                if (Q[i][j] >= 9 * R[i] && Q[i][j] <= 11 * R[i]) {
                    indices[i].push_back(j);
                }
            }
        }

        int ans = 0;

        vector<int> current(N);
        while (true) {
            bool valid = true;
            for (int i = 0; i < N; i++) {
                if (indices[i].empty()) {
                    valid = false;
                    break;
                }
                current[i] = indices[i][0];
            }
            if (!valid) {
                break;
            }

            int servings = 0;
            for (int i = 0; i < N; i++) {
                servings = max(servings, ceil(1.0 * Q[i][current[i]] / R[i]));
            }

            int count = 1;
            for (int i = 0; i < N; i++) {
                if (Q[i][current[i]] < servings * 9 * R[i] || Q[i][current[i]] > servings * 11 * R[i]) {
                    count = 0;
                    break;
                }
            }

            ans += count;

            int i = N - 1;
            while (i >= 0 && indices[i].size() > 1 && current[i] == indices[i].back()) {
                current[i] = indices[i][0];
                i--;
            }
            if (i < 0) {
                break;
            }
            auto it = upper_bound(indices[i].begin(), indices[i].end(), current[i]);
            current[i] = *it;
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
