#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int MAXN = 50;
const int MAXP = 50;

int T, N, P;
int R[MAXN], Q[MAXN][MAXP];

bool isValid(int servings, vector<int>& quantities) {
    for (int i = 0; i < N; i++) {
        int total = 0;
        for (int j = 0; j < P; j++) {
            total += Q[i][j];
        }
        int required = servings * R[i];
        int min_qty = required * 9 / 10;
        int max_qty = required * 11 / 10;
        if (total < min_qty || total > max_qty) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    vector<int> quantities(P, 0);
    for (int i = 0; i < P; i++) {
        quantities[i] = i;
    }
    int max_kits = 0;
    do {
        int l = 0, r = 1e9;
        while (l < r) {
            int m = (l + r + 1) / 2;
            if (isValid(m, quantities)) {
                l = m;
            } else {
                r = m - 1;
            }
        }
        max_kits = max(max_kits, l);
    } while (next_permutation(quantities.begin(), quantities.end()));
    return max_kits;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
