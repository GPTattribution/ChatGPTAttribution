#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        for (int i = 0; i < P; i++) {
            vector<int> amounts(N);
            for (int j = 0; j < N; j++) {
                amounts[j] = Q[j][i];
            }

            sort(amounts.begin(), amounts.end());

            for (int k = 1; k <= 1000; k++) {
                bool valid = true;
                int lo = (k * 9 * R[0] + 10 - 1) / 10;
                int hi = (k * 11 * R[0]) / 10;

                for (int j = 0; j < N; j++) {
                    int needed = k * R[j];
                    int idx = lower_bound(amounts.begin(), amounts.end(), lo) - amounts.begin();
                    if (idx == P || amounts[idx] > hi || amounts[idx] < lo) {
                        valid = false;
                        break;
                    }
                    amounts.erase(amounts.begin() + idx);
                }

                if (valid) {
                    max_kits++;
                } else {
                    break;
                }
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
