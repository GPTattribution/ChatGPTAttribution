#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;

        for (int mask = 0; mask < (1 << P); mask++) {
            bool valid = true;
            int cnt = -1;
            for (int i = 0; i < N; i++) {
                int num = 0;
                for (int j = 0; j < P; j++) {
                    if (mask & (1 << j)) {
                        num++;
                    }
                }
                if (cnt == -1) {
                    cnt = num;
                } else if (cnt != num) {
                    valid = false;
                    break;
                }
            }
            if (!valid) {
                continue;
            }

            int servings = 1e9;
            for (int i = 0; i < N; i++) {
                int sum = 0;
                for (int j = 0; j < P; j++) {
                    if (mask & (1 << j)) {
                        sum += Q[i][j];
                    }
                }
                servings = min(servings, sum / R[i]);
            }

            valid = true;
            for (int i = 0; i < N; i++) {
                int sum = 0;
                for (int j = 0; j < P; j++) {
                    if (mask & (1 << j)) {
                        sum += Q[i][j];
                    }
                }
                if (sum < servings * R[i] * 9 / 10 || sum > servings * R[i] * 11 / 10) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, servings);
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
