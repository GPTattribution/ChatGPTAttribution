#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N), minQ(P), maxQ(P);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                int Qij;
                cin >> Qij;
                minQ[j] = ceil(R[i] * 0.9 / Qij);
                maxQ[j] = floor(R[i] * 1.1 / Qij);
            }
        }
        int ans = 0;
        for (int i = 1; i <= 1000000; i++) {
            bool possible = true;
            for (int j = 0; j < N; j++) {
                bool found = false;
                for (int k = 0; k < P; k++) {
                    if (minQ[k] <= i && i <= maxQ[k]) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    possible = false;
                    break;
                }
            }
            if (possible) {
                ans++;
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
