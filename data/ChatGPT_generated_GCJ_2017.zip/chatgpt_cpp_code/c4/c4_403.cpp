#include<bits/stdc++.h>
using namespace std;

const int MAXN = 50;
const int MAXP = 50;

int T, N, P;
int R[MAXN], Q[MAXP][MAXN];

bool can_make_kits(int servings) {
    vector<int> upper(N, 110 * servings), lower(N, 90 * servings);
    for (int i = 0; i < N; i++) {
        int total_upper = 0, total_lower = 0;
        for (int j = 0; j < P; j++) {
            total_upper += min(Q[j][i], upper[i]);
            total_lower += max(Q[j][i], lower[i]);
        }
        if (total_upper < R[i] * servings || total_lower > R[i] * servings) {
            return false;
        }
    }
    return true;
}

int binary_search() {
    int lo = 0, hi = 1000000000;
    while (lo < hi) {
        int mid = (lo + hi + 1) / 2;
        if (can_make_kits(mid)) {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }
    return lo;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> N >> P;
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        for (int i = 0; i < P; i++) {
            for (int j = 0; j < N; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = binary_search();
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
