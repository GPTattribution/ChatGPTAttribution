#include <bits/stdc++.h>
using namespace std;

#define ll long long

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<ll> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<ll>> q(n, vector<ll>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        ll ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<ll> sum(n, 0);
            int cnt = 0;
            for (int k = 0; k < p; k++) {
                if ((mask >> k) & 1) {
                    cnt++;
                    for (int j = 0; j < n; j++) {
                        sum[j] += q[j][k];
                    }
                }
            }
            bool ok = true;
            for (int j = 0; j < n; j++) {
                ll low = (ll)ceil(r[j] * 0.9 * cnt);
                ll high = (ll)floor(r[j] * 1.1 * cnt);
                if (sum[j] < low || sum[j] > high) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, (ll)cnt);
            }
        }
        cout << "Case #" << i << ": " << ans << "\n";
    }
    return 0;
}
