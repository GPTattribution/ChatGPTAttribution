#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool isPossible(const vector<int>& servings, const vector<vector<int>>& packages, const vector<int>& recipe) {
    int n = servings.size();
    for (int i = 0; i < n; i++) {
        double total = 0;
        for (int j = 0; j < packages[i].size(); j++) {
            total += (double)packages[i][j] / servings[j];
        }
        double r = (double)recipe[i] / servings[0];
        if (total < r * 0.9 || total > r * 1.1) {
            return false;
        }
    }
    return true;
}

int solve(int n, int p, const vector<int>& recipe, const vector<vector<int>>& packages) {
    vector<int> servings(p, 1);
    int ans = 0;
    while (true) {
        if (isPossible(servings, packages, recipe)) {
            ans++;
        }
        int i = p - 1;
        while (i >= 0 && servings[i] == 100) {
            servings[i] = 1;
            i--;
        }
        if (i < 0) {
            break;
        }
        servings[i]++;
    }
    return ans;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> recipe(n);
        for (int j = 0; j < n; j++) {
            cin >> recipe[j];
        }
        vector<vector<int>> packages(n, vector<int>(p));
        for (int j = 0; j < p; j++) {
            for (int k = 0; k < n; k++) {
                cin >> packages[k][j];
            }
        }
        int ans = solve(n, p, recipe, packages);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
