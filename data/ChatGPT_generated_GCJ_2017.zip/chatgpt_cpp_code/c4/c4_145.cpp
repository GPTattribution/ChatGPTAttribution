#include <iostream>
#include <vector>
using namespace std;

const double MIN_PERCENT = 0.9;
const double MAX_PERCENT = 1.1;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int max_kits = 0;
        for (int k = 1; k <= 1000000; k++) {
            int kits = k;
            bool found_kit = true;

            for (int i = 0; i < N; i++) {
                double total_weight = R[i] * k * MIN_PERCENT;
                double max_weight = R[i] * k * MAX_PERCENT;

                double package_weight = 0;
                for (int j = 0; j < P; j++) {
                    package_weight += Q[i][j];
                }

                bool has_ingredient = false;
                for (int j = 0; j < P; j++) {
                    if (Q[i][j] >= total_weight && Q[i][j] <= max_weight) {
                        Q[i][j] = -1;
                        has_ingredient = true;
                        break;
                    }
                }

                if (!has_ingredient) {
                    found_kit = false;
                    break;
                }
            }

            if (found_kit) {
                max_kits = k;
            } else {
                break;
            }
        }

        cout << "Case #" << t << ": " << max_kits << endl;
    }

    return 0;
}
