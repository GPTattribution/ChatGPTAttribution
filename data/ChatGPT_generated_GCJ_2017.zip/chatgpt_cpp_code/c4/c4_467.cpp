#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> kit(N);
            for (int i = 0; i < N; i++) {
                int sum = 0;
                for (int j = 0; j < P; j++) {
                    if ((mask >> j) & 1) {
                        sum += Q[i][j];
                    }
                }
                kit[i] = sum;
            }
            int servings = INT_MAX;
            for (int i = 0; i < N; i++) {
                int lower = ceil(0.9 * kit[i] / R[i]);
                int upper = floor(1.1 * kit[i] / R[i]);
                if (lower > upper) {
                    servings = -1;
                    break;
                } else {
                    servings = min(servings, upper);
                }
            }
            if (servings != -1) {
                int kits = 1;
                for (int i = 0; i < N; i++) {
                    int amount = servings * R[i];
                    for (int j = 0; j < P; j++) {
                        if ((mask >> j) & 1 && Q[i][j] < amount) {
                            kits = 0;
                            break;
                        }
                    }
                    if (kits == 0) {
                        break;
                    }
                }
                max_kits = max(max_kits, kits);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
