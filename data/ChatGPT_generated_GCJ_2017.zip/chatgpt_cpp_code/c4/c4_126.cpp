#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n), lower(n), upper(n);
        vector<vector<int>> q(n, vector<int>(p));

        for (int j = 0; j < n; j++) {
            cin >> r[j];
            lower[j] = static_cast<int>(ceil(0.9 * r[j]));
            upper[j] = static_cast<int>(floor(1.1 * r[j]));
        }

        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int max_kits = 0;

        for (int k = 1; k <= 1000000; k++) {
            vector<int> max_quantity(n, 0);

            for (int j = 0; j < n; j++) {
                for (int l = 0; l < p; l++) {
                    if (lower[j] * k <= q[j][l] && q[j][l] <= upper[j] * k) {
                        max_quantity[j] = max(max_quantity[j], q[j][l]);
                    }
                }
            }

            int kit_count = 0;

            for (int j = 0; j < n; j++) {
                if (max_quantity[j] == 0) {
                    kit_count = 0;
                    break;
                } else {
                    kit_count = max(kit_count, (max_quantity[j] + k * upper[j] - 1) / (k * upper[j]));
                }
            }

            max_kits = max(max_kits, kit_count);
        }

        cout << "Case #" << i << ": " << max_kits << endl;
    }

    return 0;
}
