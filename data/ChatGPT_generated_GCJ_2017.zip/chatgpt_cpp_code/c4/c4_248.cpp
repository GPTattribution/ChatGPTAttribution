#include <iostream>
#include <vector>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> sum(N);
            int num_kits = 0;

            for (int i = 0; i < P; i++) {
                if ((mask >> i) & 1) {
                    num_kits++;
                    for (int j = 0; j < N; j++) {
                        sum[j] += Q[j][i];
                    }
                }
            }

            bool valid = true;
            for (int i = 0; i < N; i++) {
                int min_amt = R[i] * num_kits * 9 / 10;
                int max_amt = R[i] * num_kits * 11 / 10;
                if (sum[i] < min_amt || sum[i] > max_amt) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                ans = max(ans, num_kits);
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
