#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> total(n);
            int count = 0;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    count++;
                    for (int i = 0; i < n; i++) {
                        total[i] += q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < n; i++) {
                double needed = static_cast<double>(r[i]) * count;
                if (total[i] < 0.9 * needed || total[i] > 1.1 * needed) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, count);
            }
        }
        cout << "Case #" << case_num << ": " << ans << endl;
    }
    return 0;
}
