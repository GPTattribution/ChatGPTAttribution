#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> max_serves(P, 0);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                max_serves[j] = Q[i][j] / (int)round(R[i] * 1.1);
            }
        }
        int max_kits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            int num_kits = 0;
            vector<int> remaining(P, 0);
            for (int j = 0; j < P; j++) {
                if ((mask >> j) & 1) {
                    num_kits++;
                    for (int i = 0; i < N; i++) {
                        remaining[i] += Q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int needed = remaining[i] / (num_kits * R[i]);
                int max_needed = (int)round(needed * 1.1);
                int min_needed = (int)round(needed * 0.9);
                if (max_needed < 1 || min_needed > max_serves[0]) {
                    valid = false;
                    break;
                }
                if (min_needed < 1) {
                    min_needed = 1;
                }
                int j = 0;
                for (; j < P; j++) {
                    if (!((mask >> j) & 1)) {
                        continue;
                    }
                    if (Q[i][j] < min_needed * R[i] || Q[i][j] > max_needed * R[i]) {
                        valid = false;
                        break;
                    }
                }
                if (j == P) {
                    remaining[i] -= needed * num_kits * R[i];
                }
                if (!valid) {
                    break;
                }
            }
            if (valid) {
                max_kits = max(max_kits, num_kits);
            }
        }
        cout << "Case #" << t << ": " << max_kits << endl;
    }
    return 0;
}
