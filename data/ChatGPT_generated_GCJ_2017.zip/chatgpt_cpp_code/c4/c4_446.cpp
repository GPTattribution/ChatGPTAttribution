#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

const double EPS = 1e-9;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        vector<int> idx(N, 0);
        while (true) {
            bool valid = true;
            int servings = Q[0][idx[0]] / R[0];
            for (int i = 1; i < N; i++) {
                if (Q[i][idx[i]] / R[i] != servings) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans++;

                for (int i = 0; i < N; i++) {
                    idx[i]++;
                }
            } else {
                bool done = false;
                for (int i = N - 1; i >= 0; i--) {
                    idx[i]++;
                    if (idx[i] == P) {
                        idx[i] = 0;
                    } else {
                        done = true;
                        break;
                    }
                }
                if (!done) {
                    break;
                }
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
