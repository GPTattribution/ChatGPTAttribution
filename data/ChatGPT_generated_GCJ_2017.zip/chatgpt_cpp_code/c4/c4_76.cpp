#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> max_kits(P, 0);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                int low = (90 * R[i] * j + 99) / 100;
                int high = (110 * R[i] * j) / 100;
                int k = -1;
                for (int l = 0; l < P; l++) {
                    if (Q[i][l] >= low && Q[i][l] <= high) {
                        k = l;
                        break;
                    }
                }
                if (k == -1) {
                    max_kits[j] = 0;
                    break;
                }
                max_kits[k]++;
            }
        }
        int ans = *min_element(max_kits.begin(), max_kits.end());
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
