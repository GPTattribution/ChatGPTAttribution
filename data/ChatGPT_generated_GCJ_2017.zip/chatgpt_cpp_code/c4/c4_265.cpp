#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        vector<int> indices(N);
        for (int i = 0; i < N; i++) {
            indices[i] = i;
        }
        do {
            bool ok = true;
            int servings = 0;
            vector<int> mins(N), maxs(N);
            for (int i = 0; i < N; i++) {
                int sum = 0;
                for (int j = 0; j < P; j++) {
                    sum += Q[indices[i]][j];
                }
                mins[i] = R[indices[i]] * 9 * P;
                maxs[i] = R[indices[i]] * 11 * P;
                if (sum < mins[i] || sum > maxs[i]) {
                    ok = false;
                    break;
                }
                servings = max(servings, sum / R[indices[i]]);
            }
            if (ok) {
                ans = max(ans, servings);
            }
        } while (next_permutation(indices.begin(), indices.end()));

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
