#include <bits/stdc++.h>
using namespace std;

const int MAXN = 55, MAXP = 55;

int T, n, p, ans;
int r[MAXN], q[MAXN][MAXP];
bool used[MAXN][MAXP];

bool check(int x) {
    int sum[MAXN];
    memset(sum, 0, sizeof(sum));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < p; j++) {
            if (used[i][j]) {
                sum[i] += q[i][j];
            }
        }
        int low = (int)(r[i] * 0.9 * x), high = (int)(r[i] * 1.1 * x);
        if (sum[i] < low || sum[i] > high) {
            return false;
        }
    }
    return true;
}

void dfs(int cur) {
    if (cur == n) {
        int l = 1, r = 1000, mid;
        while (l <= r) {
            mid = (l + r) / 2;
            if (check(mid)) {
                l = mid + 1;
            } else {
                r = mid - 1;
            }
        }
        ans = max(ans, l - 1);
        return;
    }
    for (int i = 0; i < p; i++) {
        used[cur][i] = true;
        dfs(cur + 1);
        used[cur][i] = false;
    }
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        ans = 0;
        memset(used, false, sizeof(used));
        cin >> n >> p;
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        dfs(0);
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
