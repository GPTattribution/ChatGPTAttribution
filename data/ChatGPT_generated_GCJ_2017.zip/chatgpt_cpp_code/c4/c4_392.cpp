#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            cin >> R[i];
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> max_kits(P);
        for (int j = 0; j < P; j++) {
            int max_kit = 0;
            for (int bitmask = 0; bitmask < (1 << N); bitmask++) {
                int total_qty = 0;
                int total_need = 0;
                for (int i = 0; i < N; i++) {
                    if (bitmask & (1 << i)) {
                        total_qty += Q[i][j];
                        total_need += R[i];
                    }
                }
                if (total_qty >= 0.9 * total_need && total_qty <= 1.1 * total_need) {
                    int num_kits = total_qty / total_need;
                    max_kit = max(max_kit, num_kits);
                }
            }
            max_kits[j] = max_kit;
        }
        int ans = 0;
        sort(max_kits.begin(), max_kits.end());
        for (int j = P-1; j >= 0; j--) {
            if (max_kits[j] > 0) {
                ans++;
                for (int k = 0; k < j; k++) {
                    max_kits[k] -= max_kits[j];
                }
            }
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
