#include <bits/stdc++.h>
using namespace std;

const int MAXN = 55, MAXP = 55;

int t, n, p, r[MAXN], q[MAXN][MAXP];

int main() {
    cin >> t;

    for (int c = 1; c <= t; c++) {
        cin >> n >> p;

        for (int i = 0; i < n; i++)
            cin >> r[i];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }

        int ans = 0;

        for (int i = 0; i < p; i++) {
            bool flag = true;
            vector<int> amount;

            for (int j = 0; j < n; j++) {
                amount.push_back(q[j][i]);
            }

            sort(amount.begin(), amount.end());

            for (int servings = 1; flag; servings++) {
                flag = false;

                for (int j = 0; j < n; j++) {
                    int min_amt = r[j] * servings * 9;
                    int max_amt = r[j] * servings * 11;

                    if (amount[j] < min_amt || amount[j] > max_amt) {
                        flag = true;
                        break;
                    }
                }

                if (!flag) {
                    ans++;
                    for (int j = 0; j < n; j++) {
                        amount[j] -= r[j] * servings;
                    }
                }
            }
        }

        cout << "Case #" << c << ": " << ans << endl;
    }

    return 0;
}
