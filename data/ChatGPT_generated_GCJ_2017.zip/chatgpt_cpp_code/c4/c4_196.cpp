#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        vector<vector<int>> packages;
        for (int i = 0; i < P; i++) {
            vector<int> curr;
            for (int j = 0; j < N; j++) {
                curr.push_back(Q[j][i]);
            }
            packages.push_back(curr);
        }
        int numPackages = packages.size();

        int maxKits = 0;
        for (int i = 0; i < numPackages; i++) {
            for (int j = i + 1; j < numPackages; j++) {
                for (int k = j + 1; k < numPackages; k++) {
                    vector<int> servings;
                    servings.push_back(packages[i][0] / R[0]);
                    servings.push_back(packages[j][1] / R[1]);
                    servings.push_back(packages[k][2] / R[2]);
                    sort(servings.begin(), servings.end());
                    int numKits = 0;
                    for (int l = 0; l < servings.size(); l++) {
                        if (servings[l] < 9 || servings[l] > 11) {
                            break;
                        }
                        if (l == servings.size() - 1) {
                            numKits++;
                        }
                    }
                    if (numKits > maxKits) {
                        maxKits = numKits;
                    }
                }
            }
        }

        cout << "Case #" << t << ": " << maxKits << endl;
    }

    return 0;
}
