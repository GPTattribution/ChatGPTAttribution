#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int maxKits = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> totalQ(N);
            for (int j = 0; j < P; j++) {
                if ((mask >> j) & 1) {
                    for (int i = 0; i < N; i++) {
                        totalQ[i] += Q[i][j];
                    }
                }
            }
            int minK = 1e9;
            for (int i = 0; i < N; i++) {
                int k = (100 * totalQ[i] + 110 * R[i] - 1) / (110 * R[i]);
                if (k == 0) {
                    minK = 0;
                    break;
                }
                minK = min(minK, k);
            }
            if (minK > 0) {
                maxKits = max(maxKits, __builtin_popcount(mask));
            }
        }
        cout << "Case #" << t << ": " << maxKits << endl;
    }
    return 0;
}
