#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
            sort(Q[i].begin(), Q[i].end());
        }
        int ans = 0;
        for (int k = 1; k <= 10000; k++) {
            vector<int> q(P);
            for (int i = 0; i < N; i++) {
                int need = R[i] * k;
                int l = lower_bound(Q[i].begin(), Q[i].end(), need * 9 / 10) - Q[i].begin();
                int r = upper_bound(Q[i].begin(), Q[i].end(), need * 11 / 10) - Q[i].begin() - 1;
                if (l <= r) {
                    q[i] = Q[i][l];
                } else {
                    q.clear();
                    break;
                }
            }
            if (q.empty()) {
                break;
            }
            ans = k;
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
