#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;

    for(int i = 1; i <= t; i++)
    {
        int n, p;
        cin >> n >> p;

        int r[n], q[n][p];
        for(int j = 0; j < n; j++)
            cin >> r[j];

        for(int j = 0; j < n; j++)
            for(int k = 0; k < p; k++)
                cin >> q[j][k];

        vector<int> maxKits(p, 0);
        for(int j = 0; j < n; j++)
        {
            vector<pair<int, int>> packages(p);
            for(int k = 0; k < p; k++)
                packages[k] = make_pair(q[j][k], k);

            sort(packages.begin(), packages.end());

            int maxServings = 0;
            vector<bool> used(p, false);
            for(int k = 0; k < p; k++)
            {
                int idx = packages[k].second;
                int quantity = packages[k].first;

                for(int l = 1; l <= p; l++)
                {
                    int servings = (r[j] * l);
                    int lowerLimit = (int) ceil((0.9 * servings) / quantity);
                    int upperLimit = (int) floor((1.1 * servings) / quantity);

                    if(lowerLimit <= l && l <= upperLimit && !used[idx])
                    {
                        used[idx] = true;
                        maxServings += l;
                        break;
                    }
                }
            }

            maxKits = maxServings;
        }

        int ans = *min_element(maxKits.begin(), maxKits.end());
        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
