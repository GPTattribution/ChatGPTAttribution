#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAXN = 55;
const int MAXP = 55;

int N, P;
int R[MAXN], Q[MAXN][MAXP];

bool check(int s, vector<int>& cnt) {
    for (int i = 0; i < N; i++) {
        int total = 0;
        for (int j = 0; j < P; j++) {
            total += Q[i][j] * cnt[j];
        }
        if (total < s * R[i] * 9 || total > s * R[i] * 11) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }

    vector<int> cnt(P);
    for (int i = 0; i < P; i++) {
        cnt[i] = i;
    }

    int ans = 0;
    do {
        int lo = 0, hi = 1000000;
        while (lo < hi) {
            int mid = (lo + hi + 1) / 2;
            if (check(mid, cnt)) {
                lo = mid;
            } else {
                hi = mid - 1;
            }
        }
        ans = max(ans, lo);
    } while (next_permutation(cnt.begin(), cnt.end()));

    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
