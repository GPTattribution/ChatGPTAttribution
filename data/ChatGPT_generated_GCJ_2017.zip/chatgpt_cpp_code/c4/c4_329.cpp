#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }
        vector<int> kits;
        for (int j = 0; j < p; j++) {
            vector<int> amounts(n);
            for (int k = 0; k < n; k++) {
                amounts[k] = q[k][j];
            }
            sort(amounts.begin(), amounts.end());
            int servings = 0;
            for (int k = 0; k < n; k++) {
                int amount = amounts[k];
                int needed = r[k];
                int min_amount = needed * servings;
                int max_amount = needed * servings * 1.1;
                if (amount < min_amount || amount > max_amount) {
                    break;
                }
                servings++;
            }
            kits.push_back(servings);
        }
        int max_kits = 0;
        for (int j = 0; j < (1 << p); j++) {
            int total_kits = 0;
            vector<int> counts(n, 0);
            for (int k = 0; k < p; k++) {
                if (j & (1 << k)) {
                    total_kits++;
                    for (int l = 0; l < n; l++) {
                        counts[l] += q[l][k];
                    }
                }
            }
            bool valid = true;
            for (int k = 0; k < n; k++) {
                int needed = r[k] * total_kits;
                int min_amount = needed * 9 / 10;
                int max_amount = needed * 11 / 10;
                if (counts[k] < min_amount || counts[k] > max_amount) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                max_kits = max(max_kits, total_kits);
            }
        }
        cout << "Case #" << i << ": " << max_kits << endl;
    }
    return 0;
}
