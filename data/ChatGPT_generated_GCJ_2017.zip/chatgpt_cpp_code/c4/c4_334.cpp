#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

const int MAXN = 50;
const double EPS = 1e-9;

int N, P, R[MAXN];
vector<int> Q[MAXN];

bool check(int servings) {
    vector<pair<int, int>> ranges;
    for (int i = 0; i < N; i++) {
        int low = (int)ceil(R[i] * servings * 0.9 / Q[i][0]);
        int high = (int)floor(R[i] * servings * 1.1 / Q[i][P - 1]);
        if (low > high) return false;
        ranges.emplace_back(low, high);
    }
    sort(ranges.begin(), ranges.end());
    int L = ranges[0].first, R = ranges[0].second;
    for (int i = 1; i < N; i++) {
        L = max(L, ranges[i].first);
        R = min(R, ranges[i].second);
        if (L > R) return false;
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
        Q[i].resize(P);
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
        sort(Q[i].begin(), Q[i].end());
    }
    int lo = 0, hi = 1e9, ans = 0;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        if (check(mid)) {
            ans = mid;
            lo = mid + 1;
        } else {
            hi = mid - 1;
        }
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
