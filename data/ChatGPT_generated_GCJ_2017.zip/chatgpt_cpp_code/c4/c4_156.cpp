#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        for (int i = 0; i < P; i++) {
            vector<int> max_q(N);
            for (int j = 0; j < N; j++) {
                max_q[j] = (110 * R[j] + Q[j][i] - 1) / Q[j][i];
            }
            int kits = *min_element(max_q.begin(), max_q.end());
            bool valid = true;
            for (int j = 0; j < N; j++) {
                if (Q[j][i] < kits * R[j] * 90 / 100 || Q[j][i] > kits * R[j] * 110 / 100) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans += 1;
                for (int j = 0; j < N; j++) {
                    Q[j][i] = 0;
                }
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
