#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>
using namespace std;

const int MAXN = 55, MAXP = 55, MAXQ = 1000005;

int N, P, R[MAXN], Q[MAXN][MAXP];
int dp[MAXN][MAXQ];

int solve() {
    memset(dp, -1, sizeof(dp));
    dp[0][0] = 0;
    for (int i = 1; i <= N; ++i) {
        for (int j = 0; j < P; ++j) {
            for (int k = 0; k < MAXQ; ++k) {
                if (dp[i - 1][k] != -1) {
                    int x = min(110 * k / R[i] - Q[i][j], (k * 100 + R[i] - 1) / R[i] - Q[i][j]);
                    if (x >= 0 && x <= P - 1) {
                        dp[i][k + x * R[i]] = max(dp[i][k + x * R[i]], dp[i - 1][k] + 1);
                    }
                }
            }
        }
    }
    int ans = 0;
    for (int k = 0; k < MAXQ; ++k) {
        ans = max(ans, dp[N][k]);
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        cin >> N >> P;
        for (int i = 1; i <= N; ++i) {
            cin >> R[i];
        }
        for (int i = 1; i <= N; ++i) {
            for (int j = 0; j < P; ++j) {
                cin >> Q[i][j];
            }
            sort(Q[i], Q[i] + P);
        }
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
