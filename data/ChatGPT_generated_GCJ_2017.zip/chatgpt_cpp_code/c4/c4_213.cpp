#include <iostream>
#include <vector>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> sum(N);
            int count = 0;
            bool valid = true;

            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    count++;
                    for (int i = 0; i < N; i++) {
                        sum[i] += Q[i][j];
                    }
                }
            }

            for (int i = 0; i < N; i++) {
                if (sum[i] < R[i] * count * 9 / 10 || sum[i] > R[i] * count * 11 / 10) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                ans = max(ans, count);
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
