#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define debug(x) cerr << #x << ": " << x << endl
#define pb push_back
#define mp make_pair

const int INF = 1e9;

int T;
int N, P;
int R[50];
int Q[50][50];

bool possible(int s, vector<int>& cnt) {
    for (int i = 0; i < N; i++) {
        int l = R[i] * s * 9;
        int r = R[i] * s * 11;
        if (cnt[i] * 10 < l || cnt[i] * 10 > r) {
            return false;
        }
    }
    return true;
}

int solve() {
    cin >> N >> P;
    for (int i = 0; i < N; i++) {
        cin >> R[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cin >> Q[i][j];
        }
    }
    int ans = 0;
    for (int mask = 0; mask < (1 << P); mask++) {
        vector<int> cnt(N, 0);
        int sum = 0;
        for (int i = 0; i < P; i++) {
            if ((mask >> i) & 1) {
                for (int j = 0; j < N; j++) {
                    cnt[j] += Q[j][i];
                }
                sum++;
            }
        }
        for (int i = 1; i <= sum; i++) {
            if (possible(i, cnt)) {
                ans = max(ans, i);
            }
        }
    }
    return ans;
}

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int ans = solve();
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
