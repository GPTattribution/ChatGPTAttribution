#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int i = 0; i < P; i++) {
            vector<int> kits(N);
            for (int j = 0; j < N; j++) {
                kits[j] = Q[j][i];
            }
            sort(kits.begin(), kits.end());
            int max_kits = kits[0] / ceil(R[0] * 1.1 / kits.size());
            for (int k = 1; k < kits.size(); k++) {
                if (kits[k] > R[k] * 1.1 * max_kits) {
                    break;
                }
                max_kits = min(max_kits, kits[k] / ceil(R[k] * 1.1 / kits.size()));
            }
            ans += max_kits;
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
