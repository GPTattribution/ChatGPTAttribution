#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        vector<int> indices(P);
        for (int i = 0; i < P; i++) {
            indices[i] = i;
        }
        int ans = 0;
        do {
            int servings = INT_MAX;
            for (int i = 0; i < N; i++) {
                servings = min(servings, Q[i][indices[0]] / R[i]);
            }
            for (int s = 1; s <= servings; s++) {
                bool valid = true;
                for (int i = 0; i < N; i++) {
                    int total = 0;
                    for (int j = 0; j < P; j++) {
                        total += Q[i][indices[j]];
                    }
                    if (total < s * R[i] * 9 / 10 || total > s * R[i] * 11 / 10) {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    ans = max(ans, s);
                }
            }
        } while (next_permutation(indices.begin(), indices.end()));
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
