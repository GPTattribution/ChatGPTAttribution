#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        int n, p;
        cin >> n >> p;

        vector<int> r(n);
        for (int j = 0; j < n; j++) {
            cin >> r[j];
        }

        vector<vector<int>> q(n, vector<int>(p));
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < p; k++) {
                cin >> q[j][k];
            }
        }

        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            bool valid = true;
            vector<int> amount(n, 0);
            int servings = 1;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    for (int k = 0; k < n; k++) {
                        amount[k] += q[k][j];
                    }
                    servings++;
                }
            }
            for (int j = 0; j < n; j++) {
                int min_amount = servings * r[j] * 9;
                int max_amount = servings * r[j] * 11;
                if (amount[j] < min_amount || amount[j] > max_amount) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, servings);
            }
        }

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
