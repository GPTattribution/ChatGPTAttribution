#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;

        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }

        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
            sort(Q[i].begin(), Q[i].end());
        }

        int ans = 0;
        vector<int> indexes(N);
        fill(indexes.begin(), indexes.end(), 0);

        while (true) {
            bool can_make_kit = true;
            int servings = Q[0][indexes[0]] / R[0];

            for (int i = 1; i < N; i++) {
                int package = Q[i][indexes[i]];
                int required = servings * R[i];

                if (package < required * 9 / 10 || package > required * 11 / 10) {
                    can_make_kit = false;
                    break;
                }
            }

            if (can_make_kit) {
                ans++;
                for (int i = 0; i < N; i++) {
                    indexes[i]++;
                    if (indexes[i] == P) {
                        break;
                    }
                }
            } else {
                bool found_next = false;
                for (int i = N - 1; i >= 0; i--) {
                    indexes[i]++;
                    if (indexes[i] < P) {
                        found_next = true;
                        break;
                    } else {
                        indexes[i] = 0;
                    }
                }

                if (!found_next) {
                    break;
                }
            }
        }

        cout << "Case #" << t << ": " << ans << endl;
    }

    return 0;
}
