#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int N, P;
        cin >> N >> P;
        vector<int> R(N);
        for (int i = 0; i < N; i++) {
            cin >> R[i];
        }
        vector<vector<int>> Q(N, vector<int>(P));
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < P; j++) {
                cin >> Q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << P); mask++) {
            vector<int> counts(N, 0);
            int servings = 0;
            for (int j = 0; j < P; j++) {
                if (mask & (1 << j)) {
                    servings++;
                    for (int i = 0; i < N; i++) {
                        counts[i] += Q[i][j];
                    }
                }
            }
            bool valid = true;
            for (int i = 0; i < N; i++) {
                int needed = servings * R[i];
                auto it = minmax_element(counts.begin(), counts.end());
                if (*it.first < 9 * needed || *it.second > 11 * needed) {
                    valid = false;
                    break;
                }
            }
            if (valid) {
                ans = max(ans, servings);
            }
        }
        cout << "Case #" << t << ": " << ans << "\n";
    }
    return 0;
}
