#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        int n, p;
        cin >> n >> p;
        vector<int> r(n);
        for (int i = 0; i < n; i++) {
            cin >> r[i];
        }
        vector<vector<int>> q(n, vector<int>(p));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < p; j++) {
                cin >> q[i][j];
            }
        }
        int ans = 0;
        for (int mask = 0; mask < (1 << p); mask++) {
            vector<int> sum(n);
            int num_kits = 0;
            bool ok = true;
            for (int j = 0; j < p; j++) {
                if (mask & (1 << j)) {
                    num_kits++;
                    for (int i = 0; i < n; i++) {
                        sum[i] += q[i][j];
                    }
                }
            }
            for (int i = 0; i < n; i++) {
                if (sum[i] < r[i] * num_kits * 9 / 10 || sum[i] > r[i] * num_kits * 11 / 10) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                ans = max(ans, num_kits);
            }
        }
        cout << "Case #" << case_num << ": " << ans << endl;
    }
    return 0;
}
