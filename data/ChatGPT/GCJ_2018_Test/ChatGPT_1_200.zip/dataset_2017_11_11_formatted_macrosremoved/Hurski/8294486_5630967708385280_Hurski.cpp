#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(NULL);
    int t;
    cin>>t;
    for(int ti=1;ti<=t;ti++){
        int n;
        double s,t=0.0;
        cin>>s>>n;
        for(int i=0;i<n;i++){
            double x,y;
            cin>>x>>y;
            t=max(t,(s-x)/y);
        }
        cout<<"Case #"<<ti<<": "<<fixed<<setprecision(10)<<s/t<<endl;
    }
    return 0;
}
