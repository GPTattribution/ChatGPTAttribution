#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio(0);
    ifstream fin("input.txt");
    int t;
    cin>>t;
    for(int ti=1;ti<=t;ti++){
        int n;
        string s;
        cin>>n>>s;
        stack <int> st;
        int c=1,d=0,ans=0;
        for(int i=0;i<s.length();i++){
            if(s[i]=='C'){
                st.push(i);
                c=c*2;
            }else if(s[i]=='S') d=d+c;
        }
        if(d>n){
            int flag=0;
            while(!st.empty()){
                if(flag==1) break;
                int j = st.top();
                for(int i=j+1;i<s.length();i++){
                    if(d<=n){
                        flag=1;
                        break;
                    }
                    swap(s[i],s[i-1]);
                    d=d-pow(2,st.size())+pow(2,st.size()-1);
                    ans++;
                }
                st.pop();
            }
        }
        if(d>n) cout<<"Case #"<<ti<<": IMPOSSIBLE"<<endl;
        else cout<<"Case #"<<ti<<": "<<ans<<endl;
    }
    return 0;
}
