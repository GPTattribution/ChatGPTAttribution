#include <bits/stdc++.h>
using namespace std;

int main(){
    int t;
    cin>>t;
    for(int ti=1;ti<=t;ti++){
        priority_queue <long long> pq;
        map <long long,long long> mp;
        mp.clear();
        long long n,k;
        cin>>n>>k;
        long long mn=n,mx=n;
        pq.push(n);
        mp[n]=1;
        long long top;
        while(k>0){
            top=pq.top();
            pq.pop();
            k=k-mp[top];
            if(k<=0) break;
            if(mp.find(top/2)==mp.end()) pq.push(top/2);
            if((top%2==0)&&mp.find((top/2)-1)==mp.end()) pq.push((top/2)-1);
            mp[top/2-(top%2==0)]+=mp[top];
            mp[top/2]+=mp[top];
        }
        cout<<"Case #"<<ti<<": "<<top/2<<' '<<top/2-(top%2==0)<<endl;
    }
    return 0;
}
