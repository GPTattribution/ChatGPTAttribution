#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

const double PI = acos(-1);

std::vector<double> compute_face_centers(double A) {
    double theta = asin(A / sqrt(2));
    double phi = PI / 4;

    std::vector<double> p1 = {0.5 * cos(theta) * cos(phi), 0.5 * cos(theta) * sin(phi), 0.5 * sin(theta)};
    std::vector<double> p2 = {0.5 * cos(theta + PI / 2) * cos(phi), 0.5 * cos(theta + PI / 2) * sin(phi), 0.5 * sin(theta + PI / 2)};
    std::vector<double> p3 = {0.5 * cos(theta + PI) * cos(phi), 0.5 * cos(theta + PI) * sin(phi), 0.5 * sin(theta + PI)};

    return {p1[0], p1[1], p1[2], p2[0], p2[1], p2[2], p3[0], p3[1], p3[2]};
}

int main() {
    int T;
    double A;

    std::cin >> T;
    std::cout << std::fixed << std::setprecision(15);

    for (int t = 1; t <= T; ++t) {
        std::cin >> A;

        std::vector<double> face_centers = compute_face_centers(A);

        std::cout << "Case #" << t << ":\n";
        for (int i = 0; i < 9; i += 3) {
            std::cout << face_centers[i] << " " << face_centers[i + 1] << " " << face_centers[i + 2] << "\n";
        }
    }

    return 0;
}
