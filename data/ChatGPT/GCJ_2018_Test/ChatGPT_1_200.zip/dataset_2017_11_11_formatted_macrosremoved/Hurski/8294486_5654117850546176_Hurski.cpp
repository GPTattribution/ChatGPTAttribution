#include <bits/stdc++.h>
using namespace std;

int main(){
    int t;
    cin>>t;
    while(t--){
        long long a,b,n;
        string s;
        cin>>a>>b>>n;
        int cnt=0;
        while(a<=b){
            if(cnt==n) break;
            long long mid = a+(b-a)/2;
            cout<<mid<<endl<<flush;
            cin>>s;
            if(s=="TOO_SMALL") a=mid+1;
            else if(s=="TOO_BIG") b=mid-1;
            else if(s=="CORRECT"||s=="WRONG_ANSWER") break;
            cnt++;
        }
    }
}
