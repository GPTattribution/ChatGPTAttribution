#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    //ifstream fin("input.txt");
    int t;
    cin>>t;
    for(int ti=1;ti<=t;ti++){
        int n,x;
        cin>>n;
        vector <int> a,b,c;
        a.clear();
        b.clear();
        c.clear();
        for(int i=0;i<n;i++){
            cin>>x;
            if(i%2) b.push_back(x);
            else a.push_back(x);
        }
        sort(a.begin(),a.end());
        sort(b.begin(),b.end());
        c.push_back(0);
        for(int i=0;i<n;i++){
            if(i%2) c.push_back(b[i/2]);
            else c.push_back(a[i/2]);
        }
        c.push_back(INT_MAX);
        int p=-1;
        for(int i=1;i<=n;i++){
            if(!(c[i]>=c[i-1]&&c[i]<=c[i+1])){
                p=i;
                break;
            }
        }
        if(p==-1) cout<<"Case #"<<ti<<": OK"<<endl;
        else cout<<"Case #"<<ti<<": "<<(p-1)<<endl;
    }
    return 0;
}
