#include <bits/stdc++.h>
using namespace std;

int main(){
    int t;
    cin>>t;
    for(int ti=1;ti<=t;ti++){
        int n;
        cin>>n;
        vector< pair<int,int> >a;
        a.clear();
        int sum=0;
        for(int i=0;i<n;i++){
            int x;
            cin>>x;
            a.push_back({x,i});
            sum=sum+x;
        }
        cout<<"Case #"<<ti<<":";
        while(sum>0){
            cout<<" ";
            sort(a.begin(),a.end());
            sum--;
            a.back().first--;
            cout<<char(a.back().second+(int)'A');
            if(sum==0) break;
            sort(a.begin(),a.end());
            if(a.back().first*2>sum){
                sum--;
                a.back().first--;
                cout<<char(a.back().second+(int)'A');
            }
        }
        cout<<endl;
    }
    return 0;
}
