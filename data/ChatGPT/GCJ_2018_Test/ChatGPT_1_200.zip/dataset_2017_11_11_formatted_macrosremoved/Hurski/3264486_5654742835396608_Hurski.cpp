#include <bits/stdc++.h>
using namespace std;

int dx[8]={-1,-1,-1,0,0,1,1,1},dy[8]={-1,0,1,1,-1,-1,0,1};

int main(){
    ios_base::sync_with_stdio(0);
    int t;
    cin>>t;
    for(int ti=1;ti<=t;ti++){
        int z,n;
        cin>>z;
        n=sqrt(z);
        if(n*n!=z) n=n++;
        bool vis[1001][1001];
        memset(vis,false,sizeof(vis));
        int cnt=0,k=0;
        vector < pair<int,int> >a;
        a.clear();
        for(int i=2;i<=n;i++){
            for(int j=2;j<=n;j++){
                a.push_back({i,j});
            }
        }
        while(cnt<1000){
            int x,y;
            cout<<a[k].first<<' '<<a[k].second<<endl;
            cout.flush();
            cin>>x>>y;
            if(x==0&&y==0) break;
            vis[x][y] = true;
            bool f = true;
            for(int i=0;i<8;i++) f=f&vis[a[k].first+dx[i]][a[k].second+dy[i]];
            if(f) k=(k+1)%a.size();
            cnt++;
        }
    }
    return 0;
}
