// Compile with MinGW-64 (6.3.0) in MSYS2
// Compile switches: -std=c++11 -Wall -Wconversion -Werror

#include <stdint.h>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <map>
#include <string>
#include <queue>
#include <vector>

using namespace std;

void solve(int caseNo) {
    std::cout << "Case #" << caseNo << ": ";

    int n;
    std::cin >> n;
    string junk;
    std::getline(std::cin, junk);

    std::vector<int> veven;
    std::vector<int> vodd;

    for (int i = 0; i < n; ++i) {
        int v;
        std::cin >> v;

		if (i%2 == 0)
            veven.push_back(v);
	    else
			vodd.push_back(v);
    }

	sort(veven.begin(), veven.end());
	if (n > 1) sort(vodd.begin(), vodd.end());

	long long badpos = -1;
	for (size_t i = 0; i < veven.size(); ++i) {
		if (i >= vodd.size()) break;
		if (veven[i] > vodd[i]) {
			badpos = i * 2;
			break;
		}
		if (i+1 >= veven.size()) break;
		if (vodd[i] > veven[i+1]) {
			badpos = i * 2 + 1;
			break;
		}
	}

    // output results
    if (badpos == -1)
		cout << "OK\n";
	else
		cout << badpos << "\n";
}

int main(int argc, char** argv) {
    int N;
    std::cin >> N;
    std::string str;
    std::getline(std::cin, str);

    for (int i = 0; i < N; ++i) {
        solve(i + 1);
    }

    return 0;
}
