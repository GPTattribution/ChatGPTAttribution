// Compile with MinGW-64 (6.3.0) in MSYS2

#include <stdint.h>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <map>
#include <string>
#include <queue>
#include <vector>

using namespace std;

void solve(int caseNo) {
    std::cout << "Case #" << caseNo << ": ";

    double d;
    int n;
    cin >> d >> n;

    double maxtime = 0;
    for (int i=0; i<n; i++) {
        double pos, speed;
        cin >> pos >> speed;
        maxtime = std::max(maxtime, (d-pos) / speed);
    }
    cout << std::setprecision(10) << (d / maxtime) << "\n";
}

int main(int argc, char** argv) {
    int N;
    std::cin >> N;
    std::string str;
    std::getline(std::cin, str);

    for(int i = 0; i < N; ++i) {
        solve(i + 1);
    }

    return 0;
}
