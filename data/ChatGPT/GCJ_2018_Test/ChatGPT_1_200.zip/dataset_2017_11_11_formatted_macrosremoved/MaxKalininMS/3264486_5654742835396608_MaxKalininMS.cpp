// Compile with MinGW-64 (6.3.0) in MSYS2
// Compile switches: -std=c++11 -Wall -Wconversion -Werror

#include <stdint.h>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <map>
#include <string>
#include <queue>
#include <vector>

using namespace std;

void solve(int caseNo) {
    int n;
    std::cin >> n;
    string junk;
    std::getline(std::cin, junk);

	int h, w;
	if (n == 20) {
		h = 6; w = 6;
	} else {
		h = 15; w = 15;
	}

	vector<int> xlist;
	vector<int> ylist;
	for (int i = 1; i < w; i+=3)
		xlist.push_back(i);
	for (int i = 1; i < h; i+=3)
		ylist.push_back(i);

	vector<vector<bool>> field;
	for (int i = 0; i < w; ++i) {
		vector<bool> d(h, false);
		field.push_back(d);
	}

	for (int x : xlist) {
		for (int y : ylist) {
			while (true) {
				if (
				    field[x-1][y-1] && field[x-1][y] && field[x-1][y+1] &&
				    field[x][y-1] && field[x][y] && field[x][y+1] &&
				    field[x+1][y-1] && field[x+1][y] && field[x+1][y+1]
			    )
					break;

				cout << (x+1) << " " << (y+1) << "\n" << flush;

				int x1, y1;
				cin >> x1 >> y1;

				if (x1 < 0) exit(1);
				if (x1 < 1) return;
				x1--; y1--;

				field[x1][y1] = true;
			}
		}
	}
}

int main(int argc, char** argv) {
    int N;
    std::cin >> N;
    std::string str;
    std::getline(std::cin, str);

    for (int i = 0; i < N; ++i) {
        solve(i + 1);
    }

    return 0;
}
