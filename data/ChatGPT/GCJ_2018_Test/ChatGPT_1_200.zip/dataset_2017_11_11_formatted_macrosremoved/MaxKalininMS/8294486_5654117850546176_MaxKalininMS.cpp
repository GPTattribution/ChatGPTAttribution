// Compile with MinGW-64 (6.3.0) in MSYS2

#include <stdint.h>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <map>
#include <string>
#include <queue>
#include <vector>
#include <utility>

using namespace std;

void solve(int caseNo) {
    int a, b, n;
    cin >> a >> b >> n;
    a++;

    string response;
    std::getline(std::cin, response);

    while (a <= b) {
        int guess = (a+b)/2;
        cout << guess << '\n' << flush;
        string response;
        std::getline(std::cin, response);
        if (response == "TOO_SMALL")
            a = guess + 1;
        else if (response == "TOO_BIG")
            b = guess - 1;
        else
            break;
    }
}

int main(int argc, char** argv) {
    int N;
    std::cin >> N;
    std::string str;
    std::getline(std::cin, str);

    for(int i = 0; i < N; ++i) {
        solve(i + 1);
    }

    return 0;
}
