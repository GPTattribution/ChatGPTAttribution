// Compile with MinGW-64 (6.3.0) in MSYS2

#include <stdint.h>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <map>
#include <string>
#include <queue>
#include <vector>
#include <utility>

using namespace std;

void solve(int caseNo) {
    std::cout << "Case #" << caseNo << ":";

    int n;
    cin >> n;

    std::vector<std::pair<int, int>> data;
    for (int i = 0; i < n; i++) {
        int k;
        cin >> k;
        data.push_back(std::make_pair(k, i));
    }

    std::sort(data.begin(), data.end(), std::greater<std::pair<int, int>>());

    while (data[0].first > data[1].first) {
        data[0].first--;
        cout << " " << (char)('A' + data[0].second);
    }

    for (int i = 2; i < n; i++) {
        while (data[i].first > 0) {
            data[i].first--;
            cout << " " << (char)('A' + data[i].second);
        }
    }

    while (data[0].first > 0) {
        data[0].first--;
        data[1].first--;
        cout << " " << (char)('A' + data[0].second) << (char)('A' + data[1].second);
    }

    cout << "\n";
}

int main(int argc, char** argv) {
    int N;
    std::cin >> N;
    std::string str;
    std::getline(std::cin, str);

    for(int i = 0; i < N; ++i) {
        solve(i + 1);
    }

    return 0;
}
