// Compile with MinGW-64 (6.3.0) in MSYS2
// Compile switches: -std=c++11 -Wall -Wconversion -Werror

#include <stdint.h>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <map>
#include <string>
#include <queue>
#include <vector>

using namespace std;

const char kCakeEmpty = '?';

void solve(int caseNo) {
    std::cout << "Case #" << caseNo << ": ";

    long long d;
    std::cin >> d;

    string seq;
    std::getline(std::cin, seq);
	seq = seq.substr(1);

	long long l = seq.length();
	vector<int> charges;
	for (int i = 0; i < l; ++i) {
		if (seq[i] == 'C')
			charges.push_back(i);
	}

    long long charge_s = charges.size();
	long long shoots = l - charges.size();

	if (shoots > d) {
		cout << "IMPOSSIBLE\n";
		return;
	}

	long long dmg = shoots;
	long long basedmg = 1;
	for (int i = 0; i < charge_s; ++i) {
		long long mult = (shoots + i - charges[i]);
		dmg += basedmg * mult;
		basedmg *= 2;
	}

	long long swaps = 0;
	for (long long i = charge_s - 1; i >= 0; --i) {
		if (dmg <= d) break;
		basedmg /= 2;

		long long extra = dmg - d;
		long long needs = extra / basedmg;
        if (extra % basedmg > 0) needs++;
		long long cswaps = min(shoots + i - charges[i], needs);
		dmg -= basedmg * cswaps;
		swaps += cswaps;
	}

    // output results
    cout << swaps << "\n";
}

int main(int argc, char** argv) {
    int N;
    std::cin >> N;
    std::string str;
    std::getline(std::cin, str);

    for (int i = 0; i < N; ++i) {
        solve(i + 1);
    }

    return 0;
}
