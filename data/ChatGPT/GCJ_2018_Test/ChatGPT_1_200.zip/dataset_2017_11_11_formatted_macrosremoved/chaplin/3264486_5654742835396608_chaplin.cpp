#include<cstdio>
#include<cstdlib>
#include<iostream>
#include<vector>
#include<queue>
#include<bitset>
#include<string>
#include<stack>
#include<set>
#include<map>
#include<cstring>
#include<complex>
#include<cmath>
#include<iomanip>
#include<numeric>
#include<algorithm>
#include<list>
#include<functional>
#include<cassert>
#define mp make_pair
#define X first
#define Y second
#define INF 987654321
#define PI 3.14159265358979323846264
#define fup(i,a,b,c) for(int (i)=(a);(i)<=(b);(i)+=(c))
#define fdn(i,a,b,c) for(int (i)=(a);(i)>=(b);(i)-=(c))
#define MEM0(a) memset(a,0,sizeof(a));
#define MEM_1(a) memset(a,-1,sizeof(a));
#define ALL(a) a.begin(),a.end()
using namespace std;
typedef long long ll;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef pair<int, int> Pi;
typedef pair<ll, ll> Pll;
typedef pair<double, double> Pd;
typedef vector<int> Vi;
typedef vector<ll> Vll;
typedef vector<double> Vd;
typedef vector<Pi> VPi;
typedef vector<Pll> VPll;
typedef vector<Pd> VPd;
typedef tuple<int, int, int> iii;
typedef tuple<ll, ll, ll> LLL;
typedef vector<iii> Viii;
typedef vector<LLL> VLLL;
typedef complex<double> base;
ll MOD = 1000007;
ll POW(ll a, ll b, ll MMM = MOD) { ll ret = 1; for (; b; b >>= 1, a = (a*a) % MMM)if (b & 1)ret = (ret*a) % MMM; return ret; }
ll gcd(ll a, ll b) { return b ? gcd(b, a%b) : a; }
ll lcm(ll a, ll b) { if (a == 0 || b == 0)return a + b; return a*(b / gcd(a, b)); }
int dx[] = { 0,-1,1,0 }, dy[] = { 1,0,0,-1 };
int ddx[] = { 0,0,1,1,1,-1,-1,-1 }, ddy[] = { 1,-1,1,0,-1,1,0,-1 };

VPi a200, a20;
bool chk[100][100];
bool done(int x, int y)
{
	fup(i,-1,1,1)
		fup(j, -1, 1, 1)
	{
		if (!chk[x + i][y + j])return 0;
	}
	return 1;
}
void solve20()
{
	MEM0(chk);
	int i = 0;
	while (1)
	{
		printf("%d %d\n", a20[i].X, a20[i].Y);
		fflush(stdout);
		int x, y;
		scanf("%d%d", &x, &y);
		if (x <= 0 && y <= 0)return;
		chk[x][y] = 1;
		if (done(a20[i].X, a20[i].Y))i++;
	}
}
void solve200()
{
	MEM0(chk);
	int i = 0;
	while (1)
	{
		printf("%d %d\n", a200[i].X, a200[i].Y);
		fflush(stdout);
		int x, y;
		scanf("%d%d", &x, &y);
		if (x <= 0 && y <= 0)return;
		chk[x][y] = 1;
		if (done(a200[i].X, a200[i].Y))i++;
	}
}
int main() {
	fup(i,0,3,1)
		fup(j, 0, 5, 1)
	{
		a200.push_back(mp(10 + 3 * i, 10 + 3 * j));
	}
	fup(i, 0, 2, 1)
		a20.push_back(mp(10, 10 + 3 * i));
	int tc;
	scanf("%d", &tc);
	fup(TC, 1, tc, 1)
	{
		//printf("Case #%d: ", TC);
		int a;
		scanf("%d", &a);
		if(a==20)solve20();
		else solve200();
	}
}
