#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>

using namespace std;

vector<vector<double>> find_face_centers(double A) {
    double theta = acos(A / sqrt(2));
    double phi = (M_PI - theta) / 2.0;

    double x = 0.5 * cos(phi);
    double y = 0.5 * sin(phi);

    return {
        {x, y, 0},
        {-x, y, 0},
        {0, 0.5, 0}
    };
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; ++t) {
        cin >> A;

        vector<vector<double>> face_centers = find_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const vector<double>& point : face_centers) {
            cout << point[0] << " " << point[1] << " " << point[2] << endl;
        }
    }

    return 0;
}
