#include <iostream>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <cmath>
#include <stack>
#include <iomanip>
#include <functional>
#include <array>
#include <bitset>

using namespace std;
typedef long long ll;

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);

	int T;
	cin >> T;
	cout << setprecision(12) << fixed;
	for (int t = 1; t <= T; ++t) {
		int D, N;
		cin >> D >> N;
		double ans = 1e15;
		for (int i = 0; i < N; ++i) {
			int K, S;
			cin >> K >> S;
			ans = min(ans, (double)D / ((double)(D - K) / S));
		}
		cout << "Case #" << t << ": " << ans << '\n';
	}
	return 0;
}
