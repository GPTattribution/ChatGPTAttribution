#include <iostream>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <cmath>
#include <stack>
#include <iomanip>
#include <functional>
#include <array>
#include <bitset>

using namespace std;
typedef long long ll;

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);

	int T;
	cin >> T;
	for (int t = 1; t <= T; ++t) {
		int N;
		cin >> N;
		int total = 0;
		vector<pair<int, char>> v;
		for (int i = 0; i < N; ++i) {
			v.push_back({ 0, i + 'A' });
			cin >> v.back().first;
			total += v.back().first;
		}
		cout << "Case #" << t << ":";
		for (;;) {
			sort(v.begin(), v.end());
			cout << ' ' << v.back().second;
			--total;
			if (--v.back().first == 0) {
				v.pop_back();
				if (v.empty())
					break;
			}

			sort(v.begin(), v.end());
			if (v.back().first * 2 <= total) continue;

			cout << v.back().second;
			--total;
			if (--v.back().first == 0) {
				v.pop_back();
				if (v.empty())
					break;
			}

		}
		cout << '\n';
	}
	return 0;
}
