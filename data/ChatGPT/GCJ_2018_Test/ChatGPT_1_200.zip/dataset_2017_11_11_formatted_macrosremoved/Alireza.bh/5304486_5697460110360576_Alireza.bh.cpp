#include <iostream>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <cmath>
#include <stack>
#include <iomanip>
#include <functional>
#include <array>
#include <memory>

using namespace std;
typedef long long ll;

ll damage(string P) {
	ll res = 0;
	ll coeff = 1;
	for (char c : P) {
		if (c == 'C') {
			coeff <<= 1;
		}
		else if(c == 'S') {
			res += coeff;
		}
		else {
			cout << "error!!!!";
			exit(1);
		}
	}
	return res;
}

void f(ll D, string P) {
	ll ans = 0;
	while (damage(P) > D) {
		int i = P.size() - 1;
		while (i > 0 && P[i] != 'S')
			--i;
		while (i && P[i - 1] == 'S')
			--i;
		if (!i) {
			cout << "IMPOSSIBLE";
			return;
		}
		swap(P[i - 1], P[i]);
		++ans;
	}
	cout << ans;
}

int main() {
	int T;
	cin >> T;
	for (int t = 1; t <= T; ++t) {
		ll D;
		string P;
		cin >> D >> P;

		cout << "Case #" << t << ": ";
		f(D, P);
		cout << '\n';
	}

	return 0;
}
