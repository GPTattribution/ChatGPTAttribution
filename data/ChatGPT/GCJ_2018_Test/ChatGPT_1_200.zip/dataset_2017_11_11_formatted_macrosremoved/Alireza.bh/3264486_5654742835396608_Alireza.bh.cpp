#include <iostream>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <cmath>
#include <stack>
#include <iomanip>
#include <functional>
#include <array>
#include <memory>

using namespace std;
typedef long long ll;

pair<int, int> interact(int i, int j) {
	cout << i << ' ' << j << endl;
	cin >> i >> j;
	return{ i, j };
}

int filled[1001][4];

void f(const int N) {
	memset(filled, 0, sizeof filled);
	for (int i = 1; i <= N; ++i) {
		while (!filled[i][1] || !filled[i][2] || !filled[i][3]) {
			auto pt = interact(min(i + 1, N - 1), 2);
			if (!pt.first) return;
			if (pt.first < 0) {
				cerr << "error 1";
				exit(12);
			}
			filled[pt.first][pt.second] = 1;
		}
	}
	cerr << "error 2";
	exit(23);
}

int main() {
	int T;
	cin >> T;
	for (int t = 1; t <= T; ++t) {
		int A;
		cin >> A;
		f(max(3, (A + 2) / 3));
	}
	return 0;
}
