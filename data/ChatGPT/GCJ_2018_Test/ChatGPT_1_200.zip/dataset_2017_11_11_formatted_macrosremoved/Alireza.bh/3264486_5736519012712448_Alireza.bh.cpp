#include <iostream>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <cmath>
#include <stack>
#include <iomanip>
#include <functional>
#include <array>
#include <memory>

using namespace std;
typedef long long ll;

int V[(int)1e5];
vector<int> dp[2];

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);

	int T;
	cin >> T;
	for (int t = 1; t <= T; ++t) {
		int N;
		cin >> N;

		for (int i = 0; i < N; ++i) {
			cin >> V[i];
			dp[i & 1].push_back(V[i]);
		}
		for(int i = 0; i < 2; ++i)
			sort(dp[i].rbegin(), dp[i].rend());

		for (int i = 0; i < N; ++i) {
			V[i] = dp[i & 1].back();
			dp[i & 1].pop_back();
		}

		cout << "Case #" << t << ": ";
		bool sorted = true;
		for(int i = 0; i + 1 < N; ++i)
			if (V[i] > V[i + 1]) {
				sorted = false;
				cout << i;
				break;
			}
		if (sorted)
			cout << "OK";
		cout << '\n';
	}
	return 0;
}
