#include <iostream>

using namespace std;

int main() {
	int cases;
	cin >> cases;
	for(int i = 1; i <= cases; ++i) {
		int parties = 0;
		int amount[30] = {0};
		bool odd = false;
		int zerocount = 0;
		cin >> parties;
		for(int j = 0; j < parties; ++j) {
			cin >> amount[j];
		}
		cout << "Case #" << i << ": ";
		int total = 0;
		for(int j = 0; j < parties; ++j) {
			total += amount[j];
		}
		if(total % 2 == 1) odd = true;
		while(zerocount < parties) {
			int largest = 0;
			for(int k = 0; k < parties; ++k) {
				if(amount[k] > amount[largest]) largest = k;
			}
			--amount[largest];
			if(amount[largest] == 0) zerocount++;
			char letter = 65 + largest;
			cout << letter;
			if(odd) {
				cout << " ";
				odd = false;
				continue;
			}
			largest = 0;
			for(int k = 0; k < parties; ++k) {
				if(amount[k] > amount[largest]) largest = k;
			}
			--amount[largest];
			if(amount[largest] == 0) zerocount++;
			letter = 65 + largest;
			cout << letter << " ";
		}
		cout << endl;
	}
}
