#include <iostream>
#include <cmath>

using namespace std;

int main() {
	int cases;
	cin >> cases;
	for(int i = 1; i <= cases; ++i) {
		long long int stalls, people;
		cin >> stalls >> people;
		long long int increment = log2(people);
		long long int sum = (stalls - people) >> increment;
		long long int min, max;
		min = max = sum / 2;
		if(sum % 2 == 1) max += 1;
		cout << "Case #" << i << ": " << max << " " << min << endl;
	}
}
