#include <iostream>
#include <cmath>
#include <string>

using namespace std;

int main() {
	int cases;
	long long incs[30];
	for(int i = 0; i < 30; ++i) {
		incs[i] = pow(2, i);
	}
	cin >> cases;
	for(int i = 1; i <= cases; ++i) {
		long long d;
		string s;
		cin >> d;
		cin >> s;
		long long dd = 0;
		long long inc = 1;
		int vals[29] = {0};
		int ix = 0;
		for(int j = 0; j < s.size(); ++j) {
			if(s[j] == 'C') {
				inc *= 2;
				++ix;
			}
			if(s[j] == 'S') {
				++vals[ix];
				dd += inc;
			}
		}
		int switches = 0;
		bool imposs = false;
		while(dd > d) {
			int larg = -1;
			for(int j = 1; j < 30; ++j) {
				if(vals[j] > 0) larg = j;
			}
			if(larg == -1) {
				imposs = true;
				break;
			}
			dd -= incs[larg] / 2;
			--vals[larg];
			++vals[larg - 1];
			++switches;
		}
		cout << "Case #" << i << ": ";
		if(imposs) {
			cout << "IMPOSSIBLE";
		} else {
			cout << switches;
		}
		cout << "\n";
	}
}
