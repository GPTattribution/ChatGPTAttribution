#include <iostream>
#include <string>

using namespace std;

int main() {
	int cases;
	cin >> cases;
	int guess = 0;
	int increment = 0;
	string message;
	for(int i = 0; i < cases; ++i) {
		int a, b, n;
		cin >> a >> b >> n;
		guess = (a + b) / 2;
		increment = guess / 2;
		while(n > 0) {
			cout << guess << endl;
			cin >> message;
			if (message == "CORRECT") {
				break;
			} else if (message == "TOO_SMALL") {
				guess += increment;
				increment /= 2;
			} else if (message == "TOO_BIG") {
				guess -= increment;
				increment /= 2;
			} else {

			}
			if(increment == 0) increment = 1;
			--n;
		}
	}
}
