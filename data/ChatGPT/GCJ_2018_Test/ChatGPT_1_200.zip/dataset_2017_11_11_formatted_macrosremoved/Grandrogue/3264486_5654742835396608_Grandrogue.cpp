#include <iostream>
#define ROWS 20
#define COLUMNS 10
using namespace std;

int main() {
	int cases;
	cin >> cases;
	for(int i = 1; i <= cases; ++i) {
		int a;
		cin >> a;
		bool orchad[ROWS * COLUMNS] = {};
		while(true) {
			int low_x = 0;
			int low_y = 0;
			int lowest_count = 9;
			for(int i = 1; i < ROWS - 1; ++i) {
				for(int j = 1; j < COLUMNS - 1; ++j) {
					int count = 0;
					for(int k = i - 1; k < i + 2; ++k) {
						for(int l = j - 1; l < j + 2; ++l) {
							if(orchad[COLUMNS * k + l] == 1) ++count;
						}
					}
					if(count < lowest_count) {
						lowest_count = count;
						low_x = i;
						low_y = j;
					}
				}
			}
			cout << low_x + 1 << " " << low_y + 1 << endl;
			int ans_x, ans_y;
			cin >> ans_x >> ans_y;
			if(ans_x == -1 && ans_y == -1) {
				return -1;
			} else if (ans_x == 0 && ans_y == 0) {
				break;
			} else {
				orchad[(ans_x - 1) * COLUMNS + (ans_y - 1)] = 1;
			}
		}
	}
}
