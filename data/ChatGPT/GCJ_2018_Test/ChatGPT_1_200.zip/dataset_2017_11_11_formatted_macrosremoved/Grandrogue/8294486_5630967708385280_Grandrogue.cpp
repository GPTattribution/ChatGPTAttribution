#include <iostream>
#include <iomanip>

using namespace std;

int main() {
	int cases;
	cin >> cases;
	cout << fixed << setprecision(6);
	for(int i = 1; i <= cases; ++i) {
		long double destination, horses;
		cin >> destination >> horses;
		long double horse_speed;
		long double horse_pos;
		long double time;
		long double largest = 0;
		for(int j = 0; j < horses; ++j) {
			cin >> horse_pos >> horse_speed;
			time = (destination - horse_pos) / horse_speed;
			if(time > largest) largest = time;
		}
		cout << "Case #" << i << ": " << destination/largest << endl;
	}
}
