#include <iostream>
#include <algorithm>

using namespace std;

int main() {
	int cases;
	cin >> cases;
	for(int i = 1; i <= cases; ++i) {
		long nums;
		cin >> nums;
		long long odd[nums/2];
		long even_sz;
		if(nums % 2 == 1) {
			even_sz = nums/2 + 1;
		} else {
			even_sz = nums/2;
		}
		long long even[even_sz];
		for(int j = 0; j < nums; ++j) {
			if(j % 2 == 1) {
				cin >> odd[(j - 1)/2];
			} else {
				cin >> even[j/2];
			}
		}
		sort(odd, odd + nums/2);
		sort(even, even + even_sz);
		long long old_num = even[0];
		long long new_num;
		bool correct = true;
		cout << "Case #" << i << ": ";
		for(int j = 0; j < nums; ++j) {
			if(j % 2 == 1) {
				new_num = odd[(j-1)/2];
			} else {
				new_num = even[j/2];
			}
			if(new_num < old_num) {
				correct = false;
				cout << j - 1;
				break;
			}
			old_num = new_num;
		}
		if(correct) {
			cout << "OK";
		}
		cout << "\n";
	}
}
