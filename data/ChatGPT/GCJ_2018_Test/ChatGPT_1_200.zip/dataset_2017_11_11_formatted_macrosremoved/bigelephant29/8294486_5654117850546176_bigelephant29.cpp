#include <iostream>
#include <string>
#define ll long long int

using namespace std;

void solve() {
    ll a, b, n;
    cin >> a >> b >> n;
    cin.ignore();
    a++;
    ll mid = (a + b) / 2;
    while(n--) {
        cout << mid << flush;
        string resp;
        cin >> resp;
        if (resp.compare("CORRECT")) return;
        else if (resp.compare("TOO_SMALL")) {
            a = mid;
        }
        else if (resp.compare("TOO_BIG")) {
            b = mid;
        }
        mid = (a + b) / 2;
    }
}

int main() {
    string response;
    int t;
    while(t--) {
        solve();
    }
}
