#include<iostream>
#include<iomanip>
#include<math.h>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<queue>
#include<stack>
#include<string>
#include<bitset>
#include<random>
#include<time.h>
#include<fstream>
#define INF 1000000000ll
#define MOD 1000000007ll
#define EPS 1e-10
#define REP(i,m) for(long long i=0; i<(ll)m; i++)
#define FOR(i,n,m) for(long long i=n; i<(ll)m; i++)
#define DUMP(a) for(long long dump=0; dump<(ll)a.size(); dump++) { cout<<a[dump]; if(dump!=(ll)a.size()-1) cout<<" "; else cout<<endl; }
#define ALL(v) v.begin(),v.end()
#define UNIQUE(v) sort(v.begin(),v.end()); v.erase(unique(v.begin(),v.end()),v.end());
#define pb push_back
using namespace std;
typedef long long ll;
typedef pair<ll, ll> P;
typedef long double ld;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	ll T;
	cin>>T;
	REP(testcase,T) {
		ll n,k;
		cin>>n>>k;
		ll n1=0,n2=0;	//n1:odd n2:even
		ll c1=0,c2=0;
		if(n%2) {
			n1=n;
			n2=n+1;
			c1=1;
		} else {
			n2=n;
			n1=n+1;
			c2=1;
		}
		while(1) {
			if((c1+c2)<k) {
				k-=(c1+c2);
				ll tmp1=0,tmp2=0,tmp3=0,tmp4=0;
				if((n1/2)%2) {
					tmp1=n1/2;
					tmp2=((n2/2)%2==0) ? n2/2 : (n2/2)-1;
					tmp3=c1*2+c2;
					tmp4=c2;
				} else {
					tmp1=((n2/2)%2!=0) ? n2/2 : (n2/2)-1;
					tmp2=n1/2;
					tmp3=c2;
					tmp4=c1*2+c2;
				}
				n1=tmp1;
				n2=tmp2;
				c1=tmp3;
				c2=tmp4;
			} else {
				if(n1>n2) {
					if(c1>=k) {
						cout<<"Case #"<<testcase+1<<": "<<n1/2<<" "<<n1/2<<endl;
					} else {
						cout<<"Case #"<<testcase+1<<": "<<n2/2<<" "<<n2/2-1<<endl;
					}
				} else {
					if(c2>=k) {
						cout<<"Case #"<<testcase+1<<": "<<n2/2<<" "<<n2/2-1<<endl;
					} else {
						cout<<"Case #"<<testcase+1<<": "<<n1/2<<" "<<n1/2<<endl;
					}
				}
				break;
			}
		}
	}
}
