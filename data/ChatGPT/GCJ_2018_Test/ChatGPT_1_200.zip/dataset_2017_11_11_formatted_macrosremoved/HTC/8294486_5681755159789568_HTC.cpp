#include<iostream>
#include<iomanip>
#include<math.h>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<queue>
#include<stack>
#include<string>
#include<bitset>
#include<random>
#include<time.h>
#include<fstream>
#define INF 1000000000ll
#define MOD 1000000007ll
#define EPS 1e-10
#define REP(i,m) for(long long i=0; i<(ll)m; i++)
#define FOR(i,n,m) for(long long i=n; i<(ll)m; i++)
#define DUMP(a) for(long long dump=0; dump<(ll)a.size(); dump++) { cout<<a[dump]; if(dump!=(ll)a.size()-1) cout<<" "; else cout<<endl; }
#define ALL(v) v.begin(),v.end()
#define UNIQUE(v) sort(v.begin(),v.end()); v.erase(unique(v.begin(),v.end()),v.end());
#define pb push_back
using namespace std;
typedef long long ll;
typedef pair<ll, ll> P;
typedef long double ld;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	ll T;
	cin>>T;
	REP(testcase,T) {
		ll N;
		cin>>N;
		vector<P> v;
		ll sum=0;
		REP(i,N) {
			ll p;
			cin>>p;
			sum+=p;
			v.pb(P(p,i));
		}
		vector<string> ans;
		while(sum>0) {
			sort(ALL(v));
			if(v[N-1].first==v[N-2].first&&sum%2==0&&v[N-1].first==sum/2) {
				string str="";
				str+='A'+v[N-1].second;
				str+='A'+v[N-2].second;
				v[N-1].first--;
				v[N-2].first--;
				ans.pb(str);
				sum-=2;
			} else {
				string str="";
				str+='A'+v[N-1].second;
				v[N-1].first--;
				ans.pb(str);
				sum--;
			}
		}
		cout<<"Case #"<<testcase+1<<": ";
		DUMP(ans);
	}
}
