#include<iostream>
#include<iomanip>
#include<math.h>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<queue>
#include<stack>
#include<string>
#include<bitset>
#include<random>
#include<time.h>
#define INF 1000000000ll
#define MOD 1000000007ll
#define EPS 1e-10
#define REP(i,m) for(long long i=0; i<(ll)m; i++)
#define FOR(i,n,m) for(long long i=n; i<(ll)m; i++)
#define DUMP(a) for(long long dump=0; dump<(ll)a.size(); dump++) { cout<<a[dump]; if(dump!=(ll)a.size()-1) cout<<" "; else cout<<endl; }
#define ALL(v) v.begin(),v.end()
#define UNIQUE(v) sort(v.begin(),v.end()); v.erase(unique(v.begin(),v.end()),v.end());
#define pb push_back
using namespace std;
typedef long long ll;
typedef pair<ll, ll> P;
typedef long double ld;

int main() {
	ios::sync_with_stdio(false);
	ll T;
	cin>>T;
	REP(testcase,T) {
		ll A;
		cin>>A;
		bool solved=false;
		ll h=0,w=0;
		if(A==20)  {
			h=4;
			w=5;
		} else if(A==200) {
			h=10;
			w=20;
		}
		P p=P(2,2);
		REP(i,h/3) {
			p.second=2;
			REP(j,w/3) {
				set<P> s;
				while(!solved&&(ll)s.size()<9) {
					cout<<p.first<<" "<<p.second<<endl;
					ll x,y;
					cin>>x>>y;
					if(x==0&&y==0) solved=true;
					else s.insert(P(x,y));
				}
				p.second+=3;
			}
			if(w%3) {
				p.second-=(3-w%3);
				set<P> s;
				while(!solved&&(ll)s.size()<3*(w%3)) {
					cout<<p.first<<" "<<p.second<<endl;
					ll x,y;
					cin>>x>>y;
					if(x==0&&y==0) solved=true;
					else {
						if(y-(p.second-1)>=(3-w%3)) s.insert(P(x,y));
					}
				}
			}
			p.first+=3;
		}
		if(h%3) {
			p.first-=(3-h%3);
			p.second=2;
			REP(j,w/3) {
				set<P> s;
				while(!solved&&(ll)s.size()<3*(h%3)) {
					cout<<p.first<<" "<<p.second<<endl;
					ll x,y;
					cin>>x>>y;
					if(x==0&&y==0) solved=true;
					else {
						if(x-(p.first-1)>=(3-h%3)) s.insert(P(x,y));
					}
				}
				p.second+=3;
			}
			if(w%3) {
				p.second-=(3-w%3);
				set<P> s;
				while(!solved&&(ll)s.size()<(h%3)*(w%3)) {
					cout<<p.first<<" "<<p.second<<endl;
					ll x,y;
					cin>>x>>y;
					if(x==0&&y==0) solved=true;
					else {
						if(x-(p.first-1)>=(3-h%3)&&y-(p.second-1)>=(3-w%3)) s.insert(P(x,y));
					}
				}
			}
		}
	}
}
