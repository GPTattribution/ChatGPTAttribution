#include<iostream>
#include<iomanip>
#include<math.h>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<queue>
#include<stack>
#include<string>
#include<bitset>
#include<random>
#include<time.h>
#include<fstream>
#define INF 1000000000ll
#define MOD 1000000007ll
#define EPS 1e-10
#define REP(i,m) for(long long i=0; i<(ll)m; i++)
#define FOR(i,n,m) for(long long i=n; i<(ll)m; i++)
#define DUMP(a) for(long long dump=0; dump<(ll)a.size(); dump++) { cout<<a[dump]; if(dump!=(ll)a.size()-1) cout<<" "; else cout<<endl; }
#define ALL(v) v.begin(),v.end()
#define UNIQUE(v) sort(v.begin(),v.end()); v.erase(unique(v.begin(),v.end()),v.end());
#define pb push_back
using namespace std;
typedef long long ll;
typedef pair<ll, ll> P;
typedef long double ld;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	ll T;
	cin>>T;
	REP(testcase,T) {
		ll d,n;
		cin>>d>>n;
		vector<P> h(n);
		REP(i,n) cin>>h[i].first>>h[i].second;
		ld l=EPS, r=INF*INF;
		ll c=0;
		while(c<100) {
			ld m=(l+r)/2;
			bool f=true;
			REP(i,n) if(d/m<(d-h[i].first)/(ld)h[i].second) f=false;
			if(f) l=m;
			else r=m;
			c++;
		}
		cout<<"Case #"<<testcase+1<<": "<<fixed<<setprecision(39)<<l<<endl;
	}
}
