#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;
typedef vector<int> vi;

int main(){
	int t,n;
	cin >> t;
	for(int i = 0; i < t; i++){
		cin >> n;
		vi v(n), imp(n/2), par(n/2+n%2);
		for(int j = 0; j < n; j++){
			cin >> v[j];
			if(j%2) imp[j/2] = v[j];
			else par[j/2] = v[j];
		}
		sort(par.begin(),par.end());
		sort(imp.begin(),imp.end());
		//for(int j = 0; j < n; j++)
		//	if(j%2) cout << imp[j/2] << " ";
		//	else cout << par[j/2] << " ";
		//cout << endl;
		int j;
		for(j = 0; j < n-1; j++){
			if(j%2 == 0 && par[j/2] > imp[j/2])
				break;
			else if(j%2 == 1 && imp[j/2] > par[j/2+1])
				break;
		}
		if(j == n-1)
			printf("Case #%d: OK\n",i+1);
		else
			printf("Case #%d: %d\n",i+1,j);
	}
	return 0;
}
