#include <iostream>
#include <string>

using namespace std;

int main(){
	int t, a, b, n, g;
	string ans;
	cin >> t;
	for(int i = 0; i < t; i++){
		cin >> a >> b;
		a += 1;
		cin >> n;
		for(int j = 0; j < n; j++){
			g = (a+b)/2;
			cout << g << endl;
			cin >> ans;
			if(ans.compare("CORRECT") == 0)
				break;
			if(ans.compare("TOO_SMALL") == 0)
				a = g+1;
			else if(ans.compare("TOO_BIG") == 0)
				b = g-1;
		}
	}
}
