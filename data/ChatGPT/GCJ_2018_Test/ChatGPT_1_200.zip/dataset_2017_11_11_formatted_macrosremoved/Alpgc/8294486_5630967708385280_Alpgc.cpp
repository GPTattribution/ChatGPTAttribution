#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdio>
using namespace std;
typedef vector<double> vd;

int main(){
	int t, d, n, k, s;
	double max_t;
	cin >> t;
	for(int i = 0; i < t; i++){
		cin >> d >> n;
		vd dt(n);
		for(int j = 0; j < n; j++){
			cin >> k >> s;
			dt[j] = (d-k)/(double)s;
		}
		max_t = *max_element(dt.begin(),dt.end());
		printf("Case #%d: %.6lf\n",i+1,d/max_t);
		//cout << "Case #" << i+1 << ": " << d/max_t << endl;
	}
}
