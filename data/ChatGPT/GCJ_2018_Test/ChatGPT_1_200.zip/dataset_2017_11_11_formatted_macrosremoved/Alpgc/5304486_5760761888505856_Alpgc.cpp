#include <iostream>
#include <cstdio>
#include <queue>
using namespace std;

typedef unsigned long long int llu;
typedef pair<llu,llu> ii;

int main(){
	int t;
	llu n, k;
	cin >> t;
	for(int i = 0; i < t; i++){
		cin >> n >> k;
		queue<ii> q;
		ii f, next;
		llu h1, h2;
		q.push(ii(1,n));
		while(k > 0 && !q.empty()){
			//cout << q.size() << endl;
			f = q.front(); q.pop();
			if(k <= f.first) break;
			if((f.second-1)%2 == 0){
				h1 = h2 = (f.second-1)/2;
			} else{
				h2 = (f.second-1)/2;
				h1 = h2 + 1;
			}
			if(q.empty()){
				if(h1 == h2){
					q.push(ii(2*f.first,h1));
				} else {
					q.push(ii(f.first,h1));
					q.push(ii(f.first,h2));
				}
				k -= f.first;
			} else {
				next = q.front();
				if(f.second == next.second){
					q.front().first += f.first;
					continue;
				} else {
					if(h1 == h2){
						q.push(ii(2*f.first,h1));
					} else {
						q.push(ii(f.first,h1));
						q.push(ii(f.first,h2));
					}
					k -= f.first;
				}
			}
		}
		if((f.second-1)%2 == 0){
			h1 = h2 = (f.second-1)/2;
		} else{
			h2 = (f.second-1)/2;
			h1 = h2 + 1;
		}
		printf("Case #%d: %llu %llu\n",i+1,max(h1,h2),min(h1,h2));
	}
}
