#include <iostream>
#include <cstdio>
#include <vector>
#define NR 4
#define NC 6

using namespace std;
typedef vector<int> vi;
typedef vector<vi> vvi;
bool check_subgrid(vvi &grid, int r, int c);

int main(){
	int t,a,ri,rj;
	bool ok;
	cin >> t;
	for(int i = 0; i < t; i++){
		cin >> a;
		vvi grid(14,*(new vi(20,0)));
		ok = false;
		if(a == 20){
			for(int j = 3; j < 8 && !ok; j++){
				for(int l = 0; l < 125 && !ok; l++){ //
					cout << j << " " << 3 << endl;
					cin >> ri >> rj;
					ok = (ri == rj && rj == 0);
					if(ri == rj && rj == -1) return 0;
				}
			}
		} else {
			for(int j = 0; j < NR && !ok; j++){
				for(int k = 0; k < NC && !ok; k++){
					while(!check_subgrid(grid,3*j+3,3*k+3) && !ok){ //
						cout << 3*j+3 << " " << 3*k+3 << endl;
						cin >> ri >> rj;
						ok = (ri == rj && rj == 0);
						if(ri == rj && rj == -1) return 0;
						if(!ok) grid[ri][rj] = 1;
					}
				}
			}
		}
	}
	return 0;
}

bool check_subgrid(vvi &grid, int r, int c){
	bool ok = true;
	for(int i = -1; i <= 1; i++)
		for(int j = -1; j <= 1; j++)
			if(grid[r+i][c+j] == 0)
				return false;
	return ok;
}
