#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;
typedef vector<int> vi;

vi::iterator sec_argmax(vi::iterator b, vi::iterator e, vi::iterator m){
	vi::iterator mit;
	if(m == b) mit = m+1;
	else mit = b;
	for(vi::iterator it = b; it != e; it++)
		if(it != m && *it > *mit) mit = it;
	return mit;
}

int main(){
	int t, n, sum_s;
	vi::iterator m1, m2;
	cin >> t;
	for(int i = 0; i < t; i++){
		cin >> n;
		vi p(n);
		sum_s = 0;
		for(int j = 0; j < n; j++){
			cin >> p[j];
			sum_s += p[j];
		}
		cout << "Case #" << i+1 << ":";
		while(sum_s > 0){
			m1 = max_element(p.begin(),p.end());
			m2 = sec_argmax(p.begin(),p.end(),m1);
			//cout << " -- " << *m2 << endl;
			if(*m1 > *m2){
				cout << " " << (char)((m1-p.begin())+'A');
				(*m1)--;
				sum_s--;
			} else {
				if(sum_s == 3 && *m1 == 1 ){
					cout << " " << (char)((m1-p.begin())+'A');
					(*m1)--;
					sum_s--;
				} else {
					cout << " " << (char)((m1-p.begin())+'A') << (char)((m2-p.begin())+'A');
					(*m1)--; (*m2)--;
					sum_s -= 2;
				}
			}
		}
		cout << endl;
	}
}
