#include <iostream>
#include <cstdio>

using namespace std;
unsigned int calc_damage(string p);
void swap_char(string &p, int pos);
int get_pos(string p);

int main(){
	int t, d, s, pos;
	string p;
	cin >> t;
	for(int i = 0; i < t; i++){
		cin >> d >> p;
		s = 0;
		while((pos=get_pos(p)) > 0){
			if(calc_damage(p) <= d)
				break;
			swap_char(p,pos);
			s++;
		}
		if(calc_damage(p) <= d){
			printf("Case #%d: %d\n",i+1,s);
		} else {
			printf("Case #%d: IMPOSSIBLE\n",i+1);
		}
	}
	return 0;
}

unsigned int calc_damage(string p){
	unsigned int d = 0;
	int power = 1;
	for(int i = 0; i < p.length(); i++){
		if(p[i] == 'S') d += power;
		else power *= 2;
	}
	return d;
}

void swap_char(string &p, int pos){
	char tmp = p[pos];
	p[pos] = p[pos-1];
	p[pos-1] = tmp;
}

int get_pos(string p){
	int pos = p.length()-1;
	while(pos > 0 && !(p[pos] == 'S' && p[pos-1] == 'C')) pos--;
	return pos;
}
