#include <bits/stdc++.h>
#include <unistd.h>

#pragma GCC optimize ("O3")

#define REP(i, s, e) for (lli i = s, iend = e; i <= iend; ++i)
#define REPR(i, s, e) for (lli i = s, iend = e; i >= iend; --i)
#define FOR(i, s, e) for (lli i = s, iend = e; i != iend; ++i)
#define FORR(i, s, e) for (lli i = s, iend = e; i != iend; --i)

using namespace std;

typedef long long int lli;
typedef long double ld;
typedef string str;
template<typename T> using vec = vector<T>;

int T;
int A;
int desiredW;
bool M[3][1000];
int centerI = 3;
int iRet, jRet;

bool stop_condition() {
    return iRet == -1 && jRet == -1;
}

bool surroundingFilled(int i)
{
    REP(y,0,2)
        REP(x,i-1,i+1)
            if (M[y][x] == 0) return false;
    return true;
}

void printM()
{
    REP(j,0,2) {
        REP(i,centerI-3,centerI+desiredW+3) {
                if (M[j][i]) fprintf(stderr, "x");
                else fprintf(stderr, ".");
        }
        //fprintf(stderr, "\n");
    }
}

pair<int, int> nextPointA()
{
    for (int i = centerI, iend = centerI + desiredW; i <= iend; i+=3) {
        if (!surroundingFilled(i)) {
            return make_pair(i, 4);
        }
    }

    //fprintf(stderr, "Must be solved, failed assertion\n");
    exit(-2);
}

bool solve()
{
    //fprintf(stderr, "A = %d\n", A);
    do {
        //printM();
        pair<int, int> np = nextPointA();

        printf("%d %d\n", np.first, np.second);
        fflush(stdout);

        scanf("%d %d", &iRet, &jRet);

        if (iRet == 0 && jRet == 0) {
            return true;
        }

        M[jRet-3][iRet] = true;
    } while (!stop_condition());

    return false;
}

int main()
{
    scanf("%d", &T);
    FOR (t,0,T) {
        scanf("%d", &A);

        desiredW = (A + 2) / 3;

        if (!solve()) return -1;

        FOR(j,0,3)FOR (i,0,1000)M[j][i]=0;
    }

    return 0;
}
