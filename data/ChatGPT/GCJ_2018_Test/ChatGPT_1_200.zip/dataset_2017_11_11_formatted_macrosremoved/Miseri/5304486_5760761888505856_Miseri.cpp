#include <bits/stdc++.h>
#include <unistd.h>

// #pragma GCC optimize ("O3")

#define REP(i, s, e) for (lli i = s, iend = e; i <= iend; ++i)
#define REPR(i, s, e) for (lli i = s, iend = e; i >= iend; --i)
#define FOR(i, s, e) for (lli i = s, iend = e; i != iend; ++i)
#define FORR(i, s, e) for (lli i = s, iend = e; i != iend; --i)

using namespace std;

typedef long long int lli;
typedef long double ld;
typedef string str;
template<typename T> using vec = vector<T>;

const lli INF = 2e18;

lli T;
lli N, K;
lli maxval, minval, elem;
set<lli> visited;

void recalc_L_R(vec<lli>& L, vec<lli>& R)
{
    lli lastpicked;

    FOR (i, 0, N) {
        if (L[i] == INF) {
            lastpicked = i;
            continue;
        }

        L[i] = i - lastpicked - 1;
    }

    REPR (i, N-1, 0) {
        if (R[i] == INF) {
            lastpicked = i;
            continue;
        }

        R[i] = lastpicked - i - 1;
    }
}

void pick_stall(vec<lli>& L, vec<lli>& R)
{
    maxval = -1;
    minval = -1;
    elem = -1;

    FOR (i, 0, N) {
        if (L[i] == INF) continue;

        if (minval < min(L[i], R[i])) {
            minval = min(L[i], R[i]);
            maxval = max(L[i], R[i]);
            elem = i;
        } else if (minval == L[i] || minval == R[i]) {
            if (max(L[i], R[i]) > maxval) {
                elem = i;
                maxval = max(L[i], R[i]);
            }
        }
    }

    if (elem == -1) {
        printf("No suitable elem");
        exit(-1);
    }

    L[elem] = INF;
    R[elem] = INF;

    recalc_L_R(L, R);
}

void brute_solve()
{
    vec<lli> L, R;
    L.resize(N, 0);
    R.resize(N, 0);

    L[0] = INF;
    L[N-1] = INF;
    R[0] = INF;
    R[N-1] = INF;

    recalc_L_R(L, R);

    FOR (i, 0, K) pick_stall(L, R);
    printf("%lld %lld", maxval, minval);
}

bool stop;
lli clPow2, kModPow2;

void traverse(lli n, lli k)
{
    if (visited.find(n) != visited.end() || stop == true) {
        return;
    }

    maxval = n/2;
    minval = n-n/2-1;

    if (k == 1) {
        stop = true;
        return;
    }

    visited.insert(n);

    if (k%2 == 0) traverse(maxval, k/2);
    if (k%2 == 1) traverse(minval, k/2);
}

void smart_solve()
{
    visited.clear();
    stop = false;
    traverse(N-2, K);

    printf("%lld %lld", maxval, minval);
}

void solve()
{
    smart_solve();
}

int main()
{
    scanf("%lld", &T);

    FOR (i, 0, T) {
        scanf("%lld %lld", &N, &K);
        N += 2;

        printf("Case #%lld: ", i+1);
        solve();
        printf("\n");
    }

    return 0;
}
