#include <bits/stdc++.h>
#include <unistd.h>

#pragma GCC optimize ("O3")

#define REP(i, s, e) for (lli i = s, iend = e; i <= iend; ++i)
#define REPR(i, s, e) for (lli i = s, iend = e; i >= iend; --i)
#define FOR(i, s, e) for (lli i = s, iend = e; i != iend; ++i)
#define FORR(i, s, e) for (lli i = s, iend = e; i != iend; --i)

using namespace std;

typedef long long int lli;
typedef long double ld;
typedef string str;
template<typename T> using vec = vector<T>;

int T;
vector<int> L;

void TroubleSort(vector<int>& L)
{
    int tmp;
    bool done = false;
    while (!done) {
        done = true;
        FOR(i,0,L.size()-2) {
            if (L[i] > L[i+2]) {
                done = false;

                tmp = L[i];
                L[i] = L[i+2];
                L[i+2] = tmp;
            }
        }
    }
}

int Sorted(vector<int>& L)
{
    FOR(i,0,L.size()-1) {
        if (L[i] > L[i+1]) {
            return i;
        }
    }

    return -1;
}

int main()
{
    int S, v, srt;
    L.reserve(100000);

    scanf("%d\n", &T);
    FOR(t,0,T) {
        L.clear();
        scanf("%d", &S);
        FOR (s,0,S) {
            scanf("%d", &v);
            L.push_back(v);
        }

        TroubleSort(L);
        srt = Sorted(L);

        printf("Case #%d: ", t+1);
        if (srt == -1) printf("OK");
        else printf("%d", srt);
        printf("\n");
    }

    return 0;
}
