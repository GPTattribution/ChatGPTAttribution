#include <bits/stdc++.h>
#include <unistd.h>

// #pragma GCC optimize ("O3")

#define REP(i, s, e) for (lli i = s, iend = e; i <= iend; ++i)
#define REPR(i, s, e) for (lli i = s, iend = e; i >= iend; --i)
#define FOR(i, s, e) for (lli i = s, iend = e; i != iend; ++i)
#define FORR(i, s, e) for (lli i = s, iend = e; i != iend; --i)

using namespace std;

typedef long long int lli;
typedef long double ld;
typedef string str;
template<typename T> using vec = vector<T>;

int T, D;
string P;

int beamdmg(const string& S)
{
    int beam = 1;
    int dmg = 0;
    FOR(i,0,S.length())
        if (S[i] == 'C') beam *= 2;
        else dmg += beam;

    return dmg;
}

int mindmg(const string& S)
{
    int strikes = 0;

    FOR(i,0,S.length())
        if (S[i] == 'S') ++strikes;

    return strikes;
}

bool mindmg_seq(const string& S)
{
    return beamdmg(S) == mindmg(S);
}

void reducedmg(string& S)
{
    REPR(i,S.size()-2,0) {
        if (S[i] == 'C' && S[i+1] == 'S') {
            S[i+1] = 'C';
            S[i] = 'S';
            return;
        }
    }
}

void solve()
{
    int moves = 0;

    for(;;) {
        if (beamdmg(P) <= D) {
            printf("%d", moves);
            return;
        }

        if (mindmg_seq(P)) {
            printf("IMPOSSIBLE");
            return;
        }

        reducedmg(P);
        ++moves;
    }
}

int main()
{
    char Pbuf[40];
    scanf("%d\n", &T);
    FOR(t,0,T) {
        scanf("%d %s\n", &D, Pbuf);
        P = Pbuf;

        printf("Case #%d: ", t+1);
        solve();
        printf("\n");
    }

    return 0;
}
