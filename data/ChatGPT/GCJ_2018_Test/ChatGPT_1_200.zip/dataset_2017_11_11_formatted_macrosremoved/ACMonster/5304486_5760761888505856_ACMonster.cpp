#include <bits/stdc++.h>
static inline uint32_t log2(const uint32_t x) {
  uint32_t y;
  asm ( "\tbsr %1, %0\n"
      : "=r"(y)
      : "r" (x)
  );
  return y;
}

using namespace std;

map<long,pair<long,map<long,long> > > m;

pair<long,long> solve(long n,long k){
	long mi,ma,t;
	queue<long> s;
	s.push(n);

	m[n*-1]=make_pair(1,map<long,long>());
	while(s.size()>0){
		t = s.front();s.pop();
		ma = mi = t/2;
		if(t%2==0){
			mi--;
		}
		//printf("a %ld %ld %ld\n",t,ma,mi);
		if(ma <= 1);
		else if(m.find(ma*-1)!=m.end()){
			//printf("b %ld\n",ma);
			m[ma*-1].first++;
			if(m[ma*-1].second.find(t)==m[ma*-1].second.end())m[ma*-1].second[t]=1;
			else m[ma*-1].second[t]++;
		}
		else{
			//printf("b %ld\n",ma);
			m[ma*-1]=make_pair(1,map<long,long>());
			if(m[ma*-1].second.find(t)==m[ma*-1].second.end())m[ma*-1].second[t]=1;
			else m[ma*-1].second[t]++;
			s.push(ma);
		}
		if(mi <= 1);
		else if(m.find(mi*-1)!=m.end()){
			//printf("b %ld\n",mi);
			m[mi*-1].first++;
			if(m[mi*-1].second.find(t)==m[mi*-1].second.end())m[mi*-1].second[t]=1;
			else m[mi*-1].second[t]++;
		}
		else{
			//printf("b %ld\n",mi);
			m[mi*-1]=make_pair(1,map<long,long>());
			if(m[mi*-1].second.find(t)==m[mi*-1].second.end())m[mi*-1].second[t]=1;
			else m[mi*-1].second[t]++;
			s.push(mi);
		}
		//printf("%ld %ld\n",m[ma*-1].first,m[ma*-1].second[t]);
	}
	map<long,pair<long,map<long,long> > >::iterator it;
	long sum=0;
	for(it=m.begin();it!=m.end();it++){
		//printf("!%ld %ld\n",(*it).first*-1,(*it).second.first);
		sum+=(*it).second.first;
		ma = mi = (*it).first*-1/2;
		if((*it).first*-1%2==0)mi--;
		if(sum>=k)break;
		//printf("%ld %ld %ld %ld (%ld)\n",ma,m[ma*-1].first, m[ma*-1].second[(*it).first*-1], (*it).second.first * m[ma*-1].second[(*it).first*-1],m[ma*-1].first - m[ma*-1].second[(*it).first*-1] + (*it).second.first * m[ma*-1].second[(*it).first*-1]);
		m[ma*-1].first = m[ma*-1].first - m[ma*-1].second[(*it).first*-1] + (*it).second.first * m[ma*-1].second[(*it).first*-1];

		//if(ma!=mi)printf("%ld %ld %ld %ld (%ld)\n",mi,m[mi*-1].first,m[mi*-1].second[(*it).first*-1],(*it).second.first * m[mi*-1].second[(*it).first*-1],m[mi*-1].first - m[mi*-1].second[(*it).first*-1] + (*it).second.first * m[mi*-1].second[(*it).first*-1]);
		if(ma!=mi)m[mi*-1].first = m[mi*-1].first - m[mi*-1].second[(*it).first*-1] + (*it).second.first * m[mi*-1].second[(*it).first*-1];
		(*it).second.second.clear();
	}

	m.clear();
	return make_pair(mi,ma);
}

int main(){
	pair<long,long> p;
	long x,y;
	int T;
	scanf("%d",&T);
	for(int tt=0;tt<T;tt++){
		scanf("%ld %ld",&x,&y);
		p = solve(x,y);
		//printf("(%ld,%ld)\n",x,y);
		printf("Case #%d: %ld %ld\n",tt+1,p.second,p.first);
	}
	return 0;
}
