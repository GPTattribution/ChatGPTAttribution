#include <bits/stdc++.h>

using namespace std;

priority_queue<pair<int,int> > q;

int main(){
	int T;
	scanf("%d",&T);
	int d,n,kx,sx;
	double x;
	for(int tt=0;tt<T;tt++){
		scanf("%d %d",&d,&n);
		for(int i=0;i<n;i++){
			scanf("%d %d",&kx,&sx);
			q.push(make_pair(kx,sx));
		}
		x = 0;
		while(q.size()>0){
			kx = q.top().first;
			sx = q.top().second;
			q.pop();
			if(x<(d-kx)*1.0/sx*1.0)x = (d-kx)*1.0/sx*1.0;
		}
		printf("Case #%d: %.6lf\n",tt+1,d/x);
	}
	return 0;
}
