#include <stdio.h>
#include <cstring>

#define ki0 5
#define kj0 4

#define ki1 50
#define kj1 4

using namespace std;

int m[300][300];
int v[300][300];
int ki,kj;

void val(int mi,int mj){
	for(int i = 0;i<mi;i++){
		for(int j = 0;j<mj;j++){
			if(m[i][j]!=1){
				for(int xi=-1;xi<2;xi++){
					if(i+xi>=0 && i+xi<mi){
						for(int xj=-1;xj<2;xj++){
							if(j+xj>=0 && j+xj<mj)
								v[i+xi][j+xj]++;
						}
					}
				}
			}
		}
	}
}

void fmax(int mi,int mj){
	ki=1;kj=1;
	int vl=0;
	for(int i = 1;i<mi-1;i++){
		for(int j = 1;j<mj-1;j++){
			if(v[i][j]>vl){
				vl=v[i][j];
				ki = i;kj = j;
			}
		}
	}
}

int main(){
	int T;
	scanf("%d",&T);
	int A,mi,mj,xi,xj;
	for(int tt = 0;tt<T;tt++){
		memset(m,0,sizeof(m));
		scanf("%d",&A);

		if(A==20){
			mi=ki0;mj=kj0;
		}
		else{
			mi=ki1;mj=kj1;
		}

		while(true){
			memset(v,0,sizeof(v));
			val(mi,mj);
			fmax(mi,mj);

			printf("%d %d\n",ki+1,kj+1);
			fflush(stdout);

			scanf("%d %d",&xi,&xj);
			if(xi==0 && xj==0) break;
			if(xi==-1 && xj==-1){
				return 1/0;
			}

			m[xi-1][xj-1]=1;
		}
	}
	return 0;
}
