#include <bits/stdc++.h>

using namespace std;

void clean_s(char s[]){
    for(int i=0;i<15;i++) s[i] = '\0';
}

int main(){
    int T;
    scanf("%d",&T);
    int a,b,n,m,A,B;
    char s[15];
    for(int tt = 0;tt < T;tt++){
        scanf("%d %d %d",&a,&b,&n);
        A = a;B = b;
        m = min(max(A+1,(a+b)/2),B);
        printf("%d\n",m);

        cout << flush;
        clean_s(s);
        scanf("%s",s);

        while(strcmp(s,"CORRECT")!=0){
            if(strcmp(s,"TOO_SMALL")==0){
                a = m + 1;
            }
            else{
                b = m - 1;
            }

            m = min(max(A+1,(a+b)/2),B);
            printf("%d\n",m);

            cout << flush;
            clean_s(s);
            scanf("%s",s);
        }
    }
    return 0;
}
