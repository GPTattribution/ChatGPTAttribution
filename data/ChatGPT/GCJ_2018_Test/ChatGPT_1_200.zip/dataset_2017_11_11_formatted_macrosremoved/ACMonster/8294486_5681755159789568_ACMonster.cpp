#include <stdio.h>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

string res;

int solve(int n,vector<pair<int,int> > q){
	/*
	cout << res <<endl;
		printf(" ");
		for(int k=0;k<q.size();k++) printf("%d%c ",q[k].first,'A'+q[k].second);
		printf("\n");
	*/
	//if(n == 0) return 1;

	sort(q.begin(),q.end());

	int mx = q.back().first,mx2;
	if(q.size()>1){
		mx2 = max(q.back().first-1,q[q.size()-2].first);
	}
	else mx2 = mx-1;
	/*
	cout << res;
	printf(" %d %d\n",n,mx);
	for(int i=0;i<q.size();i++) printf("%d ",q[i].first);
	printf("\n");*/

	if(2*mx>n && (n>2 || (n == 1 && mx == 1) || (n == 2 && mx == 2))){
		//printf("!!\n");
		return 0;
	}
	if(n == 0) return 1;
	//cout <<0<<endl;
	//if(2*mx2>n-1) return 0;
	//cout <<0<<endl;

	res+=' ';

	int a1,b1,a2,b2,flag;
	for(int i=(int)q.size()-1;i>=0;i--){

		//if(q[i].first < mx) break;
		if(q[i].first>0){
			a1 = q[i].first;
			b1 = q[i].second;

			res+='A'+b1;
			q[i].first--;

			if(solve(n-1,q)) return 1;

			for(int j = i;j>=0;j--){
				//for(int k=0;k<q.size();k++) printf("%d ",q[i].first);
				//printf("b\n");
				flag = 1;
				//printf("a %d %d\n",j,(int)q.size());
				/*
				if(q[j].first > 0 && q[j].first < mx2){
					if(j == i) flag = 0;
					else break;
				}*/
				//printf("b\n");
				if(flag && q[j].first > 0){
					a2 = q[j].first;
					b2 = q[j].second;

					res+='A'+b2;
					//cout << res <<endl;

					q[j].first--;

					//for(int k=0;k<q.size();++) printf("%d ",q[i].first);
					//printf("a\n");

					if(solve(n-2,q)) return 1;
					res.pop_back();
					q[j].first++;
				}
			}
			res.pop_back();
			q[i].first++;
		}
	}

	res.pop_back();
	return 0;
}

int main(){
	int T;
	scanf("%d",&T);
	int N;
	int x,tp;
	vector<pair<int,int> > q;
	for(int tt = 0;tt< T;tt++){
	    scanf("%d",&N);
	    tp = 0;
	    for(int i=0;i<N;i++){
				scanf("%d",&x);
				tp += x;
				q.push_back(make_pair(x,i));
			}
			if(!solve(tp,q))while(true);

			cout << "Case #" << tt+1 << ":" << res << endl;
			q.clear();
			res.clear();
			//printf("Case #%d ",tt);
			/*
			while(q.size()>0){
				a = q.top().first;
				b = q.top().second;

				a = a-1;
				tp -= 1;

				printf("%c",'A'+b);
				q.pop();
				if(a>0) q.push(make_pair(a,b));

				a = q.top().first;
				b = q.top().second;
				q.pop()
			}*/
	}
	return 0;
}
