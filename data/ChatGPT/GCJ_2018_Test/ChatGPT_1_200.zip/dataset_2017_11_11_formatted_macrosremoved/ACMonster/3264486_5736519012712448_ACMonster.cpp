#include <stdio.h>
#include <set>

using namespace std;

multiset<int> s0,s1;

int main(){
	int T;
	scanf("%d",&T);

	int n,x,k;
	bool b;
	multiset<int>::iterator it0,it1;
	for(int tt = 0;tt<T;tt++){
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			scanf("%d",&x);
			if(i%2==0)s0.insert(x);
			else s1.insert(x);
		}
		k=0;
		x = (*s0.begin());
		b = true;
		for(it0 = s0.begin(),it1 = s1.begin();k<n;k++){
			if(k%2==0){
				if(*it0 < x){
					b = false;
					break;
				}
				x = *it0;
				it0++;
			}
			else{
				if(*it1 < x){
					b = false;
					break;
				}
				x = *it1;
				it1++;
			}
		}
		if(b) printf("Case #%d: OK\n",tt+1);
		else  printf("Case #%d: %d\n",tt+1,k-1);
		s0.clear();s1.clear();
	}
	return 0;
}
