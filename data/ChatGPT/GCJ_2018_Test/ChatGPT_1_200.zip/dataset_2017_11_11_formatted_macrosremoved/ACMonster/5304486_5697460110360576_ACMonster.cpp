#include <stdio.h>

using namespace std;

int v[35];
int vd[35];

int check(long d,long n){
	long t=0;
	int k = 0;
	if(n%2 != 0) n--;
	for(int i=0;i<=n-2;i+=2){
		t+=(v[i]*(1<<vd[i]));
		if(t>d) return -1;
	}
	if(t+(1<<(vd[n]-1))>d) return -1;
	else{
		while(k<=v[n] && t+k*(1<<(vd[n]-1))+(v[n]-k)*(1<<(vd[n]))>d ){
			k++;
		}
	}
	return k;
}

long solve(long d,long n){
	long res = 0;
	int c;
	if(n%2!=0){
		n--;
	}
	while (n>1){
		if(v[n]==0)n = n-2;
		else{
			c = check(d,n);
			if(c == -1){
				if(vd[n] == 1){
					res+=v[n];
					v[n-2]+=v[n];
					v[n] = 0;
				}
				else{
					res+=v[n];
					vd[n]--;
				}
			}
			else if ( c == 0) return res;
			else return res+c;
		}
	}
	return res;
}

int main(){
	int T;
	scanf("%d",&T);
	long d,n,ch,sh;
	char s[35];
	for(int tt = 0;tt<T;tt++){
		ch = 0; sh = 0;
		for(int i=0;i<35;i++){
			vd[i] = 0;
			v[i] = 0;
			s[i] = '\0';
		}
		scanf("%ld ",&d);
		scanf("%s",s);
		if(s[0] == 'C'){
			ch++;
			vd [2]++;
			n = 1;
		}
		else{
			n = 0;
			sh++;
		}
		v[n]++;
		for(int i = 1;s[i]!='\0';i++){
			if(s[i]!=s[i-1])n++;
			if(s[i] == 'C'){
				ch++;
			}
			else{
				vd[n]=ch;
				sh++;
			}
			v[n]++;
		}
		if(sh>d) printf("Case #%d: IMPOSSIBLE\n",tt+1);
		else     printf("Case #%d: %ld\n",tt+1,solve(d,n));
	}
	return 0;
}
