#include <stdio.h>
#include <stdlib.h>
#include <string.h>

using namespace std;

double solve()
{
    int dest, nH;
    scanf("%d%d", &dest, &nH);
    double longestTime = 0;
    for (int i = 0; i < nH; ++i) {
        int pos, speed;
        scanf("%d%d", &pos, &speed);
        double time = (double)(dest - pos) / (double) speed;
        if (time > longestTime) longestTime = time;
    }

    return (double)dest / longestTime;
}

int main(void)
{
    int nC;
    scanf("%d", &nC);
    for (int cC = 0; cC < nC; ++cC) {
        printf("Case #%d: %.6f\n", cC + 1, solve());
    }
    return 0;
}
