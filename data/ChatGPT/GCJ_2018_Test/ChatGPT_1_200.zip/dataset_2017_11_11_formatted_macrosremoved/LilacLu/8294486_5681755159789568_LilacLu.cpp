#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <queue>

using namespace std;

struct Party {
    int count;
    char id;

    bool operator<(const Party &other) const {
        return count < other.count;
    }
};

void solve()
{
    int parties;
    int total = 0;

    scanf("%d", &parties);

    priority_queue<Party> party;
    for (int i = 0; i < parties; ++i) {
        Party newParty;

        scanf("%d", &newParty.count);

        total += newParty.count;
        newParty.id = 'A' + i;

        party.push(newParty);
    }

    while (!party.empty()) {
        Party most = party.top();
        printf(" %c", most.id);
        most.count--;
        party.pop();

        total--;
        if (most.count) {
            party.push(most);
        }

        most = party.top();
        if (most.count > total / 2) {
            printf("%c", most.id);
            most.count--;
            party.pop();
            total--;
            if (most.count) {
                party.push(most);
            }
        }
    }

}

int main(void)
{
    int nC;
    scanf("%d", &nC);
    for (int cC = 0; cC < nC; ++cC) {
        printf("Case #%d:", cC + 1);
        solve();
        printf("\n");
    }
    return 0;
}
