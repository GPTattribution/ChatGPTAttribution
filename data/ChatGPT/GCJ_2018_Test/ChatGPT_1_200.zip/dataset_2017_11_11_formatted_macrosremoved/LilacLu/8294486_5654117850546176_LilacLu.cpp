#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void compete()
{
    int A, B, N;
    scanf("%d%d%d", &A, &B, &N);
    ++A;

    for (int i = 0; i < N; ++i) {
        int val = (A + B) / 2;
        printf("%d\n", val);
        fflush(stdout);
        char resp[80];
        scanf("%s", resp);
        if (strcmp(resp, "CORRECT") == 0) {
            return;
        } else if (strcmp(resp, "WRONG_ANSWER") == 0) {
            exit(1);
        } else if (strcmp(resp, "TOO_SMALL") == 0) {
            A = val + 1;
        } else if (strcmp(resp, "TOO_BIG") == 0) {
            B = val - 1;
        } else {
            abort();
        }
    }
}

int main(void)
{
    int nC;
    scanf("%d", &nC);
    for (int i = 0; i < nC; ++i) {
        compete();
    }
    return 0;
}
