#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>

#include <algorithm>
#include <vector>

void solve()
{
    int64_t maxDmg;
    char seq[31];
    scanf("%lld%s", &maxDmg, seq);

    int len = strlen(seq);

    while (len && seq[len - 1] == 'C') --len;

    int moves = 0;
    int64_t currDmg = 0;
    int shotDmg = 1;
    int lastC = -1;
    int sCount = 0;
    for (int i = 0; i < len; ++i) {
        if (seq[i] == 'S') {
            currDmg += shotDmg;
            ++sCount;
        } else {
            shotDmg *= 2;
            lastC = i;
        }
    }

    shotDmg /= 2;

    if (sCount > maxDmg) {
        printf("IMPOSSIBLE\n");
        return;
    }

    while (currDmg > maxDmg) {
        ++moves;
        seq[lastC] = 'S';
        seq[lastC + 1] = 'C';
        ++lastC;
        currDmg -= shotDmg;

        if (currDmg <= maxDmg) break;

        if (lastC == len - 1) {
            --len;
            lastC = len - 1;
            while (seq[lastC] == 'S') --lastC;

            shotDmg /= 2;
        }
    }

    printf("%d\n", moves);
}

int main(void)
{
    int nC;
    scanf("%d", &nC);
    for (int cC = 0; cC < nC; ++cC) {
        printf("Case #%d: ", cC + 1);
        solve();
    }
    return 0;
}
