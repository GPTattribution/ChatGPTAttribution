#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <utility>

using namespace std;

bool filled[1000][1000];

int length, width;
int area;

pair<int, int> getNext()
{
    if (area <= 9) {
        return make_pair(500, 500);
    }

    int bestX = 0;
    int bestY = 0;
    int bestArea = 0;

    for (int i = 1; i <= length - 2; ++i) {
        for (int j = 1; j <= width - 2; ++j) {
            int count = 0;
            for (int k = i - 1; k <= i + 1; ++k) {
                for (int l = j - 1; l <= j + 1; ++l) {
                    if (!filled[k][l]) ++count;
                }
            }
            if (count > bestArea) {
                bestArea = count;
                bestX = i; bestY = j;
            }
        }
    }

    return make_pair(bestX + 1, bestY + 1);
}

void solve()
{
    memset(filled, 0, sizeof(filled));

    scanf("%d", &area);

    length = 1;
    width = 1;

    while (length * width < area) {
        if (length == width) ++length;
        else ++width;
    }

    while (true)
    {
        pair<int, int> resp = getNext();
        printf("%d %d\n", resp.first, resp.second);
        fflush(stdout);

        int x, y;
        scanf("%d%d", &x, &y);
        if (x == -1 && y == -1) {
            exit(0);
        } else if (x == 0 && y == 0) {
            return;
        }

        --x; --y;
        filled[x][y] = true;
    }
}

int main(void)
{
    int nC;
    scanf("%d", &nC);
    for (int cC = 0; cC < nC; ++cC) {
        solve();
    }
    return 0;
}
