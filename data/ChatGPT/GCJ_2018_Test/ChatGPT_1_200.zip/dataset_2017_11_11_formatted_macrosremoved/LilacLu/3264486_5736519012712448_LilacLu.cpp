#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <algorithm>
#include <vector>

using namespace std;

void solve()
{
    vector<int> odd, even;
    int nums;
    scanf("%d", &nums);
    for (int i = 0; i < nums; ++i) {
        int val;
        scanf("%d", &val);
        if (i % 2 == 1) {
            odd.push_back(val);
        } else {
            even.push_back(val);
        }
    }

    sort(odd.begin(), odd.end());
    sort(even.begin(), even.end());

    if (even[0] > odd[0]) {
        printf("0\n");
        return;
    }

    for (int i = 1; i < (int)odd.size(); ++i) {
        if (odd[i - 1] > even[i]) {
            printf("%d\n", i * 2 - 1);
            return;
        }
        if (even[i] > odd[i]) {
            printf("%d\n", i * 2);
            return;
        }
    }

    if (odd.size() < even.size()) {
        if (odd.back() > even.back()) {
            printf("%d\n", (int)odd.size() * 2 - 1);
            return;
        }
    }

    printf("OK\n");
}

int main(void)
{
    int nC;
    scanf("%d", &nC);
    for (int cC = 0; cC < nC; ++cC) {
        printf("Case #%d: ", cC + 1);
        solve();
    }

    return 0;
}
