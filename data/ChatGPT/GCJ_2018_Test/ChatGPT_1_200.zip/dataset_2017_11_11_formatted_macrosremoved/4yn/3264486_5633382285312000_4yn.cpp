#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

const double PI = acos(-1);

vector<double> findRotation(double A) {
    double theta = acos(A / sqrt(2));
    double phi = (PI - theta) / 2;

    return {
        0.5 * cos(phi), 0.5 * sin(phi), 0,
        -0.5 * sin(phi), 0.5 * cos(phi), 0,
        0, 0, 0.5
    };
}

int main() {
    int T;
    double A;
    cin >> T;

    for (int i = 1; i <= T; ++i) {
        cin >> A;
        vector<double> rotation = findRotation(A);

        cout << "Case #" << i << ":" << endl;
        for (int j = 0; j < 9; ++j) {
            cout << rotation[j];
            if ((j + 1) % 3 == 0) cout << endl;
            else cout << ' ';
        }
    }

    return 0;
}
