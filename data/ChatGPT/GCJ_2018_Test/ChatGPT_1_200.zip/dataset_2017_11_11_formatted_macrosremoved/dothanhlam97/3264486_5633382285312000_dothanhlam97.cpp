#include <iostream>
#include <cmath>
#include <vector>

const double EPS = 1e-9;

void solve(double A) {
    double phi = (A - 1) / (sqrt(2) - 1);
    double theta = atan(phi);

    std::vector<std::vector<double>> ans = {
        {0.5 * cos(theta), 0.5 * sin(theta), 0},
        {-0.5 * sin(theta), 0.5 * cos(theta), 0},
        {0, 0, 0.5}
    };

    for (const auto &vec : ans) {
        for (const auto &coord : vec) {
            std::cout << coord << ' ';
        }
        std::cout << std::endl;
    }
}

int main() {
    int T;
    double A;
    std::cin >> T;

    for (int i = 1; i <= T; ++i) {
        std::cin >> A;
        std::cout << "Case #" << i << ":\n";
        solve(A);
    }

    return 0;
}
