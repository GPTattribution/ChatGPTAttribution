#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double pi = acos(-1.0);

void solve(int t, double A) {
    double theta = acos(A / sqrt(2));

    cout << "Case #" << t << ":\n";
    cout << fixed << setprecision(10);
    cout << 0.5 * cos(theta) << " " << 0.5 * sin(theta) << " " << 0 << "\n";
    cout << -0.5 * sin(theta) << " " << 0.5 * cos(theta) << " " << 0 << "\n";
    cout << 0 << " " << 0 << " " << 0.5 << "\n";
}

int main() {
    int T;
    double A;
    cin >> T;

    for (int t = 1; t <= T; ++t) {
        cin >> A;
        solve(t, A);
    }

    return 0;
}
