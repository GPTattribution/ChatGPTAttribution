#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <map>
#include <queue>
#include <iomanip>

using namespace std;

#define ff first
#define ss second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef pair<ll,ll> pii;
typedef vector<pii> vii;
typedef vector<ll> vi;
typedef vector<vi> vvi;

void debugvi(vi & v){
    for (ll i=0; i<v.size(); i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

bool operator<(pii & p1, pii & p2){
	return p1.ff<p2.ff;
}

ll LowerRoot(ll x){
	ll lower=0;
	ll upper=x;
	while (lower<upper){
		ll mid=(lower+upper+1)/2;
		if (x<(mid*mid)){
			upper=mid-1;
		}
		else {
			lower=mid;
		}
	}
	return lower;
}

int main(){
	int t; cin>>t;
	for (int h=0; h<t; h++){
		ll a; cin>>a;
		ll r=5;
		if (a==200){
			r=15;
		}
		vvi v(r, vi(r,0));
		bool done=false;
		while (true){
			if (done){
				break;
			}
			bool reset=false;
			for (int i=0; i<r; i++){
				if (reset){
					break;
				}
				for (int j=0; j<r; j++){
					if (reset){
						break;
					}
					if (!v[i][j]){
						reset=true;
						ll si=i;
						ll sj=j;
						if (si==0){si++;}
						if (sj==0){sj++;}
						if (si==r-1){si--;}
						if (sj==r-1){sj--;}
						si++;
						sj++;
						cout<<si<<" "<<sj<<endl;
						ll ai;
						ll aj;
						cin>>ai>>aj;
						if (ai==0 && aj==0){
							done=true;
							break;
						}
						ai--;
						aj--;
						v[ai][aj]=1;
					}
				}
			}
		}
	}
}
