#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <map>
#include <queue>
#include <iomanip>

using namespace std;

#define ff first
#define ss second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef pair<ll,ll> pii;
typedef vector<pii> vii;
typedef vector<ll> vi;
typedef vector<vi> vvi;

void debugvi(vi & v){
    for (ll i=0; i<v.size(); i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

int main(){
	int t; cin>>t;
	for (int h=0; h<t; h++){
		ll a, b; cin>>a>>b;
		ll n; cin>>n;
		ll low=a;
		ll upp=b;
		while (true){
			ll m=(low+upp)/2;
			cout<<m<<endl;
			string s; cin>>s;
			if (s=="CORRECT"){
				break;
			}
			if (s=="TOO_SMALL"){
				low=m+1;
			}
			else {
				upp=m-1;
			}
		}
	}

}
