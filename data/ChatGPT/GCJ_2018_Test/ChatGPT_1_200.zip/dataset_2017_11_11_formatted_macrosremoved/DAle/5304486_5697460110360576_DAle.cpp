#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <map>
#include <queue>
#include <iomanip>

using namespace std;

#define ff first
#define ss second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef pair<ll,ll> pii;
typedef vector<pii> vii;
typedef vector<ll> vi;
typedef vector<vi> vvi;

void debugvi(vi & v){
    for (ll i=0; i<v.size(); i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

bool operator<(pii & p1, pii & p2){
	return p1.ff<p2.ff;
}

ll score(vi & ctByStrength){
	ll val=0;
	ll mult=1;
	for (int i=0; i<ctByStrength.size(); i++){
		val+=(ctByStrength[i]*mult);
		mult*=2;
	}
	return val;
}

int main(){
	int t; cin>>t;
	for (int h=0; h<t; h++){
		cout<<"Case #"<<h+1<<": ";
		ll shield; cin>>shield;
		string s; cin>>s;
		ll z=s.size();
		vi ctByStrength(z,0);
		int vpos=0;
		ll sumshoot=0;
		for (int i=0; i<z; i++){
			if (s[i]=='C'){
				vpos++;
			}
			else {
				ctByStrength[vpos]++;
				sumshoot++;
			}
		}
		if (sumshoot>shield){
			cout<<"IMPOSSIBLE"<<endl;
			continue;
		}

		ll swappos=z-1;
		ll numswaps=0;
		while (true){
			if (shield>=score(ctByStrength)){
				break;
			}
			if (ctByStrength[swappos]>0){
				ctByStrength[swappos]--;
				ctByStrength[swappos-1]++;
				numswaps++;
			}
			else {
				swappos--;
			}
		}
		cout<<numswaps<<endl;
	}
}
