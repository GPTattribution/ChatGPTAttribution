//"I am the senate." - The Senate

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <map>
#include <queue>
#include <iomanip>

using namespace std;

#define ff first
#define ss second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef pair<ll,ll> pii;
typedef vector<pii> vii;
typedef vector<ll> vi;
typedef vector<vi> vvi;

void debugvi(vi & v){
    for (ll i=0; i<v.size(); i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

bool operator<(pii & p1, pii & p2){
	return p1.ff<p2.ff;
}

int main(){
	int t; cin>>t;
	for (int h=0; h<t; h++){
		cout<<"Case #"<<h+1<<": ";
		ll n; cin>>n;
		vii v(n);
		ll tot=0;
		for (ll i=0; i<n; i++){
			ll pop; cin>>pop;
			v[i].ff=pop;
			v[i].ss=i;
			tot+=pop;
		}
		sort(v.begin(),v.end());
		reverse(v.begin(),v.end());
		if (n==2){
			while (v[0].ff>v[1].ff){
				v[0].ff--;
				cout<<(char)(v[0].ss+'A')<<" ";
			}
			while (v[0].ff>0){
				v[0].ff--;
				v[1].ff--;
				cout<<(char)(v[0].ss+'A')<<(char)(v[1].ss+'A')<<" ";
			}
			cout<<endl;
		}
		else {
			while (tot>2){
				ll highest=v[0].ff;
				for (int i=0; i<n; i++){
					if (v[i].ff==highest){
						v[i].ff--;
						tot--;
						cout<<(char)(v[i].ss+'A')<<" ";
					}
					else {
						break;
					}
					if (tot==2){
						break;
					}
				}
			}
			for (int i=0; i<n; i++){
				if (v[i].ff>0){
					cout<<(char)(v[i].ss+'A');
				}
			}
			cout<<endl;
		}
	}
}
