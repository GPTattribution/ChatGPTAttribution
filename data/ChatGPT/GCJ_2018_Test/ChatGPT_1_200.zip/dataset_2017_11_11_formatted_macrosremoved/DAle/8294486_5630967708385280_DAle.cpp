#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <map>
#include <queue>
#include <iomanip>

using namespace std;

#define ff first
#define ss second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef pair<ll,ll> pii;
typedef vector<pii> vii;
typedef vector<ll> vi;
typedef vector<vi> vvi;

void debugvi(vi & v){
    for (ll i=0; i<v.size(); i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

bool operator<(pii & p1, pii & p2){
	return p1.ff<p2.ff;
}

int main(){
	int t; cin>>t;
	for (int h=0; h<t; h++){
		cout<<"Case #"<<h+1<<": ";
		ll d, n; cin>>d>>n;
		vii horses(n);
		double minspd=1000000000000000000;
		for (int i=0; i<n; i++){
			ll pos, spd;
			cin>>pos>>spd;
			double ispd=(double)(d*spd)/(d-pos);
			minspd=min(minspd,ispd);
		}
		printf("%.8f\n",minspd);
	}
}
