#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <map>
#include <queue>
#include <iomanip>

using namespace std;

#define ff first
#define ss second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef pair<ll,ll> pii;
typedef vector<pii> vii;
typedef vector<ll> vi;
typedef vector<vi> vvi;

void debugvi(vi & v){
    for (ll i=0; i<v.size(); i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

bool operator<(pii & p1, pii & p2){
	return p1.ff<p2.ff;
}

int main(){
	int t; cin>>t;
	for (int h=0; h<t; h++){
		cout<<"Case #"<<h+1<<": ";

		ll n, k; cin>>n>>k;

		ll m=1;
		ll tot=1;
		while (tot<k){
			n-=m;
			m*=2;
			tot+=m;
		}
		ll base=n/m;
		ll rem=n%m;
		ll pos=k+m-tot;

		ll val=base-1;
		if (pos<=rem){
			val++;
		}

		ll mn=val/2;
		ll mx=val-mn;
		cout<<mx<<" "<<mn<<endl;
	}
}
