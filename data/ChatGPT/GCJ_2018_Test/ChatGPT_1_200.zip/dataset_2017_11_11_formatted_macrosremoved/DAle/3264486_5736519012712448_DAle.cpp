#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <map>
#include <queue>
#include <iomanip>

using namespace std;

#define ff first
#define ss second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef pair<ll,ll> pii;
typedef vector<pii> vii;
typedef vector<ll> vi;
typedef vector<vi> vvi;

void debugvi(vi & v){
    for (ll i=0; i<v.size(); i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

bool operator<(pii & p1, pii & p2){
	return p1.ff<p2.ff;
}

int main(){
	int t; cin>>t;
	for (int h=0; h<t; h++){
		cout<<"Case #"<<h+1<<": ";
		int n; cin>>n;
		vi odd;
		vi ev;
		for (int i=0; i<n; i++){
			ll x; cin>>x;
			if (i%2){
				odd.pb(x);
			}
			else {
				ev.pb(x);
			}
		}
		sort(odd.begin(),odd.end());
		sort(ev.begin(),ev.end());
		bool valid=true;
		for (int i=0; i<ev.size(); i++){
			if (i>0 && ev[i]<odd[i-1]){
				valid=false;
				cout<<i*2-1<<endl;
				break;
			}
			if (i<odd.size() && odd[i]<ev[i]){
				valid=false;
				cout<<i*2<<endl;
				break;
			}
		}
		if (valid){
			cout<<"OK"<<endl;
		}
	}
}
