#include <iostream>
#include <cstdlib>

typedef int i32;
typedef unsigned int u32;
typedef long long int i64;
typedef unsigned long long int u64;

using namespace std;

void interactive_solve() {
    int A, B, N;
    cin >> A >> B >> N;
    string response = "Blob";
    while (response != "CORRECT") {
        int midpoint = (A + B + 1) / 2;
        cout << midpoint << endl << flush;
        cin >> response;
        if (response == "TOO_BIG") {
            B = midpoint-1;
        } else if (response == "TOO_SMALL") {
            A = midpoint;
        } else if (response == "WRONG_ANSWER") {
            exit(0);
        }
    }
}

int main(int argc, char *argv[]) {
    ios_base::sync_with_stdio(false);
    int T;
    cin >> T;
    for (int ci = 1; ci <= T; ++ci) {
        interactive_solve();
    }
    return 0;
}
