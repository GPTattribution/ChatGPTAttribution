#include <iostream>
#include <algorithm>

using namespace std;

pair<int, int> sen[27];
int N;
int total;

bool poss() {
	sen[0].first--;
	sen[1].first--;
	total -= 2;

	int greatest = sen[0].first;
	if (N >= 3 && sen[2].first>greatest) {
		greatest = sen[2].first;
	}

	if (greatest / (double)total > 0.50)
		return false;
	else
		return true;
}

bool compare(pair<int, int> x, pair<int, int> y) {
	return x.first > y.first;
}

int main() {

	int cases;
	cin >> cases;

	for (int cas = 1; cas <= cases; cas++) {

		cout << "Case #" << cas << ": ";

		cin >> N;
		int temp;
		total = 0;
		for (int i = 0; i < N; i++) {
			cin >> temp;
			total += temp;
			sen[i].first = temp;
			sen[i].second = i;
		}

		sort(sen, sen + N, compare);

		while (sen[0].first > 0) {
			if (!poss()) {
				sen[1].first++;
				total++;
				cout << (char)('A' + sen[0].second);
			}
			else {
				cout << (char)('A' + sen[0].second) << (char)('A' + sen[1].second);
			}
			sort(sen, sen + N, compare);
			if (sen[0].first > 0)
				cout << ' ';
		}
		cout << '\n';
	}

	return 0;
}
