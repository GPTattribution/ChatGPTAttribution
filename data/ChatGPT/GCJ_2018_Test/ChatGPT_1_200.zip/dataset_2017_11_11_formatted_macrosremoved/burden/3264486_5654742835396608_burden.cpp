#include <iostream>
#include <math.h>
#include <string.h>

using namespace std;

bool arr[1005][1005];
int A, si, sj, ei, ej;

bool check(int i, int j) {
	if (arr[i - 1][j - 1] && arr[i][j - 1] && arr[i + 1][j-1])
		return true;
	return false;
}

int main() {
	int cases;
	cin >> cases;

	while (cases--) {
		cin >> A;

		memset(arr, 0, sizeof(arr));
		int length = 3;
		int width = ceil(A / 3.0);

		ej = 1 + width - 1;

		int x, y, curri = 2, currj = 2;

		cout << curri << ' ' << currj << endl;
		cin >> x >> y;

		while (x > 0 && y > 0) {
			arr[x][y] = true;
			while (check(curri, currj) && currj<ej-1)
				currj++;
			cout << curri << ' ' << currj << endl;
			cin >> x >> y;
		}

		if (x < 0)
			break;
	}
	return 0;
}
