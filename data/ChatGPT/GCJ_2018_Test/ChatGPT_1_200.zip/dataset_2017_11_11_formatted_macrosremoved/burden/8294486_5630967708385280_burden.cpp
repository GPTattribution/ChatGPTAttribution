#include <iostream>
#include <algorithm>
#include <string.h>
#include <limits.h>
#include <limits>
#include <float.h>
#include <iomanip>

using namespace std;

int D, N;
pair<double, int> horses[1010];
pair<double, int> diff[1010];
bool reached[1010];

void incDistance(double time) {
	for (int i = 0; i < N; i++) {
		horses[i].first += horses[i].second*time;
	}
}

void check() {
	for (int i = 0; i < N - 1; i++) {
		if (horses[i].first == horses[i + 1].first)
			horses[i].second = horses[i + 1].second;
	}
}

void calcDiff() {
	for (int i = 0; i < N - 1; i++) {
		if (horses[i].second > horses[i + 1].second) {
			diff[i].first = (double)(horses[i+1].first - horses[i].first) / ((double)(horses[i].second - horses[i + 1].second));
		}
		else {
			diff[i].first = DBL_MAX;
		}
		diff[i].second = i;
	}
}

int main() {

	int cases;
	cin >> cases;

	for (int cas = 1; cas <= cases; cas++) {

		cout << "Case #" << cas << ": ";
		cin >> D >> N;

		for (int i = 0; i < N; i++) {
			reached[i] = false;
			cin >> horses[i].first >> horses[i].second;
		}


		sort(horses, horses + N);

		double totalTime = 0;

		while (true) {

			calcDiff();
			sort(diff, diff + N - 1);

			if (N>1 && diff[0].first < DBL_MAX && horses[0].first + horses[0].second*diff[0].first < D) {
				totalTime += diff[0].first;
				incDistance(diff[0].first);
				check();
			}

			else {
				totalTime += (D - horses[0].first) / horses[0].second;
				break;
			}
		}

		cout << fixed << setprecision(6) << D / totalTime << '\n';
	}
	return 0;
}
