#include <bits/stdc++.h>

using namespace std;

int inp[100010];
int siz;


int main() {

	ios_base::sync_with_stdio(false);
	cin.tie(0);

	int cases;
	cin >> cases;

	for (int cas = 1; cas <= cases; cas++) {

		cout << "Case #" << cas << ": ";
		cin >> siz;

		for (int i = 0; i < siz; i++) {
			cin >> inp[i];
		}

		for (int i = 0; i < siz-2; i++) {

		}

		bool done = false;

		while (!done) {
			done = true;

			for (int i = 0; i < siz - 2; i++) {
				if (inp[i] > inp[i + 2]) {
					int temp = inp[i];
					inp[i] = inp[i + 2];
					inp[i + 2] = temp;
					done = false;
				}
			}
		}

		bool sorted = true;
		int i = 0;
		for (; i < siz - 1; i++) {
			if (inp[i] > inp[i + 1]) {
				sorted = false;
				break;
			}
		}

		if (sorted)
			cout << "OK\n";
		else
			cout << i << '\n';
	}
	return 0;
}
