#include <iostream>
#include <string>

using namespace std;

string ok = "CORRECT";
string small = "TOO_SMALL";
string big = "TOO_BIG";

int main() {

	int cases;
	cin >> cases;

	for (int cas = 1; cas <= cases; cas++) {
		long long a, b;
		cin >> a >> b;
		int n;
		cin >> n;
		a++;

		long long guess = (a + b) / 2;
		string verd;

		cout << guess << '\n' << flush;
		cin >> verd;

		while (verd != ok && verd!="WRONG_ANSWER") {
			if (verd == small) {
				a = guess + 1;
			}
			else {
				b = guess - 1;
			}
			guess = (a + b) / 2;
			cout << guess << '\n' << flush;
			cin >> verd;
		}

		if (verd == "WRONG_ANSWER")
			break;
	}
	return 0;
}
