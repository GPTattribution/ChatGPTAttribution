#include <bits/stdc++.h>

using namespace std;

int D;
long long damage, strength;
char inp[40];
int siz;

void calcDamage() {
	damage = 0, strength = 1;

	for (int i = 0; inp[i]; i++) {
		if (inp[i] == 'S')
			damage += strength;
		else
			strength *= 2;
	}
}

int getInd() {
	for (int i = siz - 2; i >= 0; i--) {
		if (inp[i] == 'C' && inp[i + 1] == 'S')
			return i;
	}

	return -1;
}

int main() {

	int cases;
	cin >> cases;

	for (int cas = 1; cas <= cases; cas++) {
		cin >> D >> inp;
		siz = 0;

		for (int i = 0; inp[i]; i++)
			siz++;

		int steps = 0;

		calcDamage();
		while (damage > D) {
			int index = getInd();
			if (index == -1)
				break;
			swap(inp[index], inp[index + 1]);
			calcDamage();
			steps++;
		}
		cout << "Case #" << cas << ": ";
		if (damage <= D)
			 cout << steps << '\n';
		else
			cout << "IMPOSSIBLE\n";
	}
	return 0;
}
