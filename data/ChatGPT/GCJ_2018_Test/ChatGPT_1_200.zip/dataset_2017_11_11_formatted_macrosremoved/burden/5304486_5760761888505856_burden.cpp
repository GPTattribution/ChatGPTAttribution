#include <iostream>
#include <cmath>

using namespace std;

unsigned long long N, K;

int main() {

	int cases;
	cin >> cases;

	for (int cas = 1; cas <= cases; cas++) {
		cout << "Case #" << cas << ": ";
		cin >> N >> K;

		int level = log10(K) / log10(2);
		long long dis = (1 << level);
		long long ans = (N >> level);

		long long count1 = 1, count2 = 0;
		long long temp = N;


		for (int i = 1; i <= level; i++) {
			if (temp % 2 == 0) {
				count2 *= 2;
				count2 += count1;
			}
			else {
				count1 *= 2;
				count1 += count2;
			}
			temp = temp / 2;
		}

		dis--;
		if (K - dis > count1)
			ans--;

		cout << (ans / 2) << ' ' << ((ans - 1) / 2) << '\n';
	}
	return 0;
}
