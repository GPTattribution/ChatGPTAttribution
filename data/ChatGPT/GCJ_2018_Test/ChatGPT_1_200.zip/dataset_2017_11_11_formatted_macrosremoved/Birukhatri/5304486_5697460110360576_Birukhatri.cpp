#include <memory.h>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <climits>
#include <cctype>
#include <cstring>
#include <climits>
#include <cmath>
#include <vector>
#include <string>
#include <memory>
#include <numeric>
#include <limits>
#include <functional>
#include <tuple>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <queue>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <iomanip>
#include <iostream>

using namespace std;

#define PROFILE_START(i)    clock_t start##i = clock()
#define PROFILE_STOP(i)     fprintf(stderr, "elapsed time (" #i ") = %f\n", double(clock() - start##i) / CLOCKS_PER_SEC)

typedef long long           ll;
typedef unsigned long long  ull;

ll calc(const string& s) {
    ll x = 0;
    for (int i = 0, mask = 1; i < (int)s.length(); i++) {
        if (s[i] == 'S')
            x += mask;
        else
            mask <<= 1;
    }
    return x;
}

bool change(string& s) {
    for (int i = (int)s.length() - 1; i > 0; i--) {
        if (s[i] == 'S' && s[i - 1] == 'C') {
            swap(s[i], s[i - 1]);
            return true;
        }
    }
    return false;
}

int main(void) {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int D;
        string P;
        cin >> D >> P;

        int ans = 0;
        ll x = calc(P);
        while (D < x) {
            if (!change(P)) {
                ans = -1;
                break;
            }
            x = calc(P);
            ans++;
        }

        cout << setprecision(9) << "Case #" << t << ": ";
        if (ans >= 0)
            cout << ans;
        else
            cout << "IMPOSSIBLE";
        cout << endl;
    }

    return 0;
}
