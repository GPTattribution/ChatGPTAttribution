#include <memory.h>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <climits>
#include <cctype>
#include <cstring>
#include <climits>
#include <cmath>
#include <vector>
#include <string>
#include <memory>
#include <numeric>
#include <limits>
#include <functional>
#include <tuple>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <queue>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <iostream>

using namespace std;

#define PROFILE_START(i)    clock_t start##i = clock()
#define PROFILE_STOP(i)     fprintf(stderr, "elapsed time (" #i ") = %f\n", double(clock() - start##i) / CLOCKS_PER_SEC)

#ifndef M_PI
#define M_PI       3.14159265358979323846   // pi
#define M_1_PI     0.318309886183790671538  // 1/pi
#define M_SQRT2    1.41421356237309504880   // sqrt(2)
#endif

typedef long long           ll;
typedef unsigned long long  ull;

void outN(char ch, int n) {
    while (n-- > 0)
        cout << ch;
}

void out2(char ch1, char ch2) {
    cout << ch1 << ch2;
}

int main(void) {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int N;
        cin >> N;

        int cnt = 0;
        vector<int> P(N);
        for (int i = 0; i < N; i++) {
            cin >> P[i];
            cnt += P[i];
        }

        vector<int> A(N);
        iota(A.begin(), A.end(), 0);
        sort(A.begin(), A.end(), [&P](int a, int b) { return P[a] < P[b]; });

        cout << "Case #" << t << ":";

        int i = (int)A.size() - 1;
        while (P[A[i]] > P[A[i - 1]]) {
            int n = min(2, P[A[i]] - P[A[i - 1]]);
            cout << " ";
            outN('A' + A[i], n);

            P[A[i]] -= n;
        }

        for (int i = 0; i < (int)A.size() - 2; i++) {
            while (P[A[i]] > 0) {
                int n = min(2, P[A[i]]);
                cout << " ";
                outN('A' + A[i], n);

                P[A[i]] -= n;
            }
        }

        i = (int)A.size() - 1;
        while (P[A[i]] > 0) {
            cout << " ";
            out2('A' + A[i], 'A' + A[i - 1]);

            P[A[i]]--;
            P[A[i - 1]]--;
        }

        cout << endl;
    }

    return 0;
}
