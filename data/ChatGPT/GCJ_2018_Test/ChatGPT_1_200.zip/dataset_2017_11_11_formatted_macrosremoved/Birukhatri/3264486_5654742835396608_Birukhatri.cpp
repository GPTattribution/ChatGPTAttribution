#include <memory.h>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <climits>
#include <cctype>
#include <cstring>
#include <climits>
#include <cmath>
#include <vector>
#include <string>
#include <memory>
#include <numeric>
#include <limits>
#include <functional>
#include <tuple>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <queue>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <iomanip>
#include <iostream>

using namespace std;

#define PROFILE_START(i)    clock_t start##i = clock()
#define PROFILE_STOP(i)     fprintf(stderr, "elapsed time (" #i ") = %f\n", double(clock() - start##i) / CLOCKS_PER_SEC)

typedef long long           ll;
typedef unsigned long long  ull;

bool isDone(const vector<vector<bool>>& p, int r0, int r1, int c0, int c1) {
    for (int i = r0; i <= r1; i++) {
        for (int j = c0; j <= c1; j++) {
            if (!p[i][j])
                return false;
        }
    }

    return true;
}

int main(void) {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        int A;
        cin >> A;

        int X0 = 500;
        int Y0 = 500;
        int W = (A == 20) ? 5 : 20;
        int H = (A == 20) ? 4 : 10;

        vector<vector<bool>> prepared(1001, vector<bool>(1001));

        priority_queue<tuple<double, int, int>> Q;
        for (int i = 0; i < H; i++) {
            for (int j = 0; j < W; j++) {
                Q.emplace(-1.0 * (i - Y0) * (i - Y0) + -1.0 * (j - X0) * (j - X0), Y0 + i, X0 + j);
            }
        }
        while (true) {
            int r = get<1>(Q.top());
            int c = get<2>(Q.top());
            if (isDone(prepared, r - 1, r + 1, c - 1, c + 1)) {
                Q.pop();
                continue;
            }

            cout << r << " " << c << endl;

            int rr, rc;
            cin >> rr >> rc;
            if (rr == 0 && rc == 0)
                break;
            if (rr == -1 && rc == -1)
                return 0;

            prepared[rr][rc] = true;
        }
    }

    return 0;
}
