#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for (int (i)=(0);(i)<(int)(n);++(i))
using ll = long long;
using P = pair<int, int>;
using namespace std;

template<class T> void vin(vector<T>& v, int n) {
    v.resize(n);
    for (int i = 0; i < n; ++i) {
        cin >> v[i];
    }
}

int main() {
    int T;
    cin >> T;
    rep(t, T) {
        ll D, N;
        cin >> D >> N;
        vector<double> b(N), v(N);
        vector<pair<double, int>> p;
        rep(i, N) {
            cin >> b[i] >> v[i];
            p.push_back(make_pair((D-b[i])/v[i], i));
        }
        sort(p.begin(), p.end());
        reverse(p.begin(), p.end());
        double ans = D / p[0].first;
        printf("Case #%d: %.10f\n", t+1, ans);
    }
    return 0;
}
