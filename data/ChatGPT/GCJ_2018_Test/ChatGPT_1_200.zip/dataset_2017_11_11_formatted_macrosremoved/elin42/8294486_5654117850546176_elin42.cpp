#include <bits/stdc++.h>
using namespace std;

int main() {
    long long t;
    cin >> t;
    for (int i = 0; i < t; ++i) {
        long long a, b, n;
        int cnt = 0;
        cin >> a >> b >> n; ++b;
        while (b-a>1 and cnt < n) {
            long long m = (a + b) / 2;
            cout << m << endl;
            string ans;
            cin >> ans;
            if (ans == "TOO_BIG") {
                b = m;
            }
            else if (ans == "TOO_SMALL") {
                a = m;
            }
            else {
                break;
            }
            cnt++;
        }
    }
}
