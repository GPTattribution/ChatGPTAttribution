#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for (int (i)=(0);(i)<(int)(n);++(i))
using ll = long long;
using P = pair<int, int>;
using namespace std;

template<class T> void vin(vector<T>& v, int n) {
    v.resize(n);
    for (int i = 0; i < n; ++i) {
        cin >> v[i];
    }
}

string no = "IMPOSSIBLE";
inline void output(int t) {
    cout << "Case #" << t+1 << ": ";
}

int main() {
    int T;
    cin >> T;
    rep(t, T) {
        ll D;
        string s;
        cin >> D >> s;

        ll damage = 1, sum = 0;
        rep(i, s.size()) {
            if (s[i] == 'S') sum += damage;
            else if (s[i] == 'C') damage *= 2;
        }
        if (sum <= D) {
            output(t);
            cout << 0 << endl;
            continue;
        }

        bool update = true, ok = false;
        ll ans = 0;
        while (update) {
            update = false;
            for (int i = s.size()-2; i >= 0; --i) {
                if (s[i] == 'C' and s[i+1] == 'S') {
                    swap(s[i], s[i+1]);
                    ans++;
                    update = true;
                    break;
                }
            }
            if (update) {
                ll damage = 1, sum = 0;
                rep(i, s.size()) {
                    if (s[i] == 'S') sum += damage;
                    else if (s[i] == 'C') damage *= 2;
                }
                if (sum <= D) {
                    output(t);
                    cout << ans << endl;
                    ok = true;
                    break;
                }
            }
        }
        if (!ok) {
            output(t);
            cout << no << endl;
        }
    }
    return 0;
}
