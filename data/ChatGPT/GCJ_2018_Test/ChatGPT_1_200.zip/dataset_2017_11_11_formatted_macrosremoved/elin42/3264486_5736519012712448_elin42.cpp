#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for (int (i)=(0);(i)<(int)(n);++(i))
using ll = long long;
using P = pair<int, int>;
using namespace std;

template<class T> void vin(vector<T>& v, int n) {
    v.resize(n);
    for (int i = 0; i < n; ++i) {
        cin >> v[i];
    }
}

inline void TroubleSort(vector<int> &L) {
    bool update = true;
    while (update) {
        update = false;
        for (int i = 0; i < L.size()-2; ++i) {
            if (L[i] > L[i+2]) {
                update = true;
                swap(L[i], L[i+2]);
            }
        }
    }
}

inline void output(int t) {
    cout << "Case #" << t+1 << ": ";
}

int main() {
    int T;
    scanf("%d", &T);
    rep(t, T) {
        int n;
        scanf("%d", &n);
        vector<int> L(n);
        rep(i, n) scanf("%d", &L[i]);
        //TroubleSort(L);
        vector<int> t1, t2;
        rep(i, n) {
            if (i%2) t2.push_back(L[i]);
            else t1.push_back(L[i]);
        }
        sort(t1.begin(), t1.end());
        sort(t2.begin(), t2.end());
        vector<int> ans(n);
        int idx1 = 0, idx2 = 0;
        rep(i, n) {
            if (i%2 == 0) ans[i] = t1[idx1++];
            else ans[i] = t2[idx2++];
        }
        bool flag = false;
        rep(i, n-1) {
            if (ans[i] > ans[i+1]) {
                output(t);
                cout << i << endl;
                flag = true;
                break;
            }
        }
        if (!flag) {
            output(t);
            cout << "OK" << endl;
        }
    }
    return 0;
}
