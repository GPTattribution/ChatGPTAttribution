#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for (int (i)=(0);(i)<(int)(n);++(i))
using ll = long long;
using P = pair<int, int>;
using namespace std;

template<class T> void vin(vector<T>& v, int n) {
    v.resize(n);
    for (int i = 0; i < n; ++i) {
        cin >> v[i];
    }
}

int main() {
    int T;
    cin >> T;
    rep(t, T) {
        ll N, K;
        cin >> N >> K;
        map<ll, ll> que;
        que[N] = 1;
        while (true) {
            ll len, cnt;
            auto m = *que.rbegin();
            len = m.first; cnt = m.second;
            que.erase(len);
            ll l = (len - 1) / 2;
            ll r = (len - 1 + 1) / 2;
            que[l] += cnt;
            que[r] += cnt;
            K -= cnt;
            if (K <= 0) {
                cout << "Case #" << t+1 << ": " << r << ' ' << l << endl;
                break;
            }
        }
    }
    return 0;
}
