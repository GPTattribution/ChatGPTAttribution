#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for (int (i)=(0);(i)<(int)(n);++(i))
using ll = long long;
using P = pair<int, int>;
using namespace std;

template<class T> void vin(vector<T>& v, int n) {
    v.resize(n);
    for (int i = 0; i < n; ++i) {
        cin >> v[i];
    }
}

inline void output(int t) {
    cout << "Case #" << t+1 << ": ";
}

int cells[1010][1010];
int dx[] = { 1, 1, 1, 0, -1, -1, -1, 0, 0 };
int dy[] = { 1, 0, -1, -1, -1, 0, 1, 1, 0 };

int main() {
    int T;
    cin >> T;
    rep(t, T) {
        int A;
        cin >> A;
        fill(cells[0], cells[1010], 0);
        if (A == 20) {
            P a = make_pair(1000/2, 1000/2), b = make_pair(1000/2, 1000/2-1), c = make_pair(1000/2+3, 1000/2), d = make_pair(1000/2+3, 1000/2-1);
            vector<P> p;
            p.push_back(a); p.push_back(b); p.push_back(c); p.push_back(d);
            bitset<5> flag;
            rep(i, 1000) {
                int idx = 0;
                rep(i, 4) {
                    if (!flag[i]) {
                        cout << p[i].first << ' ' << p[i].second << endl;
                        idx = i;
                        break;
                    }
                }

                int x, y;
                cin >> x >> y;
                if (x == 0 and y == 0) {
                    break;
                }
                else if (x == -1 and y == -1) {
                    return 0;
                }

                cells[y][x] = 1;
                bool ok = true;
                rep(d, 8) {
                    int nx = p[idx].first + dx[d], ny = p[idx].second + dy[d];
                    if (!cells[ny][nx]) {
                        ok = false;
                        break;
                    }
                }
                if (ok) {
                    flag[idx] = 1;
                }
            }
        }
        else {

            vector<P> p;
            for (int i = 2; i <= 8; ++i) {
                for (int j = 2; j <= 8; ++j) {
                    p.emplace_back(3*i-2, 3*j-2);
                }
            }
            bitset<50> flag;

            rep(i, 1000) {
                int idx = 0;
                rep(i, 49) {
                    if (!flag[i]) {
                        cout << p[i].first << ' ' << p[i].second << endl;
                        idx = i;
                        break;
                    }
                }

                int x, y;
                cin >> x >> y;
                if (x == 0 and y == 0) {
                    break;
                }
                else if (x == -1 and y == -1) {
                    return 0;
                }

                cells[y][x] = 1;
                bool ok = true;
                rep(d, 8) {
                    int nx = p[idx].first + dx[d], ny = p[idx].second + dy[d];
                    if (!cells[ny][nx]) {
                        ok = false;
                        break;
                    }
                }
                if (ok) {
                    flag[idx] = 1;
                }
            }

        }
    }
    return 0;
}
