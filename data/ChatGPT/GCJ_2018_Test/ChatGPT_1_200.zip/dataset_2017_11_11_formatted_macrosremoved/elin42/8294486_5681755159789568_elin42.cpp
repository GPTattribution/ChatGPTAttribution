#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for (int (i)=(0);(i)<(int)(n);++(i))
using ll = long long;
using P = pair<int, int>;
using namespace std;

template<class T> void vin(vector<T>& v, int n) {
    v.resize(n);
    for (int i = 0; i < n; ++i) {
        cin >> v[i];
    }
}

int main() {
    int t;
    cin >> t;
    rep(i, t) {
        int n;
        cin >> n;
        vector<pair<int, char>> v;
        ll sum = 0;
        rep(j, n) {
            int p;
            cin >> p;
            sum += p;
            v.push_back(make_pair(p, 'A'+j));
        }
        vector<string> ans;
        string tmp = "";
        rep(s, sum) {
            sort(v.begin(), v.end());
            reverse(v.begin(), v.end());
            if (v[0].first == 1) {
                if (tmp.size() > 0) {
                    ans.push_back(tmp);
                    tmp = "";
                }
                ll tmpsum = 0;
                rep(j, n) {
                    if (v[j].first > 0) tmpsum += v[j].first;
                    else break;
                }
                if (tmpsum%2 == 1) {
                    v[0].first--;
                    tmp += v[0].second;
                    ans.push_back(tmp);
                    tmp = "";
                    tmpsum--;
                }
                rep(j, n) {
                    if (v[j].first > 0) {
                        tmp += v[j].second;
                    }
                    if (tmp.size() == 2) {
                        ans.push_back(tmp);
                        tmp = "";
                    }
                }
                if (tmp.size() > 0) ans.push_back(tmp);
                break;
            }
            else {
                if (tmp.size() == 2) {
                    ans.push_back(tmp);
                    tmp = "";
                }
                tmp += v[0].second;
                v[0].first--;
            }
        }
        cout << "Case #" << (i+1) << ": ";
        rep(j, ans.size()) {
            if (j) cout << " ";
            cout << ans[j];
        }
        cout << endl;
    }
}
