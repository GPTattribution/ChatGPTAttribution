#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<unsigned> vu;
typedef vector<ll> vll;
typedef vector<ull> vull;
typedef pair<int, int> pii;
typedef pair<unsigned, unsigned> puu;
typedef pair<ll, ll> pll;
typedef pair<ull, ull> pull;
typedef vector<string> vs;
#define pb push_back
#define ppb pop_back
#define be begin
#define all(x) (x).be(), (x).end()
#define fst first
#define fir first
#define sec second
#define mkp make_pair
#define brif(cond) if (cond) break
#define ctif(cond) if (cond) continue
#define retif(cond) if (cond) return
static inline void canhazfast() {ios_base::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);}
template<typename T> T gcd(T a, T b) {return b == 0 ? a : gcd(b, a%b);}
template<typename T> T extgcd(T a, T b, T &x, T &y)
{
    T x0 = 1, y0 = 0, x1 = 0, y1 = 1;
    while (b) {
        T q = a/b; a %= b; swap(a, b);
        x0 -= q*x1; swap(x0, x1);
        y0 -= q*y1; swap(y0, y1);
    }
    x = x0; y = y0; return a;
}

void evac(pii &p, int &s)
{
    --p.fir; --s;
    putchar('A'+p.sec);
}

void add(pii p, priority_queue<pii> &q) { if (p.fir) q.push(p); }

void solve(int tc)
{
    int n, s = 0;
    priority_queue<pii> q;

    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        int p;
        scanf("%d", &p);
        s += p;
        q.push(mkp(p, i));
    }
    printf("Case #%d:", tc);
    while (!q.empty()) {
        pii cur = q.top(); q.pop();
        pii nxt = q.top(); q.pop();
        putchar(' ');
        evac(cur, s);
        if (2*nxt.fir > s) evac(nxt, s);
        else if (2*nxt.fir < s && cur.fir) evac(cur, s);
        add(cur, q);
        add(nxt, q);
        assert(q.empty() || 2*q.top().fir <= s);
    }
    putchar('\n');
}

int main()
{
    //canhazfast();

    int t;
    scanf("%d", &t);
    for (int i = 1; i <= t; ++i) solve(i);

    return 0;
}
