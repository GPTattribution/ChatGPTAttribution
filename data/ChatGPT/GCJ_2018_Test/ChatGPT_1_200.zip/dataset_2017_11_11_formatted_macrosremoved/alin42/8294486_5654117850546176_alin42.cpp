#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

void solve()
{
    int a, b, n;
    string rep;

    cin >> a >> b >> n;
    ++a;
    while (a < b) {
        int m = (a+b)/2;
        cout << m << endl;
        cin >> rep;
        if (rep == "CORRECT") return;
        else if (rep == "TOO_SMALL") a = m+1;
        else if (rep == "TOO_BIG") b = m-1;
        else if (rep == "WRONG_ANSWER") exit(0);
    }
    cout << a << endl;
    cin >> rep;
}

int main()
{
    int t;
    cin >> t;
    for (; t; --t) solve();
    return 0;
}
