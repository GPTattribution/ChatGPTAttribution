#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<unsigned> vu;
typedef vector<ll> vll;
typedef vector<ull> vull;
typedef pair<int, int> pii;
typedef pair<unsigned, unsigned> puu;
typedef pair<ll, ll> pll;
typedef pair<ull, ull> pull;
typedef vector<string> vs;
#define pb push_back
#define ppb pop_back
#define be begin
#define all(x) (x).be(), (x).end()
#define fst first
#define fir first
#define sec second
#define mkp make_pair
#define brif(cond) if (cond) break
#define ctif(cond) if (cond) continue
#define retif(cond) if (cond) return
static inline void canhazfast() {ios_base::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);}
template<typename T> T gcd(T a, T b) {return b == 0 ? a : gcd(b, a%b);}
template<typename T> T extgcd(T a, T b, T &x, T &y)
{
    T x0 = 1, y0 = 0, x1 = 0, y1 = 1;
    while (b) {
        T q = a/b; a %= b; swap(a, b);
        x0 -= q*x1; swap(x0, x1);
        y0 -= q*y1; swap(y0, y1);
    }
    x = x0; y = y0; return a;
}

void solve(int tc)
{
    ll n, k;
    map<ll, ll, greater<ll>> m;

    scanf("%lld%lld", &n, &k);
    m[n] = 1;
    while (!m.empty()) {
        auto it = m.be();
        ll x = it->fir, c = it->sec;
        ll x0 = x/2, x1 = (x-1)/2;
        m.erase(it);
        k -= c;
        if (k <= 0) {
            printf("Case #%d: %lld %lld\n", tc, x0, x1);
            return;
        }
        m[x0] += c;
        m[x1] += c;
    }
}

int main()
{
    //canhazfast();

    int t;
    scanf("%d", &t);
    for (int i = 1; i <= t; ++i) solve(i);

    return 0;
}
