#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<unsigned> vu;
typedef vector<ll> vll;
typedef vector<ull> vull;
typedef pair<int, int> pii;
typedef pair<unsigned, unsigned> puu;
typedef pair<ll, ll> pll;
typedef pair<ull, ull> pull;
typedef vector<string> vs;
#define pb push_back
#define ppb pop_back
#define be begin
#define all(x) (x).be(), (x).end()
#define fst first
#define fir first
#define sec second
#define mkp make_pair
#define brif(cond) if (cond) break
#define ctif(cond) if (cond) continue
#define retif(cond) if (cond) return
static inline void canhazfast() {ios_base::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);}
template<typename T> T gcd(T a, T b) {return b == 0 ? a : gcd(b, a%b);}
template<typename T> T extgcd(T a, T b, T &x, T &y)
{
    T x0 = 1, y0 = 0, x1 = 0, y1 = 1;
    while (b) {
        T q = a/b; a %= b; swap(a, b);
        x0 -= q*x1; swap(x0, x1);
        y0 -= q*y1; swap(y0, y1);
    }
    x = x0; y = y0; return a;
}

#define SZ 1000

bool f[SZ+1][1024];
int c[SZ+1][1024];
set<pii> s[10];
mt19937_64 rng;
int a, l, r, u, d;
//int imn, imx, jmn, jmx;
//int resps;

void exchange(int &i, int &j)
{
    cout << i << ' ' << j << endl;

    /// regular
    cin >> i >> j;

    /// test
    /*++resps;
    if (i <= 1 || i >= SZ || j <= 1 || j >= SZ || resps > 1000) {
        i = j = -1;
        cout << "WA" << endl;
        return;
    }
    i = uniform_int_distribution<int>(i-1, i+1)(rng);
    j = uniform_int_distribution<int>(j-1, j+1)(rng);
    imn = min(imn, i); imx = max(imx, i);
    jmn = min(jmn, j); jmx = max(jmx, j);
    int cnt = 0;
    for (int ii = imn; ii <= imx; ++ii) {
        for (int jj = jmn; jj <= jmx; ++jj) cnt += f[ii][jj];
    }
    if (!f[i][j]) ++cnt;
    if (cnt == (imx-imn+1)*(jmx-jmn+1) && cnt >= a) i = j = 0;
    cerr << "re: " << i << ' ' << j << '\n';*/
}

void update(int ii, int jj)
{
    retif(f[ii][jj]);
    f[ii][jj] = true;
    int i0 = max(ii-1, u+1), i1 = min(ii+1, d-1);
    int j0 = max(jj-1, l+1), j1 = min(jj+1, r-1);

    for (int i = i0; i <= i1; ++i) for (int j = j0; j <= j1; ++j) {
        s[c[i][j]].erase(mkp(i, j));
        ++c[i][j];
        s[c[i][j]].insert(mkp(i, j));
    }
}

pii select()
{
    for (int i = 0; i <= 8; ++i) {
        ctif(s[i].empty());

        auto it = s[i].be();
        /// random
        //size_t p = uniform_int_distribution<size_t>(0, s[i].size()-1)(rng);
        //advance(it, p);
        return *it;
    }
    exit(1);
}

void solve(int tc)
{
    /*imn = jmn = SZ+1;
    imx = jmx = 0;
    resps = 0;*/

    memset(f, 0, sizeof(f));
    memset(c, 0, sizeof(c));
    cin >> a;

    l = u = 50;
    if (a == 20) d = u+3, r = l+4; /// 20 -> 4x5
    else d = u+9, r = l+19; /// 200 -> 10x20

    for (int i = 0; i <= 9; ++i) s[i].clear();
    for (int i = u+1; i < d; ++i) for (int j = l+1; j < r; ++j) s[0].insert(mkp(i, j));

    for (;;) {
        int i, j;

        tie(i, j) = select();
        exchange(i, j);
        if (i == -1 && j == -1) exit(0);
        brif(i == 0 && j == 0);
        update(i, j);
    }
    //cerr << resps << " resps\n";
}

int main()
{
    canhazfast();

    int t;
    cin >> t;
    rng = mt19937_64(time(nullptr));
    for (int i = 1; i <= t; ++i) solve(i);

    return 0;
}
