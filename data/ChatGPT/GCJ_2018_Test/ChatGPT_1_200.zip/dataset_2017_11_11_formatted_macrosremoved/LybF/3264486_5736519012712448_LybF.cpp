#include <bits/stdc++.h>

using namespace std;

#define ff first
#define ss second
#define pb push_back
using ii = pair<long long, long long>;
using ll = long long;
#define oo 1000000000000000000
#define mod 1000000007

int main (){
	int t;
	scanf("%d",&t);
	for(int caso = 1; caso <= t; caso++){
		int n;
		int v[2][100005];
		int v2[100005];
		scanf("%d",&n);
		for(int i = 0; i < n; i++){
			scanf("%d",&v[i&1][i/2]);
		}
		sort(v[0], v[0] + (n/2 + (n&1)));
		sort(v[1], v[1] + n/2);
		for(int i = 0; i < n; i++){
			v2[i] = v[i&1][i/2];
		}

		int ans = -1;
		for(int i = 0; i < n-1; i++){
			if(v2[i] > v2[i+1]){
				ans = i;
				break;
			}
		}
		if(ans != -1)
			printf("Case #%d: %d\n",caso,ans );
		else
			printf("Case #%d: OK\n",caso );
	}
	return 0;
}
