#include <bits/stdc++.h>

using namespace std;

#define ff first
#define ss second
#define pb push_back
using ii = pair<int, int>;
using ll = long long;

int main (){
	int t;
	scanf("%d", &t);
	while(t--){
		char ans[100];
		int a, b;
		scanf("%d %d",&a, &b);
		a++;
		int n;
		scanf("%d",&n);
		while(a <= b){
			int mid = (a + b) / 2;
			printf("%d\n",mid );
			fflush(stdout);
			scanf("%s",ans);
			if(strcmp(ans, "TOO_SMALL") == 0)
				a = mid + 1;
			else if(strcmp(ans, "TOO_BIG") == 0)
				b = mid - 1;
			else if(strcmp(ans, "WRONG_ANSWER") == 0)
				return 0;
			else break;
		}
	}
	return 0;
}
