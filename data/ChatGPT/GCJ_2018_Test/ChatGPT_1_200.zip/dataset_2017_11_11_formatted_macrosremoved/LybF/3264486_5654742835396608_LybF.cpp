#include <bits/stdc++.h>

using namespace std;

#define ff first
#define ss second
#define pb push_back
using ii = pair<long long, long long>;
using ll = long long;
#define oo 1000000000000000000
#define mod 1000000007

int main (){
	int t;
	scanf("%d",&t);
	for(int caso = 1; caso <= t; caso++){
		bool mat[5][500];
		memset(mat, 0, sizeof mat);
		int a;
		scanf("%d",&a);
		int x = 2, y = 2;
		int lim = max(a/3 + int(a%3 != 0) - 1, 2);
		int i = 3, j = 3;
		while(i || j){
			printf("%d %d\n",x,y );
			fflush(stdout);
			scanf("%d %d",&i, &j);
			if(j == -1 && i == -1)	return 0;
			mat[i][j] = 1;
			while(mat[x-1][y-1] && mat[x+1][y-1] && mat[x][y-1] && y < lim)
				y++;
		}
	}
	return 0;
}
