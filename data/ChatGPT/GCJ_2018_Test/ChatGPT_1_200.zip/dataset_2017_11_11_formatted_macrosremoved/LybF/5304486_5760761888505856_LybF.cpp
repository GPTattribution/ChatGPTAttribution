#include <bits/stdc++.h>

using namespace std;

#define ff first
#define ss second
#define pb push_back
using ii = pair<long long, long long>;
using ll = long long;

int main (){
    int t;
    scanf("%d", &t);
    for(int caso = 1; caso <= t; caso++){
        ll n, k;
        scanf("%lld %lld",&n, &k);
        map<ll,ll> pq;
        pq[n] = 1;
        auto it = pq.end();
        it--;
        ii x = *it;
        while(pq.size() && k > x.ss){
            pq.erase(it);
            if(x.ff&1)
                    pq[x.ff/2] += 2*x.ss;
            else{
                pq[x.ff/2] += x.ss;
                pq[x.ff/2 - !(x.ff&1)] += x.ss;
            }
            k -= x.ss;
            it = pq.end();
            it--;
            x = *it;
        }
        printf("Case #%d: %lld %lld\n", caso, x.ff/2, x.ff/2 - !(x.ff&1) );
    }
    return 0;
}
