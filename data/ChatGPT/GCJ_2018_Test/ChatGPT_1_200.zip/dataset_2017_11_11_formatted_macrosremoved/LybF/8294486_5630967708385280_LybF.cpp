#include <bits/stdc++.h>

using namespace std;

#define ff first
#define ss second
#define pb push_back
using ii = pair<int, int>;
using ll = long long;

int qtd[1001];
int main (){
	int t;
	scanf("%d", &t);
	for(int caso = 1; caso <= t; caso++){
		int n, d;
		scanf("%d %d",&d, &n);
		double mt = 0;
		for(int i = 0; i < n; i++){
			int k, s;
			scanf("%d %d",&k, &s);
			mt = max(mt, (d - k) / double(s));
		}
		printf("Case #%d: %lf\n", caso, d / mt );
	}
	return 0;
}
