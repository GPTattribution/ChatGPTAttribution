#include <bits/stdc++.h>

using namespace std;

#define ff first
#define ss second
#define pb push_back
using ii = pair<long long, long long>;
using ll = long long;
#define oo 1000000000000000000
#define mod 1000000007

int main (){
	int t;
	scanf("%d",&t);
	for(int caso = 1; caso <= t; caso++){
		int d;
		scanf("%d",&d);
		char v[100];
		ll val[100];
		scanf("%s",v);
		int n = strlen(v);
		ll sum = 0;
		ll at = 1;
		for(int i = 0; i < n; i++){
			if(v[i] == 'C')
				at *= 2;
			else{
				val[i] = at;
				sum += at;
			}
		}
		int id = n-1;
		int ans = 0;
		while(sum > d && id >= 0){
			while(id >= 0 && v[id] != 'C')
				id--;
			if(id >= 0){
				for(int i = id+1; i < n && sum > d; i++){
					if(v[i] == 'S'){
						val[i] /= 2;
						sum -= val[i];
						ans++;
					}
				}
				id--;
			}
		}
		if(sum <= d){
			printf("Case #%d: %d\n",caso, ans );
		}
		else{
			printf("Case #%d: IMPOSSIBLE\n",caso);
		}
	}
	return 0;
}
