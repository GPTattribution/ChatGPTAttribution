#include <bits/stdc++.h>

using namespace std;

#define ff first
#define ss second
#define pb push_back
using ii = pair<int, int>;
using ll = long long;

int qtd[1001];
int main (){
	int t;
	scanf("%d", &t);
	for(int caso = 1; caso <= t; caso++){
		int n;
		scanf("%d",&n);
		priority_queue<pair<int, char> > pq;
		for(int i = 0; i < n; i++){
			int x;
			scanf("%d",&x);
			pq.push({x, i + 'A'});
			qtd[x]++;
		}
		printf("Case #%d:",caso);
		while(qtd[pq.top().ff] != n){
			pair<int, char> x = pq.top();
			pq.pop();
			qtd[x.ff]--;
			x.ff--;
			qtd[x.ff]++;
			printf(" %c",x.ss);
			pq.push(x);
		}
		while(pq.size() != 2){
			pair<int, char> x = pq.top();
			pq.pop();
			while(x.ff--)
				printf(" %c",x.ss);
		}
		pair<int, char> x = pq.top();
		pq.pop();
		pair<int, char> x2 = pq.top();
		while(x.ff--)
			printf(" %c%c",x.ss,x2.ss);
		printf("\n");
		memset(qtd, 0, sizeof qtd);
	}
	return 0;
}
