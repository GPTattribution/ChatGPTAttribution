#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define sz(a) (int)(a).size()
#define rep(i, a, b) for (int i = (a), _b = (b); i < _b; ++i)
#define frep(i, a, b) for (int i = (a), _b = (b); i <= _b; ++i)

typedef vector<int> vi;
typedef pair<int, int> ii;
typedef pair<ii, int> iii;
typedef vector<ii> vii;

const int inf = 1e9 + 7;
const ll linf  = 1ll * inf * inf;
const int N = 1e5 + 7;
const int M = 30;
const int multipleTest = 0;

string s;

int read_ans() {
	cin >> s;
	cerr << s << '\n';
	if (s == "TOO_BIG") return 1;
	if (s == "TOO_SMALL") return -1;
	if (s == "CORRECT") return 0;
	return 2;
}

int guess(int n) {
	cout << n << '\n';
	cerr << n << '\n';
	fflush(stdout);
	return read_ans();
}

void solve() {
	int T;
	scanf("%d\n", &T);
	int max_guess;
	while (T-- > 0) {
		int a, b;
		cin >> a >> b >> max_guess;
		++a;
		while (a <= b) {
			int mid = (a + b) / 2;
			int res = guess(mid);
//			cerr << ' ' << res << '\n';
			if (res == 0) {
				break;
			} else if (res == 1) {
				b = mid - 1;
			} else if (res == -1) {
				a = mid + 1;
			} else {
//				exit(100);
			}
		}
	}
}

int main() {
#ifdef _LOCAL_
//	freopen("in.txt", "r", stdin);
	//    freopen("out.txt", "w", stdout);
#endif
	int Test = 1;
	if (multipleTest) {
		cin >> Test;
	}
	for(int i = 0; i < Test; ++i) {
		//        printf("Case #%d: ", i + 1);
		solve();
	}
#ifdef _LOCAL_
//	cout << "\n" << 1.0 * clock() / CLOCKS_PER_SEC << "\n";
#endif
}
