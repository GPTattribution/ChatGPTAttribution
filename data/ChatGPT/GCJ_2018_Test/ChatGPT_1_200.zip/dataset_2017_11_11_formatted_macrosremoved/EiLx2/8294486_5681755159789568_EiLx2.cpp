#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define sz(a) (int)(a).size()
#define rep(i, a, b) for (int i = (a), _b = (b); i < _b; ++i)
#define frep(i, a, b) for (int i = (a), _b = (b); i <= _b; ++i)
#define _all(a) a.begin(), a.end()

typedef vector<int> vi;
typedef pair<int, int> ii;
typedef pair<ii, int> iii;
typedef vector<ii> vii;

const int inf = 1e9 + 7;
const ll linf  = 1ll * inf * inf;
const int N = 1e5 + 7;
const int M = 30;
const int multipleTest = 1;

vector<ii> all;

bool valid(vector<ii> x) {
	int sum = 0;
	for (ii i : x) {
		if (i.first < 0) return false;
		sum += i.first;
	}
	sort(x.begin(), x.end());
	return x.back().first * 2 <= sum;
}

void solve() {
	int n;
	cin >> n; all.resize(n);
	rep(i, 0, n) {
		cin >> all[i].first;
		all[i].second = i;
	}

	vii res;
	while (all.size() > 2) {
		sort(all.begin(), all.end());
		cout << char('A' + all.back().second) << ' ';
		all.back().first--;
		if (!all.back().first) all.pop_back();
	}

	sort(all.begin(), all.end());
	assert(all.size() != 1);
	while (all[1].first > all[0].first) {
		cout << char('A' + all.back().second) << ' ';
		all.back().first--;
	}

	while (all[0].first) {

		cout << char('A' + all.back().second) << char('A' + all[0].second) << ' ';
		all[0].first--;
	}
	puts("");

}

int main() {
#ifdef _LOCAL_
	freopen("in.txt", "r", stdin);
	//    freopen("out.txt", "w", stdout);
#endif
	int Test = 1;
	if (multipleTest) {
		cin >> Test;
	}
	for(int i = 0; i < Test; ++i) {
		        printf("Case #%d: ", i + 1);
		solve();
	}
#ifdef _LOCAL_
//	cout << "\n" << 1.0 * clock() / CLOCKS_PER_SEC << "\n";
#endif
}
