#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define sz(a) (int)(a).size()
#define rep(i, a, b) for (int i = (a), _b = (b); i < _b; ++i)
#define frep(i, a, b) for (int i = (a), _b = (b); i <= _b; ++i)

typedef vector<int> vi;
typedef pair<int, int> ii;
typedef pair<ii, int> iii;
typedef vector<ii> vii;

const int inf = 1e9 + 7;
const ll linf  = 1ll * inf * inf;
const int N = 1e5 + 7;
const int M = 30;
const int multipleTest = 1;

int d;
string s;

int calc(string &x) {
	int cost = 0;
	int power = 1;
	for (char c : x) {
		if (c == 'C') power <<= 1;
		else cost += power;
	}
	return cost;
}

bool reduce(string& s) {
	for (int i = sz(s) - 1; i > 0; --i) if (s[i] == 'S' && s[i - 1] == 'C') {
		swap(s[i], s[i - 1]);
		return true;
	}
	return false;
}

void solve() {
	cin >> d >> s;
	int res = 0;

	while (calc(s) > d) {
		if (!reduce(s)) {
			puts("IMPOSSIBLE");
			return;
		}
		++res;
	}
	cout << res << '\n';
}

int main() {
#ifdef _LOCAL_
	freopen("in.txt", "r", stdin);
	//    freopen("out.txt", "w", stdout);
#endif
	int Test = 1;
	if (multipleTest) {
		cin >> Test;
	}
	for(int i = 0; i < Test; ++i) {
		printf("Case #%d: ", i + 1);
		solve();
	}
#ifdef _LOCAL_
	cout << "\n" << 1.0 * clock() / CLOCKS_PER_SEC << "\n";
#endif
}
