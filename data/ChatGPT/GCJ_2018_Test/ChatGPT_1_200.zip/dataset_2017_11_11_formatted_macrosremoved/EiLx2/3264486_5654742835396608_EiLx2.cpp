#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define sz(a) (int)(a).size()
#define rep(i, a, b) for (int i = (a), _b = (b); i < _b; ++i)
#define frep(i, a, b) for (int i = (a), _b = (b); i <= _b; ++i)

typedef vector<int> vi;
typedef pair<int, int> ii;
typedef pair<ii, int> iii;
typedef vector<ii> vii;

const int inf = 1e9 + 7;
const ll linf  = 1ll * inf * inf;
const int N = 100 + 7;
const int M = 30;
const int multipleTest = 1;

int n, m, A;

bool check[N][N];

bool deploy(int u, int v) {
	printf("%d %d\n", u, v);
//	cerr << "write " << u << ' ' << v << '\n';
	fflush(stdout);

	scanf("%d%d", &u, &v);

//	cerr << "check " << u << ' ' << v << '\n';

	check[u][v] = true;
	if (!u && !v) {
//		for (int i = 1; i <= n; ++i) {
//			for (int j = 1; j <= m; ++j) cerr << check[i][j];
//			cerr << '\n';
//
//		}
		return true;
	}
	return false;
}

void solve() {
	cin >> A;
	if (A == 20) {
		n = 4; m = 5;
	} else if (A == 200) {
		n = 14; m = 15;
	} else {
		n = 3; m = 4;
	}
	rep(i, 1, n + 1) rep(j, 1, m + 1) check[i][j] = false;

	for (int i = 1; i + 2 <= n; ++i) for (int j = 1; j + 2 <= m; ++j) {
		if (check[i][j]) continue;
		while (!check[i][j]) {
			bool r = deploy(i + 1, j + 1);
			if (r) return;
		}
	}

	for (int i = 1; i + 2 <= n; ++i) {
		while (!check[i][m - 1] || !check[i][m]) {
			bool r = deploy(i + 1, m - 1);
			if (r) return;
		}
	}

	for (int j = 1; j + 2 <= m; ++j) {
		while (!check[n - 1][j] || !check[n][j]) {
			bool r = deploy(n - 1, j + 1);
			if (r) return;
		}
	}

	while (!check[n - 1][m - 1] || !check[n - 1][m] || !check[n][m - 1] || !check[n][m]) {
		bool r = deploy(n - 1, m - 1);
		if (r) return;
	}


}

int main() {
#ifdef _LOCAL_
//	freopen("in.txt", "r", stdin);
	//    freopen("out.txt", "w", stdout);
#endif
	int Test = 1;
	if (multipleTest) {
		cin >> Test;
	}
	for(int i = 0; i < Test; ++i) {
//		printf("Case #%d: ", i + 1);
		solve();
	}
#ifdef _LOCAL_
	cerr << "\n" << 1.0 * clock() / CLOCKS_PER_SEC << "\n";
#endif
}
