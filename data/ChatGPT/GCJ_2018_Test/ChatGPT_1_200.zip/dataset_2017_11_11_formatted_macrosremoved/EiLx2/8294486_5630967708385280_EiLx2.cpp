#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define sz(a) (int)(a).size()
#define rep(i, a, b) for (int i = (a), _b = (b); i < _b; ++i)
#define frep(i, a, b) for (int i = (a), _b = (b); i <= _b; ++i)
#define _all(a) a.begin(), a.end()

typedef vector<int> vi;
typedef pair<int, int> ii;
typedef pair<ii, int> iii;
typedef vector<ii> vii;

const int inf = 1e9 + 7;
const ll linf  = 1ll * inf * inf;
const int N = 1e5 + 7;
const int M = 30;
const int multipleTest = 1;

vector<pair<ll, ll>> horses;
double dp[N];
int n;
ll d;

vector<pair<double, double>> all;

double calc(double dest, pair<double, double> x) {
	return (dest - x.first) / x.second;
}


double eps = 0.0000001;

bool check(long double speed) {
	pair<double, double> horse = {0, speed};
	double t = 0;
	for (int i = sz(all) - 1; i > 0; --i) {
		if (speed <= all[i].second) return true;
		double dest = all[i - 1].first;
		t += calc(dest, all[i]);
		double diff = t - calc(dest, horse);
		if (diff > 0 || (abs(diff) < eps && speed > all[i - 1].second && i > 1)) return false;
	}
	return t <= calc(d, horse);
}

void solve() {
	cin >> d >> n; horses.resize(n);
	rep(i, 0, n) {
		cin >> horses[i].first >> horses[i].second;
	}
	sort(_all(horses));
	all.clear();
	all.push_back({d, 0});
	all.push_back({horses[n - 1].first, horses[n - 1].second});

	for (int i = n - 2; i >= 0; --i) {
		while (all.size() > 1) {
			double dest = all[all.size() - 2].first;
			if (calc(dest, all.back()) < calc(dest, horses[i])) {
				all.pop_back();
			} else {
				// ai + bi * t = aj + bj * t => t = (aj - ai) / (bi - bj)
				// ai + bi * (aj - ai) / (bi - bj) = (bi * aj - ai * bj) / (bi - bj)
				auto tmp = all.back(); all.pop_back();

				all.push_back({(tmp.first * horses[i].second - horses[i].first * tmp.second)/ (horses[i].second - tmp.second), tmp.second});
				break;
			}
		}

		all.push_back({horses[i].first, horses[i].second});
	}
	double t = 0;
	for (int i = 1; i < sz(all); ++i) t += (all[i - 1].first - all[i].first) / all[i].second;

	printf("%.6lf\n", max(d / t, all[1].second));
}

int main() {
#ifdef _LOCAL_
	freopen("in.txt", "r", stdin);
	//    freopen("out.txt", "w", stdout);
#endif
	int Test = 1;
	if (multipleTest) {
		cin >> Test;
	}
	for(int i = 0; i < Test; ++i) {
		printf("Case #%d: ", i + 1);
		solve();
	}
#ifdef _LOCAL_
	//	cout << "\n" << 1.0 * clock() / CLOCKS_PER_SEC << "\n";
#endif
}
