#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

const double EPSILON = 1e-6;

void solve(double A) {
    double angle = acos(A / sqrt(2)) / 2;
    vector<vector<double>> face_centers = {
        {0.5 * cos(angle), 0.5 * sin(angle), 0},
        {-0.5 * sin(angle), 0.5 * cos(angle), 0},
        {0, 0, 0.5}
    };

    for (const auto& face_center : face_centers) {
        cout << face_center[0] << " " << face_center[1] << " " << face_center[2] << endl;
    }
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;

        cout << "Case #" << i << ":" << endl;
        solve(A);
    }

    return 0;
}
