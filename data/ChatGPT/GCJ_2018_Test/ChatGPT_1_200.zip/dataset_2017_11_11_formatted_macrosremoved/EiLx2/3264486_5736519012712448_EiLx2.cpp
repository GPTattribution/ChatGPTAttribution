#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define sz(a) (int)(a).size()
#define rep(i, a, b) for (int i = (a), _b = (b); i < _b; ++i)
#define frep(i, a, b) for (int i = (a), _b = (b); i <= _b; ++i)

typedef vector<int> vi;
typedef pair<int, int> ii;
typedef pair<ii, int> iii;
typedef vector<ii> vii;

const int inf = 1e9 + 7;
const ll linf  = 1ll * inf * inf;
const int N = 1e5 + 7;
const int M = 30;
const int multipleTest = 1;

vector<int> a, b;
int n;

void solve() {
	cin >> n;
	a.resize(n - n / 2); b.resize(n / 2);
	for (int i = 0; i < n; ++i) if (i & 1) scanf("%d", &b[i >> 1]);
	else scanf("%d", &a[i >> 1]);

	sort(a.begin(), a.end());
	sort(b.begin(), b.end());

	vector<int> c(n);
	for (int i = 0; i < b.size(); ++i) {
		c[i << 1] = a[i]; c[i << 1 | 1] = b[i];
	}
	if (n & 1) c.back() = a.back();

	for (int i = 0; i + 1 < n; ++i) if (c[i] > c[i + 1]) {
		printf("%d\n", i);
		return;
	}
	puts("OK");
}

int main() {
#ifdef _LOCAL_
	freopen("in.txt", "r", stdin);
	//    freopen("out.txt", "w", stdout);
#endif
	int Test = 1;
	if (multipleTest) {
		cin >> Test;
	}
	for(int i = 0; i < Test; ++i) {
		printf("Case #%d: ", i + 1);
		solve();
	}
#ifdef _LOCAL_
	cout << "\n" << 1.0 * clock() / CLOCKS_PER_SEC << "\n";
#endif
}
