#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define sz(a) (int)(a).size()
#define rep(i, a, b) for (int i = (a), _b = (b); i < _b; ++i)
#define frep(i, a, b) for (int i = (a), _b = (b); i <= _b; ++i)
#define _all(a) a.begin(), a.end()

typedef vector<int> vi;
typedef pair<int, int> ii;
typedef pair<ii, int> iii;
typedef vector<ii> vii;

const int inf = 1e9 + 7;
const ll linf  = 1ll * inf * inf;
const int N = 1e5 + 7;
const int M = 30;
const int multipleTest = 1;

ll n, k;

pair<ll, ll> get(ll x) {
	--x;
	return {x / 2, x - x / 2};
}
map<ll, ll> f;

void solve() {
	cin >> n >> k;f.clear();
	f[n] = 1;
	--k;
	while (k > 0) {
//		for (auto x : f) cout << x.first << ' ' << x.second << '\n'; puts("");
		ll len = f.rbegin()->first;
		ll cnt = f.rbegin()->second;
		if (k < cnt) {
			f[len] -= k;
			auto tmp = get(len);
			f[tmp.first] += k;
			f[tmp.second] += k;
			break;
		} else {
			f.erase(len);
			k -= cnt;
			auto tmp = get(len);
			f[tmp.first] += cnt;
			f[tmp.second] += cnt;
		}
	}
	ll mx = f.rbegin()->first;
	cout << (mx) / 2 << ' ' << (mx - 1) / 2 << '\n';
}

int main() {
#ifdef _LOCAL_
	freopen("in.txt", "r", stdin);
	//    freopen("out.txt", "w", stdout);
#endif
	int Test = 1;
	if (multipleTest) {
		cin >> Test;
	}
	for(int i = 0; i < Test; ++i) {
		printf("Case #%d: ", i + 1);
		solve();
	}
#ifdef _LOCAL_
	//	cout << "\n" << 1.0 * clock() / CLOCKS_PER_SEC << "\n";
#endif
}
