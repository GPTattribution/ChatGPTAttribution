#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <cmath>
#include <cstring>
#include <unordered_set>
#include <unordered_map>
using namespace std;

#define pb push_back
#define fst first
#define snd second

typedef long long ll;
typedef pair<int,int> pii;
template<typename T> using min_queue=priority_queue<T,vector<T>,greater<T> >;

const ll MOD=1e9+7;

int main(){
  ios::sync_with_stdio(0);cin.tie(0);

  int T;cin>>T;
  for(int tt=1;tt<=T;tt++){
    cout<<"Case #"<<tt<<": ";
    vector<int> v[2];
    int N;cin>>N;
    for(int i=0;i<N;i++){
      int x;cin>>x;
      v[i%2].push_back(x);
    }
    sort(v[0].begin(),v[0].end());
    sort(v[1].begin(),v[1].end());
    int res=-1;
    for(int i=0;i<N-1;i++){
      if(v[i%2][i/2]>v[(i+1)%2][(i+1)/2]){
	res=i;break;
      }
    }
    if(res==-1) cout<<"OK\n";
    else cout<<res<<'\n';
  }
  return 0;
}
