#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void solve(int case_num, double desired_area) {
    double theta = acos(desired_area / sqrt(2.0));

    double p1[3] = {0.5 * cos(theta), 0.5 * sin(theta), 0};
    double p2[3] = {-0.5 * sin(theta), 0.5 * cos(theta), 0};
    double p3[3] = {0, 0, 0.5};

    cout << "Case #" << case_num << ":\n";
    cout << setprecision(15) << p1[0] << " " << p1[1] << " " << p1[2] << "\n";
    cout << setprecision(15) << p2[0] << " " << p2[1] << " " << p2[2] << "\n";
    cout << setprecision(15) << p3[0] << " " << p3[1] << " " << p3[2] << "\n";
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; ++i) {
        double a;
        cin >> a;
        solve(i, a);
    }
    return 0;
}
