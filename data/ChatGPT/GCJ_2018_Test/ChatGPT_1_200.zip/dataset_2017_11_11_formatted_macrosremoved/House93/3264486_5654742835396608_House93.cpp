#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <cmath>
#include <cstring>
#include <unordered_set>
#include <unordered_map>
using namespace std;

#define pb push_back
#define fst first
#define snd second

typedef long long ll;
typedef pair<int,int> pii;
template<typename T> using min_queue=priority_queue<T,vector<T>,greater<T> >;

const ll MOD=1e9+7;

int b[1010][1010];
int s[1010][1010];


int main(){
  ios::sync_with_stdio(0);cin.tie(0);

  int T;cin>>T;
  for(int tt=1;tt<=T;tt++){
    srand(time(0));
    memset(b,0,sizeof b);
    int A;cin>>A;
    int H=4,W=5;
    if(A>20) H+=10,W+=10;
    set<pair<int,pii>> q;
    for(int i=500;i<500+H;i++){
      for(int j=500;j<500+W;j++){
	q.insert({-9,{i,j}});
	s[i][j]=9;
      }
    }
    int good=0;
    int cnt=0;
    while(1){
      auto it=q.begin();
      int wt=it->fst,i0=it->snd.fst,j0=it->snd.snd;
      cout<<i0<<' '<<j0<<endl;
      cnt++;
      cin>>i0>>j0;
      // i0=i0-1+rand()%3;
      // j0=j0-1+rand()%3;
      // if(good==A) i0=j0=0;
      // cout<<i0<<' '<<j0<<endl;
      // int tmp;cin>>tmp;
      if(i0==0 && j0==0) break;
      if(b[i0][j0]==1){
	continue;
      }
      b[i0][j0]=1;
      if(!(i0<500||i0>=500+H||j0<500||j0>=500+W)) good++;
      for(int i=i0-1;i<=i0+1;i++){
	for(int j=j0-1;j<=j0+1;j++){
	  if(i<500||i>=500+H||j<500||j>=500+W) continue;
	  pair<int,pii> pr={-s[i][j],{i,j}};
	  q.erase(pr);
	  s[i][j]--;pr.fst++;
	  q.insert(pr);
	}
      }
    }
    // cerr<<cnt<<'\n';
  }

  return 0;
}
