#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <cmath>
#include <cstring>
#include <unordered_set>
#include <unordered_map>
using namespace std;

#define pb push_back
#define fst first
#define snd second

typedef long long ll;
typedef pair<int,int> pii;
template<typename T> using min_queue=priority_queue<T,vector<T>,greater<T> >;

const ll MOD=1e9+7;

int main(){
  ios::sync_with_stdio(0);cin.tie(0);

  int T;cin>>T;
  for(int tt=1;tt<=T;tt++){
    cout<<"Case #"<<tt<<": ";

    ll N,K;
    cin>>N>>K;
    ll cnt[2]{1,0};
    while(cnt[0]+cnt[1]<K){
      K-=cnt[0]+cnt[1];
      ll tmp[2]{};
      tmp[0]+=cnt[0];
      tmp[(N+1)%2]+=cnt[0]+cnt[1];
      tmp[1]+=cnt[1];
      cnt[0]=tmp[0],cnt[1]=tmp[1];
      N/=2;
      // cout<<cnt[0]<<' '<<cnt[1]<<' '<<K<<' '<<N<<'\n';
    }
    if(K>cnt[0]) N--;
    cout<<N/2<<' '<<(N-1)/2<<'\n';
  }

  return 0;
}
