#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <cmath>
#include <cstring>
#include <unordered_set>
#include <unordered_map>
using namespace std;

#define pb push_back
#define fst first
#define snd second

typedef long long ll;
typedef pair<int,int> pii;
template<typename T> using min_queue=priority_queue<T,vector<T>,greater<T> >;

const ll MOD=1e9+7;

int N,p[26];

int main(){
  ios::sync_with_stdio(0);cin.tie(0);

  int T;cin>>T;
  for(int tt=1;tt<=T;tt++){
    cout<<"Case #"<<tt<<": ";
    cin>>N;

    int s=0;
    for(int i=0;i<N;i++) cin>>p[i],s+=p[i];
    if(N==2){
      for(int i=0;i<p[0];i++) cout<<"AB"<<" \n"[i==p[0]-1];
    }else{
      while(s>2){
	int ix=0,best=0;
	for(int i=0;i<N;i++){
	  if(p[i]>best) ix=i,best=p[i];
	}
	cout<<char('A'+ix)<<' ';
	p[ix]--,s--;
      }
      for(int i=0;i<N;i++) if(p[i]) cout<<char('A'+i);
      cout<<'\n';
    }

  }
  return 0;
}
