#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <cmath>
#include <cstring>
#include <unordered_set>
#include <unordered_map>
using namespace std;

#define pb push_back
#define fst first
#define snd second

typedef long long ll;
typedef pair<int,int> pii;
template<typename T> using min_queue=priority_queue<T,vector<T>,greater<T> >;

const ll MOD=1e9+7;

int main(){
  ios::sync_with_stdio(0);cin.tie(0);

  int T;cin>>T;
  for(int tt=1;tt<=T;tt++){
    cout<<"Case #"<<tt<<": ";
    ll D;cin>>D;
    string s;cin>>s;
    int N=s.size();
    int cnt=0;
    while(1){
      int ix=-1;
      ll str=1;
      ll tot=0;
      for(int i=0;i<N;i++){
	if(s[i]=='C') str<<=1;
	else tot+=str;
	if(i<N && s[i]=='C' && s[i+1]=='S') ix=i;
      }
      if(tot<=D) break;
      if(ix==-1){
	cnt=-1;
	break;
      }
      swap(s[ix],s[ix+1]);
      cnt++;
    }
    if(cnt<0) cout<<"IMPOSSIBLE\n";
    else cout<<cnt<<'\n';
  }
  return 0;
}
