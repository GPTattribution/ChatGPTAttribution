#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <cmath>
#include <cstring>
#include <unordered_set>
#include <unordered_map>
using namespace std;

#define pb push_back
#define fst first
#define snd second

typedef long long ll;
typedef pair<int,int> pii;
template<typename T> using min_queue=priority_queue<T,vector<T>,greater<T> >;

const ll MOD=1e9+7;

int main(){
  ios::sync_with_stdio(0);cin.tie(0);

  int T;cin>>T;
  while(T --> 0){
    int l,r;cin>>l>>r;
    l++;
    int N;cin>>N;
    while(1){
      int mid=l+(r-l)/2;
      cout<<mid<<endl;
      string s;cin>>s;
      if(s[0]=='C'){
	l=mid;break;
      }else if(s[4]=='B'){
	r=mid-1;
      }else{
	l=mid+1;
      }
    }
  }

  return 0;
}
