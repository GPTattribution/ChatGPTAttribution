#include <stdio.h>
#include <vector>
#include <queue>
#include <algorithm>
#include <iostream>
#include <string>
#include <bitset>
#include <map>
#include <set>
#include <tuple>
#include <string.h>
#include <math.h>
#include <random>
#include <functional>
#include <assert.h>
#include <math.h>

using namespace std;

using i64 = long long int;
using ii = pair<int, int>;
using ii64 = pair<i64, i64>;

void solve()
{
    int n;
    scanf("%d", &n);

    vector<int> parties(n);
    int total = 0;

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &parties[i]);
        total += parties[i];
    }

    while (total > 0)
    {
        auto iter = max_element(parties.begin(), parties.end());

        *iter -= 1;
        total--;

        printf("%c", 'A' + (iter - parties.begin()));

        iter = max_element(parties.begin(), parties.end());

        if (*iter > total / 2)
        {
            *iter -= 1;
            total--;
            printf("%c", 'A' + (iter - parties.begin()));
        }
        printf(" ");
    }
    printf("\n");
}

int main()
{
    int t;
    scanf("%d", &t);

    for (int i = 0; i < t; i++)
    {
        printf("Case #%d: ", i + 1);
        solve();
    }
}
