#include <stdio.h>
#include <vector>
#include <queue>
#include <algorithm>
#include <iostream>
#include <string>
#include <bitset>
#include <map>
#include <set>
#include <tuple>
#include <string.h>
#include <math.h>
#include <random>
#include <functional>
#include <assert.h>
#include <math.h>

using namespace std;

using i64 = long long int;
using ii = pair<int, int>;
using ii64 = pair<i64, i64>;

void solve()
{
    int a, b, n;
    scanf("%d %d %d", &a, &b, &n);
    a++;

    while (a <= b)
    {
        int mid = (a + b) / 2;

        printf("%d\n", mid);
        fflush(stdout);
        string res;

        cin >> res;

        if (res == "TOO_BIG")
        {
            b = mid - 1;
        }
        else if (res == "TOO_SMALL")
        {
            a = mid + 1;
        }
        else
        {
            break;
        }
    }
}

int main()
{
    int t;
    scanf("%d", &t);

    for (int i = 0; i < t; i++)
        solve();
}
