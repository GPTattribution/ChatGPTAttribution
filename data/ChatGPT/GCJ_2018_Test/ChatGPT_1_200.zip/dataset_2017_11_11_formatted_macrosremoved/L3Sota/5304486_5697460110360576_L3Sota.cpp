#include <stdio.h>
#include <vector>
#include <queue>
#include <algorithm>
#include <iostream>
#include <string>
#include <bitset>
#include <map>
#include <set>
#include <stack>
#include <tuple>
#include <string.h>
#include <math.h>
#include <random>
#include <functional>
#include <assert.h>

using namespace std;

using i64 = long long int;
using ii = pair<int, int>;
using ii64 = pair<i64, i64>;

string change(const string& s)
{
    string res = s;

    for (int i = 0; i < res.size() - 1; i++)
    {
        if (res[i] == 'C' && res[i + 1] == 'S')
        {
            swap(res[i], res[i + 1]);
            break;
        }
    }

    return res;
}

i64 damage(const string& s)
{
    i64 now = 1;
    i64 total = 0;

    for (int i = 0; i < s.size(); i++)
    {
        if (s[i] == 'S')
            total += now;
        else
            now *= 2;
    }

    return total;
}

void solve()
{
    int d;
    string s;

    cin >> d >> s;

    int number = 0;

    while (true)
    {
        i64 dam = damage(s);

        if (dam <= d)
            break;

        string changed = change(s);

        if (changed == s)
        {
            number = -1;
            break;
        }

        number++;
        s = changed;
    }

    if (number == -1)
        printf("IMPOSSIBLE\n");
    else
        printf("%d\n", number);
}

int main()
{
    int t;
    scanf("%d", &t);

    for (int i = 1; i <= t; i++)
    {
        printf("Case #%d: ", i);
        solve();
    }

    return 0;
}
