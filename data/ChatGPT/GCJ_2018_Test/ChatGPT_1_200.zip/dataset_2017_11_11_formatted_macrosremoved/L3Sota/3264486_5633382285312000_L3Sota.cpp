#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

const double PI = acos(-1.0);
const double EPS = 1e-6;

vector<vector<double>> find_rotation(double target_area) {
    double theta = asin(target_area / sqrt(2));
    double phi = PI / 4.0 - theta / 2.0;

    vector<vector<double>> face_centers(3, vector<double>(3));
    face_centers[0] = {cos(phi) / sqrt(2), sin(phi) / sqrt(2), 0};
    face_centers[1] = {-sin(phi) / sqrt(2), cos(phi) / sqrt(2), 0};
    face_centers[2] = {0, 0, 0.5};

    return face_centers;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        vector<vector<double>> face_centers = find_rotation(A);

        cout.precision(10);
        cout << "Case #" << t << ":" << endl;
        for (const auto &face_center : face_centers) {
            for (double coord : face_center) {
                cout << fixed << coord << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
