#include <stdio.h>
#include <vector>
#include <queue>
#include <algorithm>
#include <iostream>
#include <string>
#include <bitset>
#include <map>
#include <set>
#include <stack>
#include <tuple>
#include <string.h>
#include <math.h>
#include <random>
#include <functional>
#include <assert.h>

using namespace std;

using i64 = long long int;
using ii = pair<int, int>;
using ii64 = pair<i64, i64>;

void solve()
{
    int n;
    scanf("%d", &n);

    vector<int> even((n + 1) / 2);
    vector<int> odd(n / 2);

    for (int i = 0; i < n; i++)
    {
        if (i % 2 == 0)
            scanf("%d", &even[i / 2]);
        else
            scanf("%d", &odd[i / 2]);
    }

    sort(even.begin(), even.end());
    sort(odd.begin(), odd.end());

    vector<int> arr(n);

    for (int i = 0; i < even.size(); i++)
        arr[i * 2] = even[i];

    for (int i = 0; i < odd.size(); i++)
        arr[i * 2 + 1] = odd[i];

    for (int i = 0; i < arr.size() - 1; i++)
    {
        if (arr[i] > arr[i + 1])
        {
            printf("%d\n", i);
            return;
        }
    }

    printf("OK\n");
}

int main()
{
    int t;
    scanf("%d", &t);

    for (int i = 1; i <= t; i++)
    {
        printf("Case #%d: ", i);
        solve();
    }

    return 0;
}
