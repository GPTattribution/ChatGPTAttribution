#include <stdio.h>
#include <vector>
#include <queue>
#include <algorithm>
#include <iostream>
#include <string>
#include <bitset>
#include <map>
#include <set>
#include <stack>
#include <tuple>
#include <string.h>
#include <math.h>
#include <random>
#include <functional>
#include <assert.h>

using namespace std;

using i64 = long long int;
using ii = pair<int, int>;
using ii64 = pair<i64, i64>;

void solve()
{
    int a;
    scanf("%d", &a);

    int x = 3;
    while (a > 0)
    {
        set<ii> cells;

        for (int i = x - 1; i <= x + 1; i++)
            for (int y = 2; y <= 4; y++)
                cells.emplace(i, y);

        while (!cells.empty())
        {
            printf("%d %d\n", x, 3);
            fflush(stdout);

            int nx, ny;
            scanf("%d %d", &nx, &ny);

            if (nx == 0 && ny == 0)
                return;

            cells.erase(ii(nx, ny));
        }

        a -= 9;
        x += 3;
    }
}

int main()
{
    int t;
    scanf("%d", &t);

    for (int i = 1; i <= t; i++)
    {
        solve();
    }

    return 0;
}
