#include <iostream>
#include <algorithm>
using namespace std;
struct id{
    bool operator()(const bool& b)const{
        return b;
    }
} _true;
struct inv{
    bool operator()(const bool& b)const{
        return !b;
    }
} _false;
int arr[2][50000];
int main() {
    ios_base::sync_with_stdio(false);
    int t;
    cin>>t;
    for(int ct=1;ct<=t;++ct){
        int a;
        cin>>a;
        int n=(a+2)/3;
        int offset=0;
        bool data[1000][3];
        fill(&data[0][0],&data[n][0],false);
        while(offset<n-3||any_of(&data[offset][0],&data[offset+3][0],_false)){
            if(offset<n-3&&all_of(&data[offset][0],&data[offset+1][0],_true)){
                ++offset;
                continue;
            }
            cout<<offset+2<<' '<<2<<endl;
            int x,y;
            cin>>x>>y;
            if(x==0&&y==0)break;
            if(x==-1&&y==-1)return 0;
            --x;
            --y;
            data[x][y]=true;
        }
    }
}
