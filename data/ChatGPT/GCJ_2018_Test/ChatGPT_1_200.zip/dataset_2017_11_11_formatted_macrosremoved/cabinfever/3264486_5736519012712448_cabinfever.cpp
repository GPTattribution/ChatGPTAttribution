#include <iostream>
#include <algorithm>
using namespace std;
int arr[2][50000];
int main() {
    ios_base::sync_with_stdio(false);
    int t;
    cin>>t;
    for(int ct=1;ct<=t;++ct){
        int n;
        cin>>n;
        for(int i=0;i<n;++i){
            cin>>arr[i&1][i>>1];
        }
        sort(&arr[0][0],&arr[0][(n+1)>>1]);
        sort(&arr[1][0],&arr[1][n>>1]);
        cout<<"Case #"<<ct<<": ";
        bool ok=true;
        for(int i=1;i<n;++i){
            if(arr[(i-1)&1][(i-1)>>1]>arr[i&1][i>>1]){
                ok=false;
                cout<<(i-1);
                break;
            }
        }
        if(ok){
            cout<<"OK";
        }
        cout<<'\n';
    }
}
