#include <iostream>
#include <string>
#include <utility>
using namespace std;
inline int damage(const string& str){
    int ret=0;
    int strength=1;
    for(const char& ch : str){
        if(ch=='C'){
            strength<<=1;
        }
        else{
            ret+=strength;
        }
    }
    return ret;
}
inline bool hack(string& str){
    for(size_t i=str.size()-1;i>0;--i){
        if(str[i-1]=='C'&&str[i]=='S'){
            swap(str[i-1],str[i]);
            return true;
        }
    }
    return false;
}
int main() {
    ios_base::sync_with_stdio(false);
    int t;
    cin>>t;
    for(int ct=1;ct<=t;++ct){
        int d;
        string str;
        cin>>d>>str;
        int hacks=0;
        while(d<damage(str)){
            if(!hack(str))break;
            ++hacks;
        }
        cout<<"Case #"<<ct<<": ";
        if(d<damage(str)){
            cout<<"IMPOSSIBLE";
        }
        else{
            cout<<hacks;
        }
        cout<<'\n';
    }
}
