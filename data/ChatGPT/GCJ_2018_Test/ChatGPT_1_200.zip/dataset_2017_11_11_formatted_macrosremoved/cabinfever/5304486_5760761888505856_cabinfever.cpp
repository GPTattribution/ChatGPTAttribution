#include <iostream>
using namespace std;
int main() {
    ios_base::sync_with_stdio(false);
    int t;
    cin>>t;
    for(int ct=1;ct<=t;++ct){
        long long n,k,s=1,h=1;
        cin>>n>>k;
        cout<<"Case #"<<ct<<": ";
        while(true){
            if(k<=h){
                long long v=n>>1;
                cout<<v<<' '<<n-1-v<<'\n';
                break;
            }
            if(k<=s){
                --n;
                long long v=n>>1;
                cout<<v<<' '<<n-1-v<<'\n';
                break;
            }
            k-=s;
            h=(n&1)?((h<<1)+(s-h)):h;
            n>>=1;
            s<<=1;
        }
    }
}
