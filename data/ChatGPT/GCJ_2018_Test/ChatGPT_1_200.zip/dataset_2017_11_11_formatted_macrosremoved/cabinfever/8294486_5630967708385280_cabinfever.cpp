#include <iostream>
#include <iomanip>
#include <queue>
using namespace std;
int main() {
    ios_base::sync_with_stdio(false);
    int t;
    cin>>t;
    for(int ct=1;ct<=t;++ct){
        int d,n;
        cin>>d>>n;
        double tm=0;
        for(int i=0;i<n;++i){
            int k,s;
            cin>>k>>s;
            tm=max(tm,(double)(d-k)/s);
        }
        cout<<"Case #"<<ct<<": "<<setprecision(9)<<(d/tm)<<'\n';
    }
}
