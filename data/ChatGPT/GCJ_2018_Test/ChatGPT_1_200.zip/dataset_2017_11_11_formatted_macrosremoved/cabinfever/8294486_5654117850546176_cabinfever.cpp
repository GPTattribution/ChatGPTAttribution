#include <iostream>
#include <string>
using namespace std;
int main() {
    ios_base::sync_with_stdio(false);
    int t;
    cin>>t;
    while(t-->0){
        int a,b;
        cin>>a>>b;
        ++a;
        {
            int n;
            cin>>n; // discard n
        }
        while(true){
            int guess=(a+b)>>1;
            cout<<guess<<endl;
            string str;
            cin>>str;
            if(str=="TOO_SMALL")a=guess+1;
            else if(str=="TOO_BIG")b=guess-1;
            else break;
        }
    }
}
