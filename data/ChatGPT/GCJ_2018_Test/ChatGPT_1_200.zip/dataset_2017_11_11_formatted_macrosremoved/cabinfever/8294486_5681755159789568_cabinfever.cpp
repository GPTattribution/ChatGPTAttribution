#include <iostream>
#include <queue>
using namespace std;
int main() {
    ios_base::sync_with_stdio(false);
    int t;
    cin>>t;
    for(int ct=1;ct<=t;++ct){
        int n;
        cin>>n;
        priority_queue<pair<int,int>> pq;
        int count=0;
        for(int i=0;i<n;++i){
            int h;
            cin>>h;
            count+=h;
            pq.emplace(h,i);
        }
        cout<<"Case #"<<ct<<":";
        if(count&1){
            pair<int,int> tmp=pq.top();
            pq.pop();
            cout<<" "<<(char)('A'+tmp.second);
            if(tmp.first>1)pq.emplace(tmp.first-1,tmp.second);
        }
        while(!pq.empty()){
            char a,b;
            {
                pair<int,int> tmp=pq.top();
                pq.pop();
                a='A'+tmp.second;
                if(tmp.first>1)pq.emplace(tmp.first-1,tmp.second);
            }
            {
                pair<int,int> tmp=pq.top();
                pq.pop();
                b='A'+tmp.second;
                if(tmp.first>1)pq.emplace(tmp.first-1,tmp.second);
            }
            cout<<" "<<a<<b;
        }
        cout<<'\n';
    }
}
