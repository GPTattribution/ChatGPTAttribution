#include <bits/stdc++.h>
using namespace std;
typedef signed long long ll;

#undef _P
#define _P(...) (void)printf(__VA_ARGS__)
#define FOR(i, a, b) for (int i = (a); i < (b); ++i)
#define REP(i, n) FOR(i, 0, n)
#define FORR(x, arr) for (auto& x : arr)
#define ITR(x, c) for (__typeof(c.begin()) x = c.begin(); x != c.end(); x++)
#define ALL(a) (a.begin()), (a.end())
#define ZERO(a) memset(a, 0, sizeof(a))
#define MINUS(a) memset(a, 0xff, sizeof(a))
//-------------------------------------------------------

int N;
int P[114];

bool cmp(int i, int j) { return P[i] > P[j]; }

void solve() {
    cin >> N;
    REP(i, N) {
        vector<int> v;
        int T;
        cin >> T;
        REP(j, T) {
            cin >> P[j];
            v.push_back(j);
        }

        sort(v.begin(), v.end(), cmp);
        int s = P[v[1]];
        _P("Case #%d: ", i + 1);
        REP(j, P[v[0]] - s) { _P("%c ", 'A' + v[0]); }
        FOR(j, 2, T) {
            REP(k, P[v[j]]) { _P("%c ", 'A' + v[j]); }
        }
        REP(j, s) { _P("%c%c ", 'A' + v[0], 'A' + v[1]); }
        _P("\n");
    }
}

int main(int argc, char** argv) {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    solve();
    return 0;
}
