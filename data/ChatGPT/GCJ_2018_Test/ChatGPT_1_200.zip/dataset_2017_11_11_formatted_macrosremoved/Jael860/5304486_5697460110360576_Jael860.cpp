#include <bits/stdc++.h>
using namespace std;
typedef signed long long ll;

#undef _P
#define _P(...) (void)printf(__VA_ARGS__)
#define FOR(i, a, b) for (int i = (a); i < (b); ++i)
#define REP(i, n) FOR(i, 0, n)
#define FORR(x, arr) for (auto& x : arr)
#define ITR(x, c) for (__typeof(c.begin()) x = c.begin(); x != c.end(); x++)
#define ALL(a) (a.begin()), (a.end())
#define ZERO(a) memset(a, 0, sizeof(a))
#define MINUS(a) memset(a, 0xff, sizeof(a))
//-------------------------------------------------------

void solve() {
    int T;
    cin >> T;

    REP(i, T) {
        ll D;
        string P;
        cin >> D >> P;
        int ans = 0;

        while (true) {
            ll sum = 0;
            ll c = 1;
            REP(j, P.size()) {
                if (P[j] == 'S') {
                    sum += c;
                } else {
                    c *= 2;
                }
            }

            if (sum <= D) {
                break;
            }

            int swap = -1;
            REP(j, P.size() - 1) {
                if (P[j] == 'C' && P[j + 1] == 'S') {
                    swap = j;
                }
            }

            if (swap < 0) {
                break;
            }
            P[swap] = 'S';
            P[swap + 1] = 'C';

            ans += 1;
        }

        ll sum = 0;
        ll c = 1;
        REP(j, P.size()) {
            if (P[j] == 'S') {
                sum += c;
            } else {
                c *= 2;
            }
        }

        if (sum <= D) {
            _P("Case #%d: %d\n", i + 1, ans);
        } else {
            _P("Case #%d: IMPOSSIBLE\n", i + 1);
        }
    }
}

int main(int argc, char** argv) {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    solve();
    return 0;
}
