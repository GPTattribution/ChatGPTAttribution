#include <bits/stdc++.h>
using namespace std;
typedef signed long long ll;

#undef _P
#define _P(...) (void)printf(__VA_ARGS__)
#define FOR(i, a, b) for (int i = (a); i < (b); ++i)
#define REP(i, n) FOR(i, 0, n)
#define FORR(x, arr) for (auto& x : arr)
#define ITR(x, c) for (__typeof(c.begin()) x = c.begin(); x != c.end(); x++)
#define ALL(a) (a.begin()), (a.end())
#define ZERO(a) memset(a, 0, sizeof(a))
#define MINUS(a) memset(a, 0xff, sizeof(a))
//-------------------------------------------------------

void solve() {
    int T;
    scanf("%d", &T);
    REP(i, T) {
        vector<ll> vs[2];
        int N;
        scanf("%d", &N);

        REP(j, N) {
            ll x;
            scanf("%lld", &x);
            vs[j % 2].push_back(x);
        }

        sort(vs[0].begin(), vs[0].end());
        sort(vs[1].begin(), vs[1].end());

        vector<ll> v;
        REP(j, N) { v.push_back(vs[j % 2][j / 2]); }

        int ans = -1;
        REP(j, N - 1) {
            if (v[j] > v[j + 1]) {
                ans = j;
                break;
            }
        }

        if (ans < 0) {
            _P("Case #%d: OK\n", i + 1);
        } else {
            _P("Case #%d: %d\n", i + 1, ans);
        }
    }
}

int main(int argc, char** argv) {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    solve();
    return 0;
}
