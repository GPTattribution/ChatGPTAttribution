#include <bits/stdc++.h>
using namespace std;
typedef signed long long ll;

#undef _P
#define _P(...) (void)printf(__VA_ARGS__)
#define FOR(i, a, b) for (int i = (a); i < (b); ++i)
#define REP(i, n) FOR(i, 0, n)
#define FORR(x, arr) for (auto& x : arr)
#define ITR(x, c) for (__typeof(c.begin()) x = c.begin(); x != c.end(); x++)
#define ALL(a) (a.begin()), (a.end())
#define ZERO(a) memset(a, 0, sizeof(a))
#define MINUS(a) memset(a, 0xff, sizeof(a))
//-------------------------------------------------------

bool M[1145][1145];

void solve() {
    int T;
    cin >> T;

    REP(i, T) {
        int A;
        cin >> A;

        int d = max(3, (A + 2) / 3);

        REP(y, d) {
            REP(x, 3) { M[y][x] = false; }
        }

        while (true) {
            int Y = 1;
            int n = 0;

            FOR(y, 1, d - 2 + 1) {
                int cnt = 0;
                FOR(j, y - 1, y + 2) {
                    FOR(k, 0, 3) {
                        if (!M[j][k]) {
                            cnt++;
                        }
                    }
                }

                if (cnt > n) {
                    n = cnt;
                    Y = y;
                }
            }

            cout << (Y + 1) << " " << 2 << endl << flush;
            int a, b;
            cin >> a >> b;
            if (a == -1 && b == -1) {
                return;
            }
            if (a == 0 && b == 0) {
                break;
            }
            M[a - 1][b - 1] = true;
        }
    }
}

int main(int argc, char** argv) {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    solve();
    return 0;
}
