#include <iostream>
#include <cmath>
#include <vector>

const double pi = std::acos(-1);

struct Point {
    double x, y, z;
};

double area(double angle, double A) {
    return A * std::sin(angle) * std::cos(angle);
}

std::vector<Point> find_face_centers(double A) {
    double angle = pi / 4;
    double left = 0, right = pi / 4;
    while (right - left > 1e-9) {
        double mid = (left + right) / 2;
        if (area(mid, A) < 1) {
            angle = mid;
            left = mid;
        } else {
            right = mid;
        }
    }

    double k = std::tan(angle);
    double d = 0.5 / std::sqrt(1 + k * k);
    std::vector<Point> face_centers = {
        {d, k * d, 0},
        {-d, k * d, 0},
        {0, 0, 0.5}
    };

    return face_centers;
}

int main() {
    int T;
    std::cin >> T;
    for (int i = 1; i <= T; ++i) {
        double A;
        std::cin >> A;
        std::vector<Point> face_centers = find_face_centers(A);

        std::cout.precision(16);
        std::cout << "Case #" << i << ":\n";
        for (const auto &face_center : face_centers) {
            std::cout << face_center.x << " " << face_center.y << " " << face_center.z << "\n";
        }
    }

    return 0;
}
