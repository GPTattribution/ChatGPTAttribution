#include <bits/stdc++.h>

using namespace std;

void doCase() {
	int A;
	cin >> A;

	vector<vector<bool>> area(10, vector<bool>(20, false));

	for (int i=0; i<7; i++) {
		for (int j=0; j<17; j++) {
			while (!area[i][j]) {
				cout << i+2 << " " << j+2 << endl;

				int a,b;
				cin >> a >> b;

				if (a == 0 && b == 0) return;

				area[a-1][b-1] = true;
			}
		}

		while (!area[i][17] || !area[i][18] || !area[i][19]) {
			cout << i+2 << " " << 19 << endl;
			int a,b;
			cin >> a >> b;
			if (a == 0 && b == 0) return;
			area[a-1][b-1] = true;
		}
	}

	for (int j=0; j<17; j++) {
		while (!area[7][j] || !area[8][j] || !area[9][j]) {
			cout << 9 << " " << j+2 << endl;
			int a,b;
			cin >> a >> b;
			if (a == 0 && b == 0) return;
			area[a-1][b-1] = true;
		}
	}

	while (true) {
		cout << 9 << " " << 19 << endl;
		int a,b;
		cin >> a >> b;
		if (a == 0 && b == 0) return;
	}
}

int main() {
	int T;
	cin >> T;
	for (int i=0; i<T; i++)
		doCase();
	return 0;
}
