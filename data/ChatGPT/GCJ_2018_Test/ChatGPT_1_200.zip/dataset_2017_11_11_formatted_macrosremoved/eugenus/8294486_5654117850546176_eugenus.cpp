#include <bits/stdc++.h>

using namespace std;

void doCase() {
	int A, B, N;
	cin >> A >> B >> N;
	A++;
	B++;

	while (1) {
		string s;

		int MID = (A+B)/2;
		cout << MID << endl;
		cin >> s;

		if (s == "WRONG_ANSWER") exit(0);
		if (s == "CORRECT") return;
		if (s == "TOO_SMALL") A = MID;
		else if (s == "TOO_BIG") B = MID;
		else abort();
	}
}

int main() {
	int T;
	cin >> T;

	for (int i=0; i<T; i++)
		doCase();
}
