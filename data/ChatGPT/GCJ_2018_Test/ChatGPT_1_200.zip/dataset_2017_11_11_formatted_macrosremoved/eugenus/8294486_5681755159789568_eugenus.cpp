#include <bits/stdc++.h>

using namespace std;

void doCase(int i) {
	priority_queue<pair<int, int>> parties;
	int N, tot=0;

	cin >> N;

	for (int i=0; i<N; i++) {
		int A;
		cin >> A;
		parties.push({A,i});
		tot += A;
	}

	cout << "Case #" << i << ":";

	while (tot != 0) {
		string cur = "";

		auto curp = parties.top();
		parties.pop();
		curp.first--;
		cur += ('A'+curp.second);
		parties.push(curp);
		tot--;

		curp = parties.top();
		if (2*curp.first > tot) {
			parties.pop();
			curp.first--;
			cur += ('A'+curp.second);
			parties.push(curp);
			tot--;
		}

		cout << " " << cur;
	}
	cout << endl;
}

int main() {
	int T;
	cin >> T;

	for (int i=0; i<T; i++)
		doCase(i+1);

	return 0;
}
