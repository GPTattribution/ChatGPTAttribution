#include <bits/stdc++.h>

using namespace std;

void doCase(int t) {
	long long D;
	string P;
	cin >> D >> P;

	vector<int> dcount(1,0);
	int i=0;
	long long curD = 0;
	long long val = 1;

	for (auto c : P) {
		if (c == 'S') {
			dcount[i]++;
			curD += val;
		} else {
			dcount.push_back(0);
			i++;
			val *= 2;
		}
	}

	val /= 2;

	cout << "Case #" << t << ": ";

	if (curD <= D) {
		cout << 0 << endl;
		return;
	}

	int count = 0;

	while (i > 0) {
		if (dcount[i]) {
			curD -= val;
			dcount[i]--;
			dcount[i-1]++;
			count++;
		} else {
			i--;
			val /= 2;
		}
		if (curD <= D) {
			cout << count << endl;
			return;
		}
	}

	cout << "IMPOSSIBLE" << endl;
}

int main() {
	int T;
	cin >> T;
	for (int i=0; i<T; i++)
		doCase(i+1);
	return 0;
}
