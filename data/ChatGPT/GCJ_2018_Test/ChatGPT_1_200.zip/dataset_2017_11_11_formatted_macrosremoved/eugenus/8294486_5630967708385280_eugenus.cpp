#include <bits/stdc++.h>

using namespace std;

void doCase(int i) {
	double D;
	int N;

	cin >> D >> N;

	double tmax = 0.0;
	for (int i=0; i<N; i++) {
		double K, S;
		cin >> K >> S;
		double tcur = (D-K)/S;
		tmax = max(tmax, tcur);
	}

	cout << "Case #" << i << ": " << setprecision(10) << fixed << (D/tmax) << endl;
}

int main() {
	int T;
	cin >> T;

	for (int i=0; i<T; i++)
		doCase(i+1);

	return 0;
}
