#include <bits/stdc++.h>

using namespace std;

void doCase(int t) {
	vector<int> la, lb;
	int N;

	cin >> N;

	bool state = true;
	for (int i=0; i<N; i++) {
		int D;
		cin >> D;
		if (state)
			la.push_back(D);
		else
			lb.push_back(D);
		state = !state;
	}

	sort(la.begin(), la.end());
	sort(lb.begin(), lb.end());

	vector<int> res(N);
	state = true;
	for (int i=0; i<N; i++) {
		if (state)
			res[i] = la[i/2];
		else
			res[i] = lb[i/2];
		state = !state;
	}

	cout << "Case #" << t << ": ";

	for (int i=0; i<N-1; i++) {
		if (res[i] > res[i+1]) {
			cout << i << endl;
			return;
		}
	}

	cout << "OK" << endl;
}

int main() {
	int T;
	cin >> T;
	for (int i=0; i<T; i++)
		doCase(i+1);
	return 0;
}
