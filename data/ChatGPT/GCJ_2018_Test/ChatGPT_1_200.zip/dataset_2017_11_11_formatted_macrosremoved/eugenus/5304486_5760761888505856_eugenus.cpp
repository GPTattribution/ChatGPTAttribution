#include <bits/stdc++.h>

using namespace std;

void doCase(int i) {
	long long K, N;
	cin >> N >> K;

	priority_queue<long long> work;
	map<long long, long long> amm;
	set<long long> added;

	work.push(N);
	added.insert(N);
	amm[N] = 1;

	while (1) {
		long long cur = work.top();
		work.pop();
		long long n = amm[cur];

		long long a = (cur-1)/2;
		long long b = a+((cur-1)%2);

		if (n >= K) {
			cout << "Case #" << i << ": " << b << " " << a << endl;
			return;
		} else {
			K -= n;
			amm[a] += n;
			amm[b] += n;
			if (added.count(a) == 0) {
				work.push(a);
				added.insert(a);
			}
			if (added.count(b) == 0) {
				work.push(b);
				added.insert(b);
			}
		}
	}
}

int main() {
	int T;
	cin >> T;

	for (int i=0; i<T; i++)
		doCase(i+1);

	return 0;
}
