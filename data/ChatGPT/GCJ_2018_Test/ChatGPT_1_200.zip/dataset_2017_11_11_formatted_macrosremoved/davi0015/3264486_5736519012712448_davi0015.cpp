#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <map>
#include <queue>
#include <ctime>
#include <cmath>

using namespace std;

#define forn(I,N) for (int I=0; I<N; I++)
#define fornd(I,N) for (int I=N-1; I>=0; I--)
#define forab(I,A,B) for (int I=A; I<=B; I++)
#define forabd(I,A,B) for (int I=B; I>=A; I--)
#define FOREACH(I,A) for (__typeof__(A)::iterator I=A.begin(); I<A.end(); I++)
#define pb push_back
#define mp make_pair

typedef long long int ll;

int main() {
  int T;
  cin >> T;

  forn(i, T) {
    int N;
    cin >> N;

    vector<int> v1, v2;
    int temp;
    forn(j, N) {
      cin >> temp;
      if (j % 2 == 0) {
        v1.pb(temp);
      } else {
        v2.pb(temp);
      }
    }

    sort(v1.begin(), v1.end());
    sort(v2.begin(), v2.end());

    int index = -1;
    forn(j, v1.size()) {
      if (j < v2.size()) {
        if (v1[j] > v2[j]) {
          index = 2 * j;
          break;
        }

        if (j + 1 < v1.size() && v2[j] > v1[j + 1]) {
          index = 2 * j + 1;
          break;
        }
      }
    }

    if (index >= 0) {
      cout << "Case #" << i + 1 << ": " << index << endl;
    } else {
      cout << "Case #" << i + 1 << ": OK" << endl;
    }
  }

  return 0;
}
