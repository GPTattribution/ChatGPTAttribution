#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPS = 1e-9;
const double PI = acos(-1);

void solve(int test, double A) {
    double phi = (A - 1) / (sqrt(2) - 1);
    double theta = asin(phi) / 2;

    double x1 = 0.5 * cos(theta);
    double y1 = 0.5 * sin(theta);

    double x2 = 0.5 * (cos(theta) * cos(PI / 2) - sin(theta) * sin(PI / 2));
    double y2 = 0.5 * (cos(theta) * sin(PI / 2) + sin(theta) * cos(PI / 2));

    cout << "Case #" << test << ":\n";
    cout << fixed << setprecision(10) << x1 << " " << y1 << " " << 0.0 << "\n";
    cout << x2 << " " << y2 << " " << 0.0 << "\n";
    cout << 0.0 << " " << 0.5 * cos(theta) << " " << 0.5 * sin(theta) << "\n";
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;
        solve(t, A);
    }

    return 0;
}
