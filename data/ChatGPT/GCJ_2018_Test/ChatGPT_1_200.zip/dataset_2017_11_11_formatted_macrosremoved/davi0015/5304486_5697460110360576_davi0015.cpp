#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <map>
#include <queue>
#include <ctime>
#include <cmath>

using namespace std;

#define forn(I,N) for (int I=0; I<N; I++)
#define fornd(I,N) for (int I=N-1; I>=0; I--)
#define forab(I,A,B) for (int I=A; I<=B; I++)
#define forabd(I,A,B) for (int I=B; I>=A; I--)
#define FOREACH(I,A) for (__typeof__(A)::iterator I=A.begin(); I<A.end(); I++)
#define pb push_back
#define mp make_pair

typedef long long int ll;

string reducePower(string s) {
  fornd(i, s.length() - 1) {
    if (s[i] == 'C' && s[i + 1] == 'S') {
      s[i] = 'S';
      s[i + 1] = 'C';
      break;
    }
  }

  return s;
}

ll getPower(string s) {
  ll total = 0;
  ll p = 1;
  forn(i, s.length()) {
    if (s[i] == 'S') {
      total += p;
    } else if (s[i] == 'C') {
      p <<= 1;
    }
  }

  return total;
}

int main() {
  int T;
  cin >> T;

  forn(i, T) {
    ll D;
    string P;

    cin >> D >> P;

    ll power = getPower(P);
    int count = 0;
    string newP = P;
    while (power > D) {
      newP = reducePower(newP);
      ll newPower = getPower(newP);

      if (newPower == power) {
        count = -1;
        break;
      } else {
        power = newPower;
        count++;
      }
    }

    if (count >= 0) {
      cout << "Case #" << i + 1 << ": " << count << endl;
    } else {
      cout << "Case #" << i + 1 << ": IMPOSSIBLE" << endl;
    }
  }

  return 0;
}
