#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <map>
#include <queue>
#include <ctime>
#include <cmath>

using namespace std;

#define forn(I,N) for (int I=0; I<N; I++)
#define fornd(I,N) for (int I=N-1; I>=0; I--)
#define forab(I,A,B) for (int I=A; I<=B; I++)
#define forabd(I,A,B) for (int I=B; I>=A; I--)
#define FOREACH(I,A) for (__typeof__(A)::iterator I=A.begin(); I<A.end(); I++)
#define pb push_back
#define mp make_pair

typedef long long int ll;

int main() {
  int T;
  cin >> T;

  forn(i, T) {
    ll N, K;
    cin >> N >> K;

    priority_queue<ll> queue;
    queue.push(N);

    map<ll, ll> count;
    count[N] = 1;

    ll ct = 0;
    ll space;
    while (ct < K) {
      space = queue.top();
      queue.pop();

      ct += count[space];

      if (count[space / 2] == 0) {
        queue.push(space / 2);
        // cout << "pushing " << space / 2 << endl;
      }
      count[space / 2] += count[space];

      if (count[(space - 1) / 2] == 0) {
        queue.push((space - 1) / 2);
        // cout << "pushing " << (space - 1) / 2 << endl;
      }
      count[(space - 1) / 2] += count[space];
      // cout << space << endl;
    }

    cout << "Case #" << i + 1 << ": " << space / 2 << " " << (space - 1) / 2 << endl;
  }

  return 0;
}
