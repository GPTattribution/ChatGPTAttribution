#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <map>
#include <queue>
#include <ctime>
#include <cmath>

using namespace std;

#define forn(I,N) for (int I=0; I<N; I++)
#define fornd(I,N) for (int I=N-1; I>=0; I--)
#define forab(I,A,B) for (int I=A; I<=B; I++)
#define forabd(I,A,B) for (int I=B; I>=A; I--)
#define FOREACH(I,A) for (__typeof__(A)::iterator I=A.begin(); I<A.end(); I++)
#define pb push_back
#define mp make_pair

typedef long long int ll;

int main() {
  int T;
  cin >> T;

  forn(i, T) {
    int A;
    cin >> A;

    int x1 = 500;
    int y1 = 500;
    int x2 = 500;
    int y2 = 500;

    vector< vector<bool> > grid(1001, vector<bool>(1001));
    int tree = 0;
    int ct = 0;
    int area = 9;
    while (ct < 1000 && (tree < area || area < A)) {
      bool canExpand = area < A;

      int x = x1, y = y1;
      int empty = 0;
      forab(j, x1 - 1, x2 + 1) {
        forab(k, y1 - 1, y2 + 1) {
          if ((j >= x1 || k >= y1) && (j <= x2 || k <= y2)) {
            if (canExpand || (j >= x1 && j <= x2 && k >= y1 && k <= y2)) {
              int temp = 0;
              forab(m, j - 1, j + 1) {
                forab(n, k - 1, k + 1) {
                  if(!grid[m][n]) {
                    temp++;
                  }
                }
              }

              if (empty < temp) {
                x = j;
                y = k;
                empty = temp;
              }
            }
          }
        }
      }

      cout << x << " " << y << endl;
      int resX, resY;
      cin >> resX >> resY;
      if (resX == 0 && resY == 0) {
        break;
      }

      if (!grid[resX][resY]) {
        grid[resX][resY] = true;
        tree++;
      }

      if (resX < x1) {
        x1 = resX + 1;
      } else if (resX > x2) {
        x2 = resX - 1;
      }

      if (resY < y1) {
        y1 = resY + 1;
      } else if (resY > y2) {
        y2 = resY - 1;
      }

      area = (x2 - x1 + 3) * (y2 - y1 + 3);
      ct++;
    }
  }

  return 0;
}
