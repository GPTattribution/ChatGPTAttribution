#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>      // std::setprecision
#include <queue>
#include <map>

using namespace std;

typedef pair<int, pair<int,int> > slot;

slot make_slot(int leftmost, int rightmost){
	return make_pair(rightmost-leftmost, make_pair(leftmost,rightmost));
}

void onecase(){
	map<int,int> m;

	int N,K;
	cin>>N>>K;

	m[N]=1;
	while(K>0){
		int maxindex=m.rbegin()->first;
		int maxDup=m[maxindex];
		//cerr<<"MaxSlot="<<maxindex<<" MaxDup="<<maxDup<<endl;

		if(K>maxDup){
			//transform all these slots
			m.erase(maxindex);
			int smallhalf=(maxindex-1)/2;
			int bighalf=maxindex-1-smallhalf;
			m[smallhalf]=m[smallhalf]+maxDup;
			m[bighalf]=m[bighalf]+maxDup;

			//cerr<<" transform slot "<<maxindex<<"repeat:"<< maxDup<<"into:"<<smallhalf<<","<<bighalf<<endl;
			K-=maxDup;

		}else{
			//this is the last guy's slot!
			//cerr<<"Last person slot size:"<<maxindex<<" hasDup="<<maxDup<<" remK="<<K<<endl;
			int smallhalf=(maxindex-1)/2;
			int bighalf=maxindex-1-smallhalf;
			cout<<max(smallhalf,bighalf)<<" "<<min(smallhalf,bighalf);
			return;
		}
	}


	//std::priority_queue<slot> q;
	//q.push(make_slot(1,N));

}

int main(){
	int T;
	cin>>T;
	for(int i=0;i<T;i++){
		cout<<"Case #"<<(i+1)<<": ";
		onecase();
		cout<<endl;
	}// onecase();
	return 0;
}
