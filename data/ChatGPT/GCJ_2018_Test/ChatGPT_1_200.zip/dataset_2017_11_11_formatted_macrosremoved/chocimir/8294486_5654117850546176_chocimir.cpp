#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>      // std::setprecision
using namespace std;

void onecase(){
	int D; int N;
	double dest_Dist;

	double latest_arrive=0;

	cin>>D>>N;
	dest_Dist=(double) D;
	for(int i=0;i<N;i++){
		int Ki,Si;
		cin>>Ki>>Si;
		double this_Speed, this_Remaining;
		this_Speed=(double) Si;
		this_Remaining=dest_Dist-Ki;
		double this_arrive_time=this_Remaining/this_Speed;

		//cerr<<Ki<<","<<Si<<" this_Remaining="<<this_Remaining<<" this arr="<<this_arrive_time<<endl;

		latest_arrive=max(latest_arrive, this_arrive_time);
	}
		//cerr<<"latest arrive="<<latest_arrive<<endl;

	double max_speed=dest_Dist/latest_arrive;
	cout<<setprecision(10)<<max_speed;

}

int main(){
	int T;
	cin>>T;
	for(int i=0;i<T;i++){
		cout<<"Case #"<<(i+1)<<": ";
		onecase();
		cout<<endl;
	}
	//onecase();
	return 0;
}
