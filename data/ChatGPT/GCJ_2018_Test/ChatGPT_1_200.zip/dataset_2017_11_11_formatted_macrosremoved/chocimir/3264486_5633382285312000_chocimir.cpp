#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>

using namespace std;

const double PI = acos(-1);

void solve(int case_num, double A) {
    double theta = acos(A / sqrt(2));
    double phi = PI / 4 - theta / 2;

    vector<vector<double>> face_centers = {
        {0.5 * cos(phi), 0.5 * sin(phi), 0},
        {-0.5 * sin(phi), 0.5 * cos(phi), 0},
        {0, 0, 0.5}
    };

    cout << "Case #" << case_num << ":" << endl;
    for (const auto &center : face_centers) {
        for (const auto &coordinate : center) {
            cout << fixed << setprecision(10) << coordinate << " ";
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;
        solve(t, A);
    }
    return 0;
}
