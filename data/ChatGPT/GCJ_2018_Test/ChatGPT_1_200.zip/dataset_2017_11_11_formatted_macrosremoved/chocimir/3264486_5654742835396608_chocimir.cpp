#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;


void onecase(){
	int A;
	int map[300][5];
	for(int i=0;i<300;i++)
		for(int j=0;j<5;j++)
		map[i][j]=0;

	cin>>A;

	int R=(A/3)+3+3;
	// we want x=[3..R], y=[2..4] be filled.
	cerr<<"Desired A="<<A<<" planned region 3xR,R="<<R<<endl;
	while(true){
		//decide which one to punch: find min occupied center X
		int minOCC=10, minX=-1;
		for(int x=3;x<=R;x++){
			int occX=map[x][4]+map[x][2]+map[x][3]+
					map[x+1][4]+map[x+1][2]+map[x+1][3]+
					map[x-1][4]+map[x-1][2]+map[x-1][3];
			if(occX<minOCC){
				minOCC=occX;minX=x;
			}
		}
		//cerr<<"minx="<<minX<<" minOCC="<<minOCC<<endl;

		// send to judge, get actual response
		cout<<minX<<" "<<3<<endl<<flush;
		int dx,dy;
		cin>>dx>>dy;
		// mark response to map. if illegal, halt myself. if good, return.
		if(dx==0&&dy==0)return;
		if(dx<0||dy<0 || minOCC==9){
			if(minOCC==9){
						cerr<<"minOCC=9, why not stopped??";
					}
			cerr<<"outputting map..."<<endl;
			for(int i=0;i<R+5;i++)cerr<<(map[i][0]?'*':'-');
			cerr<<endl;
			for(int i=0;i<R+5;i++)cerr<<(map[i][1]?'*':'-');
			cerr<<endl;
			for(int i=0;i<R+5;i++)cerr<<(map[i][2]?'*':'-');
			cerr<<endl;
			for(int i=0;i<R+5;i++)cerr<<(map[i][3]?'*':'-');
			cerr<<endl;
			for(int i=0;i<R+5;i++)cerr<<(map[i][4]?'*':'-');
			cerr<<endl;

			exit(-1);}
		map[dx][dy]=1;
	}

}

int main(){
	int T;
	cin>>T;
	for(int i=0;i<T;i++){
		onecase();
	}// onecase();
	return 0;
}
