#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;


void onecase(){
	int N, O, E;
	vector<int> odds;
	vector<int> evens;
	vector<int> allnums;
	cin>>N;
	for(int i=0;i<N;i++){
		int t;
		cin>>t;
		if(i%2==0)evens.push_back(t);
		else odds.push_back(t);
	}
	sort(evens.begin(),evens.end());
	sort(odds.begin(),odds.end());
	for(int i=0;i<N;i++){
		if(i%2==0)allnums.push_back(evens[i/2]);
		else allnums.push_back(odds[i/2]);
	}
	for(int i=0;i<N-1;i++){
		if(allnums[i]>allnums[i+1]){
			cout<<i;return;
		}
	}
	cout<<"OK";
}

int main(){
	int T;
	cin>>T;
	for(int i=0;i<T;i++){
		cout<<"Case #"<<(i+1)<<": ";
		onecase();
		cout<<endl;
	}// onecase();
	return 0;
}
