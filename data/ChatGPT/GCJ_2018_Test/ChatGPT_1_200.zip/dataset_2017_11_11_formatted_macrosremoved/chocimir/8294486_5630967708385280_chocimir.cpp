#include <iostream>
using namespace std;

void onecase(){
	int A,B,N;
	string str;
	cin>>A>>B>>N;
	cerr<<"guess between..."<<A<<','<<B<<"N="<<N<<endl;

	int M;
	//binary search...
	while(A<B){
		M=(A+B+1)/2;
		cout<<M<<endl<<flush;
		cin>>str;
		if (str=="CORRECT") return;
		if (str=="TOO_SMALL") A=M;
		if (str=="TOO_BIG") B=M-1;
		if (str=="WRONG_ANSWER")  exit(-1);
		cerr<<"continue between..."<<A<<','<<B<<endl;
	}
}

int main(){
	int T;
	cin>>T;
	for(int i=0;i<T;i++)
		onecase();
	return 0;
}
