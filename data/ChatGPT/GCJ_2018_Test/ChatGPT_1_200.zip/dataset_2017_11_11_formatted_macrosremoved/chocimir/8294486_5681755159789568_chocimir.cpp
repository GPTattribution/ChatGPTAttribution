#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void onecase(){
	int N;
	vector<pair<int, char> > remaining;
	cin>>N;
	for(int i=0;i<N;i++){
		char Party='A'+i;
		int Num;
		cin>>Num;
		remaining.push_back(make_pair(Num, Party));
	}
	sort(remaining.begin(),remaining.end());
	reverse(remaining.begin(),remaining.end());


	for(int i=0;i<N;i++){
		//cerr<<"entry #"<<i<<": party="<<remaining[i].second<<" num="<<remaining[i].first<<endl;
	}

	// first: make sure #1 is equal to #2
	while(remaining[0].first>remaining[1].first){
		cout<<remaining[0].second<<" ";
		remaining[0].first--;
	}
	// then, make sure no one is at tail
	for(int i=2;i<remaining.size();i++){
		while(remaining[i].first>0){
			cout<<remaining[i].second<<" ";
			remaining[i].first--;
		}
	}
	// finally, exit together
	while(remaining[0].first>0){
		cout<<remaining[0].second<<remaining[1].second<<" ";
		remaining[0].first--;
		remaining[1].first--;
	}

}

int main(){
	int T;
	cin>>T;
	for(int i=0;i<T;i++){
		cout<<"Case #"<<(i+1)<<": ";
		onecase();
		cout<<endl;
	}
	//	onecase();
	return 0;
}
