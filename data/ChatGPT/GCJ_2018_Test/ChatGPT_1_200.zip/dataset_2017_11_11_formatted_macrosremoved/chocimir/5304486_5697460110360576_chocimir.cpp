#include <iostream>
#include <string>
using namespace std;

int damage(string seq){
	int total=0, scale=1;
	for(int i=0;i<seq.length();i++){
		if(seq[i]=='S') total+=scale;
		if(seq[i]=='C') scale*=2;
	}
	return total;
}

pair<bool, string> change(string seq){
	string res=seq;
	for(int i=seq.length()-1;i>0;i--){
		if(seq[i]=='S' && seq[i-1]=='C'){
			//found! swap it...
			res[i]='C';
			res[i-1]='S';
			return make_pair(true, res);
		}
	}
	return make_pair(false,seq);
}

void onecase(){
	int D; string seq;
	cin>>D>>seq;
	int count_change=0;
	while(damage(seq)>D){
		//do change
		pair<bool, string> ret=change(seq);
		count_change++;
		if(ret.first==false){
			cout<<"IMPOSSIBLE";
			return;
		}
		seq=ret.second;
	}
	//output length
	cout<<count_change;
}

int main(){
	int T;
	cin>>T;
	for(int i=0;i<T;i++){
		cout<<"Case #"<<(i+1)<<": ";
		onecase();
		cout<<endl;
	}
		//onecase();
	return 0;
}
