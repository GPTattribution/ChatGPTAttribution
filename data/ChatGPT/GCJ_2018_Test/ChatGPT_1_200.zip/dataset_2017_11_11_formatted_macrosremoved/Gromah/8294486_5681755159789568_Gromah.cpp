
#include <stdio.h>
#include <iostream>
#include <vector>

int main()
{
    int T = 0;
    std::cin >> T;
    for (int test = 0; test < T; ++ test) {
        int N;
        std::cin >> N;
        std::vector<int> P(N,0);
        int sum = 0;
        for (int iP = 0; iP < N; iP++) {
            std::cin >> P[iP];
            sum += P[iP];
        }

        std::string result;
        int iFirst(0), iSecond(0);
        while (iFirst < N) {
            for (;iFirst < N && P[iFirst]==0; iFirst++);
            if (iFirst == N) break;
            std::string sFirst(1, (char)((int)'A' + iFirst));
            for (iSecond = iFirst+1;iSecond < N && P[iSecond]==0; iSecond++);
            if (iSecond == N) {
                for (; P[iFirst] > 1; P[iFirst] -= 2) {
                    result = sFirst + sFirst + ' ' + result;
                }
                if (P[iFirst] == 1) result = sFirst + ' ' + result;
                break;
            }
            else {
                std::string sSecond(1, (char)((int)'A' + iSecond));
                int minP = std::min(P[iFirst], P[iSecond]);
                for (int i = 0; i < minP; ++i) {
                    result = sFirst + sSecond + ' ' + result;
                }
                P[iFirst] -= minP;
                P[iSecond] -= minP;
            }
        }

        std::cout << "Case #" << test+1 << ": " << result << std::endl;
    }
    return 0;
}
