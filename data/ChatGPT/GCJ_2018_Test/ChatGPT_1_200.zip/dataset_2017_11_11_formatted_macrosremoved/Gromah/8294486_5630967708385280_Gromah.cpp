
#include <stdio.h>
#include <iostream>
#include <vector>

int main()
{
    std::cout.precision(6);
    std::cout << std::fixed << std::showpoint;
    int T = 0;
    std::cin >> T;
    for (int test = 0; test < T; ++ test) {
        unsigned long long D, N;
        std::cin >> D >> N;
        double time = 0;
        for (int horse = 0; horse < N; ++horse) {
            unsigned long long K, S;
            std::cin >> K >> S;
            double iTime = double(D-K) / S;
            time = std::max(time, iTime);
        }

        std::string result;
        std::cout << "Case #" << test+1 << ": " << double(D/time) << std::endl;
    }
    return 0;
}
