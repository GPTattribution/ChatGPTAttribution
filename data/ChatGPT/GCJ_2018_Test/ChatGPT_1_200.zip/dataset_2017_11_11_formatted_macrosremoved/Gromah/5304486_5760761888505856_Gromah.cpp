
#include <stdio.h>
#include <iostream>
#include <vector>
#include <math.h>
#include <cmath>

int main()
{
    int T = 0;
    std::cin >> T;
    for (int test = 0; test < T; ++ test) {
        unsigned long long N, K;
        std::cin >> N >> K;

        unsigned long long sizeMinN(0), sizeN(1);
        unsigned long long g = 1;
        unsigned long long minN = N;
            unsigned long long addMin(0), addMax(0);
        while (true) {
            sizeMinN += addMin;
            sizeN += addMax;

            g *= 2;
            if (K < g) break;

            addMin = 0;
            addMax = 0;
            if ((minN-1)%2 == 0) addMin += sizeMinN;
            else addMax += sizeMinN;
            minN = (minN-1) / 2;

            if ((N-1)%2 == 0) addMax += sizeN;
            else addMin += sizeN;
            N = (N-1) / 2 + (N-1)%2;

            /*if ((N-1)%2 == 0) {
                N = minN;
                addMax += sizeN;
            }
            else {
                N = minN + 1;
                addMin += sizeN;
            }*/
        }
        if ((K - g/2) >= sizeN) N = minN;
        std::cout << "Case #" << test+1 << ": " << (N-1) / 2 + (N-1)%2 << " " << (N-1) / 2 << std::endl;
    }
    return 0;
}
