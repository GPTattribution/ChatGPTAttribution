
#include <stdio.h>
#include <iostream>
#include <vector>
#include <math.h>
#include <cmath>

unsigned long long notSorted(std::vector<unsigned long long>& vec) {
    for (int i = 1; i < vec.size(); ++i){
        if (vec[i] < vec[i-1]){
            return i-1;
        }
    }
    return -1;
}

int main()
{
    int T = 0;
    std::cin >> T;
    for (int test = 0; test < T; ++ test) {
        unsigned long long N;
        std::cin >> N;

        std::vector<unsigned long long> V(N, 1);
        for (int i = 0; i < N; ++i) std::cin >> V[i];

        while (true) {
            bool same = true;
            for (int i = 0; i < N-2; ++i) {
                if (V[i] > V[i+2]) {
                    std::swap(V[i], V[i+2]);
                    same = false;
                }
            }
            if (same) break;
        }

        long long result = notSorted(V);

        std::cout << "Case #" << test+1 << ": ";
        if (result != -1) std::cout << result << std::endl;
        else std::cout << "OK\n";
    }
    return 0;
}
