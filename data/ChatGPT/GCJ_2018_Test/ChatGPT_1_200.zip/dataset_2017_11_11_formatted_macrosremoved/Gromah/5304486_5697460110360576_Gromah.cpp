
#include <stdio.h>
#include <iostream>
#include <vector>
#include <math.h>
#include <cmath>

int main()
{
    int T = 0;
    std::cin >> T;
    for (int test = 0; test < T; ++ test) {
        unsigned long long D;
        std::string P;
        std::cin >> D >> P;

        unsigned long long damage = 0;
        std::vector<unsigned long long> strike(P.size()+1, 1);
        for (int i = 0; i < P.size(); ++i) {
            strike[i+1] = strike[i];
            if (P[i] == 'S') damage += strike[i];
            else strike[i+1] *= 2;
        }

        long long result = 0;
        while (damage > D) {
            bool same = true;
            for (int i = P.size()-1; i > 0; --i) {
                if (P[i] == 'S' && P[i-1] == 'C') {
                    same = false;
                    result++;
                    damage -= strike[i-1];
                    strike[i] = strike[i-1];
                    P[i] = 'C';
                    P[i-1] = 'S';
                    break;
                }
            }
            if (same) {
                result = -1;
                break;
            }
        }

        std::cout << "Case #" << test+1 << ": ";
        if (result != -1) std::cout << result << std::endl;
        else std::cout << "IMPOSSIBLE\n";
    }
    return 0;
}
