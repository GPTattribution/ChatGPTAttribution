
#include <stdio.h>
#include <iostream>
#include <vector>
#include <array>
#include <math.h>
#include <cmath>

int main()
{
    //std::cout.precision(15);
    //std::cout << std::scientific << std::showpoint;

    int T = 0;
    std::cin >> T;
    for (int test = 0; test < T; ++ test) {
        int A;
        std::cin >> A;

        int last = int(std::ceil(A/3.)) - 1;
        std::vector<std::vector<bool>> mask(last + 1, std::vector<bool>(3, false));

        int tI(-1), tJ;
        for (int i = 1; i < last; ++i) {
            while (true) {
                if (mask[i-1][0] && mask[i-1][1] && mask[i-1][2]){
                    break;
                }
                std::cout << i+1 << " " << 2 << std::endl;
                std::cin >> tI >> tJ;
                if (tI == 0 || tI == -1) break;
                mask[tI-1][tJ-1] = true;
            }
            if (tI == 0 || tI == -1) break;
        }
        while (tI > 0) {
            std::cout << last << " " << 2;
            std::cin >> tI >> tJ;
            //if (tI == 0) break;
            //mask[tI-1][tJ-1] = true;
        }
    }
    return 0;
}
