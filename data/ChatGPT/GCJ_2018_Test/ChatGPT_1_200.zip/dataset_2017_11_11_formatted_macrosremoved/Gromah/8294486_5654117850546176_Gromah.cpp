
#include <stdio.h>
#include <iostream>

int main()
{
    int T = 0;
    std::cin >> T;
    for (int test = 0; test < T; ++ test) {
        unsigned long long A, B, N;
        std::cin >> A >> B;
        std::cin >> N;

        A++;
        for (int iN = 0; iN < N; ++iN) {
            int mid = (A+B)/2;
            std::cout << mid << std::endl;
            std::string ans;
            std::cin >> ans;
            if (ans == "CORRECT") {
                break;
            }
            else if (ans == "TOO_SMALL") {
                A = mid+1;
            }
            else if (ans == "TOO_BIG") {
                B = mid-1;
            }
            else break;
        }
    }
    return 0;
}
