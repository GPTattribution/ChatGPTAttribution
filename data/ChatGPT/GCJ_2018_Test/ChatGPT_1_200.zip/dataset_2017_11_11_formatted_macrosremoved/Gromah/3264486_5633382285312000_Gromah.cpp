#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPS = 1e-6;
const double PI = 3.14159265358979323846;

vector<vector<double>> rotate_ship(double A) {
    double theta = asin(A / sqrt(2));
    double cos_theta = cos(theta);
    double sin_theta = sin(theta);

    return {
        {0.5 * cos_theta, 0.5 * sin_theta, 0},
        {-0.5 * sin_theta, 0.5 * cos_theta, 0},
        {0, 0, 0.5}
    };
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(15);
    for (int t = 1; t <= T; ++t) {
        cin >> A;
        vector<vector<double>> face_centers = rotate_ship(A);

        cout << "Case #" << t << ":" << endl;
        for (const auto &face_center : face_centers) {
            for (double coord : face_center) {
                cout << coord << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
