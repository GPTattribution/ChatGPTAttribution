#include <iostream>
#include <vector>
#include <queue>
#include <deque>
#include <utility>
#include <cmath>
#include <list>
#include <string>
#include <fstream>
#define mp make_pair
#define pb push_back

using namespace std;

int main()
{
	int q;
	cin >> q;
	long long dou[61];
	long long pow = 2;
	dou[0] = 1;
	for (int i = 1; i < 61; i++)
	{
		dou[i] = pow;
		pow *= 2;
	}
	for (int w = 0; w < q; w++)
	{
		cout << "Case #" << w + 1 << ": ";
		long long a, b, k = 1;
		cin >> a >> b;
		int al = 0, bl = 0;
		while (dou[al+1]-1 < a)
			al++;
		//al--;
		while (dou[bl+1]-1 < b)
			bl++;
		//bl--;
		if (b > dou[al]-1)
		{
			cout << 0 << ' ' << 0 << endl;
			continue;
		}
		long long lastl = a - dou[al]+1;
		long long res = dou[al - bl] - 1 + lastl / dou[bl] + (lastl % dou[bl] >= (b - dou[bl] + 1));
		cout << res / 2 << ' ' << res / 2 + (res % 2) - 1 << endl;
	}
	return 0;
}
