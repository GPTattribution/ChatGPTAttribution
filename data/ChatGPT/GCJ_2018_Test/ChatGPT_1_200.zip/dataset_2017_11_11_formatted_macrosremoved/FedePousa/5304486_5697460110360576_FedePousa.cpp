#include <iostream>
#include <map>
#include <vector>
#include <queue>
#include <functional>
#include <algorithm>
#include <cmath>
#include <string>
#include <set>
#define mp make_pair
#define pb push_back

using namespace std;

int solve() {
	long long d;
	string s;
	cin >> d >> s;
	long long sum = 0, cur = 1;
	priority_queue<long long> q;
	for (int i = 0; i<s.size(); ++i) {
		if (s[i] == 'C') {
			cur = cur << 1;
		}
		else {
			sum += cur;
			if (cur > 1) {
				q.push(cur);
			}
		}
	}
	int count = 0;
	while (sum > d && !q.empty()) {
		long long was = q.top();
		q.pop();
		long long now = was >> 1;
		sum -= (was - now);
		if (now > 1) {
			q.push(now);
		}
		count++;
	}

	if (sum <= d) {
		printf("%d\n", count);
	}
	else {
		printf("IMPOSSIBLE\n");
	}
}

int main()
{
	int t;
	scanf("%d", &t);
	for (int i = 0; i<t; ++i) {
		printf("CASE #%d: ", i + 1);
		solve();
	}
	return 0;
}
