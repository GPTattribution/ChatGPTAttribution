#include <iostream>
#include <map>
#include <vector>
#include <queue>
#include <functional>
#include <algorithm>
#include <cmath>
#include <string>
#include <set>
#define mp make_pair
#define pb push_back

using namespace std;

int solve() {
	int n;
	scanf("%d", &n);
	vector<int> a(n);
	vector<int> ord;
	int low = 1001;
	for (int i = 0; i<n; ++i) {
		scanf("%d", &a[i]);
		low = min(low, a[i]);
		ord.pb(i);
	}

	auto cmp = [&a](int x, int y) {
		return a[x] > a[y];
	};

	sort(ord.begin(), ord.end(), cmp);
	while (a[ord[0]] > low) {
		printf("%c ", 'A' + ord[0]);
		a[ord[0]]--;
		sort(ord.begin(), ord.end(), cmp);
	}

	for (int i = 2; i<n; ++i) {
		while (a[i] > 0) {
			if (a[i] > 1) {
				printf("%c%c ", 'A' + i, 'A' + i);
				a[i]-=2;
			}
			else {
				printf("%c ", 'A' + i);
				a[i]--;
			}
		}
	}

	for (int i = 0; i<low; ++i) {
		printf("AB ");
	}
	printf("\n");
}

int main()
{
	int t;
	scanf("%d", &t);
	for (int i = 0; i<t; ++i) {
		printf("Case #%d: ", i + 1);
		solve();
	}
	return 0;
}
