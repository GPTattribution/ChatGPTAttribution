#include <iostream>
#include <map>
#include <vector>
#include <queue>
#include <functional>
#include <algorithm>
#include <cmath>
#include <string>
#include <set>
#define mp make_pair
#define pb push_back

using namespace std;

int solve() {
	int n;
	scanf("%d", &n);
	vector<long long> v(n);
	for (int i = 0; i<n; ++i) {
		scanf("%lld", &v[i]);
	}
	while (1) {
		bool f = 1;
		for (int i = 0; i<n-2; ++i) {
			if (v[i] > v[i+2]) {
				f = 0;
				swap(v[i], v[i+2]);
			}
		}
		if (f) {
			break;
		}
	}
	int p = -1;
	for (int i = 0; i<n-1; ++i) {
		if (v[i] > v[i+1]) {
			p = i;
			break;
		}
	}

	if (p == -1) {
		printf("OK\n");
	}
	else {
		printf("%d\n", p);
	}
}

int main()
{
	int t;
	scanf("%d", &t);
	for (int i = 0; i<t; ++i) {
		printf("CASE #%d: ", i + 1);
		solve();
	}
	return 0;
}
