#include <iostream>
#include <map>
#include <vector>
#include <queue>
#include <functional>
#include <algorithm>
#include <cmath>
#include <string>
#include <set>
#define mp make_pair
#define pb push_back

using namespace std;

int solve() {
	long long a, b;
	scanf("%lld %lld", &a, &b);
	int n;
	scanf("%d", &n);
	while (b - a > 1) {
		long long mid = (a+b)/2;
		printf("%lld\n", mid);
		fflush(stdout);
		string s;
		cin >> s;
		if (s == "CORRECT")
			return 0;
		if (s == "TOO_BIG") {
			b = mid;
		}
		else {
			a = mid;
		}
	}
	printf("%lld\n", b);
	fflush(stdout);
	string s;
	cin >> s;
}

int main()
{
	int t;
	scanf("%d", &t);
	for (int i = 0; i<t; ++i) {
		solve();
	}
	return 0;
}
