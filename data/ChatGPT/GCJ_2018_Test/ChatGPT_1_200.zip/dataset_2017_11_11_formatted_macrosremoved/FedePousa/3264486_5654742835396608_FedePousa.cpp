#include <iostream>
#include <map>
#include <vector>
#include <queue>
#include <functional>
#include <algorithm>
#include <cmath>
#include <string>
#include <set>
#define mp make_pair
#define pb push_back

using namespace std;

int dx[9] = {1, 1, 1, 0, 0, 0, -1, -1, -1};
int dy[9] = {-1, 0, 1, -1, 0, 1, -1, 0, 1};

int solve() {
	int n;
	int board[1001][1001];
	for (int i = 0; i<1001; ++i) {
		for (int j = 0; j<1001; ++j) {
			board[i][j] = 0;
		}
	}
	scanf("%d", &n);
	int curx = 2, cury = 2;
	int a = 1, b = 1;
	while (a != 0 && b != 0) {
		bool f = 1;
		for (int i = 0; i<9; ++i) {
			if (board[curx + dx[i]][cury + dy[i]] == 0) {
				f = 0;
			}
		}
		if (f) {
			curx += 3;
			if (curx == 98) {
				curx = 2;
				cury += 3;
			}
		}
		printf("%d %d\n", curx, cury);
		fflush(stdout);
		scanf("%d %d", &a, &b);
		board[a][b] = 1;
	}
}

int main()
{
	int t;
	scanf("%d", &t);
	for (int i = 0; i<t; ++i) {
		solve();
	}
	return 0;
}
