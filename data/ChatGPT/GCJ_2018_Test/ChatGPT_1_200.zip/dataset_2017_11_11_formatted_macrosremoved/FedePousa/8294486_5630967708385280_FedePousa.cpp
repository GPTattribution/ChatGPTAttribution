#include <iostream>
#include <map>
#include <vector>
#include <queue>
#include <functional>
#include <algorithm>
#include <cmath>
#include <string>
#include <set>
#define mp make_pair
#define pb push_back

using namespace std;

const long long MAX = 1e9 + 1;

int solve() {
	long long d;
	int n;
	scanf("%lld %d", &d, &n);
	vector<pair<long long, int>> v;
	for (int i = 0; i<n; ++i) {
		long long k;
		int s;
		scanf("%lld %d", &k, &s);
		v.pb(mp(k,s));
	}

	auto cmp = [](pair<long long, int> x , pair<long long, int> y) {
		return x.first > y.first;
	};

	sort(v.begin(), v.end(), cmp);

	double maxtime = 0;
	for (int i = 0; i<n; ++i) {
		pair<long long, int> cur = v[i];
		double t = (d - cur.first)*1.0/cur.second;
		maxtime = max(maxtime, t);
	}

	double res = 1.0*d/maxtime;
	printf("%.10f\n", res);
}

int main()
{
	int t;
	scanf("%d", &t);
	for (int i = 0; i<t; ++i) {
		printf("Case #%d: ", i + 1);
		solve();
	}
	return 0;
}
