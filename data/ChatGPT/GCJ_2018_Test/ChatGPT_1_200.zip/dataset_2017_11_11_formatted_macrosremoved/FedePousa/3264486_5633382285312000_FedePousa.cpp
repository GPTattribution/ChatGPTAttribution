#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

const double EPS = 1e-6;

void solve(int case_num, double A) {
    double phi = acos(A / sqrt(2.0)) / 2.0;
    double x1 = 0.5 * cos(phi);
    double z1 = 0.5 * sin(phi);
    double x2 = -z1;
    double z2 = x1;

    cout << "Case #" << case_num << ":" << endl;
    cout << fixed << setprecision(15) << x1 << " 0 " << z1 << endl;
    cout << x2 << " 0 " << z2 << endl;
    cout << "0 0 0.5" << endl;
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        double A;
        cin >> A;
        solve(i, A);
    }

    return 0;
}
