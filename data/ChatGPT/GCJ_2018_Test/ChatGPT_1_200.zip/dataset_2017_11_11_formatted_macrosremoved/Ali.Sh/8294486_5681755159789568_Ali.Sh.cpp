//TAG :
#include<bits/stdc++.h>
using namespace std;
#define rep(i,n)	for(int (i)=0;(i)<(n);(i)++)
#define repd(i,n)	for(int (i)=(n)-1;(i)>=0;(i)--)
#define REP(i,j,n)  for(int (i)=(j),_n=(n);(i)<_n;(i)++)
#define FOR(i,a,b)  for(int (i)=(a),_b=(b);(i)<=_b;(i)++)
#define FORD(i,a,b) for(int (i)=(a),_b=(b);(i)>=_b;(i)--)
#define ALL(c) (c).begin(),(c).end()
#define SORT(c) sort(ALL(c))
#define CLEAR(x) memset((x),0,sizeof(x))
#define ff first
#define ss second
#define MP make_pair
typedef pair<int, int>	pii;
typedef vector<pii>	vii;
typedef vector<int>	vi;
typedef long long		ll;
template<typename T> void cmax(T& a, T b) { if (a < b) a = b; }
template<typename T> void cmin(T& a, T b) { if (a > b) a = b; }
#ifdef _MSC_VER
#include "builtin_gcc_msvc.h"
#define gets	gets_s
#else
#define popcnt(x)	__builtin_popcount(x)
#define ctz(x)		__builtin_ctz(x)
#define clz(x)		__builtin_clz(x)
#define popcntll(x)	__builtin_popcountll(x)
#define ctzll(x)	__builtin_ctzll(x)
#define clzll(x)	__builtin_clzll(x)
#endif

int n,A[26];
int main()
{
	int TC;
	scanf("%d", &TC);
	FOR(T, 1, TC)
	{
		int n; scanf("%d", &n);
		CLEAR(A);
		rep(i, n)scanf("%d", &A[i]);
		printf("Case #%d:", T);
		int sum = accumulate(A, A + n, 0);
		while (sum > 0) {
			int best = 0, check = 0;
			rep(i, n) {
				if (best < A[i]) {
					best = A[i];
					check = 1 << i;
				} else if(best==A[i]){
					check |= 1 << i;
				}
			}
			if (popcnt(check) & 1) {
				int j = ctz(check);
				--A[j];
				--sum;
				printf(" %c", 'A' + j);
			} else {
				int j = ctz(check);
				check &= check - 1;
				int k = ctz(check);
				--A[j], --A[k];
				sum -= 2;
				printf(" %c%c", 'A' + j, 'A' + k);
			}
		}
		puts("");
	}

	return 0;
}
