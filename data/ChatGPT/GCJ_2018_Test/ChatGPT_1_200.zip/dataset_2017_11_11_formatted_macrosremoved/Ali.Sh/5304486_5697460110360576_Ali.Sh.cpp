//TAG :
#include<bits/stdc++.h>
using namespace std;
#define rep(i,n)	for(int (i)=0;(i)<(n);(i)++)
#define repd(i,n)	for(int (i)=(n)-1;(i)>=0;(i)--)
#define REP(i,j,n)  for(int (i)=(j),_n=(n);(i)<_n;(i)++)
#define FOR(i,a,b)  for(int (i)=(a),_b=(b);(i)<=_b;(i)++)
#define FORD(i,a,b) for(int (i)=(a),_b=(b);(i)>=_b;(i)--)
#define ALL(c) (c).begin(),(c).end()
#define SORT(c) sort(ALL(c))
#define CLEAR(x) memset((x),0,sizeof(x))
#define ff first
#define ss second
#define MP make_pair
typedef pair<int, int>	pii;
typedef vector<pii>	vii;
typedef vector<int>	vi;
typedef long long		ll;
template<typename T> void cmax(T& a, T b) { if (a < b) a = b; }
template<typename T> void cmin(T& a, T b) { if (a > b) a = b; }
#ifdef _MSC_VER
#include "builtin_gcc_msvc.h"
#define gets	gets_s
#else
#define popcnt(x)	__builtin_popcount(x)
#define ctz(x)		__builtin_ctz(x)
#define clz(x)		__builtin_clz(x)
#define popcntll(x)	__builtin_popcountll(x)
#define ctzll(x)	__builtin_ctzll(x)
#define clzll(x)	__builtin_clzll(x)
#endif

int main()
{
	int TC;cin>>TC;
	FOR(T, 1, TC)
	{
		int D;string P;
		cin>>D>>P;
		printf("Case #%d: ",T);
		if(count(P.begin(),P.end(),'S')>D)
			puts("IMPOSSIBLE");
		else{
			queue<pair<int,string>> q;
			int ans=-1;
			q.emplace(0,P);
			while(!q.empty()){
				int d;string p;tie(d,p)=q.front();q.pop();
				int a=1,b=0;
				for(char c:p){
					if(c=='S')b+=a;
					else if(c=='C')a*=2;
				}
				if(b<=D){ans=d;break;}
				REP(i,1,p.size())if(p[i-1]=='C'&&p[i]=='S'){
					string pp=p;
					swap(pp[i-1],pp[i]);
					q.emplace(d+1,pp);
				}
			}
			printf("%d\n",ans);
		}
	}

	return 0;
}
