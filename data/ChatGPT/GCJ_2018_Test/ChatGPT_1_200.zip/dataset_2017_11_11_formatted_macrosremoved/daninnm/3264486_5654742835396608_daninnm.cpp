#include <cstdlib>
#include <cmath>
#include <climits>
#include <cfloat>
#include <map>
#include <utility>
#include <set>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <sstream>
#include <deque>
#include <complex>
#include <stack>
#include <queue>
#include <cstdio>
#include <cctype>
#include <cstring>
#include <ctime>
#include <iterator>
#include <bitset>
#include <numeric>
#include <list>
#include <iomanip>
#include <cassert>

#if __cplusplus >= 201103L
#include <array>
#include <tuple>
#include <initializer_list>
#include <unordered_set>
#include <unordered_map>
#include <forward_list>

#define cauto const auto&
#endif

using namespace std;


namespace{

typedef long long LL;
typedef pair<int,int> pii;
typedef pair<LL,LL> pll;

typedef vector<int> vint;
typedef vector<vector<int> > vvint;
typedef vector<long long> vll, vLL;
typedef vector<vector<long long> > vvll, vvLL;

#define VV(T) vector<vector< T > >

template <class T, class U=T>
void initvv(vector<vector<T> > &v, int a, int b, const U &t = U()){
	v.assign(a, vector<T>(b, t));
}
template <class T> inline T &chmin(T &x, const T &y){ return x = min(x, y); }
template <class T> inline T &chmax(T &x, const T &y){ return x = max(x, y); }
template <class F, class T>
void convert(const F &f, T &t){
	stringstream ss;
	ss << f;
	ss >> t;
}

template <class Con>
string concat(const Con &c, string spl){
	stringstream ss;
	typename Con::const_iterator it = c.begin(), en = c.end();
	bool fst = true;
	for(; it != en; ++it){
		if(!fst){ ss << spl; }
		fst = false;
		ss << *it;
	}
	return ss.str();
}


#define REP(i,n) for(int i=0;i<int(n);++i)
#define ALL(v) (v).begin(),(v).end()
#define RALL(v) (v).rbegin(),(v).rend()
#define PB push_back


#define MOD 1000000007LL
#define EPS 1e-8


void prepare(){
//	ios::sync_with_stdio(false);

}

pii query(int y, int x){
	cout << y << ' ' << x << endl;
	int i, j;
	cin >> i >> j;
	return pii(i, j);
}


void solve(){
	int a;
	cin >> a;
	VV(char) state;
	int xmax = (a + 2) / 3;
	initvv(state, 3, xmax + 10);
	int x = 1;
	int cnt = 0;
	while(1){
		int c = 0;
		for(int i = 0; i < 3; ++i)
		for(int j = -1; j < 2; ++j){
			c += state[i][x + j];
		}
		if(c < 9){
			pii p = query(2, x + 1);
			if(p.first < 0){ abort(); }
			if(p.first == 0){ break; }
			state[p.first - 1][p.second - 1] = 1;
			++cnt;
		}

		++x;
		if(x == xmax){ x = 1; }
	}
	cerr << "a: " << a << ", cnt: " << cnt << endl;
}


}
int main(){
	cout << fixed << setprecision(15);
	cerr << fixed << setprecision(6);
	prepare();

	string str = "_";
	getline(cin, str);
	int T = strtol(str.c_str(), 0, 10);
	for(int cnum = 1; cnum <= T; ++cnum){
		fprintf(stderr, "%4d / %d\n", cnum, T);
		solve();
	}
}
