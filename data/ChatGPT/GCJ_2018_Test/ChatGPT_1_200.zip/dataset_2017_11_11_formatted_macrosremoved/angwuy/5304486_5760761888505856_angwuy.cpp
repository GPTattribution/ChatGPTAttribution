// Google Code Jam 2018, Practice Session - problem 4
// "Bathroom Stalls"
// Andras Eles, Veszprem, Hungary, 2018.04.01.
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

class WrongAnswer {};
typedef unsigned long long int ull;

int T;

void solInterval (ull size)
{
	cout << ((size + 0) >> 1) << " " << ((size - 1) / 2) << endl;
}

void solveProblem (void)
{
	ull N, K;
	cin >> N >> K;
	ull A = N, cnt = 1, cntp1 = 0;
	do {
		if (K <= cnt + cntp1)
		{
			if (K <= cntp1)
			{
				solInterval(A + 1);
			}
			else
			{
				solInterval(A);
			}
			break;
		}
		K -= (cnt + cntp1);
		ull cntnext = cnt;
		ull cntp1next = cntp1;
		((A / 2 == (A - 1) / 2) ? cntnext : cntp1next) += (cnt + cntp1);
		cnt = cntnext;
		cntp1 = cntp1next;
		A =  (A - 1) / 2;
	}
	while (true);
}

int main (int argc, char** argv)
{
	try {
		cin >> T;
		for (int t=1;t<=T;++t)
		{
			cout << "Case #" << t << ": " << flush;
			solveProblem();
		}
	}
	catch (WrongAnswer const& wa)
	{
	}
	return 0;
}
