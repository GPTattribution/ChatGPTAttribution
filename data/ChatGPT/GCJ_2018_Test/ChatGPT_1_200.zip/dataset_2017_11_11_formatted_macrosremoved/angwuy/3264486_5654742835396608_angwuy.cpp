// Google Code Jam 2018, Qualification - problem 3
// "Go, Gopher!"
// Andras Eles, Veszprem, Hungary, 2018.04.07.
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <cstring>
#include <cstdlib>
using namespace std;

bool const INVESTIGATE = false;

class WrongAnswer {};
class TestCaseDone {};
int T;

struct Mat
{
public:
	char* _board;
	int A;
	int done;
	int xmin, xmax, ymin, ymax;
	int side;
	int attacks;
public:
	Mat (void)
	{
		_board = new char [1100000];
	}
	~Mat (void)
	{
		delete [] _board;
	}
public:
	char& pos (int x, int y)
	{
		return _board[1000 * x + y];
	}
	char pos (int x, int y) const
	{
		return _board[1000 * x + y];
	}
	void setPos (int x, int y)
	{
		if (!pos(x,y))
		{
			done++;
			pos(x,y) = 1;
			if (xmin > x)
			{
				xmin = x;
			}
			if (xmax < x)
			{
				xmax = x;
			}
			if (ymin > y)
			{
				ymin = y;
			}
			if (ymax < y)
			{
				ymax = y;
			}
		}
	}
	bool isRectangle (void) const
	{
		return (xmax - xmin + 1) * (ymax - ymin + 1) == done;
	}
	bool isReady (void) const
	{
		return isRectangle() && done >= A;
	}
	void shootPos (int x, int y, int& xs, int& ys)
	{
		attacks++;
		if (INVESTIGATE)
		{
			xs = x - 1 + rand() % 3;
			ys = y - 1 + rand() % 3;
		}
		else
		{
			cout << x << " " << y << endl;
			cin >> xs >> ys;
		}
		if (xs == 0 || ys == 0)
		{
			throw TestCaseDone();
		}
		else if (xs == -1 && ys == -1)
		{
			throw WrongAnswer();
		}
		setPos(xs,ys);
		// cout << "atk " << x << " " << y << " " << xs << " " << ys << endl;
		if (INVESTIGATE && isReady())
		{
			throw TestCaseDone();
		}
	}
	void setInstance (int A, int side)
	{
		attacks = 0;
		this->A = A;
		done = 0;
		memset(_board,0,1100000*sizeof(char));
		xmin = ymin = 1001;
		xmax = ymax = 0;
		this->side = side;
	}
	void solveInstance (void)
	{
		int x0, y0;
		shootPos(10,10,x0,y0);
		int const height = (A + side - 1) / side;
		do {
			int y=0, x=0;
			do {
				if (pos(x+x0,y+y0))
				{
					x++;
					if (x == side)
					{
						x = 0;
						y++;
					}
				}
				else
				{
					break;
				}
			}
			while (true);
			x++;
			y++;
			if (x >= side - 1)
			{
				x = side - 2;
			}
			if (y >= height - 1)
			{
				y = height - 2;
			}
			int dummyX, dummyY;
			shootPos(x+x0,y+y0,dummyX,dummyY);
		}
		while (true);
	}
};

void solveProblem (Mat& M)
{
	int A;
	cin >> A;
	M.setInstance(A,3);
	M.solveInstance();
}

int main (int, char**)
{
	if (INVESTIGATE)
	{
		Mat M;
		int minAttacks = 1000000;
		int maxAttacks = 0;
		int sumAttacks = 0;
		int const casenum = 1000;
		for (int i=0;i<casenum;i++)
		{
			srand(i);
			M.setInstance(200,3);
			try {
				M.solveInstance();
			}
			catch (TestCaseDone const& tcd)
			{
			}
			cout << "\t" << M.attacks << " " << M.xmin << " " << M.xmax << " " << M.ymin << " " << M.ymax << endl;
			if (minAttacks > M.attacks)
			{
				minAttacks = M.attacks;
			}
			if (maxAttacks < M.attacks)
			{
				maxAttacks = M.attacks;
			}
			sumAttacks += M.attacks;
		}
		cout << minAttacks << " " << maxAttacks << " " << sumAttacks / casenum << endl;
		return 0;
	}
	try {
		cin >> T;
		for (int t=1;t<=T;++t)
		{
			Mat mat;
			try {
				solveProblem(mat);
			}
			catch (TestCaseDone const& tcd)
			{
			}
		}
	}
	catch (WrongAnswer const& wa)
	{
	}
	return 0;
}
