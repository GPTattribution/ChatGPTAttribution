// Google Code Jam 2018, Qualification - problem 1
// "Saving The Universe Again"
// Andras Eles, Veszprem, Hungary, 2018.04.07.
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
using namespace std;

class WrongAnswer {};
typedef long long int lli;
int T;

void solveProblem (void)
{
	lli D;
	string P;
	cin >> D >> P;
	lli atk[100], acount, shots;
	{
		acount = 0;
		shots = 0;
		atk[0] = 0;
		for (unsigned i=0;i<P.size();++i)
		{
			if (P[i] == 'S')
			{
				shots++;
				atk[acount]++;
			}
			else if (P[i] == 'C')
			{
				acount++;
				atk[acount] = 0;
			}
		}
		while (acount >= 0 && !atk[acount])
		{
			acount--;
		}
		if (acount == (-1))
		{
			cout << 0;
			return;
		}
		if (D < shots)
		{
			cout << "IMPOSSIBLE";
			return;
		}
		acount++;
	}
	{
		lli presum = 0;
		lli pwat = 0;
		lli last = shots;
		do {
			presum += atk[pwat] * (1 << pwat);
			last -= atk[pwat];
			pwat++;
			lli const estimate = presum + (1 << pwat) * last;
			if (estimate > D)
			{
				lli steps = (estimate - D + (1 << (pwat - 1)) - 1) / (1 << (pwat - 1));
				for (int i=pwat;i<acount;i++)
				{
					steps += (i - pwat) * atk[i];
				}
				cout << steps;
				return;
			}
			if (pwat == acount)
			{
				cout << 0;
				return;
			}
		}
		while (true);
	}
}

int main (int, char**)
{
	try {
		cin >> T;
		for (int t=1;t<=T;++t)
		{
			cout << "Case #" << t << ": " << flush;
			solveProblem();
			cout << endl;
		}
	}
	catch (WrongAnswer const& wa)
	{
	}
	return 0;
}
