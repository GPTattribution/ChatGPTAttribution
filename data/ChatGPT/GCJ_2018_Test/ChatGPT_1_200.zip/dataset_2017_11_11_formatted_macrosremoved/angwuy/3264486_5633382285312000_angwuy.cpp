#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

const double EPS = 1e-9;

vector<vector<double>> get_face_centers(double A) {
    double theta = asin(A / sqrt(3)) / 2;
    double s = cos(theta);
    double c = sin(theta);

    vector<vector<double>> face_centers = {
        {s / 2, c / 2, 0},
        {-s / 2, c / 2, 0},
        {0, c / 2, s / 2}
    };

    return face_centers;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        double A;
        cin >> A;

        vector<vector<double>> face_centers = get_face_centers(A);

        cout << "Case #" << t << ":" << endl;
        for (const vector<double> &face_center : face_centers) {
            for (double coord : face_center) {
                cout.precision(10);
                cout << coord << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
