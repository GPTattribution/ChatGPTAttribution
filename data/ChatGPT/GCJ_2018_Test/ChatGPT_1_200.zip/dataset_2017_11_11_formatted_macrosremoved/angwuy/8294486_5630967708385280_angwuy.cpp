// Google Code Jam 2018, Practice Session - problem 3
// "Steed 2: Cruise Control"
// Andras Eles, Veszprem, Hungary, 2018.04.01.
#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
using namespace std;

class WrongAnswer {};

int T;

void solveProblem (void)
{
	int N, D;
	cin >> D >> N;
	double bestspeed = 1e100;
	for (int i=0;i<N;++i)
	{
		int K, S;
		cin >> K >> S;
		double const timeleft = (D - K) / double(S);
		double const spd = D / timeleft;
		if (bestspeed > spd)
		{
			bestspeed = spd;
		}
	}
	cout << setprecision(15) << bestspeed << endl;
}

int main (int argc, char** argv)
{
	try {
		cin >> T;
		for (int t=1;t<=T;++t)
		{
			cout << "Case #" << t << ": " << flush;
			solveProblem();
		}
	}
	catch (WrongAnswer const& wa)
	{
	}
	return 0;
}
