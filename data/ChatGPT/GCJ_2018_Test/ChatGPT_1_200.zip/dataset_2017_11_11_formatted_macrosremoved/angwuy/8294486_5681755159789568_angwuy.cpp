// Google Code Jam 2018, Practice Session - problem 2
// "Senate Evacuation"
// Andras Eles, Veszprem, Hungary, 2018.04.01.
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

class WrongAnswer {};
typedef unsigned long long int ull;

int T;
int N;
int P[26];
string line;

char letter (int index)
{
	--P[index];
	return (index + 'A');
}

void solveProblem (void)
{
	cin >> N;
	for (int i=0;i<N;++i)
	{
		cin >> P[i];
	}
	int max1 = (-1);
	for (int i=0;i<N;++i)
	{
		if (max1 == (-1) || P[max1] < P[i])
		{
			max1 = i;
		}
	}
	int max2 = (-1);
	for (int i=0;i<N;++i)
	{
		if ((max1 != i) && (max2 == (-1) || P[max2] < P[i]))
		{
			max2 = i;
		}
	}
	{
		while (P[max1] > P[max2] + 1)
		{
			cout << letter(max1) << letter(max1) << " ";
		}
		int at = 0;
		do {
			while (at < N && (at == max1 || at == max2 || !P[at]))
			{
				at++;
			}
			if (at == N)
			{
				break;
			}
			cout << letter(at);
			if (P[max1] > P[max2])
			{
				cout << letter(max1) << " ";
				continue;
			}
			while (at < N && (at == max1 || at == max2 || !P[at]))
			{
				at++;
			}
			if (at == N)
			{
				cout << " ";
				break;
			}
			cout << letter(at) << " ";
		}
		while (true);
		if (P[max1] > P[max2])
		{
			cout << letter(max1) << " ";
		}
		while (P[max1])
		{
			cout << letter(max1) << letter(max2) << " ";
		}
		cout << endl;
	}
}

int main (int argc, char** argv)
{
	try {
		cin >> T;
		for (int t=1;t<=T;++t)
		{
			cout << "Case #" << t << ": " << flush;
			solveProblem();
		}
	}
	catch (WrongAnswer const& wa)
	{
	}
	return 0;
}
