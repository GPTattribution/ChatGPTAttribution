// Google Code Jam 2018, Practice Session - problem 1
// "Number Guessing"
// Andras Eles, Veszprem, Hungary, 2018.04.01.
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

class WrongAnswer {};
typedef unsigned long long int ull;

int T;
string line;

void solveProblem (void)
{
	ull A, B, N;
	string answ;
	cin >> A >> B >> N;
	do {
		ull const C = ((A + B) >> 1) + 1;
		cout << C << endl;
		cin >> answ;
		if (answ == "CORRECT")
		{
			break;
		}
		else if (answ == "TOO_BIG")
		{
			B = C - 1;
		}
		else if (answ == "TOO_SMALL")
		{
			A = C;
		}
		else if (answ == "WRONG_ANSWER")
		{
			throw WrongAnswer();
		}
	}
	while (true);
}

int main (int argc, char** argv)
{
	try {
		{
			getline(cin,line);
			stringstream sstr(line);
			sstr >> T;
		}
		for (int t=1;t<=T;t++)
		{
			solveProblem();
		}
	}
	catch (WrongAnswer const& wa)
	{
	}
	return 0;
}
