// Google Code Jam 2018, Qualification - problem 2
// "Trouble Sort"
// Andras Eles, Veszprem, Hungary, 2018.04.07.
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
using namespace std;

class WrongAnswer {};
int T;

int N;
vector<int> even;
vector<int> odd;
vector<int> aux;

void sort (vector<int>& vec, int a, int b, vector<int>& aux)
{
	if (b <= a + 1)
	{
		return;
	}
	if (b == a + 2)
	{
		if (vec[a] > vec[a+1])
		{
			int const sw = vec[a];
			vec[a] = vec[a+1];
			vec[a+1] = sw;
		}
		return;
	}
	int const pivot = (a + b) >> 1;
	{
		sort(vec,a,pivot,aux);
		sort(vec,pivot,b,aux);
	}
	{
		int ai = a;
		int bi = pivot;
		int c = a;
		do {
			if (ai < pivot)
			{
				if (bi < b)
				{
					if (vec[ai] <= vec[bi])
					{
						aux[c] = vec[ai];
						ai++;
					}
					else
					{
						aux[c] = vec[bi];
						bi++;
					}
				}
				else
				{
					aux[c] = vec[ai];
					ai++;
				}
			}
			else
			{
				if (bi < b)
				{
					aux[c] = vec[bi];
					bi++;
				}
				else
				{
					break;
				}
			}
			c++;
		}
		while (true);
	}
	{
		for (int i=a;i<b;i++)
		{
			vec[i] = aux[i];
		}
	}
}

void solveProblem (void)
{
	cin >> N;
	even.clear();
	odd.clear();
	for (int i=0;i<N;i++)
	{
		int Vi;
		cin >> Vi;
		((i & 1) ? odd : even).push_back(Vi);
	}
	{
		aux.resize(even.size());
		sort(odd,0,odd.size(),aux);
		sort(even,0,even.size(),aux);
	}
	{
		int numprev = even[0];
		for (int i=1;i<N;i++)
		{
			int const num = ((i & 1) ? odd : even)[i >> 1];
			if (num < numprev)
			{
				cout << (i-1);
				return;
			}
			numprev = num;
		}
		cout << "OK";
	}
}

int main (int, char**)
{
	try {
		cin >> T;
		for (int t=1;t<=T;++t)
		{
			cout << "Case #" << t << ": " << flush;
			solveProblem();
			cout << endl;
		}
	}
	catch (WrongAnswer const& wa)
	{
	}
	return 0;
}
