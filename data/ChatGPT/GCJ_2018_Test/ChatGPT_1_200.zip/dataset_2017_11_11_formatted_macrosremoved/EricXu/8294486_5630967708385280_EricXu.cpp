#include <bits/stdc++.h>
#define ll long long
#define pii pair<int, int>
#define pll pair<ll, ll>
#define str string
#define fi first
#define se second
#define pb push_back
#define SET(a, b) memset(a, b, sizeof(a))
#define eps 1e-6
#define pi atan(1) * 4
#define mod 1000000007
#define inf 1000000000
#define llinf 1000000000000000000
#define FOR(i, a, b, c) for (int i = (a); i <= (b); i += (c))
#define FORD(i, a, b, c) for (int i = (a); i >= (b); i -= (c))
using namespace std;
int main () {
	ll t;
	scanf("%lld", &t);
	FOR(i, 1, t, 1) {
		double d;
		ll n;
		scanf("%lf %lld", &d, &n);
		double ans = 1e18;
		FOR(j, 1, n, 1) {
			double k, s;
			scanf("%lf %lf", &k, &s);
			double v = d * s / (d - k);
			ans = min(ans, v);
		}
		printf("Case #%lld: %.6lf\n", i, ans);
	}
	return 0;
}
