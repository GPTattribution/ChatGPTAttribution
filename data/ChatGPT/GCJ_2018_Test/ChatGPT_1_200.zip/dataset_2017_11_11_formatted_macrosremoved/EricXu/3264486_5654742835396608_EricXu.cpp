#include <bits/stdc++.h>
#define ll long long
#define pii pair<int, int>
#define pll pair<ll, ll>
#define fi first
#define se second
#define pb push_back
#define SET(a, b) memset(a, b, sizeof(a))
#define eps 1e-6
#define pi atan(1) * 4
#define inf 1000000000
#define llinf 1000000000000000000
#define ff fflush(stdout)
using namespace std;
bool mapp[60][60];
bool ok (int x, int y, bool flag, bool flag2) {
	int r = int(flag), c = int(flag2);
	for (int i = x - 1; i <= x + r; i++) {
		for (int j = y - 1; j <= y + c; j++) {
			if (!mapp[i][j]) return 0;
		}
	}
	return 1;
}
int main () {
	int t;
	scanf("%d", &t);
	for (int i = 1; i <= t; i++) {
		int a;
		scanf("%d", &a);
		int w, h;
		if (a == 20) w = 5, h = 4;
		else w = 50, h = 4;
		SET(mapp, 0);
		bool flag = false;
		int cnt = 0;
		for (int j = 2; j <= h - 1; j += 2) {
			for (int k = 2; k <= w - 1; k += 2) {
				while (true) {
					if (ok(j, k, (j == h - 1), (k == w - 1))) break;
					printf("%d %d\n", j, k); ff; cnt++;
					int x, y;
					scanf("%d %d", &x, &y);
					if (!x && !y) {
						flag = true; break;
					}
					mapp[x][y] = 1;
				}
				if (k + 2 > w - 1 && k != w - 1) k = w - 3;
			}
			if (j + 2 > h - 1 && j != h - 1) j = h - 3;
		}
	}
	return 0;
}
