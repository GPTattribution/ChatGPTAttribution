#include <bits/stdc++.h>
#define ll long long
#define pii pair<int, int>
#define pll pair<ll, ll>
#define fi first
#define se second
#define pb push_back
#define SET(a, b) memset(a, b, sizeof(a))
#define eps 1e-6
#define pi atan(1) * 4
#define inf 1000000000
#define llinf 1000000000000000000
#define FOR(i, a, b, c) for (int i = (a); i <= (b); i += (c))
#define FORD(i, a, b, c) for (int i = (a); i >= (b); i -= (c))
#define FORL(i, a, b, c) for (ll i = (a); i <= (b); i += (c))
#define FORDL(i, a, b, c) for (ll i = (a); i >= (b); i -= (c))
using namespace std;
ll freq[35], power[35];
int main () {
	ios::sync_with_stdio(false); cin.tie(0);
	ll t;
	cin >> t;
	power[0] = 1;
	FORL(i, 1, 30, 1) power[i] = (power[i - 1] << 1);
	FORL(i, 1, t, 1) {
		ll d;
		string S;
		cin >> d >> S;
		ll s = S.length();
		ll st = 0, sum = 0;
		SET(freq, 0);
		FORL(j, 0, s - 1, 1) {
			if (S[j] == 'S') {
				freq[st]++; sum += power[st];
			}
			else st++;
		}

		ll cnt = 0;
		bool flag = false;
		FORDL(j, 30, 1, 1) {
			if (sum <= d) {
				 flag = true; break;
			}
			while (freq[j]) {
				freq[j]--; freq[j - 1]++;
				sum -= power[j]; sum += power[j - 1];
				cnt++;
				if (sum <= d) {
					flag = true; break;
				}
			}
			if (flag) break;
		}
		if (sum <= d || flag) printf("Case #%lld: %lld\n", i, cnt);
		else printf("Case #%lld: IMPOSSIBLE\n", i);
	}
	return 0;
}
