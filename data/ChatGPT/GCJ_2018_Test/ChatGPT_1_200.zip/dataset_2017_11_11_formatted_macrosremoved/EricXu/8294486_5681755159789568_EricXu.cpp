#include <bits/stdc++.h>
#define ll long long
#define pii pair<int, int>
#define pll pair<ll, ll>
#define str string
#define fi first
#define se second
#define pb push_back
#define SET(a, b) memset(a, b, sizeof(a))
#define eps 1e-6
#define pi atan(1) * 4
#define mod 1000000007
#define inf 1000000000
#define llinf 1000000000000000000
#define FOR(i, a, b, c) for (int i = (a); i <= (b); i += (c))
#define FORD(i, a, b, c) for (int i = (a); i >= (b); i -= (c))
using namespace std;
struct cmp {
	bool operator() (const pii &a, const pii &b) const {
		return (a.fi < b.fi);
	}
};
priority_queue<pii, vector<pii>, cmp> pq;
int main () {
	int t;
	scanf("%d", &t);
	FOR(i, 1, t, 1) {
		int n, s = 0;
		scanf("%d", &n);
		FOR(j, 1, n, 1) {
			int f;
			scanf("%d", &f);
			pq.push({f, j}); s += f;
		}
		vector<int> output;
		while (!pq.empty()) {
			auto u = pq.top(); pq.pop();
			output.pb(u.se);
			if (u.fi - 1 == 0) continue;
			pq.push({u.fi - 1, u.se});
		}
		printf("Case #%d:", i);
		int st = 0;
		if (s & 1) {
			printf(" %c", output[0] + 'A' - 1);
			st = 1;
		}
		FOR(j, st, int(output.size()) - 1, 2) {
			printf(" %c%c", output[j] + 'A' - 1, output[j + 1] + 'A' - 1);
		}
		printf("\n");
	}
	return 0;
}
