#include <bits/stdc++.h>
#define ll long long
#define pii pair<int, int>
#define pll pair<ll, ll>
#define str string
#define fi first
#define se second
#define pb push_back
#define SET(a, b) memset(a, b, sizeof(a))
#define eps 1e-6
#define pi atan(1) * 4
#define mod 1000000007
#define inf 1000000000
#define llinf 1000000000000000000
#define FOR(i, a, b, c) for (int i = (a); i <= (b); i += (c))
#define FORD(i, a, b, c) for (int i = (a); i >= (b); i -= (c))
using namespace std;
struct cmp {
	bool operator() (const pll &a, const pll &b) const {
		return (a.fi < b.fi);
	}
};
priority_queue<pll, vector<pll>, cmp> pq;
int main () {
	ll t;
	scanf("%lld", &t);
	FOR(i, 1, t, 1) {
		ll n, k;
		scanf("%lld %lld", &n, &k);
		while (!pq.empty()) pq.pop();
		pq.push({n, 1});
		while (!pq.empty()) {
			auto u = pq.top(); pq.pop();
			while (!pq.empty() && pq.top().fi == u.fi) {
				u.se += pq.top().se; pq.pop();
			}
			if (k <= u.se) {
				printf("Case #%lld: %lld %lld\n", i, u.fi / 2, (u.fi - 1) / 2);
				break;
			}
			if (u.fi & 1) {
				pq.push({u.fi / 2, u.se * 2});
			} else {
				pq.push({u.fi / 2, u.se}); pq.push({(u.fi - 1) / 2, u.se});
			}
			k -= u.se;
		}
	}
	return 0;
}
