#include <bits/stdc++.h>
#define ll long long
#define pii pair<int, int>
#define pll pair<ll, ll>
#define str string
#define fi first
#define se second
#define pb push_back
#define SET(a, b) memset(a, b, sizeof(a))
#define eps 1e-6
#define pi atan(1) * 4
#define mod 1000000007
#define inf 1000000000
#define llinf 1000000000000000000
#define FOR(i, a, b, c) for (int i = (a); i <= (b); i += (c))
#define FORD(i, a, b, c) for (int i = (a); i >= (b); i -= (c))
using namespace std;
int main () {
	int t;
	char inp[10];
	scanf("%d", &t);
	FOR(i, 1, t, 1) {
		int l, r, n;
		scanf("%d %d %d", &l, &r, &n);
		l++;
		while (l <= r) {
			int m = (l + r) / 2;
			printf("%d\n", m); fflush(stdout);
			scanf("%s", inp);
			if (inp[4] == 'B') r = m - 1;
			else if (inp[4] == 'S') l = m + 1;
			else break;
		}
	}
	return 0;
}
