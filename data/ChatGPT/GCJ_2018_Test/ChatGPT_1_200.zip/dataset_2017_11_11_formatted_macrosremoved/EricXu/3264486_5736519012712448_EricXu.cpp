#include <bits/stdc++.h>
#define ll long long
#define pii pair<int, int>
#define pll pair<ll, ll>
#define fi first
#define se second
#define pb push_back
#define SET(a, b) memset(a, b, sizeof(a))
#define eps 1e-6
#define pi atan(1) * 4
#define inf 1000000000
#define llinf 1000000000000000000
using namespace std;
int num[100005];
int odd[50005], even[50005];
int main () {
	int t;
	scanf("%d", &t);
	for (int i = 1; i <= t; i++) {
		int n;
		scanf("%d", &n);
		for (int j = 1; j <= n; j++) {
			scanf("%d", &num[j]);
			if (j & 1) odd[(j + 1) >> 1] = num[j];
			else even[j >> 1] = num[j];
		}
		int olen = ((n + 1) >> 1);
		int elen = (n >> 1);
		sort(odd + 1, odd + olen + 1);
		sort(even + 1, even + elen + 1);
		sort(num + 1, num + n + 1);
		int id = -1;
		for (int j = 1; j <= n; j++) {
			if (j & 1 && num[j] != odd[(j + 1) >> 1] || !(j & 1) && num[j] != even[j >> 1]) {
				id = j; break;
			}
		}
		if (id == -1) printf("Case #%d: OK\n", i);
		else printf("Case #%d: %d\n", i, id - 1);
	}
	return 0;
}
