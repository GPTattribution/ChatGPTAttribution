#include <iostream>      // Input/Output
#include <cstdio>        // C Input/Output

#include <algorithm>     // Useful functions such as sort, reverse, etc...
#include <cmath>         // Math functions

#include <bitset>        // Set of bits
#include <string>        // String type

#include <vector>        // Variable size array
#include <array>         // Fixed size array
#include <forward_list>  // Single-Linked lists
#include <list>          // Doubly-Linked lists

#include <set>           // Ordered set, tipically implemented as binary trees (value is the key)
#include <unordered_set> // Unordered set, faster for direct accesses
#include <map>           // Ordered maps, tipically binary trees (provides, map and multimap)
#include <unordered_map> // Unordered maps, faster for direct access, slower for iteration

#include <queue>         // FIFO queue, priority_queue
#include <deque>         // Double ended queue
#include <stack>         // LIFO stack

using i8  = char;
using u8  = unsigned char;
using i16 = short int;
using u16 = unsigned short int;
using i32 = long int;
using u32 = unsigned long int;
using i64 = long long int;
using u64 = unsigned long long int;

using f32 = float;
using f64 = double;
using f80 = long double;

using namespace std;

i64 N;
i64 T;
i64 o[2][100010];

void solve() {
  cin >> N;
  for(i64 i=0;i<N;++i) {
    cin >> o[i%2][i/2];
  }

  sort(o[0],o[0]+(N/2)+(N%2));
  sort(o[1],o[1]+(N/2));

  for(i64 i=0;i<N-1;++i) {
    i64 j=i+1;
    if(o[i%2][i/2] > o[j%2][j/2]){
      cout << i << "\n";
      return;
    }
  }
  cout << "OK\n";
}

int main(void) {
  cin >> T;
  for(i64 i=1;i<=T;++i) {
    cout << "Case #" << i << ": ";
    solve();
  }

  return 0;
}
