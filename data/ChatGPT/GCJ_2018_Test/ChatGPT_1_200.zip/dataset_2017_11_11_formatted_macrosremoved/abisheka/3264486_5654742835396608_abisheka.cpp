#include <iostream>      // Input/Output
#include <cstdio>        // C Input/Output

#include <algorithm>     // Useful functions such as sort, reverse, etc...
#include <cmath>         // Math functions

#include <bitset>        // Set of bits
#include <string>        // String type

#include <vector>        // Variable size array
#include <array>         // Fixed size array
#include <forward_list>  // Single-Linked lists
#include <list>          // Doubly-Linked lists

#include <set>           // Ordered set, tipically implemented as binary trees (value is the key)
#include <unordered_set> // Unordered set, faster for direct accesses
#include <map>           // Ordered maps, tipically binary trees (provides, map and multimap)
#include <unordered_map> // Unordered maps, faster for direct access, slower for iteration

#include <queue>         // FIFO queue, priority_queue
#include <deque>         // Double ended queue
#include <stack>         // LIFO stack

using i8  = char;
using u8  = unsigned char;
using i16 = short int;
using u16 = unsigned short int;
using i32 = long int;
using u32 = unsigned long int;
using i64 = long long int;
using u64 = unsigned long long int;

using f32 = float;
using f64 = double;
using f80 = long double;

using namespace std;

bool M[4][100];

int solve() {
  i64 a;
  cin >> a;

  i64 l = a/3 + (a%3==0 ? 0 : 1);

  for(i64 i=1;i<=3;++i) {
    for(i64 j=1;j<=l;++j) {
      M[i][j] = false;
    }
  }

  for(i64 j=2;j<=l-1;) {
    cout << 2 << " " << j << endl;
    i64 ii,jj;
    cin >> ii >> jj;
    if(ii == 0 && jj==0) break;
    if(ii == -1 && jj==-1) return 1;
    M[ii][jj]=true;
    if(j < l-1 && M[1][j-1] && M[2][j-1] && M[3][j-1]) ++j;
  }

  return 0;
}

int main(void) {
  i64 t;
  cin >> t;
  for(i64 i=0;i<t;++i) {
    if(solve() > 0) break;
  }

  return 0;
}
