#include <iostream>      // Input/Output
#include <iomanip>
#include <cstdio>        // C Input/Output

#include <algorithm>     // Useful functions such as sort, reverse, etc...
#include <cmath>         // Math functions

#include <bitset>        // Set of bits
#include <string>        // String type

#include <vector>        // Variable size array
#include <array>         // Fixed size array
#include <forward_list>  // Single-Linked lists
#include <list>          // Doubly-Linked lists

#include <set>           // Ordered set, tipically implemented as binary trees (value is the key)
#include <unordered_set> // Unordered set, faster for direct accesses
#include <map>           // Ordered maps, tipically binary trees (provides, map and multimap)
#include <unordered_map> // Unordered maps, faster for direct access, slower for iteration

#include <queue>         // FIFO queue, priority_queue
#include <deque>         // Double ended queue
#include <stack>         // LIFO stack

using i8  = char;
using u8  = unsigned char;
using i16 = short int;
using u16 = unsigned short int;
using i32 = long int;
using u32 = unsigned long int;
using i64 = long long int;
using u64 = unsigned long long int;

using f32 = float;
using f64 = double;
using f80 = long double;

const u64 MOD = 1000000007;

using namespace std;

int main(void) {
  i64 t;
  cin >> t;

  for(;t>0;t--) {
    i64 a,b,n,i;
    cin >> a >> b;
    cin >> n;
    a=a+1;
    i=0;
    for(;i<n;++i) {
      string s;

      i64 m = (a+b)/2;
      /* cerr << a << " " << b << endl; */
      cout << m << endl << flush;
      cin >> s;
      /* cerr << s << endl; */

      if(s == "CORRECT") {
        break;
      } else if(s == "TOO_SMALL") {
        a=m+1;
      } else if(s == "TOO_BIG") {
        b=m-1;
      } else {
        return 0;
      }
    }

    if(i==n) {
      string s;
      cin >> s;
      return 0;
    }
  }

  return 0;
}
