#include <iostream>      // Input/Output
#include <iomanip>
#include <cstdio>        // C Input/Output

#include <algorithm>     // Useful functions such as sort, reverse, etc...
#include <cmath>         // Math functions

#include <bitset>        // Set of bits
#include <string>        // String type

#include <vector>        // Variable size array
#include <array>         // Fixed size array
#include <forward_list>  // Single-Linked lists
#include <list>          // Doubly-Linked lists

#include <set>           // Ordered set, tipically implemented as binary trees (value is the key)
#include <unordered_set> // Unordered set, faster for direct accesses
#include <map>           // Ordered maps, tipically binary trees (provides, map and multimap)
#include <unordered_map> // Unordered maps, faster for direct access, slower for iteration

#include <queue>         // FIFO queue, priority_queue
#include <deque>         // Double ended queue
#include <stack>         // LIFO stack

using i8  = char;
using u8  = unsigned char;
using i16 = short int;
using u16 = unsigned short int;
using i32 = long int;
using u32 = unsigned long int;
using i64 = long long int;
using u64 = unsigned long long int;

using f32 = float;
using f64 = double;
using f80 = long double;

const u64 MOD = 1000000007;

using namespace std;

struct I {
  i64 l;
  i64 r;
  i64 m;
  i64 mi;
  i64 ma;

  I(i64 l, i64 r) : l(l), r(r), m(((l+1)+(r-1))/2) {
    mi = min(m-l-1,r-m-1);
    ma = max(m-l-1,r-m-1);
  }

  bool operator<(const struct I &i) const {
    return mi < i.mi || (mi == i.mi && (ma < i.ma || (ma == i.ma && m > i.m)));
  }
};

void solve(i64 t) {
  i64 n,k;
  cin >> n >> k;

  priority_queue<I> q;
  q.emplace(0,n+1);

  for(i64 i=2;i<=k;++i) {
    i64 l,r,m;
    l = q.top().l;
    r = q.top().r;
    m = q.top().m;
    q.pop();
    if(m-l > 1) q.emplace(l,m);
    if(r-m > 1) q.emplace(m,r);
  }

  cout << "Case #" << t << ": " << q.top().ma << " " << q.top().mi << "\n";
}

// 0 1 _ 3 4

int main(void) {
  i64 t;
  cin >> t;

  for(i64 i=1;i<=t;++i) solve(i);

  return 0;
}
