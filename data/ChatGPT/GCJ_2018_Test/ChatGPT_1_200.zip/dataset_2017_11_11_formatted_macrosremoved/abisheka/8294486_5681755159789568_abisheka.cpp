#include <iostream>      // Input/Output
#include <iomanip>
#include <cstdio>        // C Input/Output

#include <algorithm>     // Useful functions such as sort, reverse, etc...
#include <cmath>         // Math functions

#include <bitset>        // Set of bits
#include <string>        // String type

#include <vector>        // Variable size array
#include <array>         // Fixed size array
#include <forward_list>  // Single-Linked lists
#include <list>          // Doubly-Linked lists

#include <set>           // Ordered set, tipically implemented as binary trees (value is the key)
#include <unordered_set> // Unordered set, faster for direct accesses
#include <map>           // Ordered maps, tipically binary trees (provides, map and multimap)
#include <unordered_map> // Unordered maps, faster for direct access, slower for iteration

#include <queue>         // FIFO queue, priority_queue
#include <deque>         // Double ended queue
#include <stack>         // LIFO stack

using i8  = char;
using u8  = unsigned char;
using i16 = short int;
using u16 = unsigned short int;
using i32 = long int;
using u32 = unsigned long int;
using i64 = long long int;
using u64 = unsigned long long int;

using f32 = float;
using f64 = double;
using f80 = long double;

const u64 MOD = 1000000007;

using namespace std;

struct P {
  i64 n;
  char c;

  bool operator<(const struct P &p) const {
    return n > p.n || (n==p.n && c < p.c);
  }
};

void solve(i64 t) {
  i64 n;
  cin >> n;

  P p[30];

  for(i64 i=0;i<n;++i) {
    cin >> p[i].n;
    p[i].c = 'A'+i;
  }

  sort(p,p+n);

  cout << "Case #" << t << ":";

  while(p[0].n > p[1].n) {
    if(p[1].n - p[0].n > 1) {
      cout << " " << p[0].c << p[0].c;
      p[0].n -= 2;
    } else {
      cout << " " << p[0].c;
      p[0].n -= 1;
    }
  }

  for(i64 i=2;i<n;) {
    if(p[i].n > 1) {
      cout << " " << p[i].c << p[i].c;
      p[i].n -= 2;
    } else if(p[i].n == 1) {
      if(i < n-1) {
        cout << " " << p[i].c << p[i+1].c;
        p[i].n -= 1;
        p[i+1].n -= 1;
      } else {
        cout << " " << p[i].c;
        p[i].n -= 1;
      }
    } else {
      ++i;
    }
  }

  while(p[0].n > 0) {
    cout << " " << p[0].c << p[1].c;
    p[0].n -= 1;
    p[1].n -= 1;
  }

  cout << "\n";
}

int main(void) {
  i64 t;
  cin >> t;

  for(i64 i=1;i<=t;++i) {
    solve(i);
  }

  return 0;
}
