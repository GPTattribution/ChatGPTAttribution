#include <iostream>      // Input/Output
#include <cstdio>        // C Input/Output

#include <algorithm>     // Useful functions such as sort, reverse, etc...
#include <cmath>         // Math functions

#include <bitset>        // Set of bits
#include <string>        // String type

#include <vector>        // Variable size array
#include <array>         // Fixed size array
#include <forward_list>  // Single-Linked lists
#include <list>          // Doubly-Linked lists

#include <set>           // Ordered set, tipically implemented as binary trees (value is the key)
#include <unordered_set> // Unordered set, faster for direct accesses
#include <map>           // Ordered maps, tipically binary trees (provides, map and multimap)
#include <unordered_map> // Unordered maps, faster for direct access, slower for iteration

#include <queue>         // FIFO queue, priority_queue
#include <deque>         // Double ended queue
#include <stack>         // LIFO stack

using i8  = char;
using u8  = unsigned char;
using i16 = short int;
using u16 = unsigned short int;
using i32 = long int;
using u32 = unsigned long int;
using i64 = long long int;
using u64 = unsigned long long int;

using f32 = float;
using f64 = double;
using f80 = long double;

using namespace std;

void solve(i64 T) {
  i64 d;
  string p;

  cin >> d >> p;

  i64 s=0;
  i64 t=0;
  i64 co[31] = {0};
  for(u64 i=0;i<p.size();++i) {
    if(p[i] == 'C') {
      s++;
    } else {
      co[s]++;
      t += (1 << s);
    }
  }

  i64 c=0;
  while(t > d && s > 0) {
    if(co[s] > 0) {
      t -= ((1 << s) - (1 << (s-1)));
      co[s]--;
      co[s-1]++;
      c++;
    } else {
      s--;
    }
  }
  if(t <= d) {
    cout << "Case #" << T << ": " << c << "\n";
  } else {
    cout << "Case #" << T << ": IMPOSSIBLE\n";
  }

}

int main(void) {
  i64 t;
  cin >> t;

  for(i64 i=1;i<=t;++i) solve(i);

  return 0;
}
