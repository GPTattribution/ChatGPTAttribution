#include <bits/stdc++.h>
#define SYNC ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
using namespace std;
#define gc getchar_unlocked
#define fo(i,n) for(i=0;i<n;i++)
#define Fo(i,k,n) for(i=k;k<n?i<n:i>n;k<n?i+=1:i-=1)
#define ll long long
#define ull unsigned long long
#define si(x)	scanf("%d",&x)
#define sl(x)	scanf("%lld",&x)
#define ss(s)	scanf("%s",s)
#define pi(x)	printf("%d\n",x)
#define pl(x)	printf("%lld\n",x)
#define ps(s)	printf("%s\n",s)
#define deb(x) cout << #x << "=" << x << endl
#define deb2(x, y) cout << #x << "=" << x << "," << #y << "=" << y << endl
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define all(x) x.begin(), x.end()
#define clr(x) memset(x, 0, sizeof(x))
#define sortall(x) sort(all(x))
#define tr(it, a) for(auto it = a.begin(); it != a.end(); it++)
#define PI 3.1415926535897932384626
typedef pair<int, int>	pii;
typedef pair<ll, ll>	pl;
typedef vector<int>		vi;
typedef vector<ll>		vl;
typedef vector<pii>		vpii;
typedef vector<pl>		vpl;
typedef vector<vi>		vvi;
typedef vector<vl>		vvl;
int main()
{
	SYNC
	int t;
	cin>>t;
	int t1=0;
	while(t--)
	{
		t1++;
		int n;
		cin>>n;
		pair<int,int> p[n+1];
		int i=1;
		int b;
		cout<<"Case #"<<t1<<": ";
		for(i=1;i<=n;i++)
		{
			cin>>b;
			p[i]=mp(b,i);
		}
		sort(p+1,p+n+1);
		if(n==2)
		{
			int tmp=p[1].first;
			while(tmp!=0)
			{
				cout<<"AB ";
				tmp--;
			}
		}
		else
		{
			char e,f,g;
			for(i=n-2;i>=1;i--)
			{
				g=(char)(p[i].second+64);
				e=(char)(p[n].second+64);
				f=(char)(p[n-1].second+64);
				//cout<<"fck "<<g<<" "<<e<<" "<<f<<"\n";
				while(p[n-2].first!=p[n-1].first)
				{
					p[n].first--;
					p[n-1].first--;
					cout<<e<<f<<" ";
				}
				while(p[n].first!=0)
				{
					if(p[n].first==1)
						{p[n].first-=1;	cout<<e<<" ";}
					else
						{p[n].first-=2;	cout<<e<<e<<" ";}
				}
				if(i==1)
				{
					int tmp=p[i].first;
					while(tmp!=0)
					{
					cout<<f<<g<<" ";
					tmp--;
					}
				}
			}
		}
		cout<<"\n";
	}
	return 0;
}
