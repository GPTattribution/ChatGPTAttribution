#include <bits/stdc++.h>
#define SYNC ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
using namespace std;
#define gc getchar_unlocked
#define fo(i,n) for(i=0;i<n;i++)
#define Fo(i,k,n) for(i=k;k<n?i<n:i>n;k<n?i+=1:i-=1)
#define ll long long
#define ull unsigned long long
#define si(x)	scanf("%d",&x)
#define sl(x)	scanf("%lld",&x)
#define ss(s)	scanf("%s",s)
#define pi(x)	printf("%d\n",x)
#define pl(x)	printf("%lld\n",x)
#define ps(s)	printf("%s\n",s)
#define deb(x) cout << #x << "=" << x << endl
#define deb2(x, y) cout << #x << "=" << x << "," << #y << "=" << y << endl
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define all(x) x.begin(), x.end()
#define clr(x) memset(x, 0, sizeof(x))
#define sortall(x) sort(all(x))
#define tr(it, a) for(auto it = a.begin(); it != a.end(); it++)
#define PI 3.1415926535897932384626
typedef pair<int, int>	pii;
typedef pair<ll, ll>	pl;
typedef vector<int>		vi;
typedef vector<ll>		vl;
typedef vector<pii>		vpii;
typedef vector<pl>		vpl;
typedef vector<vi>		vvi;
typedef vector<vl>		vvl;
int main()
{
	SYNC
	int t;
	cin>>t;

	string s;
	ll d;
	int t1=0;
	while(t--)
	{
		t1++;
		cin>>d>>s;
		int i=0,cnt=-1,cnt1=-1;
		ll tmp1=0,req=0,tmp2=1;

		pair<int,ll> p[s.length()];
		pair<int,ll> p1[s.length()];
		pair<int,ll> p2;
		int c=-1;
		ll b;
		for(i=0;i<s.length();i++)
		{
			if(s[i]=='C')	{	tmp2*=2;	p[++cnt].first=i;	p[cnt].second=tmp2;
			if(c==-1)	{	p1[++cnt1].first=-1;	p1[cnt1].second=1;	c=i;	b=tmp2;}
			else
			{
				p1[++cnt1].first=c;
				p1[cnt1].second=b;
				c=i;	b=tmp2;
			}
				}
			else
				{	req+=tmp2;
					p[++cnt].first=i;	p[cnt].second=tmp2;
					p1[++cnt1].first=c;	p1[cnt1].second=b;
				}
		}

		for(i=0;i<s.length();i++)
		{
			if(s[i]=='S')
			tmp1++;
		}

		if(tmp1>d)
			cout<<"Case #"<<t1<<": "<<"IMPOSSIBLE\n";
		else
		{
			int j;
			int k=0;
			for(i=s.length()-1;i>=1&&req>d;)
			{
				if(s[i]=='S'&&s[i-1]=='C')
				{
					k++;
					s[i-1]='S';
					s[i]='C';
					req-=p[i-1].second;
					req+=p1[i-1].second;
					p2=p[i];
					p[i]=p[i-1];
					p[i-1]=p2;


					p2=p1[i];
					p1[i]=p1[i-1];
					p1[i-1]=p2;
					i=s.length()-1;
					//cout<<req<<"fck\n";
				}
				else
					i--;
			}
			cout<<"Case #"<<t1<<": "<<k<<"\n";
		}
	}
	return 0;
}
