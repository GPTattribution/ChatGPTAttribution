#include <bits/stdc++.h>
#define SYNC ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
using namespace std;
#define gc getchar_unlocked
#define fo(i,n) for(i=0;i<n;i++)
#define Fo(i,k,n) for(i=k;k<n?i<n:i>n;k<n?i+=1:i-=1)
#define ll long long
#define ull unsigned long long
#define si(x)	scanf("%d",&x)
#define sl(x)	scanf("%lld",&x)
#define ss(s)	scanf("%s",s)
#define pi(x)	printf("%d\n",x)
#define pl(x)	printf("%lld\n",x)
#define ps(s)	printf("%s\n",s)
#define deb(x) cout << #x << "=" << x << endl
#define deb2(x, y) cout << #x << "=" << x << "," << #y << "=" << y << endl
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define all(x) x.begin(), x.end()
#define clr(x) memset(x, 0, sizeof(x))
#define sortall(x) sort(all(x))
#define tr(it, a) for(auto it = a.begin(); it != a.end(); it++)
#define PI 3.1415926535897932384626
typedef pair<int, int>	pii;
typedef pair<ll, ll>	pl;
typedef vector<int>		vi;
typedef vector<ll>		vl;
typedef vector<pii>		vpii;
typedef vector<pl>		vpl;
typedef vector<vi>		vvi;
typedef vector<vl>		vvl;
int main()
{
	SYNC
	int t;
	cin>>t;
	int t1=0;
	ll n,k;
	vector<ll>v;
	ll it;
	ll tmp1,tmp2,tmp3,cnt;
	while(t--)
	{
		t1++;
		cin>>n>>k;
		ll i;
		v.pb(n);
		cnt=0;
		it=n;
		for(i=1;;)
		{
			if(it!=0)
			{
				tmp3=(it);
				tmp1=tmp3/2;
				tmp2=(tmp3-1)/2;
				v.pb(tmp1);
				v.pb(tmp2);
				++i;
			}
			if(i>k)	break;
			else	{	++cnt;	it=v[cnt];	}
		}
		sort(all(v));
		tmp1=v[v.size()-1-(k-1)]/2;
		tmp2=(v[v.size()-1-(k-1)]-1)/2;
		cout<<"Case #"<<t1<<": "<<tmp1<<" "<<tmp2<<"\n";
		v.clear();
	}
	return 0;
}
