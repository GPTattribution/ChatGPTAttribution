#include <iostream>
using namespace std;

bool bs (int a , int b , int n)
{
    if (n <= 0) return  0 ;
    int mid = (a + b ) /2 ;
    cout << mid << endl ;
    string str ;
    cin >> str ;
    if (str == "CORRECT") return 1;
    else if (str == "TOO_SMALL" ) return bs (mid + 1 , b , n-1) ;
    else if (str == "TOO_BIG" ) return  bs (a , mid-1 , n-1) ;
    else return 0;
}

int main() {
	int t ;
	cin >> t ;
	while (t--)
	{
	    int a , b , n ;
	    cin >> a >> b >> n ;
	    bool x = bs (a , b , n) ;
	    if (x == 0) break ;
	}
	return 0;
}
