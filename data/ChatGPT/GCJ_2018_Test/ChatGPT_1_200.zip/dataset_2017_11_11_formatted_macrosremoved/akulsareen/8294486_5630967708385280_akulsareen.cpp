#include <iostream>
#include<limits.h>
#include <iomanip>
using namespace std;

int main() {

	 int t ;
    cin >> t ;
    int tm = t ;

    while (t--)
    {
        int d , n ;
        cin >> d >> n ;
        double mint = INT_MIN ;
        for (int i = 0 ; i < n ; i ++)
        {
            int p , s ;
            cin >> p >> s ;
            if (p < d)
            {
                double t = (d - p) / (s * 1.0) ;
                if (t > mint ) mint = t ;
            }
        }
        double fs = d / mint ;
        cout << "Case #" << tm-t << ": " ;
        std::cout.precision(6);
        std::cout.setf( std::ios::fixed, std:: ios::floatfield );
        cout <<  fs << endl ;

    }

}
