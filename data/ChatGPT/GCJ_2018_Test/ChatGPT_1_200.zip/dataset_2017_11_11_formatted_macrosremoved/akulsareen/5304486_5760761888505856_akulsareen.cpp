#include <iostream>
#include <map>
using namespace std;

void bs (long long int n , long long int k , long long int &mi , long long &ma)
{
    map <long long int   , long long int > m ;
    map <long long int   , long long int > :: iterator it ;
    long long int a , b;

    m.insert (make_pair(n , 1)) ;


    while (k > 0 and !m.empty()  )
    {

        it  = m.end() ;
        it-- ;
        n = it->first  ;
       // if (n < 0) break ;
        m.erase (it) ;

        a = (n - 1) /2 ;
        b = a + (n - 1) %2 ;

        long long int tim = it->second ;
        k -= tim ;

        it = m.find(a) ;
        if (it == m.end()) m.insert (make_pair(a , tim)) ;
        else it->second += tim ;
        it = m.find(b) ;
        if (it == m.end()) m.insert (make_pair(b , tim)) ;
        else it->second += tim ;

    }

    mi = a ; ma = b ;
}

int main ()
{
        //freopen("test.txt","r",stdin);
    int t ;
    cin >> t ;
    int tm = t ;

    while (t--)
    {
        long long int n , k ;
        cin >> n >> k  ;
        cout << "Case #" << tm-t << ": " ;
        long long int mi = 0 , ma = 0 ;
        bs (n , k , mi , ma) ;
        cout << ma << " " << mi << endl ;
    }
}
