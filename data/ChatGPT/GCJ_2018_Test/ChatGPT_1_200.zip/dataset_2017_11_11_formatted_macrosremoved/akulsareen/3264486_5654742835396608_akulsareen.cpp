#include <iostream>
#include <string>
using namespace std;

bool  solve ()
{
    int r ;
    cin >> r ;
    bool arr[1001][1001] ;
    for (int i = 0 ; i < 1001 ; i++)
    {
        for (int j = 0 ; j < 1001 ; j++) arr[i][j] = 0 ;
    }

    int in1 = 2 , in2 = 2 ;
    while (1)
    {
        bool br = 0 ;
        for (int i = in1-1 ; i <= in1+1 ; i++)
        {

            for (int j = in2-1 ; j <= in2+1 ; j++)
            {
                if ( arr[i][j] == 0 )
                {
                    cout << in1 << " " << in2 << endl ;
                    br  = 1 ;
                    break ;
                }
            }
            if (br == 1) break ;
        }
        if (br == 0)
        {
            in1 += 3 ;
            cout << in1 << " "  << in2 << endl ;
        }

        int a , b ;
        cin >> a >> b ;
        if (a == 0 && b == 0) return 1 ;
        else if ( a == -1 && b == -1) return 0 ;
        else {
            arr[a][b] = 1 ;
        }
    }

}


int main() {
	int t ;
	cin >> t ;
	while (t--)
	{
	    bool res = solve () ;
	    if (res == 0) break ;
	}
	return 0;
}
