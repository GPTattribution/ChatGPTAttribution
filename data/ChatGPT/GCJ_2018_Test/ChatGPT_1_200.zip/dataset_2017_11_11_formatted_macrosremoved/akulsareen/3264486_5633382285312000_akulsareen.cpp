#include <iostream>
#include <cmath>
#include <vector>

const double EPS = 1e-6;

std::vector<std::vector<double>> solve(double A) {
    double theta = (A - 1) / (std::sqrt(2) - 1);
    double phi = std::acos(1 / std::sqrt(3));
    double sin_theta = std::sin(theta);
    double cos_theta = std::cos(theta);
    double sin_phi = std::sin(phi);
    double cos_phi = std::cos(phi);

    std::vector<std::vector<double>> points(3, std::vector<double>(3));
    points[0] = {0.5 * (sin_theta * cos_phi + cos_theta), 0.5 * sin_phi, 0.5 * (sin_theta * cos_phi - cos_theta)};
    points[1] = {0.5 * (cos_theta * cos_phi - sin_theta), 0.5 * sin_phi, 0.5 * (cos_theta * cos_phi + sin_theta)};
    points[2] = {0.5 * cos_phi, 0.5 * sin_phi, 0.5};

    return points;
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;

        std::vector<std::vector<double>> points = solve(A);

        std::cout << "Case #" << t << ":\n";
        for (const auto& point : points) {
            std::cout << point[0] << ' ' << point[1] << ' ' << point[2] << '\n';
        }
    }

    return 0;
}
