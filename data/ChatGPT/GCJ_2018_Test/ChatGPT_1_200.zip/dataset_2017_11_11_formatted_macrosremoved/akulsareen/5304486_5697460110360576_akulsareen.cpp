#include <iostream>
using namespace std;

#define loop(x, n) for(int x = 0; x < n; ++ x)

int stua (int d , string str)
{
    int n = str.length() ;
    int *dp = new int[n] ;
    int val = 1 ;
    int sum = 0 ;
    for (int i = 0 ; i < n ; i++)
    {
        if (str[i] == 'C') {
            val *= 2 ;
            dp[i] = val ;
        } else if (str[i] == 'S')
        {
            dp[i] = val ;
            sum += val ;
        }
    }

    int res = 0 ;
    while (sum > d )
    {
        bool im = 1 ;
        for (int i = n-1 ; i > 0 ; i--)
        {
            if (str[i] == 'S' && str[i-1] == 'C')
            {
                str[i] = 'C' ; str[i-1] = 'S' ;
                dp[i-1] = dp[i-1]/2 ;
                sum -= dp[i-1] ;
                res++;
                im = 0 ;
                break ;
            }
        }
        if (im == 1) return -1 ;

    }

    return res ;
}

int main() {

    int t ;
    cin >> t ;
    for (int i = 0 ; i < t ; i++)
    {
        cout << "case #" << i+1 << ": " ;
        int d ;
        string str ;
        cin >> d >> str ;

        int res = stua (d , str) ;
        if (res == -1 ) cout << "IMPOSSIBLE" << endl ;
        else cout << res << endl ;
    }

    return 0;
}
