#include <iostream>
#include <string>
#include <vector>
#include<algorithm>
#include <limits.h>
using namespace std;

int main() {

	int t ;
    cin >> t ;
    for (int k = 0 ; k < t ; k++)
    {
        cout << "Case #" << k+1 << ": " ;
        int n ;
        cin >> n ;
        int *arr = new int[n] ;
       // for (int i = 0 ; i < n ; i++) cin >> arr[i] ;
        int n2 = n/2  ;
        int n1 = n2 + n%2 ;
        int *arr1 = new int[n1] ;
        int *arr2 = new int[n2] ;

        int i = 0 ; int j = 0 ;
        while (i + j  < n )
        {
            cin >> arr1[i++] ;
            if (i + j  < n) cin >> arr2[j++] ;
        }

        sort (arr1 , arr1+n1 ) ;
        sort (arr2 , arr2+n2 ) ;
        i = 0 ; j = 0 ;
        int res = -1 ;
        int x = 0 ;
        while (i + j  < n )
        {
            //cout <<  arr1[i++] << " " ;
            arr[x++] = arr1[i++] ;
            if (i + j  < n) arr[x++] = arr2[j++] ;
        }
        //for (int i = 0 ; i < n ; i++ ) cout << arr[i] << " ";
        for (int i = 1 ; i < n ; i++)
        {
            if (arr[i] < arr[i-1])
            {
                res = i-1 ;
                break ;
            }
        }
        if (res == -1) cout << "OK" << endl ;
        else cout << res << endl ;
    }

    return 0 ;
}
