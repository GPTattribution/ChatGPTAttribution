#include <iostream>
#include <algorithm>
using namespace std;

struct pa
{
    char ch ;
    int val ;
} ;

bool compareInterval(pa i1, pa i2)
{
    return (i1.val < i2.val );
}

int main() {
	int t ;
	cin >> t;
	for (int i = 0 ; i < t ; i++)
	{
	    cout << "Case #" << i+1 << ": " ;
	   int n ;
	   cin >> n ;
	   struct pa arr[n] ;
	   int sum = 0 ;
	   for (int i = 0 ; i < n ; i++)
	   {
	       cin >> arr[i].val ;
	       arr[i].ch = 'A' + i ;
	       sum += arr[i].val ;
	   }

	   while (sum > 0)
	   {

	   sort(arr, arr+n, compareInterval);

	   struct pa t1 = arr[n-1] ;
	   struct pa t2 = arr[n-2] ;
	   if (t1.val == t2.val)  {
	       if (sum == 3)
	       {
	           sum -= 1 ;
	           cout << t1.ch <<  " " ;
	           arr[n-1].val -= 1;
	       }
	       else {
	       sum -= 2 ;
	       cout << t1.ch << t2.ch << " " ;
	       arr[n-1].val -= 1; arr[n-2].val -= 1;
	       }
	   }
	   else {
	      /* sum -= 1 ;
	       cout << t1.ch <<  " " ;
	       arr[n-1].val -= 1;
	       */
	       sum -= 2 ;
	       if (t1.val - t2.val > 1) {
	           cout << t1.ch << t1.ch << " " ;
	           arr[n-1].val -= 2 ;
	       } else {
	       cout << t1.ch << t2.ch << " " ;
	       arr[n-1].val -= 1; arr[n-2].val -= 1;
	       }
	   }

	   }
	   cout << endl ;
	}
	return 0;
}
