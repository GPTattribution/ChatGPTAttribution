//hi
#include<bits/stdc++.h>
using namespace std;
#define PB push_back
#define MP make_pair
#define F first
#define S second
typedef long long int LL;
map<LL, LL> mp;
LL sol(LL k){
	while(true){
		LL len=mp.rbegin()->F;
		LL cnt=mp.rbegin()->S;
		mp.erase(len);
		if(k<=cnt) return len-1;
		k-=cnt;
		if(len%2==0){
			mp[len/2]+=cnt;
			mp[len/2-1]+=cnt;
		}else{
			mp[len/2]+=2LL*cnt;
		}
	}
}
int main(void){
    int t;
    scanf("%d",&t);
    for(int hh=1;hh<=t;hh++){
		LL k,n;
		scanf("%lld%lld",&n,&k);
		mp.clear();
		mp[n]=1;
		LL ans=sol(k);
		if(ans%2==0) printf("Case #%d: %lld %lld\n",hh,ans/2, ans/2);
		else printf("Case #%d: %lld %lld\n",hh,ans/2+1, ans/2);
	}
    return 0;
}
