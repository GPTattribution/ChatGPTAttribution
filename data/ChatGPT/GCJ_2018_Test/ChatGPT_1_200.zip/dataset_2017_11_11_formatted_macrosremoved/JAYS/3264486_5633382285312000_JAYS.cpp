#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

double find_phi(double A) {
    return 2 * acos((A - 1) / (A + 1));
}

vector<vector<double>> find_face_centers(double phi) {
    double half_side = 0.5;
    double x = half_side * cos(phi / 2);
    double y = half_side * sin(phi / 2);

    return {
        {x, y, 0},
        {-x, y, 0},
        {0, 0, half_side}
    };
}

int main() {
    int T;
    cin >> T;
    cout << fixed << setprecision(15);

    for (int i = 1; i <= T; ++i) {
        double A;
        cin >> A;

        double phi = find_phi(A);
        vector<vector<double>> face_centers = find_face_centers(phi);

        cout << "Case #" << i << ":" << endl;
        for (const auto &face_center : face_centers) {
            for (double coord : face_center) {
                cout << coord << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
