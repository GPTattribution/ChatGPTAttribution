//hi
#include<bits/stdc++.h>
using namespace std;
#define PB push_back
#define MP make_pair
#define F first
#define S second
typedef long long int LL;
struct AA{
	int id, cnt;
	bool operator<(const AA x)const{
		return cnt<x.cnt;
	}
}a[30];
priority_queue<AA> pq;
int main(void){
    int t;
    scanf("%d",&t);
    for(int hh=1;hh<=t;hh++){
		int n;
		scanf("%d",&n);
		int i;
		while(!pq.empty()) pq.pop();
		int sum=0;
		for(i=0;i<n;i++){
			scanf("%d",&a[i].cnt);
			a[i].id=i;
			pq.push(a[i]);
			sum+=a[i].cnt;
		}
		printf("Case #%d: ",hh);
		while(!pq.empty()){
			AA m=pq.top();
			pq.pop();
			printf("%c",char(m.id+'A'));
			m.cnt--;
			sum--;
			if(m.cnt!=0) pq.push(m);
			if(sum%2==0){ printf(" "); continue; }
			if(pq.empty()) break;
			m=pq.top();
			pq.pop();
			printf("%c",char(m.id+'A'));
			m.cnt--;
			sum--;
			if(m.cnt!=0) pq.push(m);
			printf(" ");
		}
		printf("\n");
	}
    return 0;
}
