//hi
#include<bits/stdc++.h>
using namespace std;
#define PB push_back
#define MP make_pair
#define F first
#define S second
typedef long long int LL;
int s[100005];
vector<int> even,odd;
int main(void){
    int t;
    scanf("%d",&t);
    for(int hh=1;hh<=t;hh++){
		int n;
		scanf("%d",&n);
		int i;
		even.clear();
		odd.clear();
		for(i=0;i<n;i++){
			scanf("%d",&s[i]);
			if(i%2==0) even.PB(s[i]);
			else odd.PB(s[i]);
		}
		sort(even.begin(), even.end());
		sort(odd.begin(), odd.end());
		bool ok=true;
		int ans=-1;
		int prev=even[0];
		for(i=1;i<n;i++){
			int cur;
			if(i%2==0) cur=even[i/2];
			else cur=odd[i/2];
			if(cur<prev){
				ans=i-1;
				ok=false;
				break;
			}
			prev=cur;
		}
		if(ok) printf("Case #%d: OK\n",hh);
		else printf("Case #%d: %d\n",hh,ans);
	}
    return 0;
}
