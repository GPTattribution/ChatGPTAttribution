//hi
#include<bits/stdc++.h>
using namespace std;
#define PB push_back
#define MP make_pair
#define F first
#define S second
typedef long long int LL;
int main(void){
    int t;
    scanf("%d",&t);
    for(int hh=1;hh<=t;hh++){
		int d, n;
		scanf("%d%d",&d,&n);
		int i;
		double mx=0;
		for(i=0;i<n;i++){
			int a,k;
			scanf("%d%d",&a,&k);
			mx=max(mx, double(d-a)/k);
		}
		printf("Case #%d: %.9lf\n", hh, double(d)/mx);
	}
    return 0;
}
