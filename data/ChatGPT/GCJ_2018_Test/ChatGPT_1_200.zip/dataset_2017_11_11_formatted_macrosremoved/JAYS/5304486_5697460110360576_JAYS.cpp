//hi
#include<bits/stdc++.h>
using namespace std;
#define PB push_back
#define MP make_pair
#define F first
#define S second
typedef long long int LL;
char s[40];
int n;
LL count(){
	LL ret=0;
	LL mul=1;
	for(int i=0;i<n;i++){
		if(s[i]=='S') ret+=mul;
		else mul<<=1;
	}
	return ret;
}
void swapbig(){
	for(int i=n-1;i>0;i--){
		if(s[i]=='S' && s[i-1]=='C'){
			swap(s[i], s[i-1]);
			return;
		}
	}
}
int main(void){
    int t;
    scanf("%d",&t);
    for(int hh=1;hh<=t;hh++){
		LL d;
		scanf("%lld%s",&d,s);
		n=strlen(s);
		int i;
		LL mn=0;
		for(i=0;i<n;i++) if(s[i]=='S') mn++;
		if(mn>d){
			printf("Case #%d: IMPOSSIBLE\n",hh);
		}else{
			for(i=0;;i++){
				LL g=count();
				if(g<=d) break;
				swapbig();
			}
			printf("Case #%d: %d\n",hh,i);
		}
	}
    return 0;
}
