//hi
#include<bits/stdc++.h>
using namespace std;
#define PB push_back
#define MP make_pair
#define F first
#define S second
typedef long long int LL;
char s[20];
int main(void){
    int t;
    scanf("%d",&t);
    for(;t>0;t--){
		int a,b;
		scanf("%d%d",&a,&b);
		int n;
		scanf("%d",&n);
		int l=a+1, r=b;
		bool find=false;
		while(l<=r){
			int mid=(l+r)/2;
			printf("%d\n",mid); fflush(stdout);
			scanf("%s",s);
			if(s[0]=='C'){
				find=true;
				break;
			}
			else if(s[4]=='S') l=mid+1;
			else r=mid-1;
		}
		if(!find){
			printf("%d\n",l); fflush(stdout);
			scanf("%s",s);
		}
	}
    return 0;
}
