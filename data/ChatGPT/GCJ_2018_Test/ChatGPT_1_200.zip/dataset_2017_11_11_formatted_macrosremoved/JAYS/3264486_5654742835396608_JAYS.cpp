//hi
#include<bits/stdc++.h>
using namespace std;
#define PB push_back
#define MP make_pair
#define F first
#define S second
typedef long long int LL;
int s[5][100];
int main(void){
    int t;
    scanf("%d",&t);
    for(;t>0;t--){
		int a;
		scanf("%d",&a);
		int i,j;
		for(i=1;i<=3;i++)
			for(j=1;j<=70;j++)
				s[i][j]=0;
		int c=2;
		int mx=66;
		if(a==20) mx=6;
		while(1){
			printf("%d %d\n",2,c); fflush(stdout);
			int x,y;
			scanf("%d%d",&x,&y);
			if(x==0 && y==0) break;
			s[x][y]=1;
			while(c<mx && s[1][c-1]==1 && s[2][c-1]==1 && s[3][c-1]==1) c++;
		}
	}
    return 0;
}
