#include <bits/stdc++.h>

using namespace std;



#define MAXN 1001
int dx[8] = {1,  1,  0, -1, -1, -1,  0,  1};
int dy[8] = {0, -1, -1, -1,  0,  1,  1,  1};
pair<int, int> ask(int i, int j) {
  printf("%d %d\n", i, j);
  fflush(stdout);
  scanf(" %d %d", &i, &j);
  return make_pair(i, j);
}

int m[MAXN][MAXN]={};
pair<int, int> greedy(int h, int w) {
  int oi = 0, oj = 0;
  int I, J, mx = -1;
  for (int i = 2+oi; i < h+oi; ++i) {
    for (int j = 2+oj; j < w+oj; ++j) {
      int cnt = 9-m[i][j];
      for (int di = 0; di < 8; ++di) {
        cnt -= m[i+dy[di]][j+dx[di]];
      }
      if (cnt>mx) {
        I = i;
        J = j;
        mx = cnt;
      }
      if (cnt==9) return {I, J};
    }
  }
  return {I, J};
}

bool sol() {
  memset(m, 0, sizeof(m));
  int a, ic, jc;
  cin >> a;
  int h = 3;
  while (h*h < a) ++h;
  int w = h;
  while (w-1>=3 && (w-1)*h > a) --w;
  assert(w*h>=a && h>=3 && w>=3);
  bool get_greedy = true;
  int i, j;
  while (true) {
    if (get_greedy) tie(i, j) = greedy(h, w);
    tie(ic, jc) = ask(i, j);
    if (!ic && !jc) return true;
    if (ic==-1 && jc==-1) return false;
    get_greedy = !m[ic][jc];
    m[ic][jc] = 1;
  }
  return true;
}

int main() {
  int t;
  scanf("%d", &t);
  while(t--) if (!sol()) break;
  return 0;
}
