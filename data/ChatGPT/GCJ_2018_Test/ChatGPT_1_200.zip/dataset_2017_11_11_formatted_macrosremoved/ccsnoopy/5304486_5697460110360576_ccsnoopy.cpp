#include <bits/stdc++.h>

using namespace std;


int damage(string &s) {
  int cur = 1, ret = 0;
  for (auto &c : s) {
    if (c=='C') cur *= 2;
    else ret += cur;
  }
  return ret;
}

bool swaps(string &s) {
  for (int i = s.size()-1; i >= 0; --i) {
    if (s[i]=='C' && i<s.size()-1 && s[i+1]=='S') {
      swap(s[i], s[i+1]);
      return true;
    }
  }
  return false;
}

void sol() {
  int d;
  string s;
  cin >> d >> s;
  int ans = 0;
  while(damage(s)>d) {
    if (!swaps(s)) {
      cout << "IMPOSSIBLE" << endl;
      return;
    }
    ans++;
  }
  cout << ans << endl;
}

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    cout << "Case #" << i << ": ";
    sol();
  }
  return 0;
}
