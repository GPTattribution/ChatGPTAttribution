#include <bits/stdc++.h>

using namespace std;


void sol() {
  int d, n;
  double t = 0;
  cin >> d >> n;
  for (int i = 0; i < n; ++i) {
    int k, s;
    cin >> k >> s;
    t = max(t, double(d-k)/s);
  }
  cout << fixed << setprecision(10) << d/t << "\n";
}

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    cout << "Case #" << i << ": ";
    sol();
  }
  return 0;
}
