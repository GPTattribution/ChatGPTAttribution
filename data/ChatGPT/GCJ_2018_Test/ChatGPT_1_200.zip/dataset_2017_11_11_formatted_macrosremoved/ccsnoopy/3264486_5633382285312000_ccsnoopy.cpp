#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

void solve(double A) {
    double area_ratio = A / 1.0;
    double edge_ratio = sqrt(area_ratio);
    double edge = 0.5 * edge_ratio;

    vector<vector<double>> result(3, vector<double>(3, 0.0));
    result[0][0] = edge;
    result[1][1] = edge;
    result[2][2] = 0.5;

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            cout << result[i][j];
            if (j < 2) cout << ' ';
        }
        cout << endl;
    }
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        cout << "Case #" << t << ":" << endl;
        solve(A);
    }

    return 0;
}
