#include <bits/stdc++.h>

using namespace std;



int ask(int &idx) {
  printf("%d\n", idx);
  fflush(stdout);
  char ans[30];
  scanf("%s", ans);
  if (strcmp(ans, "TOO_BIG")==0) return -1;
  if (strcmp(ans, "TOO_SMALL")==0) return 1;
  if (strcmp(ans, "CORRECT")==0) return 0;
  return 2;
}

void sol() {
  int lo, hi, n, mid;
  scanf("%d%d%d", &lo, &hi, &n);
  ++hi;
  while(lo+1<hi) {
    mid = (lo+hi)/2;
    int ans = ask(mid);
    if (ans==-1) hi = mid;
    else if (ans==1) lo = mid;
    else if (ans==0) return;
  }
  return;
}

int main() {
  int t;
  scanf("%d", &t);
  while(t--) sol();
  return 0;
}
