#include <bits/stdc++.h>

using namespace std;


#define MAXN 100001
void sol() {
  int n, a[2][MAXN], b[MAXN];
  cin >> n;
  for (int i = 0; i < n; ++i) {
    cin >> a[i%2][i/2];
  }
  sort(a[0], a[0]+(n+1)/2);
  sort(a[1], a[1]+n/2);
  for (int i = 0; i < n; ++i) {
    b[i] = a[i%2][i/2];
  }
  for (int i = 0; i < n-1; ++i) {
    if (b[i]>b[i+1]) {
      cout << i << endl;
      return;
    }
  }
  cout << "OK" << endl;
}

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    cout << "Case #" << i << ": ";
    sol();
  }
  return 0;
}
