#include <bits/stdc++.h>

using namespace std;



void sol() {
  int n;
  priority_queue<pair<char, int>, vector<pair<char, int>>> pq;
  cin >> n;
  for (int i = 0; i < n; ++i) {
    int p;
    cin >> p;
    pq.push({p, (char)i+'A'});
  }
  while (!pq.empty()) {
    int p1, p2;
    char c1, c2;
    tie(p1, c1) = pq.top();
    pq.pop();
    cout << " " << c1;
    if (pq.size() == 1) {
      tie(p2, c2) = pq.top();
      pq.pop();
      if (pq.size() && pq.top().first!=p1 || p1==p2) {
        cout << c2;
        p2--;
      }
      if (p2) pq.push({p2, c2});
    }
    p1--;
    if (p1) pq.push({p1, c1});
  }
}

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  int t;
  cin >> t;
  for (int i = 1; i <= t; ++i) {
    cout << "Case #" << i << ":";
    sol();
    cout << "\n";
  }
  return 0;
}
