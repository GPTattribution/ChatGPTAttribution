/**
 * Author:   Cheng-Shih Wong
 * Email:    mob5566@gmail.com
 * Date:     2018-04-01
 */
#include <bits/stdc++.h>

using namespace std;

#define MAXN 27
typedef pair<int, int> PII;
typedef stack<PII> SII;

int main(int argc, char *argv[]) {
	int tt, ti;
	int n, p[MAXN];
	int max, smax;
	int maxi, smaxi;
	PII tmpp;
	int i;

	scanf("%d", &tt);

	for (ti = 1; ti <= tt; ++ti) {
		printf("Case #%d:", ti);
		SII stk;

		scanf("%d", &n);

		for (i = 0; i < n; i++) {
			scanf("%d", &p[i]);
		}

		while(true) {
			max = smax = maxi = smaxi = -1;
			for (i = 0; i < n; ++i) {
				if (max < p[i]) {
					smax = max;
					smaxi = maxi;
					max = p[i];
					maxi = i;
				} else if (smax < p[i]) {
					smax = p[i];
					smaxi = i;
				}
			}

			if (0 == max) {
				break;
			}

			stk.push(make_pair(maxi, p[smaxi] ? smaxi : -1));
			--p[maxi];
			--p[smaxi];
		}

		if(!stk.empty()) {
			tmpp = stk.top(); stk.pop();
			if (tmpp.second == -1) {
				printf(" %c", tmpp.first+'A');
			} else {
				printf(" %c%c", tmpp.first+'A', tmpp.second+'A');
			}
		}

		while(!stk.empty()) {
			tmpp = stk.top(); stk.pop();
			printf(" %c%c", tmpp.first+'A', tmpp.second+'A');
		}
		putchar('\n');

		fprintf(stderr, "## test case %d solved at %.3f sec ##\n",
			ti, (double)clock()/CLOCKS_PER_SEC);
	}

	return 0;
}
