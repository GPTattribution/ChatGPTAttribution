#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;

struct Point {
    double x, y, z;
};

double shadow_area(double a) {
    return sqrt(1 - (a - 1) * (a - 1));
}

vector<Point> get_face_centers(double a) {
    double theta = acos(shadow_area(a));
    double half_side = 0.5;
    return {
        {half_side * cos(theta), half_side * sin(theta), 0},
        {half_side * cos(theta + M_PI / 2), half_side * sin(theta + M_PI / 2), 0},
        {0, 0, half_side}
    };
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        cin >> A;
        vector<Point> face_centers = get_face_centers(A);
        cout << "Case #" << t << ":" << endl;
        cout << fixed << setprecision(15);
        for (const auto &point : face_centers) {
            cout << point.x << " " << point.y << " " << point.z << endl;
        }
    }
    return 0;
}
