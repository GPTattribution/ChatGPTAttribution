/**
 * Author:   Cheng-Shih Wong
 * Email:    mob5566@gmail.com
 * Date:
 */
#include <bits/stdc++.h>

using namespace std;

typedef unsigned long long ULL;


int main(int argc, char *argv[]) {
	int tt, ti;
	ULL N, K, acc;
	ULL ls, rs, nls, nrs;
	ULL ansl, ansr;
	int i;

	scanf("%d", &tt);

	for (ti = 1; ti <= tt; ++ti) {
		printf("Case #%d:", ti);

		scanf("%llu%llu", &N, &K);

		acc = 0;
		ls = 0, rs = 1;

		while (true) {
			acc += rs;
			if (acc >= K) {
				if (N & 1) {
					ansl = ansr = N/2;
				} else {
					ansl = N/2;
					ansr = N/2-1;
				}
				break;
			}
			acc += ls;
			if (acc >= K) {
				if (N & 1) {
					ansl = (N-1)/2;
					ansr = (N-1)/2-1;
				} else {
					ansl = ansr = (N-1)/2;
				}
				break;
			}

			if (N & 1) {
				nrs = rs * 2 + ls;
				nls = ls;
			} else {
				nrs = rs;
				nls = ls * 2 + rs;
			}

			N /= 2;
			rs = nrs;
			ls = nls;
		}

		printf(" %llu %llu\n", ansl, ansr);

		fprintf(stderr, "## test case %d solved at %.3f sec ##\n",
			ti, (double)clock()/CLOCKS_PER_SEC);
	}

	return 0;
}
