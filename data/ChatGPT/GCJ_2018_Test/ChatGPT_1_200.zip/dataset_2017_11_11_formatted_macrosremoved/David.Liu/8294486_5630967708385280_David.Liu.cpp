/**
 * Author:   Cheng-Shih Wong
 * Email:    mob5566@gmail.com
 * Date:
 */
#include <bits/stdc++.h>

using namespace std;

#define MAXN 1005
#define EPS 1e-6

typedef struct {
	double k;
	double s;
	double nt;
} Horse;

inline int dcmp(double v) {
	return v < -EPS ? -1 : v > EPS;
}

int hcmp(Horse a, Horse b) {
	return dcmp(b.nt - a.nt) > 0;
}

int main(int argc, char *argv[]) {
	int tt, ti;
	int i;
	Horse H[MAXN];
	int N;
	double D;
	double ultraspeed;

	scanf("%d", &tt);

	for (ti = 1; ti <= tt; ++ti) {
		printf("Case #%d:", ti);

		scanf("%lf%d", &D, &N);

		for (i = 0; i < N; ++i) {
			scanf("%lf%lf", &H[i].k, &H[i].s);
			H[i].nt = (D-H[i].k)/H[i].s;
		}

		sort(H, H+N, hcmp);

		for (i = 0; i < N; ++i) {
			fprintf(stderr, "%lf ", H[i].nt);
		}
		fputs("\n", stderr);

		printf(" %.7lf\n", D/H[N-1].nt);

		fprintf(stderr, "## test case %d solved at %.3f sec ##\n",
			ti, (double)clock()/CLOCKS_PER_SEC);
	}

	return 0;
}
