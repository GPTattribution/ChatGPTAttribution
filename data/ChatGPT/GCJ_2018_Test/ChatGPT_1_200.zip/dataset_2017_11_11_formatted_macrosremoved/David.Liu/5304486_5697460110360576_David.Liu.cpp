/**
 * Author:   Cheng-Shih Wong
 * Email:    mob5566@gmail.com
 * Date:
 */
#include <bits/stdc++.h>

using namespace std;

#define PN 30

int main(int argc, char *argv[]) {
	int tt, ti;
	char ins[PN];
	int pl, D, cn;
	int sum;
	int pow[PN];
	int base, i;
	int ans;

	scanf("%d", &tt);

	for (ti = 1; ti <= tt; ++ti) {
		printf("Case #%d:", ti);

		scanf("%d%s", &D, ins);

		pl = strlen(ins);
		cn = count(ins, ins+pl, 'S');

		if (cn > D) {
			printf(" IMPOSSIBLE\n");
			continue;
		}

		memset(pow, 0, sizeof(pow));
		sum = base = 0;

		for (i = 0; i < pl; ++i) {
			if(ins[i] == 'C') {
				++base;
			} else {
				++pow[base];
			}
		}

		for (i = 0; i <= base; ++i) {
			sum += pow[i] * (1 << i);
		}

		ans = 0;
		while (base >= 1 && sum > D) {
			if (!pow[base]) {
				--base;
				continue;
			}

			++ans;
			--pow[base];
			++pow[base-1];
			sum -= (1 << (base-1));
		}

		printf(" %d\n", ans);

		//fprintf(stderr, "## test case %d solved at %.3f sec ##\n",
			//ti, (double)clock()/CLOCKS_PER_SEC);
	}

	return 0;
}
