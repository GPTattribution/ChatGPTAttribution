/**
 * Author:   Cheng-Shih Wong
 * Email:    mob5566@gmail.com
 * Date:
 */
#include <bits/stdc++.h>

using namespace std;

#define MAXS 256

int main(int argc, char *argv[]) {
	int tt, ti;
	int a, b, n;
	int mid;
	char buf[MAXS];

	scanf("%d", &tt);

	for (ti = 1; ti <= tt; ++ti) {
		cin >> a >> b >> n;
		a += 1;

		while(a <= b) {
			mid = (a+b)/2;

			printf("%d\n", mid);
			fflush(stdout);

			scanf("%s", buf);
			if (!strcmp("WRONG_ANSWER", buf)) {
				goto END;
			} else if (!strcmp("TOO_SMALL", buf)) {
				a = mid+1;
			} else if (!strcmp("TOO_BIG", buf)) {
				b = mid-1;
			} else {
				break;
			}
		}
	}

END:

	return 0;
}
