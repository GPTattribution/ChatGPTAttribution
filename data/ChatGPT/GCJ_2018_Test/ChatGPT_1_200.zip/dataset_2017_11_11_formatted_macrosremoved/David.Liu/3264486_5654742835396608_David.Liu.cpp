/**
 * Author:   Cheng-Shih Wong
 * Email:    mob5566@gmail.com
 * Date:
 */
#include <bits/stdc++.h>

using namespace std;

#define MAXN 1005
#define FULL ((1<<9)-1)

enum {
	FAIL = -1,
	SUCCESS,
	PASS,
};

int fill(int r, int c) {
	int fill = 0;
	int rr, cc;

	while ((fill&FULL) != FULL) {
		printf("%d %d\n", r, c);
		fflush(stdout);

		scanf("%d%d", &rr, &cc);

		if (rr == -1 && cc == -1) {
			return FAIL;
		} else if (rr == 0 && cc == 0) {
			return PASS;
		}

		fill |= (1 << ((rr-r+1)*3 + (cc-c+1)));
	}

	return SUCCESS;
}

int main(int argc, char *argv[]) {
	int tt, ti;
	int A;
	int acc;
	int r, c;

	scanf("%d", &tt);

	for (ti = 1; ti <= tt; ++ti) {
		//printf("Case #%d:", ti);

		scanf("%d", &A);

		acc = 0;
		r = c = 2;

		while(acc < A) {
			switch(fill(r, c)) {
			case FAIL:
				goto ERR;
			case PASS:
				goto CON;
			default:
				break;
			}
			r += 3;
		}

CON:
		fprintf(stderr, "## test case %d solved at %.3f sec ##\n",
			ti, (double)clock()/CLOCKS_PER_SEC);
	}

ERR:
	return 0;
}
