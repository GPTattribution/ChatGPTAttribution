/**
 * Author:   Cheng-Shih Wong
 * Email:    mob5566@gmail.com
 * Date:
 */
#include <bits/stdc++.h>

using namespace std;

#define MAXN 100005

int main(int argc, char *argv[]) {
	int tt, ti;
	int N, V[MAXN];
	int ss[2][MAXN];
	int l[2];
	int i;

	scanf("%d", &tt);

	for (ti = 1; ti <= tt; ++ti) {
		printf("Case #%d:", ti);

		scanf("%d", &N);
		for (i = 0; i < N; ++i) {
			scanf("%d", &ss[i & 1][i >> 1]);
		}

		l[0] = l[1] = N / 2;
		l[0] += (N&1);

		sort(ss[0], ss[0]+l[0]);
		sort(ss[1], ss[1]+l[1]);

		V[0] = ss[0][0];
		for (i = 1; i < N; ++i) {
			V[i] = ss[i & 1][i >> 1];
			if (V[i] < V[i-1])
				break;
		}

		if (i == N) {
			puts(" OK");
		} else {
			printf(" %d\n", i-1);
		}

	}

	return 0;
}
