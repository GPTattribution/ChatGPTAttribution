#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
const int maxn = 30;
int num[maxn];
int n, sum;
int deal(int x){
	if(num[x] <= 0) return 0;
	num[x]--; sum--;
	for(int i = 0; i < n; i++) if(num[i] * 2 > sum){
		num[x]++; sum++;
		return 0;
	}
	printf("%c ", x + 'A');
	return 1;
}
int deal(int x, int y){
	if(num[x] <= 0) return 0;
	num[x]--;
	if(num[y] <= 0){
		num[x] ++;
		return 0;
	}
	num[y]--; sum -= 2;
	for(int i = 0; i < n; i++) if(num[i] * 2 > sum){
		num[x]++; num[y]++; sum+=2;
		return 0;
	}
	printf("%c%c ", x + 'A', y + 'A');
	return 1;
}
int main(){
	//freopen("main.in", "r", stdin);
	int t; scanf(" %d", &t);
	int cnt = 0;
	while(t--){
		scanf(" %d", &n);
		sum = 0;
		for(int i = 0; i < n; i++){
		       	scanf(" %d", num + i);
			sum += num[i];
		}
		printf("Case #%d: ", ++cnt);
		while(sum){
			for(int i = 0; i < n; i++){
				for(int j = i; j < n; j++){
					if(deal(i, j)) break;
				}
			}
			for(int i = 0; i < n; i++){
				if(deal(i)) break;
			}
		}
		puts("");
	}
	return 0;
}
