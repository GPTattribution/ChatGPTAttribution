#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
const int maxn = 35;
char p[maxn];
int val[maxn];
int n;
int d;
int l;
int sum;
void updateL(){
	int maxVal = 0;
	for(int i = 1; i <= n; i++)
		maxVal = max(maxVal, val[i]);
	for(int i = 1; i <= n; i++) if(val[i] == maxVal) {
		l = i; break;
	}
}
void pre_work(){
	sum = 0;
	int cur = 1;
	for(int i = 1; i <= n; i++) {
		if(p[i] == 'S') {val[i] = cur; sum += cur;}
		else cur <<= 1;
	}
}
int work(){
	int cnt = 0;
	while(sum > d){
		cnt++;
		updateL();
		if(l == 1) break;
		swap(val[l], val[l-1]);
		swap(p[l], p[l-1]);
		sum -= val[l-1] - (val[l-1] >> 1);
		val[l-1] >>= 1;
	}
	return cnt;
}
int main(){
#ifdef __APPLE__
	freopen("main.in", "r", stdin);
#endif
	int t; scanf(" %d", &t);
	int cnt = 0;
	while(t--){
		scanf(" %d %s", &d, p + 1);
		n = strlen(p + 1);
		pre_work();
		int ans = work();
		if(sum <= d) printf("Case #%d: %d\n", ++cnt, ans);
		else printf("Case #%d: IMPOSSIBLE\n", ++cnt);
	}
	return 0;
}
