#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
char response[1005];
int l, r;
int n;
int main(){
	int t; cin >> t;
	while(t--){
		scanf(" %d%d%d", &l, &r, &n);
		int flag = 0;
		while(l + 1 < r){
			int mid = (l + r) >> 1;
			cout << mid  << endl;
			flush(cout);
			scanf(" %s", response);
			if(response[0] == 'C'){
				flag = 1;
				break;
			} else if(response[4] == 'S'){
				l = mid;
			} else if(response[4] == 'B'){
				r = mid - 1;
			} else {
				return 1;
			}
		}
		if(!flag){
			cout << r << endl;
			flush(cout);
			scanf(" %s", response);
		}
	}
	return 0;
}
