#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main() {
    int T;
    double A;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        cin >> A;
        double theta = asin(A / sqrt(2));
        double x = 0.5 * cos(theta);
        double z = 0.5 * sin(theta);

        cout << fixed << setprecision(15);
        cout << "Case #" << t << ":" << endl;
        cout << x << " " << 0.0 << " " << z << endl;
        cout << -z << " " << 0.0 << " " << x << endl;
        cout << 0.0 << " " << 0.5 << " " << 0.0 << endl;
    }

    return 0;
}
