#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
int n;
double d;
int main(){
	//freopen("main.in", "r", stdin);
	int t; scanf(" %d", &t);
	int cnt = 0;
	while(t--){
		scanf(" %lf%d", &d, &n);
		double max_t = 0.00000001;
		for(int i = 1; i <= n; i++){
			int k, s; scanf(" %d%d", &k, &s);
			max_t = max((d-k)/s, max_t);
		}
		printf("Case #%d: %.10f\n", ++cnt, d / max_t);
	}
	return 0;
}
