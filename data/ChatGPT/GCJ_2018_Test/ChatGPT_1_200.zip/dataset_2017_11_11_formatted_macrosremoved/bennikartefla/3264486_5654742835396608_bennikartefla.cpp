#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
using namespace std;
int vis[4][4];
int A;
int ooflag;
bool check(){
	for(int i = 0; i < 3; i++)
		for(int j = 0; j < 3; j++)
			if(!vis[i][j]) return false;
	return true;
}
void mark(int x, int y){
	while(!check()){
		cout << x << " " << y << endl;
		flush(cout);
		int x1, y1;
		cin >> x1 >> y1;
		if(x1 == -1 && y1 == -1) exit(1);
		if(x1 == 0 && y1 == 0) { ooflag = 1; return;}
		vis[x1 - x + 1][y1 - y + 1] = 1;
	}
}
void work(){
	ooflag = 0;
	int sum = 0;
	for(int i = 2; i <= 999; i += 3){
		memset(vis, 0, sizeof(vis));
		mark(2, i);
		sum += 9;
		if(sum >= A) break;
	}
	if(!ooflag) {
		cout << "2 2" << endl; flush(cout);
		int tx, ty; cin >> tx >> ty;
		if(tx != 0 || ty != 0) exit(2);
	}
}
int main(){
	int t; cin >> t;
	while(t--){
		cin >> A;
		work();
	}
	return 0;
}
