#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
typedef long long LL;
LL n, k;
LL wid[2], num[2];
LL le[2], numl[2];
LL ri[2], numr[2];
int h_bit(LL x){
	for(int i = 63; i >= 0; i--)
		if((x >> i) & 1) return i;
	return -1;
}
void add(int at, int wi, int nu){
	if(nu == 0 || wi == 0) return;
	wid[at] = wi;
	num[at] += nu;
}
void update(int wi, int nu){
	if(wid[0] == 0){ wid[0] = wi; num[0] = nu; }
	else if(wi == wid[0]) add(0, wi, nu);
	else add(1, wi, nu);
}
int main(){
	//freopen("main.in", "r", stdin);
	int t; scanf(" %d", &t);
	int cnt = 0;
	while(t--){
		scanf(" %lld%lld", &n, &k);
		LL pre = h_bit(k); k -= (1ll << pre) - 1;
		wid[0] = n; num[0] = 1;
		wid[1] = num[1] = 0;
		for(int i = 0; i < pre; i++){
			for(int k = 0; k < 2; k++){
				LL mid = (1 + wid[k]) >> 1;
				le[k] = mid - 1;
				numl[k] = num[k];
				ri[k] = wid[k] - mid;
				numr[k] = num[k];
			}
			wid[0] = wid[1] = 0;
			num[0] = num[1] = 0;
			update(le[0], numl[0]);
			update(ri[0], numr[0]);
			update(le[1], numl[1]);
			update(ri[1], numr[1]);
		}
		if(wid[0] > wid[1]){
			swap(wid[0], wid[1]);
			swap(num[0], num[1]);
		}
		LL ls, rs;
		LL wi;
		if(k <= num[1]) wi = wid[1];
		else  wi = wid[0];

		LL mid = (1 + wi) >> 1;
		ls = mid - 1;
		rs = wi - mid;

		printf("Case #%d: %lld %lld\n", ++cnt, max(ls, rs), min(ls, rs));
	}

	return 0;
}
