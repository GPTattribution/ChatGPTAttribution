#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>
using namespace std;
const int maxn = 100005;
int a[maxn];
int n;
vector <int> odd;
vector <int> even;
void work(){
	sort(odd.begin(), odd.end());
	sort(even.begin(), even.end());
	int p_odd = 0, p_even = 0, p_a = 1;
	while(p_a <= n){
		if(p_a & 1) {
			a[p_a] = odd[p_odd]; p_odd++;
		} else {
			a[p_a] = even[p_even]; p_even++;
		}
		p_a ++;
	}
	for(int i = 1; i < n; i++){
		if(a[i] > a[i+1]) {
			printf("%d\n", i-1); return;
		}
	}
	puts("OK");
}
int main(){
#ifdef __APPLE__
	freopen("main.in", "r", stdin);
#endif
	int t; scanf(" %d", &t);
	int cnt = 0;
	while(t--){
		scanf(" %d", &n);
		odd.clear(); even.clear();
		for(int i = 1; i <= n; i++){
			int tmp; scanf(" %d", &tmp);
			if(i & 1) odd.push_back(tmp);
			else even.push_back(tmp);
		}
		printf("Case #%d: ", ++cnt);
		work();
	}
	return 0;
}
