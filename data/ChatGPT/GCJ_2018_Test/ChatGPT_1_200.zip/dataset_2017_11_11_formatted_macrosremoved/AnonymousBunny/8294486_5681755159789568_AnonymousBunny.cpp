#include<bits/stdc++.h>

using namespace std;

typedef vector<double> vd;
typedef vector<vd> vvd;
typedef vector<vvd> vvvd;
typedef vector<char> vc;
typedef vector<vc> vvc;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef long long ll;
typedef vector<long long> vll;
typedef vector<vll> vvll;
typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef vector<bool> vb;
typedef vector<vb> vvb;

#define pb push_back
#define ctz __builtin_ctz
#define db(x) cerr << #x << "=" << x << endl
#define db2(x, y) cerr << #x << "=" << x << "," << #y << "=" << y << endl
#define db3(x, y, z) cerr << #x << "=" << x << "," << #y << "=" << y << "," << #z << "=" << z << endl

vi v,vs[1005];
int sum,n;

void callWhenHalf(int i) {
	vii ans;
	char str[3];
	str[2]='\0';
	str[0]='A'+i;
	for(int j=0;j<n;++j) {
		if(j!=i) {
			str[1]='A'+j;
			while(v[j]--) printf(" %s",str);
		}
	}
	for(int j=0;j<1005;++j) vs[j].clear();
	sum=0;
}

int main() {
	int tc,cur;
	scanf("%d",&tc);
	for(int cn=1;cn<=tc;++cn) {
		scanf("%d",&n);
		sum=0;
		v=vi(n);
		for(int i=0;i<1005;++i) vs[i].clear();
		for(int i=0;i<n;++i) {
			scanf("%d",&cur);
			v[i]=cur;
			sum+=cur;
			vs[cur].pb(i);
		}
		printf("Case #%d:",cn);
		bool can=1;
		for(int i=1000;i>0;--i) {
			while(!vs[i].empty()) {
				int k=vs[i].back();
				if(i*2==sum) {
					callWhenHalf(k);
				} else {
					--sum;--v[k];
					printf(" %c",'A'+k);
					vs[i].pop_back();
					vs[i-1].pb(k);
				}
			}
			if(can==0) break;
		}
		printf("\n");
	}
}
