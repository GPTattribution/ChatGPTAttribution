#include<bits/stdc++.h>

using namespace std;

typedef vector<double> vd;
typedef vector<vd> vvd;
typedef vector<vvd> vvvd;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<vc> vvc;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef long long ll;
typedef vector<long long> vll;
typedef vector<vll> vvll;
typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef vector<bool> vb;
typedef vector<vb> vvb;

#define pb push_back
#define ctz __builtin_ctz
#define db(x) cerr << #x << "=" << x << endl
#define db2(x, y) cerr << #x << "=" << x << "," << #y << "=" << y << endl
#define db3(x, y, z) cerr << #x << "=" << x << "," << #y << "=" << y << "," << #z << "=" << z << endl

const ll inf=-1;

struct lvl {
	ll a,b,c,d;
	lvl(ll a,ll b,ll c,ll d):a(a),b(b),c(c),d(d) {}
	lvl() {}
};

lvl split(lvl l) {
	if(l.b&1LL) {
		if(l.d==inf) return lvl(l.a*2,l.b/2,0,inf);
		return lvl(l.a*2+l.c,l.b/2,l.c,l.b/2-1);
	}
	if(l.d==inf) return lvl(l.a,l.b/2,l.a,l.b/2-1);
	return lvl(l.a,l.b/2,l.a+2*l.c,l.b/2-1);
}

void print(lvl l) {
	printf("(%lld,%lld,%lld,%lld)\n",l.a,l.b,l.c,l.d);
}

int main() {
	int tc;
	ll n,k;
	scanf("%d",&tc);
	for(int q=1;q<=tc;++q) {
		scanf("%lld%lld",&n,&k);
		int d=0;
		lvl l(1LL,n,0,inf);
		while(l.a+l.c<k) {
			//print(l);
			k-=1LL<<d;
			l=split(l);
			++d;
		}
		ll ans;
		if(k<=l.a) ans=l.b;
		else ans=l.d;
		if(ans&1LL) printf("Case #%d: %lld %lld\n",q,ans/2,ans/2);
		else printf("Case #%d: %lld %lld\n",q,ans/2,ans/2-1);
	}

}
