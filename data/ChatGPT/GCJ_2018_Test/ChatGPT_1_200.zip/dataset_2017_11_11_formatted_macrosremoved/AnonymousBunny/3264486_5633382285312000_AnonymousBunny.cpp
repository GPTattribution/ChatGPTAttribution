#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void face_center_coordinates(double A) {
    double max_area = sqrt(2);

    double theta = (A - 1) / (max_area - 1) * (M_PI / 4);

    double x = 0.5 * cos(theta);
    double y = 0.5 * sin(theta);

    cout << x << " " << y << " " << 0.0 << endl;
    cout << -x << " " << y << " " << 0.0 << endl;
    cout << 0.0 << " " << 0.0 << " " << 0.5 << endl;
}

int main() {
    int T;
    double A;
    cin >> T;

    cout << fixed << setprecision(15);

    for (int t = 1; t <= T; ++t) {
        cin >> A;
        cout << "Case #" << t << ":" << endl;
        face_center_coordinates(A);
    }

    return 0;
}
