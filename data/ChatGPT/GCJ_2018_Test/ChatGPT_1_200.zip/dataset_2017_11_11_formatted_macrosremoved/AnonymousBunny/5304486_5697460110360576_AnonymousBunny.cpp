#include<bits/stdc++.h>

using namespace std;

typedef vector<double> vd;
typedef vector<vd> vvd;
typedef vector<vvd> vvvd;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<vc> vvc;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef long long ll;
typedef vector<long long> vll;
typedef vector<vll> vvll;
typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef vector<bool> vb;
typedef vector<vb> vvb;

#define pb push_back
#define ctz __builtin_ctz
#define db(x) cerr << #x << "=" << x << endl
#define db2(x, y) cerr << #x << "=" << x << "," << #y << "=" << y << endl
#define db3(x, y, z) cerr << #x << "=" << x << "," << #y << "=" << y << "," << #z << "=" << z << endl

const int maxn=40;

ll p[maxn];

int main() {
	p[0]=1;
	for(int i=1;i<maxn;++i) p[i]=2*p[i-1];
	int tc;
	ll d;
	char str[35];
	scanf("%d",&tc);
	for(int cn=1;cn<=tc;++cn) {
		scanf("%lld %s",&d,str);
		int charge=0;
		ll s=0,dmg=0;
		int len=strlen(str);
		bool can=1;
		vi shots(maxn,0);
		for(int i=0;i<len;++i) {
			if(str[i]=='C') ++charge;
			else {
				++shots[charge];
				++s;
				dmg+=p[charge];
			}
		}
		if(s>d) printf("Case #%d: IMPOSSIBLE\n",cn);
		else {
			int ans=0,idx=maxn-1;
			while(dmg>d) {
				while(shots[idx]==0) --idx;
				--shots[idx];
				++shots[idx-1];
				++ans;
				dmg-=p[idx-1];
				//db2(idx,dmg);
			}
			printf("Case #%d: %d\n",cn,ans);
		}
	}
}
