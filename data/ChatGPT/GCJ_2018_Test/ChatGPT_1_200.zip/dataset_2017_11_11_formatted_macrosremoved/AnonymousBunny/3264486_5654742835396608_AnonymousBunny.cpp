#include<bits/stdc++.h>

using namespace std;

typedef vector<double> vd;
typedef vector<vd> vvd;
typedef vector<vvd> vvvd;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<vc> vvc;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef long long ll;
typedef vector<long long> vll;
typedef vector<vll> vvll;
typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef vector<bool> vb;
typedef vector<vb> vvb;

#define pb push_back
#define ctz __builtin_ctz
#define db(x) cerr << #x << "=" << x << endl
#define db2(x, y) cerr << #x << "=" << x << "," << #y << "=" << y << endl
#define db3(x, y, z) cerr << #x << "=" << x << "," << #y << "=" << y << "," << #z << "=" << z << endl
#define conv(i, j) (i*5+j)
#define conv2(i, j) (i*20+j)

int dx[9]={1,1,1,0,0,0,-1,-1,-1};
int dy[9]={1,0,-1,1,0,-1,1,0,-1};
int N;

void go() {
	vvi v(N,vi(N,9)),filled(N,vi(N,0));
	int a,b;
	for(int i=0;i<1000;++i) {
		int ansx=1,ansy=1,best=0;
		for(int x=1;x<N-1;++x) {
			for(int y=1;y<N-1;++y) {
				if(v[x][y]>best) {
					best=v[x][y];
					ansx=x;ansy=y;
				}
			}
		}
		cout<<ansx+500<<" "<<ansy+500<<endl;
		cin>>a>>b;
		if(a==0 && b==0) return;
		if(a==-1 && b==-1) return;
		a-=500;b-=500;
		if(!filled[a][b]) {
			filled[a][b]=1;
			for(int j=0;j<9;++j) {
				int na=a+dx[j],nb=b+dy[j];
				if(na>0 && nb>0 && na<N-1 && nb<N-1) --v[na][nb];
			}
		}
	}
}

int main() {
	int tc,a;
	cin>>tc;
	while(tc--) {
		cin>>a;
		if(a==20) N=5;
		else N=15;
		go();
	}
}
