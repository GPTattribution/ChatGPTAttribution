#include<bits/stdc++.h>

using namespace std;

typedef vector<double> vd;
typedef vector<vd> vvd;
typedef vector<vvd> vvvd;
typedef vector<string> vs;
typedef vector<char> vc;
typedef vector<vc> vvc;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef long long ll;
typedef vector<long long> vll;
typedef vector<vll> vvll;
typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef vector<bool> vb;
typedef vector<vb> vvb;

#define pb push_back
#define ctz __builtin_ctz
#define db(x) cerr << #x << "=" << x << endl
#define db2(x, y) cerr << #x << "=" << x << "," << #y << "=" << y << endl
#define db3(x, y, z) cerr << #x << "=" << x << "," << #y << "=" << y << "," << #z << "=" << z << endl



int main() {
	int tc,d,n,k,v;
	scanf("%d",&tc);
	for(int cn=1;cn<=tc;++cn) {
		scanf("%d%d",&d,&n);
		vii horses;
		for(int i=0;i<n;++i) {
			scanf("%d%d",&k,&v);
			horses.pb(ii(k,v));
		}
		sort(horses.begin(), horses.end());
		double maxt=0;
		for(int i=0;i<n;++i) {
			double t=double(d-horses[i].first)/horses[i].second;
			maxt=max(maxt,t);
		}
		double ans=d;
		ans/=maxt;
		printf("Case #%d: %.6lf\n",cn,ans);
	}
}
