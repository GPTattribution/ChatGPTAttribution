#include <iostream> // includes cin to read from stdin and cout to write to stdout
#include <map>
#include <set>
#include <list>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <cassert>
#include <math.h>
#include <iomanip>
#include <limits>
#define FOR(i,a,b) for(int i=(a),_b=(b);i<=_b;i++)
#define REP(i,n) FOR(i,0,(n)-1)
#define FORD(i,a,b) for(int i=(a),_b=(b);i>=_b;i--)
#define sz size()
#define FORA(i,c) REP(i,size(c))

#define itype(c) __typeof((c).begin())
#define FORE(e,c) for(itype(c) e=(c).begin();e!=(c).end();e++)
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define SORT(x) sort(all(x))
#define REVERSE(x) reverse(all(x))
#define CLEAR(x,c) memset(x,c,sizeof(x))
#define amfor(Iterator, Container) 	for ( auto Iterator = begin(Container); (Iterator) != end(Container); ++(Iterator) )
#define ramfor(Iterator, Container) for ( auto Iterator = Container.rbegin(); (Iterator) != Container.rend(); ++(Iterator) )
template<class C, class E> inline bool contains(const C& container, const E& element) { return container.find(element) != container.end(); }
#define  NP(nn,ta,a,tb,b) struct nn : pair<ta,tb> { nn():pair<ta,tb>(){}; nn(ta pa,tb pb):pair<ta,tb>(pa,pb){} ta& a(){return first;} tb& b(){return second;} };
template<class T> inline void checkmin(T &a, T b) { if (b < a) a = b; }//asigna en a el minimo
template<class T> inline void checkmax(T &a, T b) { if (b > a) a = b; }//asigna en a el maximo


using namespace std; // since cin and cout are both in namespace std, this saves some text
long long a, b, n;
vector<int> vals;
char Letter(vector<int>::iterator it)
{
	return 'A' + (it - vals.begin());
}

void Solve()
{
	int ps;
	cin >> ps;
	int tot = 0;
	vals = vector<int>(ps);
	REP(i, ps)
	{
		cin >> vals[i];
		tot+= vals[i];
	}
	while (tot != 0)
	{
		auto pos1 = std::max_element(all(vals));
		int v1 = *pos1;
		(*pos1)--;
		--tot;
		cout << Letter(pos1);
		if(tot != 0)
		{
			auto pos2 = std::max_element(all(vals));
			int v2 = *pos2;
			if (2*v2 > tot)
			{
				(*pos2)--;
				--tot;
				cout << Letter(pos2);
			}
		}
		cout << " ";
	}

}

int main()
{
	int totalCases;
	cin >> totalCases;
	cout << std::setprecision(15);
	cout << std::fixed;

	REP(theCase, totalCases)
	{
		cerr << theCase << endl;
		cout << "Case #" << theCase + 1 << ": ";
		Solve();
		cout << endl;
	}
	return 0;
}
