#include <iostream> // includes cin to read from stdin and cout to write to stdout
#include <map>
#include <set>
#include <list>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <cassert>
#include <math.h>
#include <iomanip>
#include <limits>
#define FOR(i,a,b) for(int i=(a),_b=(b);i<=_b;i++)
#define REP(i,n) FOR(i,0,(n)-1)
#define FORD(i,a,b) for(int i=(a),_b=(b);i>=_b;i--)
#define sz size()
#define FORA(i,c) REP(i,size(c))

#define itype(c) __typeof((c).begin())
#define FORE(e,c) for(itype(c) e=(c).begin();e!=(c).end();e++)
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define SORT(x) sort(all(x))
#define REVERSE(x) reverse(all(x))
#define CLEAR(x,c) memset(x,c,sizeof(x))
#define amfor(Iterator, Container) 	for ( auto Iterator = begin(Container); (Iterator) != end(Container); ++(Iterator) )
#define ramfor(Iterator, Container) for ( auto Iterator = Container.rbegin(); (Iterator) != Container.rend(); ++(Iterator) )
template<class C, class E> inline bool contains(const C& container, const E& element) { return container.find(element) != container.end(); }
#define  NP(nn,ta,a,tb,b) struct nn : pair<ta,tb> { nn():pair<ta,tb>(){}; nn(ta pa,tb pb):pair<ta,tb>(pa,pb){} ta& a(){return first;} tb& b(){return second;} };
template<class T> inline void checkmin(T &a, T b) { if (b < a) a = b; }//asigna en a el minimo
template<class T> inline void checkmax(T &a, T b) { if (b > a) a = b; }//asigna en a el maximo


using namespace std; // since cin and cout are both in namespace std, this saves some text
long long a, b, n;
vector<int> valsI, valsP,res;

int Find()
{
	for (int i = 0; i < res.size() - 1;++i)
	{
		if (res[i] > res[i + 1])
			return i;
	}
	return -1;
}
void Solve()
{
	int s;
	cin >> s;
	valsP = vector<int>((s+1)/2);
	valsI = vector<int>(s-valsP.size());
	int p = 0;
	REP(i, s)
	{
		cin >> valsP[p];
		++i;
		if(i < s)
			cin >> valsI[p];
		++p;
	}

	sort(all(valsP));
	sort(all(valsI));

	res = vector<int>(s);
	p = 0;
	REP(i, s)
	{
		res[i] = valsP[p];
		++i;
		if (i < s)
			res[i] = valsI[p];
		++p;
	}
	int f = Find();
	if (f == -1)
		cout << "OK";
	else
		cout << f;
}

int main()
{
	int totalCases;
	cin >> totalCases;
	cout << std::setprecision(15);
	cout << std::fixed;

	REP(theCase, totalCases)
	{
		cerr << theCase << endl;
		cout << "Case #" << theCase + 1 << ": ";
		Solve();
		cout << endl;
	}
	return 0;
}
