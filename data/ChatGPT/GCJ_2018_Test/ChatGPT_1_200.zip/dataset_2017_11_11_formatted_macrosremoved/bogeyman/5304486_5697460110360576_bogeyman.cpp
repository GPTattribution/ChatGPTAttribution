#include <bits/stdc++.h>
using namespace std;
#define forr(i, a, b) for(int i = (a); i < (int) (b); i++)
#define forn(i, n) forr(i, 0, n)
#define forall(it, v) for(auto it = v.begin(); it != v.end(); ++it)
#define dforn(i, n) for(int i = ((int) n) - 1; i >= 0; i--)
#define db(v) cerr << #v << " = " << v << endl
#define pb push_back
#define sz(x) ((int)x.size())
#define ff first
#define ss second
typedef long long ll;
const int MAXN = -1;

int n;
ll DOS[35], D;
vector<ll> V;
string S;

int main(){
	DOS[0] = 1; forr(i, 1, 35)DOS[i] = DOS[i-1]*2;
	int t; scanf("%d", &t);
	forn(cs, t){
	    V.clear();
	    scanf("%lld", &D); cin >> S; n = S.size();
	    int acc = 0; ll t = 0;
	    forn(i, n){
            if(S[i] == 'S'){acc++; t++;}
            else{ V.pb(acc); acc = 0; }
	    } V.pb(acc);
	    if(D < t){
            printf("Case #%d: IMPOSSIBLE\n", cs+1);
            continue;
	    }
//	    forn(i, n)printf("%d ", V[i]); puts("");
	    int ans = 0; ll T = 0; forn(i, V.size())T += V[i] * DOS[i];
	    while(D < T){
            while(V.back() == 0)V.pop_back(); int sz = V.size();
            T -= DOS[sz-2]; V[sz-2]++; V[sz-1]--; ans++;
	    }
	    printf("Case #%d: %d\n", cs+1, ans);
    }
	return 0;
}
