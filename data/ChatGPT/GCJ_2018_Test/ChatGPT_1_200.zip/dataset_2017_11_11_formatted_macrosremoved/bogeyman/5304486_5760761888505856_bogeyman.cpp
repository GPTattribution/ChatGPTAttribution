#include <bits/stdc++.h>
using namespace std;
#define forr(i, a, b) for(int i = (a); i < (int) (b); i++)
#define forn(i, n) forr(i, 0, n)
#define forall(it, v) for(auto it = v.begin(); it != v.end(); ++it)
#define dforn(i, n) for(int i = ((int) n) - 1; i >= 0; i--)
#define db(v) cerr << #v << " = " << v << endl
#define pb push_back
#define sz(x) ((int)x.size())
#define ff first
#define ss second
typedef long long ll;
const int MAXN = 100500;

ll n, k;

int main(){
	int t; scanf("%d", &t);
	forn(cs, t){
        scanf("%lld %lld", &n, &k);
        ll p = 1;
        while(k/2 >= p) p *= 2; p--; k -= p; n -= p; k--;
        ll a = p+1, sz = n / a, b = n - a*sz; a -= b;
//        printf("Luego de que pasen %lld\n", p);
//        printf("Quedan %lld segmentos de %lld y %lld segmentos de %lld\n", a, sz, b, sz+1);
//        printf("Y faltan pasar %lld personas\n", k);
        if(k >= b)sz--;
        printf("Case #%d: %lld %lld\n", cs+1, sz - sz/2, sz/2);
    }
	return 0;
}
