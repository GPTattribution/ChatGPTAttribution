#include <bits/stdc++.h>
using namespace std;
#define forr(i, a, b) for(int i = (a); i < (int) (b); i++)
#define forn(i, n) forr(i, 0, n)
#define forall(it, v) for(auto it = v.begin(); it != v.end(); ++it)
#define dforn(i, n) for(int i = ((int) n) - 1; i >= 0; i--)
#define db(v) cerr << #v << " = " << v << endl
#define pb push_back
#define sz(x) ((int)x.size())
#define ff first
#define ss second
typedef long long ll;
const int MAXN = -1;

int n, ans;
vector<ll> V, A, B;

void getans(){
    ans = -1;
    forn(i, n-1)if(V[i] > V[i+1]){
        ans = i; return;
    }
}

int main(){
	int t; scanf("%d", &t);
	forn(cs, t){
	    scanf("%d", &n);
	    V.resize(n); forn(i, n)scanf("%lld", &V[i]); A.clear(); B.clear();
	    forn(i, n){
            if(i%2 == 0)A.pb(V[i]); else B.pb(V[i]);
	    }
	    sort(A.begin(), A.end()); sort(B.begin(), B.end());
	    forn(i, n){
            if(i%2 == 0)V[i] = A[i/2];
            else V[i] = B[i/2];
	    }
	    getans();
	    if(ans > -1)printf("Case #%d: %d\n", cs+1, ans);
	    else printf("Case #%d: OK\n", cs+1);
    }
	return 0;
}
