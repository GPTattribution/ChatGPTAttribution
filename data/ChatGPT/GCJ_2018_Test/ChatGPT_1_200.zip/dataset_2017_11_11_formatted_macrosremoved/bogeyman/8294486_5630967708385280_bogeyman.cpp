#include <bits/stdc++.h>
using namespace std;
#define forr(i, a, b) for(int i = (a); i < (int) (b); i++)
#define forn(i, n) forr(i, 0, n)
#define forall(it, v) for(auto it = v.begin(); it != v.end(); ++it)
#define dforn(i, n) for(int i = ((int) n) - 1; i >= 0; i--)
#define db(v) cerr << #v << " = " << v << endl
#define pb push_back
#define sz(x) ((int)x.size())
#define ff first
#define ss second
typedef long long ll;
const int MAXN = 100500;

struct horse{
    ll x, v;
    horse(ll x = 0, ll v = 0): x(x), v(v){}
};

int n;
ll L;
vector<horse> H;

int main(){
	int t; scanf("%d", &t);
	forn(cs, t){
        scanf("%lld %d", &L, &n);
        H.resize(n); forn(i, n)scanf("%lld %lld", &H[i].x, &H[i].v);
        double t = 0.; forn(i, n)t = max(t, (double)(L - H[i].x) / H[i].v);
        printf("Case #%d: %.9f\n", cs+1, (double)L / t);
    }
	return 0;
}
