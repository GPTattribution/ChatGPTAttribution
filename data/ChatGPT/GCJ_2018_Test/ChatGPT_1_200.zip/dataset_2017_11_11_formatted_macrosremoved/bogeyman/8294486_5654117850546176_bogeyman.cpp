#include <bits/stdc++.h>
using namespace std;
#define forr(i, a, b) for(int i = (a); i < (int) (b); i++)
#define forn(i, n) forr(i, 0, n)
#define forall(it, v) for(auto it = v.begin(); it != v.end(); ++it)
#define dforn(i, n) for(int i = ((int) n) - 1; i >= 0; i--)
#define db(v) cerr << #v << " = " << v << endl
#define pb push_back
#define sz(x) ((int)x.size())
#define ff first
#define ss second
typedef long long ll;
const int MAXN = 100500;

bool res;
bool corre(ll x){
    printf("%lld\n", x);
    string ans; cin >> ans;
    if(ans == "CORRECT")return true;
    res = (ans == "TOO_SMALL");
    return false;
}

ll a, b, n;

int main(){
	int t; scanf("%d", &t);
	forn(cs, t){
        scanf("%lld %lld %lld", &a, &b, &n);
        ll l = a, r = b + 1;
        while(r - l > 1){
            ll m = (l + r)/2;
            if(corre(m))break;
            if(res)l = m;
            else r = m;
        }
    }
	return 0;
}
