#include <bits/stdc++.h>
using namespace std;
#define forr(i, a, b) for(int i = (a); i < (int) (b); i++)
#define dforr(i, a, b) for(int i = (a - 1); i >= (int) (b); i--)
#define forn(i, n) forr(i, 0, n)
#define forall(it, v) for(auto it = v.begin(); it != v.end(); ++it)
#define dforn(i, n) for(int i = ((int) n) - 1; i >= 0; i--)
#define db(v) cerr << #v << " = " << v << endl
#define pb push_back
#define sz(x) ((int)x.size())
#define ff first
#define ss second
typedef long long ll;
const int MAXN = 100500;

struct party{
    int q; char flag;
}P[30];

int n;
vector<string> ANS;

int main(){
	int t; scanf("%d", &t);
	forn(cs, t){
        scanf("%d", &n); ANS.clear();
        forn(i, n){scanf("%d", &P[i].q); P[i].flag = 'A' + i;}
        string ST;
        dforr(lim, 1005, 2)forn(i, n)if(P[i].q >= lim)ST.pb(P[i].flag);
        forn(i, n)P[i].q = 1; reverse(ST.begin(), ST.end());
//        cout << ST << endl;
        if(ST.size() % 2){
            string ADD; ADD.pb(ST.back());
            ANS.pb(ADD);
//            cout << ADD << endl;
            ST.pop_back();
        }
        while(ST.size()){
            string ADD; ADD.pb(ST[ST.size() - 1]); ADD.pb(ST[ST.size() - 2]);
//            cout << ADD << endl;
            ANS.pb(ADD);
            ST.pop_back(); ST.pop_back();
        }
        if(n%2){string ADD; ADD.pb(P[n-1].flag); ANS.pb(ADD) ; n--;}
        forn(i, n/2){
            string ADD; ADD.pb(P[2*i].flag); ADD.pb(P[2*i+1].flag);
            ANS.pb(ADD);
        }
        printf("Case #%d:", cs+1); forn(i, ANS.size())cout << " " << ANS[i]; cout << endl;
    }
	return 0;
}
