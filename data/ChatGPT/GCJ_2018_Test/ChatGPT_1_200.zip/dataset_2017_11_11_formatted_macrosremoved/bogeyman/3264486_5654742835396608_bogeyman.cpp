#include <bits/stdc++.h>
using namespace std;
#define forr(i, a, b) for(int i = (a); i < (int) (b); i++)
#define forn(i, n) forr(i, 0, n)
#define forall(it, v) for(auto it = v.begin(); it != v.end(); ++it)
#define dforn(i, n) for(int i = ((int) n) - 1; i >= 0; i--)
#define db(v) cerr << #v << " = " << v << endl
#define pb push_back
#define sz(x) ((int)x.size())
#define ff first
#define ss second
typedef long long ll;
const int MAXN = -1;

struct dot{ int x, y; dot(int x = 0, int y = 0): x(x), y(y){}};

bool ask(dot P, dot &Ans){
    printf("%d %d\n", P.x, P.y); fflush(stdout);
    scanf("%d %d", &Ans.x, &Ans.y);
    return Ans.x && Ans.y;
}

int A;
bool board[70][3];

bool check(int p){
    p--;
    return board[p][0] && board[p][1] && board[p][2];
}

int main(){
	int t; scanf("%d", &t);
	forn(cs, t){
	    forn(i, 3)forn(j, 70)board[i][j] = false;
	    scanf("%d", &A);
	    int lim = (A+2) / 3 - 1;
	    dot P(2, 2), Q;
	    while(ask(P, Q)){
            if(Q.x == -1 && Q.y == -1)exit(0);
            board[Q.x-1][Q.y-1] = true;
            while(P.x < lim && check(P.x-1))P.x++;
	    }
    }
	return 0;
}
