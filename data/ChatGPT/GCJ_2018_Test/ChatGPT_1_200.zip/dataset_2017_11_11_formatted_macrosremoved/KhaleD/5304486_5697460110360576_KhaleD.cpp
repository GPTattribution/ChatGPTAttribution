#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;
typedef long long ll;
int main()
{
  int tc;
  scanf("%d", &tc);
  for(int t=1;t<=tc;t++)
  {
    char a[64];
    ll m;
    scanf("%lld%s", &m, a);
    int cnt[64] = {0,};
    ll dam=1; int e=0;
    ll tot=0;
    int ss=0;
    for(int i=0;a[i];i++)
    {
      if(a[i]=='C'){dam<<=1; e++;}
      else{tot+=dam; cnt[e]++; ss++;}
    }
    printf("Case #%d: ", t);
    if(ss>m){printf("IMPOSSIBLE\n"); continue;}
    int ans=0;
    while(tot>m)
    {
      while(e>0 && cnt[e]==0){e--; dam>>=1;}
      tot-=dam; tot+=dam/2; cnt[e-1]++; cnt[e]--;
      ans++;
    }
    printf("%d\n", ans);
  }
  return 0;
}
