#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;
int main()
{
  int tc;
  scanf("%d", &tc);
  for(int t=1;t<=tc;t++)
  {
    int n;
    vector<int> a0, a1;
    scanf("%d", &n);
    while(n)
    {
      int t;
      scanf("%d", &t); n--; a0.push_back(t);
      if(!n) break;
      scanf("%d", &t); n--; a1.push_back(t);
    }
    sort(a0.begin(), a0.end());
    sort(a1.begin(), a1.end());
    vector<int> a;
    for(int i=0;i<a0.size() || i<a1.size();i++)
    {
      if(i<a0.size()) a.push_back(a0[i]);
      if(i<a1.size()) a.push_back(a1[i]);
    }
    printf("Case #%d: ", t);
    bool flag=false;
    for(int i=0;i<a.size()-1;i++)
    {
      if(a[i]>a[i+1])
      {
        printf("%d\n", i);
        flag=true; break;
      }
    }
    if(!flag) printf("OK\n");
  }
  return 0;
}
