#include<cstdio>
int main()
{
    int T;
    scanf("%d", &T);
    for(int tc=1;tc<=T;tc++)
    {
        int n, D;
        scanf("%d%d", &D, &n);
        double ans=-1;
        for(int i=0;i<n;i++)
        {
            int p, v;
            scanf("%d%d", &p, &v);
            int d=D-p;
            double v0=(double)D*(double)v/(double)d;
            if(ans<0 || ans>v0) ans=v0;
        }
        printf("Case #%d: %.8lf\n", tc, ans);
    }
    return 0;
}
