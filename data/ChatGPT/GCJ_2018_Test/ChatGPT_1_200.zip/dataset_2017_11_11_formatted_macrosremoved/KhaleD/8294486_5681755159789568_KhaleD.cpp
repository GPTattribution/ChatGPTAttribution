#include<cstdio>
#include<queue>
using namespace std;
int main()
{
    int T;
    scanf("%d", &T);
    for(int tc=1;tc<=T;tc++)
    {
        int n;
        scanf("%d", &n);
        priority_queue<pair<int, int>> q;
        for(int i=0;i<n;i++)
        {
            int c;
            scanf("%d", &c);
            q.push(make_pair(c, i));
        }
        printf("Case #%d:", tc);
        while(q.size())
        {
            auto p1=q.top(); q.pop();
            auto p2=q.top(); q.pop();
            if(p1.first == p2.first && q.empty())
            {
                p1.first--;
                p2.first--;
                printf(" %c%c", 'A'+p1.second, 'A'+p2.second);
            }
            else
            {
                p1.first--;
                printf(" %c", 'A'+p1.second);
            }
            if(p1.first) q.push(p1);
            if(p2.first) q.push(p2);
        }
        printf("\n");
    }
    return 0;
}
