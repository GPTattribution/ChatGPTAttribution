#include <cstdio>
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
typedef long long ll;
int main()
{
  int tc;
  cin>>tc;
  for(int t=1;t<=tc;t++)
  {
    int A;
    cin>>A;
    int r=-1, c=-1, mar=-1;
    for(int x=3;x<=1000;x+=3)
    {
      for(int y=3;y<=1000;y+=3)
      {
        if(x*y>=A)
        {
          if(mar==-1 || mar>x*y)
          {
            mar=x*y; r=x; c=y;
          }
          break;
        }
      }
    }
    for(int cx=2;cx<=r;cx+=3)
    {
      for(int cy=2;cy<=c;cy+=3)
      {
        int chk[3][3]={0, }, cnt=0;
        while(cnt<9)
        {
          cout<<cx<<" "<<cy<<endl;
          int rx, ry;
          cin>>rx>>ry;
          if(rx==0 && ry==0){cnt=9; break;}
          int dx=rx-cx+1, dy=ry-cy+1;
          if(!chk[dx][dy]){chk[dx][dy]=1; cnt++;}
        }
      }
    }
  }
  return 0;
}
