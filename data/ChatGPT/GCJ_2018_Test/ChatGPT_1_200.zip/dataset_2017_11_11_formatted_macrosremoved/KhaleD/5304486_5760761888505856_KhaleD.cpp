#include<cstdio>
#include<map>
using namespace std;
typedef long long ll;
int main()
{
    int T;
    scanf("%d", &T);
    for(int tc=1;tc<=T;tc++)
    {
        map<ll, ll> a;
        ll n, m;
        scanf("%lld%lld", &n, &m);
        a[-n]=1;
        printf("Case #%d: ", tc);
        while(m)
        {
          auto it=a.begin();
          ll x=-it->first;
          ll val=it->second;
          if(val>=m)
          {
            printf("%lld %lld\n", x/2, (x-1)/2);
            break;
          }
          m-=val;
          ll xl=x/2, xr=(x-1)/2;
          if(xl) a[-xl]+=val;
          if(xr) a[-xr]+=val;
          a.erase(-x);
        }
    }
    return 0;
}
