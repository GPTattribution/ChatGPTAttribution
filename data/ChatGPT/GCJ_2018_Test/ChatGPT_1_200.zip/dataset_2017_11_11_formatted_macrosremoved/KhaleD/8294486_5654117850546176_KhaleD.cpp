#include<iostream>
#include<string>
using namespace std;
int main()
{
    int T;
    cin>>T;
    while(T--)
    {
        int a, b, m;
        cin>>a>>b>>m;
        a++;
        while(a<=b)
        {
            int mid=(a+b)/2;
            cout<<mid<<endl;
            string verdict;
            cin>>verdict;
            if(verdict=="TOO_SMALL") a=mid+1;
            else if(verdict=="TOO_BIG") b=mid-1;
            else break;
        }
    }
    return 0;
}
