#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for(int i = 0; i < n; ++i)
#define Rep(i,n) for(int i = 1; i <= n; ++i)
typedef unsigned long long ULL;
typedef long long LL;
const int INF = 0x3f3f3f3f;

int main()
{
	int T, cas = 0;
	cin >> T;
	while(cas++ < T) {
		LL n, k;
        cin >> n >> k;
        map<LL, LL> cnt;
        cnt[n] = 1;
        LL x, y;
        while(k > 0) {
            auto _ = *cnt.rbegin();
            x = _.first / 2; y = _.first - x - 1;
			LL c = _.second;
            cnt.erase(_.first);
            k -= c;
            cnt[x] += c; cnt[y] += c;
        }
        printf("Case #%d: %lld %lld\n", cas, x, y);
	}
	return 0;
}
