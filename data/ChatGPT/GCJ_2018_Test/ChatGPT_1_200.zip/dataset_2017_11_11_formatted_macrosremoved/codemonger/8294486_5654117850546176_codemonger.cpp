#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for(int i = 0; i < n; ++i)
#define Rep(i,n) for(int i = 1; i <= n; ++i)
typedef unsigned long long ULL;
typedef long long LL;
const int INF = 0x3f3f3f3f;

int main()
{
	int T, cas = 0;
	cin >> T;
	while(cas++ < T) {
		int a, b, n;
		cin >> a >> b >> n;
		int m = a + b >> 1;
		cout << m << endl;
		string s;
		while(cin >> s, s[0] != 'C') {
			if(s[4] == 'B') b = m - 1;
			else a = m + 1;
			m = a + b >> 1;
			cout << m << endl;
		}
	}
	return 0;
}
