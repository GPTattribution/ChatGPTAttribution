#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

void find_rotation(double A) {
    double alpha = asin(A / sqrt(2)) / 2;
    double px = 0.5 * cos(alpha);
    double py = 0.5 * sin(alpha);

    cout << setprecision(10) << fixed;
    cout << px << " " << py << " " << 0.0 << endl;
    cout << -px << " " << py << " " << 0.0 << endl;
    cout << 0.0 << " " << 0.5 << " " << 0.0 << endl;
}

int main() {
    int T;
    double A;

    cin >> T;
    for (int i = 1; i <= T; ++i) {
        cin >> A;
        cout << "Case #" << i << ":" << endl;
        find_rotation(A);
    }

    return 0;
}
