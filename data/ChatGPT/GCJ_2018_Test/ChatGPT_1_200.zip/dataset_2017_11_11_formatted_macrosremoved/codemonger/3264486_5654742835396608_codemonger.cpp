#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for(int i = 0; i < n; ++i)
#define Rep(i,n) for(int i = 1; i <= n; ++i)
typedef unsigned long long ULL;
typedef long long LL;
const int INF = 0x3f3f3f3f;

bool vis[71][4];
int cnt[71];

int main()
{
	int T, cas = 0;
	cin >> T;
	while(cas++ < T) {
		int A;
		cin >> A;
		memset(cnt, 0, sizeof cnt);
		memset(vis, 0, sizeof vis);
		cout << "2 2" << endl;
		int x, y;
		while(cin >> x >> y, x || y) {
			if(!vis[x][y]) {
				vis[x][y] = true;
				++cnt[x+1]; ++cnt[x]; ++cnt[x-1];
			}
			int _ = 2;
			for(int i = 3; i <= 66; ++i) {
				if(cnt[i] < cnt[_]) _ = i;
			}
			cout << _ << " 2" << endl;
		}
	}
	return 0;
}
