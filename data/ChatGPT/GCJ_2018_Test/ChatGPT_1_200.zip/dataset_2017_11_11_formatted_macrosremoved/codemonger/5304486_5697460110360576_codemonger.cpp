#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for(int i = 0; i < n; ++i)
#define Rep(i,n) for(int i = 1; i <= n; ++i)
typedef unsigned long long ULL;
typedef long long LL;
const int INF = 0x3f3f3f3f;

int main()
{
	int T, cas = 0;
	cin >> T;
	while(cas++ < T) {
		int n; string s;
		cin >> n >> s;
		vector<int> data;
		int val = 1, temp = 0;
		for(char c : s) {
			if(c == 'C') val *= 2, data.push_back(0);
			else data.push_back(val), temp += val;
		}
		int cnt = 0, len = s.size();
		while(temp > n) {
			bool flag = true;
			for(int i = len-1; i; --i) {
				if(data[i] && data[i-1] == 0) {
					data[i-1] = data[i] / 2;
					data[i] = 0;
					temp -= data[i-1];
					flag = false;
					break;
				}
			}
			if(flag) break;
			++cnt;
		}
		printf("Case #%d: ", cas);
		if(temp <= n) printf("%d\n", cnt);
		else puts("IMPOSSIBLE");
	}
	return 0;
}
