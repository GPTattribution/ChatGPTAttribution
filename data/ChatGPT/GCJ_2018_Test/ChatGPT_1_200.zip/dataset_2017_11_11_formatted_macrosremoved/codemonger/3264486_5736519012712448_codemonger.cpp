#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for(int i = 0; i < n; ++i)
#define Rep(i,n) for(int i = 1; i <= n; ++i)
typedef unsigned long long ULL;
typedef long long LL;
const int INF = 0x3f3f3f3f;

int x[2][50123];
int m[2], p[2];

int main()
{
	int T, cas = 0;
	cin >> T;
	while(cas++ < T) {
		int n;
		cin >> n;
		rep(i, 2) m[i] = p[i] = 0;
		rep(i, n) scanf("%d", x[i&1] + m[i&1]++);
		rep(i, 2) x[i][m[i]] = INF, sort(x[i], x[i]+m[i]);
		printf("Case #%d: ", cas);
		int pre = 0, ans = 0;
		while(ans < n - 1) {
			int cur = pre ^ 1;
			if(x[pre][p[pre]] > x[cur][p[cur]]) {
				printf("%d\n", ans);
				break;
			}
			++ans; ++p[pre];
			pre = cur;
		}
		if(ans == n-1) puts("OK");
	}
	return 0;
}
