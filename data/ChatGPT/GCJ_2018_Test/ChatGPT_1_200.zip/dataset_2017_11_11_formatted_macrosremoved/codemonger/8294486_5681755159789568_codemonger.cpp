#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for(int i = 0; i < n; ++i)
#define Rep(i,n) for(int i = 1; i <= n; ++i)
typedef unsigned long long ULL;
typedef long long LL;
const int INF = 0x3f3f3f3f;

int main()
{
	int T, cas = 0;
	cin >> T;
	while(cas++ < T) {
		int n, p;
        cin >> n;
        priority_queue<pair<int, int>> q;
        int sum = 0;
        rep(i, n) {
            cin >> p;
            q.push({p, i});
            sum += p;
        }
        printf("Case #%d:", cas);
        if(sum & 1) {
            auto a = q.top(); q.pop();
            cout << ' ' << (char)(a.second+'A');
            --a.first;
            if(a.first) q.push(a);
        }
        while(!q.empty()) {
            auto a = q.top(); q.pop();
            cout << ' ' << (char)(a.second+'A');
            if(--a.first) q.push(a);
            a = q.top(); q.pop();
            cout << (char)(a.second+'A');
            if(--a.first) q.push(a);
        }
        puts("");
	}
	return 0;
}
