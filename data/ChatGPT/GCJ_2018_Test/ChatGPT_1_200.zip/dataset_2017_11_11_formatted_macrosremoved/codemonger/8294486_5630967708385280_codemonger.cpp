#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for(int i = 0; i < n; ++i)
#define Rep(i,n) for(int i = 1; i <= n; ++i)
typedef unsigned long long ULL;
typedef long long LL;
const int INF = 0x3f3f3f3f;

int main()
{
	int T, cas = 0;
	cin >> T;
	while(cas++ < T) {
		double d, n;
        cin >> d >> n;
        double k, s, mx = 0;
        while(n--) {
            cin >> k >> s;
            mx = max((d-k)/s, mx);
        }
        printf("Case #%d: %.6lf\n", cas, d/mx);
	}
	return 0;
}
