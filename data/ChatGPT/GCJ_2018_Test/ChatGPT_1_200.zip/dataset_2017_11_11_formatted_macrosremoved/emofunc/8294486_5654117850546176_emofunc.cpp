#include <bits/stdc++.h>
using namespace std;

int main() {
  int T;
  scanf("%d", &T);
  while (T--) {
    int a, b;
    scanf("%d %d %*d", &a, &b); a++; b++;
    while (true) {
      int me = (a + b) / 2;
      printf("%d\n", me);
      fflush(stdout);
      char buf[100];
      scanf(" %s", buf);
      if (buf[0] == 'C') break;
      if (buf[4] == 'S') a = me + 1;
      else b = me;
    }
  }
  return 0;
}
