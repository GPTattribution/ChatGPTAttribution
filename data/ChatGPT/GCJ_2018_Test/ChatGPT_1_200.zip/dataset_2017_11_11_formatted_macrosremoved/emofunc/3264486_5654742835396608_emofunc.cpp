#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using vll = vector<ll>;
using vvll = vector<vll>;
using vi = vector<int>;
using vvi = vector<vi>;
using vd = vector<double>;
using vb = vector<bool>;

#define FU(i, a, b) for (remove_const_t<remove_reference_t<decltype(b)>> i = (a); i < (b); ++i)
#define fu(i, b) FU(i, 0, b)
#define FD(i, a, b) for (auto i = (b) - 1; i >= (a); --i)
#define fd(i, b) FD(i, 0, b)

#define all(V) (V).begin(), (V).end()
#define rall(V) (V).rbegin(), (V).rend()

#define TRACE(x...) x
#define WATCH(x) TRACE(cout << #x" = " << x << endl)
#define WATCHR(b, e) TRACE({for (auto it = b; it != e; it++) cout << *it << " "; cout << endl;})
#define WATCHC(V) TRACE({cout << #V" = "; WATCHR((V).begin(), (V).end());})

int cmp(double x, double y = 0., double tol = 1.e-8) {
	return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}

ll mod(ll a, ll b) {
	return ((a%b)+b)%b;
}

array<int, 2> doit(int x, int y) {
    printf("%d %d\n", x, y);
    fflush(stdout);
    array<int, 2> ans;
    scanf("%d %d", &ans[0], &ans[1]);
    return ans;
}

void doit() {
    int a;
    scanf("%d", &a);
    int dimx, dimy;
    if (a == 20) {
        dimx = 4; dimy = 5;
    } else {
        dimx = 10; dimy = 20;
    }
    vector<vb> tab(dimx, vb(dimy, false));
    // doit
    auto first = doit(500, 500);
    tab[0][0] = true;
    fu(x, dimx) fu(y, dimy) while (!tab[x][y]) {
        // choose square containing x/y with smallest covered
        int cx, cy;
        int minimum = 10;
        FU(xx, x - 1, x + 2) FU(yy, y - 1, y + 2) {
            if (xx < 1 || xx > dimx - 2 || yy < 1 || yy > dimy - 2) continue;
            int cnt = 0;
            FU(xxx, xx - 1, xx + 2) FU(yyy, yy - 1, yy + 2)
                cnt += !!tab[xxx][yyy];
            if (cnt < minimum) {
                cx = xx;
                cy = yy;
                minimum = cnt;
            }
        }
        auto place = doit(cx + first[0], cy + first[1]);
        if (place[0] == 0 && place[1] == 0) return;
        tab[place[0] - first[0]][place[1] - first[1]] = true;
    }
}

int main() {
	int T;
	scanf("%d", &T);
	fu(t, T) {
		doit();
	}
	return 0;
}
