#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using vll = vector<ll>;
using vvll = vector<vll>;
using vi = vector<int>;
using vvi = vector<vi>;
using vd = vector<double>;
using vb = vector<bool>;

#define FU(i, a, b) for (remove_const_t<remove_reference_t<decltype(b)>> i = (a); i < (b); ++i)
#define fu(i, b) FU(i, 0, b)
#define FD(i, a, b) for (auto i = (b) - 1; i >= (a); --i)
#define fd(i, b) FD(i, 0, b)

#define all(V) (V).begin(), (V).end()
#define rall(V) (V).rbegin(), (V).rend()

#define TRACE(x...) x
#define WATCH(x) TRACE(cout << #x" = " << x << endl)
#define WATCHR(b, e) TRACE({for (auto it = b; it != e; it++) cout << *it << " "; cout << endl;})
#define WATCHC(V) TRACE({cout << #V" = "; WATCHR((V).begin(), (V).end());})

int cmp(double x, double y = 0., double tol = 1.e-8) {
	return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}

ll mod(ll a, ll b) {
	return ((a%b)+b)%b;
}

void doit() {
    int N;
    scanf("%d", &N);
    vector<int> even, odd;
    fu(i, N) {
        int x;
        scanf("%d", &x);
        if (i % 2) odd.push_back(x);
        else even.push_back(x);
    }
    sort(all(odd)); sort(all(even));
    vector<int> V;
    fu(i, N) {
        if (i % 2) V.push_back(odd[i/2]);
        else V.push_back(even[i/2]);
    }
    fu(i, N - 1) if (V[i] > V[i+1]) {
        printf(" %d\n", i);
        return;
    }
    printf(" OK\n");
}

int main() {
	int T;
	scanf("%d", &T);
	fu(t, T) {
		printf("Case #%d:", t+1);
		doit();
	}
	return 0;
}
