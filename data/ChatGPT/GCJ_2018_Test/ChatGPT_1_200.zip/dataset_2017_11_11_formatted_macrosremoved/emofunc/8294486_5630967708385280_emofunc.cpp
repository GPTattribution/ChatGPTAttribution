#include <bits/stdc++.h>
using namespace std;

void doit() {
  double d;
  int n;
  scanf("%lf %d", &d, &n);
  double ans = 0.;
  while (n--) {
    double k, s;
    scanf("%lf %lf", &k, &s);
    ans = max(ans, (d - k) / s);
  }
  printf("%.10lf\n", d / ans);
}

int main() {
  int t;
  scanf("%d", &t);
  for (int _ = 0; _ < t; _++) {
    printf("Case #%d: ", _ + 1);
    doit();
  }
  return 0;
}
