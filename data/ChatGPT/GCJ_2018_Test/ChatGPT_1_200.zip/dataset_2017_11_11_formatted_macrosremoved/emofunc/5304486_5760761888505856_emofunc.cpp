#include <bits/stdc++.h>
using namespace std;

using ll = long long;

int main() {
  int T;
  scanf("%d", &T);
  for (int t = 0; t < T; t++) {
    printf("Case #%d: ", t + 1);

    ll N, K;
    scanf("%lld %lld", &N, &K);
    queue<tuple<ll, ll>> Q;
    Q.emplace(1, N);

    while (true) {
      ll qtd, sz;
      tie(qtd, sz) = Q.front(); Q.pop();
      while (!Q.empty() && get<1>(Q.front()) == sz) {
        qtd += get<0>(Q.front()); Q.pop();
      }
      ll m = (sz - 1) / 2;
      ll M = sz / 2;
      if (qtd >= K) { // found it
        printf("%lld %lld\n", M, m);
        break;
      }
      K -= qtd;

      if (m == M) Q.emplace(2 * qtd, m);
      else {
        Q.emplace(qtd, M);
        Q.emplace(qtd, m);
      }
    }
  }
  return 0;
}
