#include <bits/stdc++.h>
using namespace std;

int main() {
  int T;
  scanf("%d", &T);
  for (int t = 0; t < T; t++) {
    printf("Case #%d:", t + 1);
    int N;
    scanf("%d", &N);
    vector<vector<char>> V(1001);
    for (int i = 0; i < N; i++) {
      int x;
      scanf("%d", &x);
      V[x].push_back('A' + i);
    }

    for (int sz = 1000; sz > 0; sz--) {
      while (!V[sz].empty()) {
        if (V[sz].size() % 2 == 0) {
          printf(" %c%c", V[sz].back(), V[sz][V[sz].size() - 2]);
          V[sz-1].push_back(V[sz].back()); V[sz].pop_back();
          V[sz-1].push_back(V[sz].back()); V[sz].pop_back();
        } else {
          printf(" %c", V[sz].back());
          V[sz-1].push_back(V[sz].back()); V[sz].pop_back();
        }
      }
    }
    printf("\n");
  }
  return 0;
}
