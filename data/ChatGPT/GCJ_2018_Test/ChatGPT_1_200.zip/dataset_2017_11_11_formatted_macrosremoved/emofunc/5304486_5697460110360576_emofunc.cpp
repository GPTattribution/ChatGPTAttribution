#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using vll = vector<ll>;
using vvll = vector<vll>;
using vi = vector<int>;
using vvi = vector<vi>;
using vd = vector<double>;
using vb = vector<bool>;

#define FU(i, a, b) for (remove_const_t<remove_reference_t<decltype(b)>> i = (a); i < (b); ++i)
#define fu(i, b) FU(i, 0, b)
#define FD(i, a, b) for (auto i = (b) - 1; i >= (a); --i)
#define fd(i, b) FD(i, 0, b)

#define all(V) (V).begin(), (V).end()
#define rall(V) (V).rbegin(), (V).rend()

#define TRACE(x...) x
#define WATCH(x) TRACE(cout << #x" = " << x << endl)
#define WATCHR(b, e) TRACE({for (auto it = b; it != e; it++) cout << *it << " "; cout << endl;})
#define WATCHC(V) TRACE({cout << #V" = "; WATCHR((V).begin(), (V).end());})

int cmp(double x, double y = 0., double tol = 1.e-8) {
	return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}

ll mod(ll a, ll b) {
	return ((a%b)+b)%b;
}

int strength(char *buf) {
    int ans = 0;
    int cur = 1;
    for (char *c = buf; *c; c++) {
        if (*c == 'C') cur *= 2;
        else ans += cur;
    }
    return ans;
}

void doit() {
    int D;
    char buf[40];
    scanf(" %d %s", &D, buf);
    int L = strlen(buf);

    int ans = 0;
    while (strength(buf) > D) {
        // find rightmost string CS
        bool found = false;
        fd(i, L - 1) if (buf[i] == 'C' && buf[i+1] == 'S') {
            found = true;
            swap(buf[i], buf[i+1]);
            ans++;
            break;
        }
        if (!found) {
            printf(" IMPOSSIBLE\n");
            return;
        }
    }
    printf(" %d\n", ans);
}

int main() {
	int T;
	scanf("%d", &T);
	fu(t, T) {
		printf("Case #%d:", t+1);
		doit();
	}
	return 0;
}
