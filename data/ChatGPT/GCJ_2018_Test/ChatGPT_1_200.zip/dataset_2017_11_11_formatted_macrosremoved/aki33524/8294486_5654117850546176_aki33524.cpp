#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <memory>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <sstream>
#include <unordered_map>
#include <vector>


#define INF 4000000000000000000LL
#define MOD 1000000007
#define ALL(x) std::begin(x), std::end(x)


int main(int argc, char** argv)
{
  std::cin.tie(0);
  std::ios_base::sync_with_stdio(0);

  std::cout << std::fixed << std::setprecision(6);
  std::cerr << std::fixed << std::setprecision(6);

  int T, A, B, N;

  std::cin >> T;

  for (int t = 1; t <= T; t ++) {
    std::cin >> A >> B >> N;

    int l = A, u = B + 1;

    while (u - l > 1) {
      int m = (l + u) / 2;

      std::cout << m << std::endl; std::cout.flush();

      std::string s;

      std::cin >> s;

      if (s == "CORRECT") {
        break;
      }
      else {
        assert(s == "TOO_SMALL" || s == "TOO_BIG");

        (s == "TOO_SMALL" ? l : u) = m;
      }
    }
  }

  return 0;
}
