#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <memory>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <sstream>
#include <unordered_map>
#include <vector>


#define INF 1000000000
#define MOD 1000000007
#define ALL(x) std::begin(x), std::end(x)


int main(int argc, char** argv)
{
  std::cin.tie(0);
  std::ios_base::sync_with_stdio(0);

  std::cout << std::fixed << std::setprecision(6);
  std::cerr << std::fixed << std::setprecision(6);

  int T, A;

  std::cin >> T;

  for (int t = 1; t <= T; t ++) {
    std::cin >> A;

    char a[111][3];

    memset(a, '.', sizeof(a));

    int h = std::max((A + 2) / 3, 3);

    for (int i = 0; i < 1000; i ++) {
      int sm = INF, ym = -1, c[111], s;

      c[0] = std::count(a[0], a[0] + 3, 'X');
      c[1] = std::count(a[1], a[1] + 3, 'X');

      s = c[0] + c[1];

      for (int y = 0; y < h - 2; y ++) {
        s += (c[y + 2] = std::count(a[y + 2], a[y + 2] + 3, 'X'));

        if (s < sm) {
          sm = s;
          ym = y;
        }

        s -= c[y];
      }

      assert(s < INF);

      if (sm == 9)
        goto endloop;

      assert(0 <= ym && ym < h - 2);

      std::cout << ym + 1 + 1 << ' ' << 2 << std::endl; std::cout.flush();

      int x, y;

      std::cin >> y >> x;

      if (x == 0 && y == 0)
        goto endloop;

      a[y - 1][x - 1] = 'X';
    }

    assert(false);

  endloop: ;
  }

  return 0;
}
