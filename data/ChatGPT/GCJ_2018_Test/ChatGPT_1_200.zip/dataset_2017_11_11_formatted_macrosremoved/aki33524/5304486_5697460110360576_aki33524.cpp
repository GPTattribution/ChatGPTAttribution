#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <memory>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <sstream>
#include <unordered_map>
#include <vector>


#define INF 4000000000000000000LL
#define MOD 1000000007
#define ALL(x) std::begin(x), std::end(x)


long long calc(const std::string& s)
{
  long long x = 0, b = 1;

  for (const auto& c : s)
    if (c == 'S') {
      x += b;
    }
    else {
      b <<= 1;
    }

  return x;
}


int main(int argc, char** argv)
{
  std::cin.tie(0);
  std::ios_base::sync_with_stdio(0);

  std::cout << std::fixed << std::setprecision(6);
  std::cerr << std::fixed << std::setprecision(6);

  int T, D;

  std::string P;

  std::cin >> T;

  for (int t = 1; t <= T; t ++) {
    std::cin >> D >> P;

    if (std::count(ALL(P), 'S') > D) {
      std::cout << "Case #" << t << ": IMPOSSIBLE" << std::endl;

      continue;
    }

    int c = 0;

    for ( ; ; c ++) {
      long long x = calc(P);

      if (x <= D)
        break;

      std::string::size_type i = P.rfind("CS");

      assert(i != std::string::npos);
      assert(i < P.size() - 1);

      std::swap(P[i], P[i + 1]);
    }

    std::cout << "Case #" << t << ": " << c << std::endl;
  }

  return 0;
}
