#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iterator>
#include <map>
#include <memory>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <sstream>
#include <unordered_map>
#include <vector>


#define INF 4000000000000000000LL
#define MOD 1000000007
#define ALL(x) std::begin(x), std::end(x)


int main(int argc, char** argv)
{
  int T, N, a[111111], b[111111], c[111111];

  scanf("%d", &T);

  for (int t = 1; t <= T; t ++) {
    scanf("%d", &N);

    for (int i = 0; i < N; i ++)
      if (i % 2 == 0) {
        scanf("%d", a + i / 2);
      }
      else {
        scanf("%d", b + i / 2);
      }

    std::sort(a, a + (N + 1) / 2);
    std::sort(b, b +  N      / 2);

    for (int i = 0; i < N; i ++)
      if (i % 2 == 0) {
        c[i] = a[i / 2];
      }
      else {
        c[i] = b[i / 2];
      }

    for (int i = 0; i < N - 1; i ++)
      if (c[i] > c[i + 1]) {
        printf("Case #%d: %d\n", t, i);

        goto endloop;
      }

    printf("Case #%d: OK\n", t);

  endloop: ;
  }

  return 0;
}
