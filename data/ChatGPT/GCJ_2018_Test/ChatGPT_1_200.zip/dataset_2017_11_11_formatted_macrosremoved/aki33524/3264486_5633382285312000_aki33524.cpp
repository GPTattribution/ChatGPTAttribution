#include <iostream>
#include <cmath>
#include <iomanip>

const double PI = std::acos(-1);

void solve(double A) {
    double theta = std::acos(A / std::sqrt(2));
    double phi = PI / 4;

    double x1 = 0.5 * std::cos(phi) * std::cos(theta);
    double y1 = 0.5 * std::cos(phi) * std::sin(theta);
    double z1 = 0.5 * std::sin(phi);

    double x2 = 0.5 * std::cos(phi + 2 * PI / 3) * std::cos(theta);
    double y2 = 0.5 * std::cos(phi + 2 * PI / 3) * std::sin(theta);
    double z2 = 0.5 * std::sin(phi + 2 * PI / 3);

    double x3 = 0.5 * std::cos(phi + 4 * PI / 3) * std::cos(theta);
    double y3 = 0.5 * std::cos(phi + 4 * PI / 3) * std::sin(theta);
    double z3 = 0.5 * std::sin(phi + 4 * PI / 3);

    std::cout << std::fixed << std::setprecision(15);
    std::cout << x1 << " " << y1 << " " << z1 << std::endl;
    std::cout << x2 << " " << y2 << " " << z2 << std::endl;
    std::cout << x3 << " " << y3 << " " << z3 << std::endl;
}

int main() {
    int T;
    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;
        std::cout << "Case #" << t << ":" << std::endl;
        solve(A);
    }
    return 0;
}
