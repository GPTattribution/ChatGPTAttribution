#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <memory>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <sstream>
#include <unordered_map>
#include <vector>


#define INF 4000000000000000000LL
#define MOD 1000000007
#define ALL(x) std::begin(x), std::end(x)


class node_t {
public:
  node_t(long long xx, long long ll, long long rr) : x(xx), l(ll), r(rr) {};

public:
  bool operator<(const node_t& n) const {
    long long a1 = std::min(l, r), a2 = std::min(n.l, n.r);

    if (a1 != a2)
      return a1 > a2;

    return x > n.x;
  };

public:
  long long x;
  long long l;
  long long r;
};


int main(int argc, char** argv)
{
  std::cin.tie(0);
  std::ios_base::sync_with_stdio(0);

  std::cout << std::fixed << std::setprecision(6);
  std::cerr << std::fixed << std::setprecision(6);

  int T;

  long long N, K;

  std::cin >> T;

  for (int t = 1; t <= T; t ++) {
    std::cin >> N >> K;

    std::map<long long, long long> map;

    map[N] = 1;

    for (int i = 0; i < 30; i ++) {
      long long k = 0;

      for (const auto& kv : map)
        k += kv.second;

      std::vector<long long> keys;

      for (const auto& kv : map)
        keys.push_back(kv.first);

      std::reverse(ALL(keys));

      if (K <= k) {
        for (const auto& key : keys) {
          if (K <= map[key]) {
            long long a, b;

            if (key % 2) {
              a = b = key / 2;
            }
            else {
              a = key / 2;
              b = key / 2 - 1;
            }

            std::cout << "Case #" << t << ": " << a << ' ' << b << std::endl;

            goto endloop;
          }

          K -= map[key];
        }

        assert(false);
      }

      std::map<long long, long long> m;

      for (const auto& kv : map) {
        long long n = kv.first;

        if (n % 2) {
          if (n / 2)
            m[n / 2] += 2 * map[n];
        }
        else {
          if (n / 2 - 1)
            m[n / 2 - 1] += map[n];

          if (n / 2)
            m[n / 2    ] += map[n];
        }
      }

      map = std::move(m);

      K -= k;
    }

  endloop: ;
  }

  return 0;
}
