#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <map>
#include <memory>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <sstream>
#include <unordered_map>
#include <vector>


#define INF 4000000000000000000LL
#define MOD 1000000007
#define ALL(x) std::begin(x), std::end(x)


int T, N, P[33];


int main(int argc, char** argv)
{
  std::cin.tie(0);
  std::ios_base::sync_with_stdio(0);

  std::cout << std::fixed << std::setprecision(6);
  std::cerr << std::fixed << std::setprecision(6);

  std::cin >> T;

  for (int t = 0; t < T; t ++) {
    std::vector<std::string> a;

    std::cin >> N;

    std::priority_queue<std::pair<int, int>> pq;

    for (int i = 0; i < N; i ++) {
      std::cin >> P[i];

      pq.emplace(P[i], i);
    }

    while (! pq.empty()) {
      if (pq.size() == 2) {
        auto pair1 = pq.top(); pq.pop();
        auto pair2 = pq.top(); pq.pop();

        assert(pair1.first == pair2.first);

        char buf[256];

        sprintf(buf, "%c%c", pair1.second + 'A', pair2.second + 'A');

        for (int i = 0; i < pair1.first; i ++) {
          P[pair1.second] --;
          P[pair2.second] --;

          a.push_back(buf);
        }
      }
      else {
        auto pair = pq.top(); pq.pop();

        a.push_back(std::string(1, pair.second + 'A'));

        P[pair.second] --;

        if (-- pair.first)
          pq.push(pair);
      }
    }

    std::cout << "Case #" << t + 1 << ": ";
    for (const auto& i : a)
      std::cout << i << ' ';
    std::cout << std::endl;
  }

  return 0;
}
