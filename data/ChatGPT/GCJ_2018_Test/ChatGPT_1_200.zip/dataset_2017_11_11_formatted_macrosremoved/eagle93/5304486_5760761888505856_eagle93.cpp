#include <iostream>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <sstream>
#include <string>
#define _repargs(_1,_2,_3,name,...) name
#define _rep(i,n) repi(i,0,n)
#define repi(i,a,b) for(int i=(int)(a);i<(int)(b);++i)
#define rep(...) _repargs(__VA_ARGS__,repi,_rep,)(__VA_ARGS__)
#define all(x) (x).begin(),(x).end()
#define mod 1000000007
#define inf 2000000007
#define mp make_pair
#define pb push_back
typedef long long ll;
using namespace std;
template <typename T>
inline void output(T a, int p = 0) {
    if(p) cout << fixed << setprecision(p)  << a << "\n";
    else cout << a << "\n";
}
// end of template
template <typename T> inline void voutput(T &v){
    rep(i, v.size()){
        if (i) cout << " " << v[i];
        else cout << v[i];
    }
    cout << endl;
}

void gcjout(int index) {
    cout << "Case #" << index + 1 << ": ";
}

pair<ll, ll> calc(ll N, ll K) {
    map<ll, ll> M;
    M[N] = 1;
    while(1) {
        pair<ll, ll> a = *M.rbegin();
        M.erase(a.first);
        ll l = (a.first - 1) / 2;
        ll r = a.first / 2;
        M[l] += a.second;
        M[r] += a.second;
        K -= a.second;
        if(K <= 0) return mp(r, l);
    }
    return mp(0, 0);
}

int main() {
    cin.tie(0);
    ios::sync_with_stdio(0);
    // source code
    int T;
    cin >> T;
    rep(t, T){
        ll N, K;
        cin >> N >> K;
        gcjout(t);
        auto ans = calc(N, K);
        cout << ans.first << " " << ans.second << endl;


    }

    return 0;
}
