#include <iostream>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <sstream>
#include <string>
#define _repargs(_1,_2,_3,name,...) name
#define _rep(i,n) repi(i,0,n)
#define repi(i,a,b) for(int i=(int)(a);i<(int)(b);++i)
#define rep(...) _repargs(__VA_ARGS__,repi,_rep,)(__VA_ARGS__)
#define all(x) (x).begin(),(x).end()
#define mod 1000000007
#define inf 2000000007
#define mp make_pair
#define pb push_back
typedef long long ll;
using namespace std;
template <typename T>
inline void output(T a, int p = 0) {
    if(p) cout << fixed << setprecision(p)  << a << "\n";
    else cout << a << "\n";
}
// end of template

bool filled(pair<int, int> rc, vector<vector<int>> &C){
    int r = rc.first;
    int c = rc.second;
    rep(i, 3 * r, 3 * (r + 1)) rep(j, 3 * c, 3 * (c + 1)) {
        if(C[i][j] == 0) return false;
    }
    return true;
}

int main() {
    cin.tie(0);
    ios::sync_with_stdio(0);
    // source code
    int T;
    cin >> T;
    rep(t, T) {
        int A;
        cin >> A;
//        cerr << t << ":" << A << endl;
        vector<vector<int>> C(15, vector<int> (15, 0));
        pair<int, int> cur = mp(0, 0);
        while(1) {
            if(filled(cur, C)) {
//                cerr << "phase completed" << endl;
                if(cur.second == 4) {
                    cur.first++;
                    cur.second = 0;
                }
                else cur.second++;
            }
            cout << cur.first * 3 + 2 << " " << cur.second * 3 + 2 << endl;
            cout.flush();
            int rnew, cnew;
            cin >> rnew >> cnew;
//            cerr << rnew << "," << cnew << endl;

            if(rnew == 0 && cnew == 0){
                break;
            }
            else if(rnew == -1 && cnew == -1){
//                cerr << "Wrong Answer" << endl;
                return 0;
            }
            C[rnew - 1][cnew - 1] = 1;
        }
    }

    return 0;
}
