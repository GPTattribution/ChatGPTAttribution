#include <iostream>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <sstream>
#include <string>
#define _repargs(_1,_2,_3,name,...) name
#define _rep(i,n) repi(i,0,n)
#define repi(i,a,b) for(int i=(int)(a);i<(int)(b);++i)
#define rep(...) _repargs(__VA_ARGS__,repi,_rep,)(__VA_ARGS__)
#define all(x) (x).begin(),(x).end()
#define mod 1000000007
#define inf 2000000007
#define mp make_pair
#define pb push_back
typedef long long ll;
using namespace std;
template <typename T>
inline void output(T a, int p = 0) {
    if(p) cout << fixed << setprecision(p)  << a << "\n";
    else cout << a << "\n";
}
// end of template

void gcjout(int index) {
    cout << "Case #" << index + 1 << ": ";
}

ll calc(string s){
    ll now = 0;
    ll power = 1;
    for(char c: s) {
        if(c == 'C') power <<= 1;
        else now += power;
    }
    return now;
}

int main() {
    cin.tie(0);
    ios::sync_with_stdio(0);
    // source code
    int T;
    cin >> T;
    rep(t, T) {
        ll D;
        string P;
        cin >> D >> P;
        ll now = calc(P);
        gcjout(t);
        if(now <= D) {
            output(0);
        }
        else {
            int cnt = 0;
            while(now > D) {
                bool ok = false;
                for(int i = P.size() - 2; i >= 0; i--) {
                    if(P[i] == 'C' && P[i + 1] == 'S') {
                        P[i] = 'S';
                        P[i + 1] = 'C';
                        cnt++;
                        break;
                    }
                }
                if(calc(P) == now) {
                    cnt = -1;
                    break;
                }
//                cout << calc(P) << ": " << now << endl;
                now = calc(P);
            }
            if(cnt == -1) {
                output("IMPOSSIBLE");
            }
            else output(cnt);
        }

    }

    return 0;
}
