#include<stdio.h>
typedef long long ll;
typedef struct _info { ll mn, mx; } info;
int T; ll N, K;
info f(ll nn, ll kk) {
	info ret;
	if (nn==kk) {
		ret.mn=ret.mx=0;
		return ret;
	}
	if (kk==1) {
		ret.mn=(nn-1)/2; ret.mx=nn/2;
		return ret;
	}
	if (nn%2) return f(nn/2, kk/2);
	else {
		if (kk%2) return f(nn/2-1, kk/2);
		else return f(nn/2, kk/2);
	}
}
int main() {
	int t; info ret;
	scanf("%d",&t);
	for (T=1; T<=t; T++) {
		scanf("%lld%lld",&N,&K);
		ret=f(N,K);
		printf("Case #%d: %lld %lld\n", T, ret.mx, ret.mn);
	}
}
