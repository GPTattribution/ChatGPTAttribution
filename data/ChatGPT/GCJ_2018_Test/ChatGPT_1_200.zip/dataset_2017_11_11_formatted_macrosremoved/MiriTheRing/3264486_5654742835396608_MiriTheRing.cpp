#include<stdio.h>
#include<math.h>
#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<queue>
#include<stack>
#include<tuple>
#include<set>
#include<utility>
#include<map>
using namespace std;
typedef long long ll;
using namespace std;
int X1, Y1, X2, Y2, A, B[300][300];
int main() {
	int t, T, x, y, x2, y2;
	setbuf(stdout, NULL);
	cin >> t; X1 = Y1 = 100; Y2 = 102;
	for (T = 1; T <= t; T++) {
		cin >> A;
		if (A == 20) X2 = 106;
		else X2 = 166;
		for (x = X1; x <= X2; x++) {
			for (y = Y1; y <= Y2; y++) {
				B[y][x] = 0;
			}
		}

		int flag = 0;
		for (x = X1+1; x < X2 && !flag; x++) {
			while (!B[Y1][x - 1] || !B[Y1 + 1][x - 1] || !B[Y1 + 2][x - 1]) {
				printf("%d %d\n", Y1 + 1, x);
				fflush(stdout);
				cin >> y2 >> x2;
				if (x2 == -1 && y2 == -1) return 0;
				if (x2 == 0 && y2 == 0) {
					flag = 1;
					break;
				}
				B[y2][x2] = 1;
			}
		}
		if (flag) continue;
		while (1) {
			printf("%d %d\n", Y1 + 1, X2 - 1);
			fflush(stdout);
			cin >> y2 >> x2;
			if (x2 == -1 && y2 == -1) return 0;
			if (x2 == 0 && y2 == 0) {
				break;
			}
		}
	}
}
