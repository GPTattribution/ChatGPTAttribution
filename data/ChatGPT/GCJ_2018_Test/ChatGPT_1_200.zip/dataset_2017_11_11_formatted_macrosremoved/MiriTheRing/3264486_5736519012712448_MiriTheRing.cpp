#include<stdio.h>
#include<math.h>
#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<queue>
#include<stack>
#include<tuple>
#include<set>
#include<utility>
#include<map>
using namespace std;
typedef long long ll;
using namespace std;
int N; int A[100004], B[100004];
int main() {
	int t, T, i, s, flag;
	cin >> t;
	for (T = 1; T <= t; T++) {
		scanf("%d", &N);
		for (i = 0; i < N; i++) {
			scanf("%d", A + i);
			B[i] = A[i];
		}
		sort(B, B + N);
		flag = 0; s = 0;
		while (flag == 0) {
			flag = 1;
			if (s == N) {
				flag = 1;
				break;
			}
			if (A[s] == B[s]) {
				s++;
				flag = 0;
				continue;
			}
			if (s >= N - 3 && A[s] > A[s + 1] && A[s + 1] == B[s] && B[s] != B[s + 1]) { // impossible at s
				flag = 0;
				break;
			}
			for (i = s; i < N - 2; i++) {
				if (A[i] > A[i + 2]) {
					flag = 0;
					swap(A[i], A[i + 2]);
				}
			}
			if (flag == 1) { // impossible at s
				flag = 0;
				break;
			}
		}
		if (flag == 0) printf("Case #%d: %d\n", T, s);
		else printf("Case #%d: OK\n", T);
	}
}
