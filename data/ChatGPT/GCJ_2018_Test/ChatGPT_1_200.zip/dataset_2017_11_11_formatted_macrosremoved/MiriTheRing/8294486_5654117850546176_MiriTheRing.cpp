#include<cstdio>
#include<memory.h>
#include<stdio.h>
#include<math.h>
#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<queue>
#include<stack>
#include<tuple>
#include<set>
#include<utility>
#include<map>
using namespace std;
typedef long long ll;
using namespace std;
int main() {
	int t, A, B, N, lo, hi, mid;
	setbuf(stdout, NULL);
	cin >> t;
	while (t-- > 0) {
		cin >> A >> B >> N;
		lo = A; hi = B;
		while (1) {
			mid = (lo + hi) / 2;
			printf("%d\n", mid);
			fflush(stdout);
			string S; cin >> S;
			if (!S.compare("CORRECT")) break;
			if (!S.compare("TOO_SMALL")) lo = mid + 1;
			else if (!S.compare("TOO_BIG")) hi = mid - 1;
			else break;
		}
	}
}
