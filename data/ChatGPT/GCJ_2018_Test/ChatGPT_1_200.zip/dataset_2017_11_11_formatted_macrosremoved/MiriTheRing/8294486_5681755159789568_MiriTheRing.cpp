#include<cstdio>
#include<memory.h>
#include<stdio.h>
#include<math.h>
#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<queue>
#include<stack>
#include<tuple>
#include<set>
#include<utility>
#include<map>
using namespace std;
typedef long long ll;
using namespace std;
int main() {
	int T, t, i, N, n, A[1004], a;
	cin >> t;
	for (T = 1; T <= t; T++) {
		cin >> N; for (i = 0; i < N; i++) cin >> A[i];
		n = N;
		printf("Case #%d:", T);
		while (n > 0) {
			if (n == 2) {
				cout << " ";
				for (i = 0; i < N; i++) {
					if (A[i]) {
						printf("%c", 'A' + i);
						A[i]--;
						if (A[i] == 0) n--;
					}
				}
			}
			else {
				a = 0;
				for (i = 1; i < N; i++) {
					if (A[i] > A[a]) a = i;
				}
				A[a]--;
				if (A[a] == 0) n--;
				printf(" %c", 'A' + a);
			}
		}
		cout << endl;
	}
}
