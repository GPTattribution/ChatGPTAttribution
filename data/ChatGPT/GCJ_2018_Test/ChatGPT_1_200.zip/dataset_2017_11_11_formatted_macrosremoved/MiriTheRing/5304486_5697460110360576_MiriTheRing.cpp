#include<stdio.h>
#include<math.h>
#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<queue>
#include<stack>
#include<tuple>
#include<set>
#include<utility>
#include<map>
using namespace std;
typedef long long ll;
using namespace std;
char X[104]; int N;
inline ll f() {
	int i; ll a = 1, ret = 0;
	for (i = 0; i < N; i++) {
		if (X[i] == 'C') a *= 2;
		else ret += a;
	}
	return ret;
}
int main() {
	int t, T, flag, i; ll a, D, ans;
	cin >> t;
	for (T = 1; T <= t; T++) {
		cin >> D >> X; flag = 0; ans = 0;
		for (N = 0; X[N]; N++);
		while (1) {
			a = f();
			if (a <= D) {
				flag = 1;
				break;
			}
			ans++;
			int x = -1;
			for (i = 0; i < N - 1; i++) {
				if (X[i] == 'C' && X[i + 1] == 'S') x = i;
			}
			if (x != -1) {
				swap(X[x], X[x + 1]);
			}
			else {
				flag = 0;
				break;
			}
		}
		if (flag == 0) {
			printf("Case #%d: IMPOSSIBLE\n", T);
		}
		else {
			printf("Case #%d: %lld\n", T, ans);
		}
	}
}
