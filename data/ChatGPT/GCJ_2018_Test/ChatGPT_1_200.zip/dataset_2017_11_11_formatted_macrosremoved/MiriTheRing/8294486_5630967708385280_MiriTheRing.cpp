#include<cstdio>
#include<memory.h>
#include<stdio.h>
#include<math.h>
#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<queue>
#include<stack>
#include<tuple>
#include<set>
#include<utility>
#include<map>
using namespace std;
typedef long long ll;
using namespace std;
int main() {
	int T, t, i, N, D, k, s;
	cin >> t;
	for (T = 1; T <= t; T++) {
		cin >> D >> N;
		double a, b = 0;
		for (i = 0; i < N; i++) {
			cin >> k >> s;
			a = double(D - k) / (double)s;
			if (a > b) b = a;
		}
		printf("Case #%d: %.10lf\n", T, (double)D / b);
	}
}
