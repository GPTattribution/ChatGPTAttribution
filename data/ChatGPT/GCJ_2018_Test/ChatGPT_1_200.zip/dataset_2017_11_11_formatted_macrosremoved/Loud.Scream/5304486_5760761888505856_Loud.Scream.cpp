#include <iostream>
#include <string>
#include <map>

using namespace std;
typedef long long ll;
typedef pair<ll,ll> lp;
typedef map<lp,ll> lm;

lm imap;



int main()
{
  int T;
  cin >> T;

  ll N, C,cnt,cend,mid;
  lp cur;
  ll ming,maxg;
  for (int i=0; i<T; ++i){
    imap.clear(); cnt=0;
    //cerr << "Case #" << i+1 << endl;
    cin >> N >> C;
    imap[lp(-N,0)]=N+1;
    while (cnt<C)
    {
      ++cnt;
      lm::iterator s=imap.begin();
      cur=s->first; cend=s->second;
      imap.erase(s);
      mid=(cur.second+cend)>>1;
      maxg=cend-mid-1; ming=mid-cur.second-1;
      if (mid-1>cur.second)
        imap[lp(-(mid-1-cur.second),cur.second)]=mid;
      if (cend-1>mid)
        imap[lp(-(cend-1-mid),mid)]=cend;
    }

    cout << "Case #"<<(i+1)<<": " << maxg << " " << ming << endl;
  }
  return 0;
}
