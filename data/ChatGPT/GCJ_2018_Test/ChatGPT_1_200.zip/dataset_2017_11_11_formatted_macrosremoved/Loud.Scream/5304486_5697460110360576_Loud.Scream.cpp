#include <iostream>
#include <string>
#include <iomanip>
#include <vector>

using namespace std;

long long D, T;
string P;
vector<int> Cs;
vector<int> Ps;

int main()
{
  int T;
  cin >> T;

  long long cd, e;
  for (int i=0; i<T; ++i){
    cin >> D >> P;
    int len=P.size();
    cd=0; e=1; Cs.clear(); Ps.clear();
    for (int j=0; j<len; ++j){
      if (P[j]=='C'){
        e*=2;
        Cs.push_back(j);
      }
      else cd+=e;
      Ps.push_back(e);
    }
    if (cd <= D){
      cout << "Case #"<<(i+1)<<": 0" << endl;
      continue;
    }
    bool isGood=false;
    int theEnd=len-1;
    long long cnt=0;
    while (Cs.size() > 0){
      int j=Cs[Cs.size()-1];
      if (j==theEnd){ Cs.pop_back(); theEnd-=1; continue; }
      Ps[j]=Ps[j]>>1;
      cd-=Ps[j];
      ++cnt;
      if (cd <=D){
        cout << "Case #"<<(i+1)<<": " << cnt << endl;
        isGood=true;
        break;
      }
      Cs[Cs.size()-1]+=1;
    }
    if (!isGood){
      cout << "Case #"<<(i+1)<<": IMPOSSIBLE" << endl;
      continue;
    }
  }
  return 0;
}
