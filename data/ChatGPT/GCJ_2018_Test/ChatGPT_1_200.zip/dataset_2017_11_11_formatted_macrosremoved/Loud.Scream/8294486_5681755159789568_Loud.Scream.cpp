#include <iostream>
#include <string>
#include <set>

using namespace std;

typedef pair<int,char> mp;
typedef set<mp> mpset;

mpset sc;
int main()
{
  int T;
  cin >> T;

  int N, c, num;
  for (int i=1; i<=T; ++i){
    sc.clear();
    num=0;
    cin >> N;
    for (int n=0; n<N; ++n){
      cin >> c;
      num+=c;
      sc.insert(mp(-c,'A'+n));
    }
    cout << "Case #" << i << ":";
    while(num>0)
    {
      //cerr << "Case #" << i << " work on " << num << endl;
      if (num==3){
        mpset::const_iterator itr=sc.begin();
        cout << " " << itr->second
             << " " << (++itr)->second << (++itr)->second;
        break;
      }
      mp f=*sc.begin(); sc.erase(sc.begin());
      mp s=*sc.begin(); sc.erase(sc.begin());
      cout << " " << f.second << s.second;
      f.first+=1; s.first+=1;
      if (f.first<0) sc.insert(f);
      if (s.first<0) sc.insert(s);
      num-=2;
    }
    cout << endl;
  }
  cout.flush();
  return 0;
}
