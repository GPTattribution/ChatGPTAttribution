#include <iostream>
#include <string>
#include <iomanip>
#include <algorithm>

using namespace std;

int T;
int N;
int odd[100001];
int oddL, evenL;
int even[100001];

int main()
{
  int T;
  cin >> T;

  int a; bool isOdd;
  for (int i=0; i<T; ++i){
    cin >> N;
    oddL=evenL=0; isOdd=false;
    for (int j=0; j<N; ++j){
      cin >> a;
      if (isOdd){ odd[oddL]=a; ++oddL; }
      else { even[evenL]=a; ++evenL; }
      isOdd = !isOdd;
    }
    sort(odd, odd+oddL);
    sort(even, even+evenL);
    isOdd=false; bool isGood=true;
    for (int j=1; j<N; ++j){
      int prev=isOdd?odd[(j-2)>>1] : even[(j-1)>>1];
      int cur=isOdd?even[j>>1] : odd[(j-1)>>1];
      if (prev > cur){ cout << "Case #"<<(i+1)<<": " << j-1 << endl; isGood=false; break; }
      isOdd = !isOdd;
    }
    if (isGood) cout << "Case #"<<(i+1)<<": OK" << endl;
  }
  return 0;
}
