#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int cnt=0;
int A;
int R1,R2,C1,C2;
bool grid[1001][1001];
bool stop=false;
bool done=false;
int round=1;
void guess(int a, int b, int e, int f)
{
  ++cnt;
  cout << a << " " << b << endl; cout.flush();
  int c, d;
  cin >> c >> d;
  if (c==0 && d==0){
    done=true;
    return;
  }
  if (c==-1 && d==-1){
    stop=true;
    return;
  }
  grid[c][d]=true;
  if (e==c && f==d){
    if (round==3) return;
    do {
      if (b==C2-1){
        b=C1+1;
        a+=2;
        if (a>R2-1){
          if (round==1){
            round=2; a=R1+2;
          }
          else if (round==2){
            round=3;
            if (!grid[R1][C1]) guess(R1+1, C1+1, R1, C1);
            if (done) return;
            if (!grid[R1][C2]) guess(R1+1, C2-1, R1, C2);
            if (done) return;
            if (!grid[R2][C1]) guess(R2-1, C1+1, R2, C1);
            if (done) return;
            if (!grid[R2][C2]) guess(R2-1, C2-1, R2, C2);
            if (done) return;
            for (int j=R1+1; j<=R2; ++j){
              if (!grid[j][C1]) guess(j, C1+1, j, C1);
              if (done) return;
              if (!grid[j][C2]) guess(j, C2-1, j, C2);
              if (done) return;
            }
            for (int j=C1+1; j<C2; ++j){
              if (!grid[R1][j]) guess(R1+1, j, R1, j);
              if (done) return;
              if (!grid[R2][j]) guess(R2-1, j, R2, j);
              if (done) return;
            }
            return;
          }
        }
      }
      else ++b;
    } while (grid[a][b]);
    guess(a,b,a,b);
    if (done) return;
  }
  else
  {
    guess(a,b,e,f);
    if (done) return;
  }
}

int main()
{

  int T;
  cin >> T;

  for (int i=0; i<T; ++i){
    cin >> A;
    cnt=0;
    round=1; done=false;
    if (A<=20){
      R1=500; R2=504;
      C1=500; C2=503;
      for (int j=R1; j<=R2; ++j)
        for (int k=C1; k<=C2; ++k)
          grid[j][k]=false;
      guess(R1+1,501, R1+1, 501);
    }
    else if (A<=200){
      R1=500; R2=519;
      C1=500; C2=509;
      for (int j=R1; j<=R2; ++j)
        for (int k=C1; k<=C2; ++k)
          grid[j][k]=false;
      guess(R1+1,501, R1+1, 501);
    }
    if (stop) break;
  }
  return 0;
}
