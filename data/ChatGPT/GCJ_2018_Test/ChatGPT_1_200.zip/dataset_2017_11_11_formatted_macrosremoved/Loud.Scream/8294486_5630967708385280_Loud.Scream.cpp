#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

long long D;
int main()
{
  int T;
  cin >> T;

  long long N, a, b;
  double tm=-1, t;
  for (int i=0; i<T; ++i){
    tm=-1;
    //cerr << "Case #" << i+1 << endl;
    cin >> D >> N;
    for (int j=0; j<N; ++j){
      cin >> a >> b;
      t=((double)(D-a))/b;
      if (tm<0) tm=t;
      else if (tm<t) tm=t;
      //cerr << "tm: " << tm << " speed " << b << endl;
    }
    cout << "Case #"<<(i+1)<<": " << fixed
      << setprecision(6) << ((double)D)/tm << endl;
  }
  return 0;
}
