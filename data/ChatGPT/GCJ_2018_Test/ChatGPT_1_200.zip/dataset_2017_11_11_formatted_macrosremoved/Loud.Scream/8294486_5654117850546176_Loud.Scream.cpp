#include <iostream>
#include <string>


using namespace std;

int cnt=0;
int n=0;
string res;
bool stop=false;
bool guess(int a, int b)
{
  //cerr << "guess (" << a << " , " << b << "]" << endl;
  //cerr.flush();
  if (a>=b) return false;
  if (cnt > n) return false;
  ++cnt;
  if (b==a+1)
  {
    cout << b << endl; cout.flush();
    cin >> res;
    if (res == "CORRECT"){
      //cerr << res << " " << a << " " << b << " " << b << endl;
      return true;
    }
    //cerr << "impossible: " << a << " " << b << endl;
    //cerr.flush();
    return false;
  }
  int c=(a+b)>>1;
  cout << c << endl; cout.flush();
  cin >> res;
  if (res=="TOO_BIG")
  {
    return guess(a, c-1);
  }
  else if (res=="TOO_SMALL")
  {
    return guess(c, b);
  }
  else if (res=="CORRECT")
  {
    //cerr << res << " " << a << " " << b << " " << c << endl;
    return true;
  }
  else if (res=="WRONG_ANSWER")
  {
    //cerr << res << " " << a << " " << b << " " << c << endl;
    stop=true;
  }
  else
  {
    //cerr << res << " " << a << " " << b << " " << c << endl;
  }
  return false;
}

int main()
{
  int T;
  cin >> T;

  int a, b;
  for (int i=0; i<T; ++i){
    cin >> a >> b >> n;
    cnt=0;
    guess(a,b);
    if (stop) break;
  }
  return 0;
}
