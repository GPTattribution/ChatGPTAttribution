#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;
typedef double ld;

typedef pair<ll, ll> ii;
typedef vector<ll> vi;
typedef vector<ii> vii;

#define PB push_back
#define ff first
#define ss second

#define FOR(prom,a,b) for ( ll prom = (a); prom < (ll)(b); ++prom )
#define F(a) FOR(i,0,a)
#define FF(a) FOR(j,0,a)

#define EPS (1e-10)
#define EQ(a,b) (fabs(a-b) <= fabs(a+b) * EPS)
#define LINF (1LL<<62LL)

ll T, c = 0;
ll P, chairs;
priority_queue<pair<ll, char> > senat;

int main(int argc, char const *argv[])
{
	ios::sync_with_stdio(false);

	cin >> T;

	while (T--) {
		//senat.clear();
		cin >> P;
		chairs = 0;
		F(P) {
			ll x;
			cin >> x;
			chairs += x;
			senat.push({x,i+'A'});
		}
		cout << "Case #" << ++c << ":";
		while (!senat.empty()) {
			pair<ll, char> tmp;
			tmp = senat.top();
			senat.pop();
			cout << " " << tmp.ss;
			--tmp.ff;
			--chairs;
			if (tmp.ff) senat.push(tmp);
			if (senat.size() > 2 ||
				( senat.size() == 2 && senat.top().ff > 1 ) ||
				senat.size() == 1)
			{
				tmp = senat.top();
				senat.pop();
				cout << tmp.ss;
				--tmp.ff;
				--chairs;
				if (tmp.ff) senat.push(tmp);
			}
		}
		cout << endl;
	}

	return 0;
}
