#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;
typedef double ld;

typedef pair<ll, ll> ii;
typedef vector<ll> vi;
typedef vector<ii> vii;

#define PB push_back
#define ff first
#define ss second

#define FOR(prom,a,b) for ( ll prom = (a); prom < (ll)(b); ++prom )
#define F(a) FOR(i,0,a)
#define FF(a) FOR(j,0,a)

#define EPS (1e-10)
#define EQ(a,b) (fabs(a-b) <= fabs(a+b) * EPS)
#define LINF (1LL<<62LL)

ll T, c = 0;
ll K, N;
ll gap;
map<ll, ll> m;

int main(int argc, char const *argv[])
{
 ios::sync_with_stdio(false);

 cin >> T;
 while (T--) {
	 m.clear();
	 cin >> N >> K;
	 m[N] = 1;
	 while (K > 0) {
		 auto it = m.rbegin();
		 auto tmp = *it;
		 m.erase(tmp.ff);
		 K -= tmp.ss;
		 //cerr << K << " " << tmp.ff << " " << tmp.ss << endl;
		 gap = tmp.ff / 2;
		 if (tmp.ff % 2 == 1) {
			 if (K <= 0) cout << "Case #" << ++c << ": " << gap << " " << gap << endl;
			 m[gap] += 2 * tmp.ss;
		 } else {
			 if (K <= 0) cout << "Case #" << ++c << ": " << gap << " " << gap-1 << endl;
			 m[gap] += tmp.ss;
			 m[gap-1] += tmp.ss;
		 }
	 }
 }

 return 0;
}
