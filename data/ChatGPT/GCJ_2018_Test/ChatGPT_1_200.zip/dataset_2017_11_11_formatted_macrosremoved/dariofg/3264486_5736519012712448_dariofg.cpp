#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;
typedef double ld;

typedef pair<ll, ll> ii;
typedef vector<ll> vi;
typedef vector<ii> vii;

#define PB push_back
#define ff first
#define ss second

#define FOR(prom,a,b) for ( ll prom = (a); prom < (ll)(b); ++prom )
#define F(a) FOR(i,0,a)
#define FF(a) FOR(j,0,a)

#define EPS (1e-10)
#define EQ(a,b) (fabs(a-b) <= fabs(a+b) * EPS)
#define LINF (1LL<<62LL)
#define MX 1

ll T, N, res;
ll it;
vi odd, eve;
bool ctr;

int main(int argc, char const *argv[])
{
	ios::sync_with_stdio(false);

	cin >> T;

	FF(T) {
		odd.clear(); eve.clear();
		cin >> N;
		ctr = true;
		F(N) {
			ll tmp;
			cin >> tmp;
			if (ctr) odd.PB(tmp);
			else eve.PB(tmp);
			ctr ^= true;
		}
		sort(odd.begin(), odd.end());
		sort(eve.begin(), eve.end());
		ctr = true;
		res = -1;
		it = 0;
		F(N) {
			//cerr << it << endl;
			if ( (it < (int)eve.size() && ctr && odd[it] > eve[it])
				 || (it+1 < (int)odd.size() && !ctr && eve[it] > odd[it+1]) ) {
				res = i;
				break;
			}
			if (!ctr) ++it;
			ctr ^= true;
		}
		if (res == -1)
			cout << "Case #" << j+1 << ": OK"<< endl;
		else
			cout << "Case #" << j+1 << ": " << res << endl;
	}

	return 0;
}
