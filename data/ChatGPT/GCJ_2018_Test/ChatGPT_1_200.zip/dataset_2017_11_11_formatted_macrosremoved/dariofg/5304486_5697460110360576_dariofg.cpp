#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;
typedef double ld;

typedef pair<ll, ll> ii;
typedef vector<ll> vi;
typedef vector<ii> vii;

#define PB push_back
#define ff first
#define ss second

#define FOR(prom,a,b) for ( ll prom = (a); prom < (ll)(b); ++prom )
#define F(a) FOR(i,0,a)
#define FF(a) FOR(j,0,a)

#define EPS (1e-10)
#define EQ(a,b) (fabs(a-b) <= fabs(a+b) * EPS)
#define LINF (1LL<<62LL)
#define MX 30

ll T, D, it, shoots, dmg, steps;
ii order[MX];
string s;

int main(int argc, char const *argv[])
{
	ios::sync_with_stdio(false);

	cin >> T;

	FF(T) {
		F(MX) order[i]={1<<i,0};
		cin >> D;
		cin >> s;
		it = 0;
		steps = dmg = shoots = 0;
		F(s.length()) {
			if (s[i] == 'C') ++it;
			else ++order[it].ss, ++shoots, dmg += order[it].ff;
		}
		if (shoots > D) {
			cout << "Case #" << j+1 << ": IMPOSSIBLE" << endl;
			continue;
		}
		while (dmg > D) {
			if (it && order[it].ss) {
				--order[it].ss;
				++order[it-1].ss;
				dmg -= order[it-1].ff;
				++steps;
			} else
				--it;
		}
		cout << "Case #" << j+1 << ": " << steps << endl;
	}

	return 0;
}
