#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;
typedef double ld;

typedef pair<ll, ll> ii;
typedef vector<ll> vi;
typedef vector<ii> vii;

#define PB push_back
#define ff first
#define ss second

#define FOR(prom,a,b) for ( ll prom = (a); prom < (ll)(b); ++prom )
#define F(a) FOR(i,0,a)
#define FF(a) FOR(j,0,a)

#define EPS (1e-10)
#define EQ(a,b) (fabs(a-b) <= fabs(a+b) * EPS)
#define LINF (1LL<<62LL)

ll T, c = 0;
ll N;
double last, D;

int main(int argc, char const *argv[])
{
	ios::sync_with_stdio(false);
	cin >> T;
	while (T--) {
		last = 0;
		cin >> D >> N;
		F(N) {
			double x, s;
			cin >> x >> s;
			x = D - x;
			s = x / s;
			last = max(last, s);
		}

		cout << fixed << setprecision(6) << "Case #" << ++c << ": " << D / last << endl;
	}

 	return 0;
}
