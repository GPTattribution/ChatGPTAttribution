#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;
typedef double ld;

typedef pair<ll, ll> ii;
typedef vector<ll> vi;
typedef vector<ii> vii;

#define PB push_back
#define ff first
#define ss second

#define FOR(prom,a,b) for ( ll prom = (a); prom < (ll)(b); ++prom )
#define F(a) FOR(i,0,a)
#define FF(a) FOR(j,0,a)

#define EPS (1e-10)
#define EQ(a,b) (fabs(a-b) <= fabs(a+b) * EPS)
#define LINF (1LL<<62LL)

ll T;
ll n;
ll lo, mi, hi;
bool correct;
string line;

int main(int argc, char const *argv[])
{
	ios::sync_with_stdio(false);

	cin >> T;

	while ( T-- ) {
		cin >> lo >> hi >> n;
		correct = false;
		mi = (lo + hi)/2;
		while ( !correct ) {
			cout << mi << endl << flush;
			//cerr << mi << endl;
			//getline(cin, line);
			cin >> line;
			//cerr << line << endl;
			if (line == "TOO_BIG") {
				//cerr << "big" << endl;
				hi = mi - 1;
			} else if (line == "TOO_SMALL") {
				//cerr << "small" << endl;
				lo = mi;
			} else if (line == "WRONG_ANSWER") {
				//cerr << "WA" << endl;
				break;
			} else {
				correct = true;
			}
			mi = (lo + hi)/2;
			if (mi == lo) ++mi;
		}

	}

	return 0;
}
