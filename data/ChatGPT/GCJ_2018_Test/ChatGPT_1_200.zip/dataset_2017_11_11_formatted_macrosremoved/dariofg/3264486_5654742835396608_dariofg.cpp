#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;
typedef double ld;

typedef pair<ll, ll> ii;
typedef vector<ll> vi;
typedef vector<ii> vii;

#define PB push_back
#define ff first
#define ss second

#define FOR(prom,a,b) for ( ll prom = (a); prom < (ll)(b); ++prom )
#define F(a) FOR(i,0,a)
#define FF(a) FOR(j,0,a)

#define EPS (1e-10)
#define EQ(a,b) (fabs(a-b) <= fabs(a+b) * EPS)
#define LINF (1LL<<62LL)
#define MX 1000

ll T, A;
ll dx, dy, sx, sy, ex, ey;
ll x, y;
ll a, b;
int garden[MX][MX];
bool ctr;

ll count (ll x, ll y) {
	return 9 - ( garden[x-1][y+1] + garden[x][y+1] + garden[x+1][y+1]
		 	  +  garden[x-1][y]   + garden[x][y]   + garden[x+1][y]
			  +  garden[x-1][y-1] + garden[x][y-1] + garden[x+1][y-1] );
}

int main(int argc, char const *argv[])
{
	ios::sync_with_stdio(false);

	cin >> T;

	FF(T) {
		cin >> A;
		dx = sqrt(A);
		dy = dx;
		if (dx*dy < A) ++dy;
		if (dx*dy < A) ++dx;
		memset(garden, 0, sizeof(garden[0][0])*MX*MX);
		x = y = sx = sy = 3;
		ex = sx + dx - 3;
		ey = sy + dy - 3;

		ll steps = 0;
		ctr = false;

		cout << x << " " << y << endl;
		while (cin >> a >> b && a != 0 && a != -1) {
			//cerr << "bad " << x << " " << y << " " << count(x, y) << endl;
			garden[a][b] = 1;
			if ((ctr && count(x,y)>1) || count(x, y) >= 5) {
				cout << x << " " << y << endl;
				continue;
			}
			++x;
			if (x > ex) x = sx, ++y;
			if (y > ey) x = sx, y = sy, ctr = true;
			cout << x << " " << y << endl;
			++steps;
		}
		cerr << "Case #" << j+1 << " : " << steps << endl;
	}

	return 0;
}
