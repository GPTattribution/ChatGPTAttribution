#include <bits/stdc++.h>
#include <ext/pb_ds/tree_policy.hpp>
#include <ext/pb_ds/assoc_container.hpp>

using namespace std;
using namespace __gnu_pbds;

typedef long long ll;
typedef long double ld;
typedef complex<ld> cd;

typedef pair<int, int> pi;
typedef pair<ll,ll> pl;
typedef pair<double,double> pd;

typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pi> vpi;

template <class T> using Tree = tree<T, null_type, less<T>, rb_tree_tag,tree_order_statistics_node_update>;

#define FOR(i, a, b) for (int i=a; i<(b); i++)
#define F0R(i, a) for (int i=0; i<(a); i++)
#define FORd(i,a,b) for (int i = (b)-1; i >= a; i--)
#define F0Rd(i,a) for (int i = (a)-1; i >= 0; i--)

#define sz(x) (int)(x).size()
#define mp make_pair
#define pb push_back
#define f first
#define s second
#define lb lower_bound
#define ub upper_bound
#define all(x) x.begin(), x.end()

const int MOD = 1000000007;
const ll INF = 1e18;
const int MX = 100001;

bool done[14][15];

pi select() {
    pair<int,pi> bes = {-1,{-1,-1}};
    FOR(i,1,13) FOR(j,1,14) {
        int val = 0;
        FOR(i1,i-1,i+2) FOR(j1,j-1,j+2) if (!done[i1][j1]) {
            if ((i1 == 0 || i1 == 13) && (j1 == 0 || j1 == 14)) val += 100;
            else if ((i1 == 0 || i1 == 13) || (j1 == 0 || j1 == 14)) val += 10;
            else val ++;
        }
        bes = max(bes,{val,{i,j}});
    }
    return bes.s;
}

pi query(int a, int b) {
    cout << a << " " << b << endl;
    // pi Z = {a+(rand()%3)-1,b+(rand()%3)-1};
    pi Z; cin >> Z.f >> Z.s;
    if (Z != mp(0,0)) done[Z.f-10][Z.s-10] = 1;
    // int ret = 0;
    // F0R(i,14) F0R(j,15) ret += done[i][j];
    // if (ret == 210) exit(0);
    // cout << "AH " << Z.f << " " << Z.s << "\n";
    return Z;
}

void solve() {
    int a; cin >> a;
    memset(done,0,sizeof done);
    while (1) {
        pi z = select();
        pi Z = query(z.f+10,z.s+10);
        if (Z.f == 0 && Z.s == 0) return;
    }
}

int main() {
    ios_base::sync_with_stdio(0); cin.tie(0);
    int T; cin >> T;
    FOR(i,1,T+1) solve();
}

// read the question correctly (is y a vowel?)
// look out for SPECIAL CASES (n=1?) and overflow (ll vs int?)
