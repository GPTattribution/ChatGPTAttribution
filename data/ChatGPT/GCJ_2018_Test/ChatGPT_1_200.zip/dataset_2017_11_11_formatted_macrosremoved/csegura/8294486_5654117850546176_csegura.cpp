#include <bits/stdc++.h>
using namespace std;

int TCs;
int A, B, N;
char ans[100];
int i, x, Q;

int main(){
	scanf("%d", &TCs);
	while(TCs--){
		scanf("%d%d%d", &A, &B, &N);
		A++;

		Q = (A+B)/2;
		printf("%d\n", Q);
		cout << flush;
		while(1){
			scanf("%s", ans);

			if (!strcmp(ans, "CORRECT")) break;

			if (!strcmp(ans, "TOO_SMALL")) A = Q+1;
			else B = Q-1;

			Q = (A+B)/2;
			printf("%d\n", Q);
			cout << flush;
		}


	}

	return 0;
}
