#include <bits/stdc++.h>
using namespace std;

#define mp make_pair
#define ft first
#define sd second

int TCs, TC;
int A;
int rec[5][100];
int remain[100];
int i, x, y, c, maxX, ans;

int main(){
	scanf("%d", &TCs);
	for (TC=1; TC<=TCs; TC++){
		scanf("%d", &A);
		memset(rec, 0, sizeof(rec));

		if (A==20) maxX = 6;
		if (A==200) maxX = 66;

		for (y=2; y<=maxX; y++) remain[y] = 9;

		c = 2;
		printf("2 %d\n", c);
		cout << flush;
		ans = 0;

		while(1){
			scanf("%d%d", &x, &y);
			if (!x) if (!y){
				//fprintf(stderr, "ans %d\n", ans);
				break;
			}
			ans++;
			if (!rec[x][y]){
				rec[x][y] = 1;
				for (i=y-1; i<=y+1; i++) remain[i]--;
			}

			for (c=2; c<=maxX; c+=3) if (remain[c]) break;
			if (c>maxX) c = maxX;

			printf("2 %d\n", c);
			cout << flush;
		}

	}

	return 0;
}
