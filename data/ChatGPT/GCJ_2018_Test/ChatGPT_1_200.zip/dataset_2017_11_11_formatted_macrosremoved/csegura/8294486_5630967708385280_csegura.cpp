#include <bits/stdc++.h>
using namespace std;

#define ft first
#define sd second
#define mp make_pair
#define pb push_back

int TCs, TC;
double D;
int N;
double ansT;
int i;
typedef pair<double, double> PDD;
vector <PDD> H;

int main(){
	scanf("%d", &TCs);
	for (TC=1; TC<=TCs; TC++){
		printf("Case #%d: ", TC);
		H.clear();

		scanf("%lf%d", &D, &N);
		for (i=0; i<N; i++){
			double K, S;
			scanf("%lf%lf", &K, &S);
			H.pb(mp(K, S));
		}
		sort(H.begin(), H.end());

		ansT = 0.0;
		for (i=N-1; i>=0; i--) ansT = max(ansT, (D-H[i].ft)/H[i].sd);

		printf("%.7lf\n", D/ansT);
	}

	return 0;
}
