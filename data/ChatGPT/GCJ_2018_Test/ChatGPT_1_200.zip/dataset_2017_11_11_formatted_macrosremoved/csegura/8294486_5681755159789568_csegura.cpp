#include <bits/stdc++.h>
using namespace std;

#define ft first
#define sd second
#define mp make_pair

int TCs, TC;
int N;
int P[100];
int i, x, sum;
char c;
typedef pair<int, char> PIC;
priority_queue<PIC, vector<PIC>, less<PIC> > PQ;

int main(){
	scanf("%d", &TCs);
	for (TC=1; TC<=TCs; TC++){
		printf("Case #%d:", TC);
		while(!PQ.empty()) PQ.pop();
		sum = 0;

		scanf("%d", &N);
		for (i=0; i<N; i++){
			scanf("%d", &P[i]);
			sum += P[i];
			PQ.push(mp(P[i], 'A'+i));
		}

		if (N==2){
			for (i=0; i<P[0]; i++) printf(" AB");
			puts("");
			continue;
		}

		while(sum>2){
			x = PQ.top().ft;
			c = PQ.top().sd;

			printf(" %c", c);
			PQ.pop();
			x--;
			if (x) PQ.push(mp(x, c));
			sum--;
		}

		printf(" %c", PQ.top().sd);
		PQ.pop();
		printf("%c\n", PQ.top().sd);
		PQ.pop();

	}

	return 0;
}
