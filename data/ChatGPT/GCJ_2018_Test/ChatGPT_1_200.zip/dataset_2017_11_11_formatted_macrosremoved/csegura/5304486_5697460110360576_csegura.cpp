#include <bits/stdc++.h>
using namespace std;

int TCs, TC;
int D;
char input[100];
int c[100];
int i, x, y, N, L, ans;

int main(){
	scanf("%d", &TCs);
	for (TC=1; TC<=TCs; TC++){
		printf("Case #%d: ", TC);

		scanf("%d%s", &D, input);
		memset(c, 0, sizeof(c));
		L = strlen(input);

		N = 0;
		for (i=0; i<L; i++) if (input[i]=='S') N++;
		if (N>D){
			puts("IMPOSSIBLE");
			continue;
		}

		N = 0;
		x = 0;
		for (i=0; i<L; i++){
			if (input[i]=='S'){
				c[x]++;
				N += (1<<x);
			}
			if (input[i]=='C') x++;
		}

		if (N<=D){
			puts("0");
			continue;
		}

		ans = 0;
		for (x=L-1; x>=0; x--){
			if (c[x]==0) continue;
			int t = (N-D+(1<<(x-1))-1) / (1<<(x-1));
			if (t>c[x]){
				ans += c[x];
				N -= (c[x]*(1<<(x-1)));
				c[x-1] += c[x];
				c[x] = 0;
				continue;
			}
			ans += t;
			break;
		}

		printf("%d\n", ans);
	}

	return 0;
}
