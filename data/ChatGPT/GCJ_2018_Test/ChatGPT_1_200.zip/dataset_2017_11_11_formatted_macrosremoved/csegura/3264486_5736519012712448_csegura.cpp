#include <bits/stdc++.h>
using namespace std;

const int INF = (1e+9)+7;
int TCs, TC;
int N;
int A[50010];
int B[50010];
int i, x, y, N2;

int Judge(){
	for (i=0; i<N2; i++){
		if (A[i]>B[i]) return i*2;
		if (B[i]>A[i+1]) return i*2+1;
	}
	return -1;
}

int main(){
	scanf("%d", &TCs);
	for (TC=1; TC<=TCs; TC++){
		printf("Case #%d: ", TC);

		scanf("%d", &N);
		N2 = N/2;
		for (i=0; i<N2; i++) scanf("%d%d", &A[i], &B[i]);
		A[N2] = INF;
		B[N2] = INF;
		if (N&1){
			scanf("%d", &A[N2]);
			N2++;
			A[N2] = INF;
			B[N2] = INF;
		}

		sort(A, A+N2);
		sort(B, B+N2);

		int ans = Judge();
		if (ans==-1) puts("OK");
		else printf("%d\n", ans);

	}

	return 0;
}
