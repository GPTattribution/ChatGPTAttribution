#include <iostream>
#include <cmath>
#include <vector>

const double EPS = 1e-6;

std::vector<double> solve(double A) {
    double theta = acos(A / sqrt(2));
    double half_length = 0.5;
    std::vector<double> result(9);

    result[0] = half_length * cos(theta);
    result[1] = half_length * sin(theta);
    result[2] = 0;

    result[3] = -half_length * sin(theta);
    result[4] = half_length * cos(theta);
    result[5] = 0;

    result[6] = 0;
    result[7] = 0;
    result[8] = half_length;

    return result;
}

int main() {
    int T;
    double A;
    std::cin >> T;

    for (int i = 1; i <= T; ++i) {
        std::cin >> A;
        std::vector<double> result = solve(A);
        std::cout.precision(15);

        std::cout << "Case #" << i << ":" << std::endl;
        for (int j = 0; j < 9; j += 3) {
            std::cout << result[j] << " " << result[j+1] << " " << result[j+2] << std::endl;
        }
    }

    return 0;
}
