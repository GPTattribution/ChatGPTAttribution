#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(A) ((int)(A).size())

typedef long long LL;

LL eval(string s) {
  LL res = 0;
  LL dmg = 1;
  for (char c : s) {
    if (c == 'C')
      dmg *= 2;
    else
      res += dmg;
  }
  return res;
}

bool proc(string& s) {
  bool foundS = false;
  int pos = -1;
  for (int i = sz(s) - 1; i >= 0; i--) {
    if (s[i] == 'S')
      foundS = true;
    else if (foundS) {
      pos = i;
      break;
    }
  }
  if (pos == -1)
    return false;
  swap(s[pos], s[pos + 1]);
  return true;
}

void solve(int t) {
  int d;
  string p;
  cin >> d >> p;
  int ans = 0;
  while (eval(p) > d) {
    if (!proc(p)) {
      ans = -1;
      break;
    }
    ans++;
  }
  cout << "Case #" << t << ": " << (ans == -1 ? "IMPOSSIBLE" : std::to_string(ans)) << endl;
}

int main() {
  ios::sync_with_stdio(0);
  int T;
  cin >> T;
  for (int i = 0; i < T; i++) {
    solve(i + 1);
  }
  return 0;
}
