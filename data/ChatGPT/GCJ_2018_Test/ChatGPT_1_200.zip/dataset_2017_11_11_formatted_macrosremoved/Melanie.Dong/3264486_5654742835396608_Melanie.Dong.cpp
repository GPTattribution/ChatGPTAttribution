#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(A) ((int)(A).size())

typedef long long LL;

const int N = 1005;

bool used[N][4];

void solve(int t) {
  int a;
  cin >> a;
  int xMax = (a + 2) / 3;
  for (int i = 0; i < N; i++) {
    for (int j = 0; j < 4; j++) {
      used[i][j] = false;
    }
  }
  for (int x = 2;;) {
    cout << x << " " << 2 << endl;
    int x_, y_;
    cin >> x_ >> y_;
    if (x_ == 0 && y_ == 0) {
      break;
    }
    used[x_][y_] = 1;
    if (x < 1 + xMax && used[x - 1][1] && used[x - 1][2] && used[x - 1][3]) {
      x++;
    }
  }
}

int main() {
  ios::sync_with_stdio(0);
  int T;
  cin >> T;
  for (int i = 0; i < T; i++) {
    solve(i + 1);
  }
  return 0;
}
