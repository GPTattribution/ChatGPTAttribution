#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(A) ((int)(A).size())

typedef long long LL;

const int N = int(1e5 + 5);

int v[N], o[N], e[N];

void solve(int t) {
  int n;
  cin >> n;
  int cntO = 0, cntE = 0;
  for (int i = 0; i < n; i++) {
    cin >> v[i];
    if (i % 2 == 1) {
      o[i / 2] = v[i];
      cntO++;
    } else {
      e[i / 2] = v[i];
      cntE++;
    }
  }
  sort(o, o + cntO);
  sort(e, e + cntE);
  sort(v, v + n);
  int ans = -1;
  for (int i = 0; i < n; i++) {
    if (i % 2 == 1) {
      if (o[i / 2] != v[i]) {
        ans = i;
        break;
      }
    } else {
      if (e[i / 2] != v[i]) {
        ans = i;
        break;
      }
    }
  }
  cout << "Case #" << t << ": " << (ans == -1 ? "OK" : to_string(ans)) << endl;
}

int main() {
  ios::sync_with_stdio(0);
  int T;
  cin >> T;
  for (int i = 0; i < T; i++) {
    solve(i + 1);
  }
  return 0;
}
