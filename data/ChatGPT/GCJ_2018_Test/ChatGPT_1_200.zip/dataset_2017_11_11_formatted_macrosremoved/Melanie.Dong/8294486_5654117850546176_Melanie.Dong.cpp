#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(A) ((int)(A).size())

typedef long long LL;

int main() {
  ios::sync_with_stdio(0);
  int t;
  cin >> t;
  for (int i = 0; i < t; i++) {
    int a, b, n;
    cin >> a >> b >> n;
    a++, b++;
    while (1) {
      int mid = (a + b) / 2;
      cout << mid << endl;
      string res;
      cin >> res;
      if (res == "CORRECT") break;
      if (res == "TOO_BIG") b = mid;
      if (res == "TOO_SMALL") a = mid;
    }
  }
  return 0;
}
