#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(A) ((int)(A).size())

typedef long long LL;

int main() {
  ios::sync_with_stdio(0);
  int t;
  cin >> t;

  for (int i = 0; i < t; i++) {
    int d, n;
    double mx = 0;
    cin >> d >> n;
    for (int j = 0; j < n; j++) {
      int kj, sj;
      cin >> kj >> sj;
      mx = max(mx, double(d - kj) / sj);
    }
    cout.precision(6);
    cout << fixed << "Case #" << i + 1 << ": " << d / mx << endl;
  }

  return 0;
}
