#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(A) ((int)(A).size())

typedef long long LL;

const int N = 26;

int p[N];

int main() {
  ios::sync_with_stdio(0);
  int t;
  cin >> t;
  for (int i = 0; i < t; i++) {
    int n;
    cin >> n;
    for (int j = 0; j < n; j++) {
      cin >> p[j];
    }
    cout << "Case #" << i + 1 << ": ";
    bool stay = true;
    while (stay) {
      stay = false;
      int mx = 1;
      for (int j = 0; j < n; j++) {
        if (p[j] > 0) {
          stay = true;
          mx = max(p[j], mx);
        }
      }
      int cntMx = 0;
      string best;
      for (int j = 0; j < n; j++) {
        if (mx == p[j]) {
          cntMx++;
          best += 'A' + j;
        }
      }
      if (cntMx == 2) {
        cout << best[0] << best[1] << " ";
        p[best[0] - 'A']--;
        p[best[1] - 'A']--;
      } else if (stay) {
        cout << best[0] << " ";
        p[best[0] - 'A']--;
      }
    }
    cout << endl;
  }
  return 0;
}
