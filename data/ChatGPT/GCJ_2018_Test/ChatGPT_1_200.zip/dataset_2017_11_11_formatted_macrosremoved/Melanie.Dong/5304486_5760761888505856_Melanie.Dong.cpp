#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(A) ((int)(A).size())

typedef long long LL;

multiset<int> all;

int main() {
  ios::sync_with_stdio(0);
  int t;
  cin >> t;
  for (int i = 0; i < t; i++) {
    long long n, k;
    cin >> n >> k;
    all.clear();
    all.insert(n);
    int mx;
    for (int j = 0; j < k; j++) {
      mx = *all.rbegin();
      all.erase(all.find(mx));

      if (mx / 2 > 0)
        all.insert(mx / 2);

      if ((mx + 1) / 2 > 1)
        all.insert((mx + 1) / 2 - 1);
    }
    cout << "Case #" << i + 1 << ": " << mx / 2 << " " << (mx + 1) / 2 - 1 << " " << endl;
  }
  return 0;
}
