#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string.h>
#include <strings.h>
#include <string>
#include <algorithm>
#include <vector>
#include <set>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <math.h>
#include <cmath>
#include <map>
#include <list>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <functional>
#include <numeric>
#include <utility>
#include <iomanip>
#include <cmath>
#include <ctime>
#include <climits>
#include <assert.h>

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int,int> ii;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> int2;
typedef pair<float, float> float2;
typedef pair<ull, ull> ull2;

#define sz(a) int((a).size())
#define pb push_back
#define all(c) (c).begin(),(c).end()
#define tr(s,i) for ( __typeof((s).begin()) i = ((s).begin())   ; i != (s).end(); ++i)
#define present(c,x) ((c).find(x) != (c).end())
#define cpresent(c,x) (find(all(c),x) != (c).end())
#define mp(a,b) make_pair(a,b)
#define del(s,x) do {__typeof((s).begin()) abcde=(s).find(x); if(abcde !=(s).end()) s.erase(abcde); } while(0);
#define del2(s,x) do {__typeof((s).begin()) abcde=find(all(s),x); if(abcde !=(s).end()) s.erase(abcde); } while(0);

#define FOR(i,a,b) for(int i=int(a); i<int(b); ++i)

void add(vector<pair<ll,ll> > &v, int i, ll x, ll occ) {
  if (x == 0) return;
  bool found = false;
  FOR(j,i,v.size()) {
    if (v[j].first == x) {
      found = true;
      v[j].second += occ;
    }
  }
  if (!found) v.pb(make_pair(x,occ));
}

int main() {
  int T;
  cin >> T;
  cout.precision(12);
  FOR (test, 1, T+1) {
    ll N, K; cin >> N >> K;
    ll s;
    vector<pair<ll,ll> > v(0);
    v.pb(make_pair(N,1));
    for (int idx = 0; ; idx++) {
      assert(idx < v.size());
      ll range = v[idx].first;
      ll occ = v[idx].second;
      ll x1 = range / 2;
      ll x2 = (range - 1) / 2;
      add(v, idx+1, x1, occ);
      add(v, idx+1, x2, occ);
      v[idx].second = 0;
      K -= occ;
      if (K <= 0) { s = range; break;}
    }

    cout << "Case #" << test << ": " << (s/2) << " " << ((s-1)/2) << endl;
  }
  return 0;
}
