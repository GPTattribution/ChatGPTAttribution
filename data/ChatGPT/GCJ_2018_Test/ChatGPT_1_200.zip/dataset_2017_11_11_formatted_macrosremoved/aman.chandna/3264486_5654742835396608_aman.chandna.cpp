#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string.h>
#include <strings.h>
#include <string>
#include <algorithm>
#include <vector>
#include <set>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <math.h>
#include <cmath>
#include <map>
#include <list>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <functional>
#include <numeric>
#include <utility>
#include <iomanip>
#include <cmath>
#include <ctime>
#include <climits>
#include <assert.h>

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int,int> ii;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> int2;
typedef pair<float, float> float2;
typedef pair<ull, ull> ull2;

#define sz(a) int((a).size())
#define pb push_back
#define all(c) (c).begin(),(c).end()
#define tr(s,i) for ( __typeof((s).begin()) i = ((s).begin())   ; i != (s).end(); ++i)
#define present(c,x) ((c).find(x) != (c).end())
#define cpresent(c,x) (find(all(c),x) != (c).end())
#define mp(a,b) make_pair(a,b)
#define del(s,x) do {__typeof((s).begin()) abcde=(s).find(x); if(abcde !=(s).end()) s.erase(abcde); } while(0);
#define del2(s,x) do {__typeof((s).begin()) abcde=find(all(s),x); if(abcde !=(s).end()) s.erase(abcde); } while(0);

#define FOR(i,a,b) for(int i=int(a); i<int(b); ++i)

int minattempt = 1001;
int maxattempt = 0;
int sum = 0;
int nb = 0;

void stats(vector<vector<bool> > &grid, int n, int trynb) {
    minattempt = min(minattempt,trynb);
    maxattempt = max(maxattempt,trynb);
    nb++; sum+=trynb;
    cerr << "Tries: " << trynb << " " << "min " << minattempt << " max " << maxattempt << " avg " << ((double)sum/nb) << endl;

    // int nbWithBorder = 0;
    // int nbWithoutBorder = 0;
    // FOR(i,2,n+1) FOR(j,2,n+1) if (grid[i][j]) nbWithBorder++;
    // FOR(i,3,n) FOR(j,3,n) if (grid[i][j]) nbWithoutBorder++;
    //    cerr << "Tries: " << trynum << " Inside " << nbWithoutBorder << " Outside " << (nbWithBorder-nbWithoutBorder) << endl;
}

int nbNeighbours(vector<vector<bool> > &grid, int a, int b) {
  int cpt = 0;
  FOR(i,-1,2) { FOR(j,-1,2) { if (grid[a+i][b+j]) { cpt++; } } }
  return cpt;
}

bool tryJudge(vector<vector<bool> > &grid, int a, int b) {
  cout << a << " " << b << endl;
  int c, d;
  cin >> c >> d;
  if (c == 0)
    return true;
  else if (c == -1)
    exit(0);
  else {
    grid[c][d] = true;
    return false;
  }
}

int main() {
  int maxmiss = 100;
  int T;
  cin >> T;
  cout.precision(12);
  FOR (test, 1, T+1) {
    int A; cin >> A;
    int n = (int) ceil(sqrt((double)A));
    vector<vector<bool> > grid(n+3, vector<bool>(n+3,false));
    int trynum = 0;
    bool endcase = false;
    // Attempt to fill     n x n     square from (2,2) to (n+1,n+1) inclusive
    // Attempts in     (n-2) x (n-2) square from (3,3) to (n,n)     inclusive
    for(; trynum < 1001; trynum++) {
      int mini = 9;
      int imini = 3;
      int jmini = 3;
      FOR(i,3,n+1) FOR(j,3,n+1) {
	int nb = nbNeighbours(grid,i,j);
	if (nb < mini) {
	  mini = nb;
	  imini = i;
	  jmini = j;
	}
      }
     endcase = tryJudge(grid,imini,jmini);
     if(endcase) {
       //stats(grid,n,trynum+1);
       break; // end of this test case
     }
    }
  }
  return 0;
}
