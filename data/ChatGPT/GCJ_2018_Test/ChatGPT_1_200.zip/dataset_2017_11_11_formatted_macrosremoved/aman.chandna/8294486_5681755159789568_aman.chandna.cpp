#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string.h>
#include <strings.h>
#include <string>
#include <algorithm>
#include <vector>
#include <set>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <math.h>
#include <cmath>
#include <map>
#include <list>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <functional>
#include <numeric>
#include <utility>
#include <iomanip>
#include <cmath>
#include <ctime>
#include <climits>
#include <assert.h>

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int,int> ii;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> int2;
typedef pair<float, float> float2;
typedef pair<ull, ull> ull2;

#define sz(a) int((a).size())
#define pb push_back
#define all(c) (c).begin(),(c).end()
#define tr(s,i) for ( __typeof((s).begin()) i = ((s).begin())   ; i != (s).end(); ++i)
#define present(c,x) ((c).find(x) != (c).end())
#define cpresent(c,x) (find(all(c),x) != (c).end())
#define mp(a,b) make_pair(a,b)
#define del(s,x) do {__typeof((s).begin()) abcde=(s).find(x); if(abcde !=(s).end()) s.erase(abcde); } while(0);
#define del2(s,x) do {__typeof((s).begin()) abcde=find(all(s),x); if(abcde !=(s).end()) s.erase(abcde); } while(0);

#define FOR(i,a,b) for(int i=int(a); i<int(b); ++i)

#define put(i) do {P[i].first--; cout << P[i].second; } while(0);
#define atmost(i) ((N==(i)) || (P[N-(i)-1].first == 0))

int main() {
  int T;
  cin >> T;
  cout.precision(12);
  FOR (test, 1, T+1) {
    int N; cin >> N;
    vector<pair<int,char> > P(N);
    FOR(i,0,N) {
      int v;
      cin >> v;
      P[i] = make_pair(v,'A'+i);
    }

    cout << "Case #" << test << ": ";
    while(1) {
      sort(all(P));
      if (P[N-1].first == 0) {
	cout << endl;
	break;
      }
      assert(!atmost(1));

      if (P[N-2].first == 1) { // If next move may remove one party
	if (atmost(2)) { // 2 senators left
	  put(N-1);
	  put(N-2);
	}
	else if (atmost(3)) { // 3 senators
	  assert(P[N-1].first <= 2);
	  put(N-1);
	  if (P[N-1].first > 0) put(N-1);
	}
      }
      else {
	put(N-1);
	put(N-2);
      }
      cout << " ";
    }
  }
  return 0;
}
