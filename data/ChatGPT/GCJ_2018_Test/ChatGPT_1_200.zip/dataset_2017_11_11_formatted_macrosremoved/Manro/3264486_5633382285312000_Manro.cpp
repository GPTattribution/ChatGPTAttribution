#include <iostream>
#include <cmath>
#include <iomanip>

const double pi = std::acos(-1);

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; ++t) {
        double A;
        std::cin >> A;

        double theta = std::acos((A - 1) / (std::sqrt(2) - 1));
        double phi = pi / 4 - theta / 2;

        double x = 0.5 * std::cos(phi);
        double z = 0.5 * std::sin(phi);
        double y = 0.5;

        std::cout << std::fixed << std::setprecision(15);
        std::cout << "Case #" << t << ":\n";
        std::cout << x << " " << 0.0 << " " << z << "\n";
        std::cout << -x << " " << 0.0 << " " << -z << "\n";
        std::cout << 0.0 << " " << y << " " << 0.0 << "\n";
    }

    return 0;
}
