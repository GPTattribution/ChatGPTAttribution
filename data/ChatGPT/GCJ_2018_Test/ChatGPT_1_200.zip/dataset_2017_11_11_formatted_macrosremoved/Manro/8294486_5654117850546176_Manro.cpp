#include <iostream>
#include <iomanip>
#include <vector>
#include <set>
#include <map>
#include <functional>
#include <algorithm>

using ll = int64_t;
using ul = uint64_t;

using namespace std;

void rep(size_t n, function<void(size_t)> f){
  for(size_t i = 0; i < n; ++i){
    f(i);
  }
}

void rep(size_t n, function<void(void)> f){
  for(size_t i = 0; i < n; ++i){
    f();
  }
}

template <typename T>
T sq(T a){ return a*a; }

template <typename T>
void readV(vector<T> &v, size_t n){
  rep(n, [&v](){
    T t;
    cin >> t;
    v.push_back(t);
  });
}

template <typename T1, typename T2>
void readV(vector<pair<T1, T2>> &v, size_t n){
  rep(n, [&v](){
    T1 a;
    T2 b;
    cin >> a >> b;
    v.push_back({a, b});
  });
}

void solve();

int main(){
  size_t t;
  cin >> t;
  rep(t, [](int i){
      //cout << "Case #" << i + 1 << ": ";
      solve();
  });
  return 0;
}

void solve(){
  ll mi;
  ll ma;
  ll g;
  string resp;
  cin >> mi >> ma >> g;
  do{
    g = (ma - mi)/2 + 1 + mi;
    cout << g << endl;
    cin >> resp;
    if(resp == "TOO_SMALL"){
      mi = g;
    }
    else if(resp == "TOO_BIG"){
      ma = g-1;
    }
    else if (resp == "CORRECT"){
      string ss;
      return;
    }
  }
  while(resp != "WRONG_ANSWER");
  exit(-1);

}
