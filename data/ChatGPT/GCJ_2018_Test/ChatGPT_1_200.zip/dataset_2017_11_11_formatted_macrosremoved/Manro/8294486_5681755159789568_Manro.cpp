#include <iostream>
#include <iomanip>
#include <vector>
#include <set>
#include <map>
#include <functional>
#include <algorithm>

using ll = int64_t;
using ul = uint64_t;

using namespace std;

void rep(size_t n, function<void(size_t)> f){
  for(size_t i = 0; i < n; ++i){
    f(i);
  }
}

void rep(size_t n, function<void(void)> f){
  for(size_t i = 0; i < n; ++i){
    f();
  }
}

template <typename T>
T sq(T a){ return a*a; }

template <typename T>
void readV(vector<T> &v, size_t n){
  rep(n, [&v](){
    T t;
    cin >> t;
    v.push_back(t);
  });
}

template <typename T1, typename T2>
void readV(vector<pair<T1, T2>> &v, size_t n){
  rep(n, [&v](){
    T1 a;
    T2 b;
    cin >> a >> b;
    v.push_back({a, b});
  });
}

void solve();

int main(){
  size_t t;
  cin >> t;
  rep(t, [](int i){
      cout << "Case #" << i + 1 << ": ";
      solve();
  });
  return 0;
}

void solve(){
  int n, m = 0;
  vector<pair<int, char>> v;
  cin >> n;
  char c = 'A';
  for(int i = 0; i < n; ++i){
    int t;
    cin >> t;
    v.push_back({t, c++});
    m += t;
  }
  if(n > 2){
    while(m > 2){
      sort(v.rbegin(), v.rend());
      cout << v.front().second << " ";
      --v.front().first;
      --m;
    }
  }
  else{
    while(m > 2){
      cout << "AB ";
      m = m-2;
    }
  }

  sort(v.rbegin(), v.rend());
  cout << v[0].second << v[1].second << endl;

}
