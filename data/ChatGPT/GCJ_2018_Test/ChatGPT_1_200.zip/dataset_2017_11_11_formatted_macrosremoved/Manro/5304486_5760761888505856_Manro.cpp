
#include <iostream>
#include <string>
#include <unordered_map>
#include <map>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

using Int = int64_t;

void solve(){
  Int people, stalls;
  cin >> stalls >> people;
  map<Int, Int, greater<Int>> ss;

  ss[stalls] = 1;

  while(people >= 0){
    auto it = ss.begin();
    Int stalls = it->first;
    Int num = it->second;
    ss.erase(it);

    people -= num;
    if(people <= 0){
      Int half = stalls/2;
      if(stalls & 1) cout << half << " " << half << endl;
      else cout << half << " " << half - 1 << endl;
      break;
    }

    ss[stalls/2] += num;
    if(stalls & 1){
      ss[stalls/2] += num;
    }
    else{
      ss[stalls/2-1] += num;
    }
  }
  return;
}

int main(){
  int n;
  cin >> n;
  for(int i = 0; i < n; ++i){
    cout << "Case #" << i + 1 << ": ";
    solve();
  }
  return 0;
}
