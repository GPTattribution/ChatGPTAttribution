#include <iostream>
#include <iomanip>
#include <vector>
#include <set>
#include <map>
#include <functional>
#include <algorithm>

using ll = int64_t;
using ul = uint64_t;

using namespace std;

void rep(size_t n, function<void(size_t)> f){
  for(size_t i = 0; i < n; ++i){
    f(i);
  }
}

void rep(size_t n, function<void(void)> f){
  for(size_t i = 0; i < n; ++i){
    f();
  }
}

template <typename T>
T sq(T a){ return a*a; }

template <typename T>
void readV(vector<T> &v, size_t n){
  rep(n, [&v](){
    T t;
    cin >> t;
    v.push_back(t);
  });
}

template <typename T1, typename T2>
void readV(vector<pair<T1, T2>> &v, size_t n){
  rep(n, [&v](){
    T1 a;
    T2 b;
    cin >> a >> b;
    v.push_back({a, b});
  });
}

void solve();

int main(){
  size_t t;
  cin >> t;
  rep(t, [](int i){
      cout << "Case #" << i + 1 << ": ";
      solve();
  });
  return 0;
}

void solve(){
  size_t n;
  cin >> n;
  vector<ll> v, v1, v2;
  for(size_t i = 0; i < n; ++i){
    ll a;
    cin >> a;
    if(i%2) v1.push_back(a);
    else v2.push_back(a);
  }
  sort(v1.begin(), v1.end());
  sort(v2.begin(), v2.end());
  for(size_t i = 0; i < n; ++i){
    if(i%2) v.push_back(v1[i/2]);
    else v.push_back(v2[i/2]);
  }

  for(size_t i = 0; i < n-1; ++i){
    if(v[i] > v[i+1]){
      cout << i << endl;
      return;
    }
  }
  cout << "OK" << endl;
}
