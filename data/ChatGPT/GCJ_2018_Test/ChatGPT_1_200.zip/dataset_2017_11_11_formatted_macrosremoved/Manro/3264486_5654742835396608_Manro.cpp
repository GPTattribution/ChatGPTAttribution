#include <iostream>
#include <iomanip>
#include <vector>
#include <set>
#include <map>
#include <functional>
#include <algorithm>

using ll = int64_t;
using ul = uint64_t;

using namespace std;

void rep(size_t n, function<void(size_t)> f){
  for(size_t i = 0; i < n; ++i){
    f(i);
  }
}

void rep(size_t n, function<void(void)> f){
  for(size_t i = 0; i < n; ++i){
    f();
  }
}

template <typename T>
T sq(T a){ return a*a; }

template <typename T>
void readV(vector<T> &v, size_t n){
  rep(n, [&v](){
    T t;
    cin >> t;
    v.push_back(t);
  });
}

template <typename T1, typename T2>
void readV(vector<pair<T1, T2>> &v, size_t n){
  rep(n, [&v](){
    T1 a;
    T2 b;
    cin >> a >> b;
    v.push_back({a, b});
  });
}

void solve();

int main(){
  size_t t;
  cin >> t;
  rep(t, [](int i){
      //cout << "Case #" << i + 1 << ": ";
      solve();
  });
  return 0;
}

using Grid = bool[20][20];

struct Coord {
  int x;
  int y;
};

int n_empty(Grid &grid, int x, int y){
  int n = 0;
  if(!grid[y][x]) ++n;
  if(!grid[y][x+1]) ++n;
  if(!grid[y][x-1]) ++n;
  if(!grid[y+1][x]) ++n;
  if(!grid[y+1][x+1]) ++n;
  if(!grid[y+1][x-1]) ++n;
  if(!grid[y-1][x]) ++n;
  if(!grid[y-1][x+1]) ++n;
  if(!grid[y-1][x-1]) ++n;
  return n;
}

bool run_gopher(Coord &c){
  ++c.x;
  ++c.y;
  cout << c.x << " " << c.y << endl;
  cin >> c.x >> c.y;
  if(c.x == -1){
    cerr << "Fail: " << c.x << " " << c.y << endl;
    exit(-1);
  }
  if(c.x == 0){
    return true;
  }
  --c.x;
  --c.y;
  return false;
}

void solve(){
  int a;
  cin >> a;
  int xm, ym;
  Grid grid = {false};
  xm = 10;
  ym = 20;
  int most_empty = 9;
  for(;;){
    bool found = false;
    for(int y = 1; y < ym-1; ++y){
      for(int x = 1; x < xm-1; ++x){
        if(n_empty(grid, x, y) == most_empty){
          found = true;
          Coord c{x,y};
          if(run_gopher(c)) return;
          grid[c.y][c.x] = true;
          break;
        }
      }
    }
    if(!found) --most_empty;
  }
}
