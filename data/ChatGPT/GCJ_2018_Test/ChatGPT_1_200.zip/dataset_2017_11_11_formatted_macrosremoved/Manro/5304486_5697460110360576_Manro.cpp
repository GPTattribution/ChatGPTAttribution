#include <iostream>
#include <iomanip>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <functional>
#include <algorithm>

using ll = int64_t;
using ul = uint64_t;

using namespace std;

void rep(size_t n, function<void(size_t)> f){
  for(size_t i = 0; i < n; ++i){
    f(i);
  }
}

void rep(size_t n, function<void(void)> f){
  for(size_t i = 0; i < n; ++i){
    f();
  }
}

template <typename T>
T sq(T a){ return a*a; }

template <typename T>
void readV(vector<T> &v, size_t n){
  rep(n, [&v](){
    T t;
    cin >> t;
    v.push_back(t);
  });
}

template <typename T1, typename T2>
void readV(vector<pair<T1, T2>> &v, size_t n){
  rep(n, [&v](){
    T1 a;
    T2 b;
    cin >> a >> b;
    v.push_back({a, b});
  });
}

void solve();

int main(){
  size_t t;
  cin >> t;
  rep(t, [](int i){
      cout << "Case #" << i + 1 << ": ";
      solve();
  });
  return 0;
}

void solve(){
  ll d;
  string s;
  cin >> d >> s;
  priority_queue<ll> q;
  ll p = 1;
  ll damage = 0;
  for(char c : s){
    if(c == 'S'){
      q.push(p);
      damage += p;
    }
    else if(c == 'C'){
      p = p*2;
    }
  }
  ll i = 0;
  for(;;){
    if(damage <= d){
      cout << i << endl;
      return;
    }
    ll a = q.top();
    q.pop();
    if(a == 1){
      cout << "IMPOSSIBLE" << endl;
      return;
    }
    a = a/2;
    damage = damage - a;
    q.push(a);
    i++;
  }
}
