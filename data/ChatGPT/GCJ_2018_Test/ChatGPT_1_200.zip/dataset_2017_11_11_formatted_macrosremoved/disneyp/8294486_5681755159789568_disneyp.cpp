#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <utility>
#include <functional>

#define REP(i, a, b) for (int i = int(a); i < int(b); i++)
#define dump(val) cerr << __LINE__ << ":\t" << #val << " = " << (val) << endl

using namespace std;

typedef long long int lli;
typedef pair<int, int> pii;

int main() {
    int T;
    cin >> T;
    REP(t, 0, T) {
        int N;
        cin >> N;
        vector<pii> P(N);
        REP(i, 0, N) {
            cin >> P[i].first;
            P[i].second = i;
        }
        cout << "Case #" << t + 1 << ":";
        string ans = " ";

        // not same
        for (;;) {
            sort(begin(P), end(P), greater<pii>());
            if (P[0].first == P[N - 1].first) {
                break;
            }
            ans += char(P[0].second + 'A');
            P[0].first--;

            cout << ans;
            ans = " ";
        }
        // same
        sort(begin(P), end(P), greater<pii>());
        REP(i, 0, P[0].first) {
            if (N % 2) {
                cout << " A";
            } else {
                cout << " AB";
            }
            for (int j = !(N % 2) + 1; j < N; j += 2) {
                cout << " " << char(j + 'A') << char(j + 1 + 'A');
            }
        }
        cout << endl;
    }
    return 0;
}
