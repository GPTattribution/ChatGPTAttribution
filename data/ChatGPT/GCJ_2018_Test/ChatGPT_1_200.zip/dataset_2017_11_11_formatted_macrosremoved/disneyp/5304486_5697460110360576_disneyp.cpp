#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

#define REP(i, a, b) for (int i = int(a); i < int(b); i++)
#define dump(val) cerr << __LINE__ << ":\t" << #val << " = " << (val) << endl

using namespace std;

typedef long long int lli;

int main() {
    int T;
    cin >> T;
    REP(t, 0, T) {
        lli D;
        string s;
        cin >> D >> s;
        cout << "Case #" << t + 1 << ": ";
        int ans = 0;
        auto check = [&]() -> lli {
            lli res = 0;
            lli bs = 1;
            REP(i, 0, s.size()) {
                if (s[i] == 'S') {
                    res += bs;
                } else {
                    bs *= 2;
                }
            }
            return res;
        };
        while (check() > D) {
            bool isS = false;
            bool update = false;
            for (int i = s.size() - 1; i >= 0; i--) {
                if (!isS && s[i] == 'S') {
                    isS = true;
                } else if (isS && s[i] == 'C') {
                    swap(s[i + 1], s[i]);
                    ans++;
                    update = true;
                    break;
                }
            }
            if (!update) {
                ans = -1;
                break;
            }
        }
        if (ans == -1) {
            cout << "IMPOSSIBLE" << endl;
        } else {
            cout << ans << endl;
        }
    }
    return 0;
}
