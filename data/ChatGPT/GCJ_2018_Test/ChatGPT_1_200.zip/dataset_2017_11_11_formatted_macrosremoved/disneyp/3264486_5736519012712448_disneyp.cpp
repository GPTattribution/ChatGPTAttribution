#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

#define REP(i, a, b) for (int i = int(a); i < int(b); i++)
#define dump(val) cerr << __LINE__ << ":\t" << #val << " = " << (val) << endl

using namespace std;

typedef long long int lli;

int main() {
    int T;
    cin >> T;
    REP(t, 0, T) {
        int N;
        cin >> N;
        vector<int> v[2];
        REP(i, 0, N) {
            int a;
            cin >> a;
            v[i % 2].push_back(a);
        }
        cout << "Case #" << t + 1 << ": ";
        REP(i, 0, 2) {
            sort(begin(v[i]), end(v[i]));
        }
        vector<int> res(N);
        REP(i, 0, N) {
            res[i] = v[i % 2][i / 2];
        }
        bool ok = true;
        REP(i, 0, res.size() - 1) {
            if (res[i] > res[i + 1]) {
                cout << i << endl;
                ok = false;
                break;
            }
        }
        if (ok) {
            cout << "OK" << endl;
        }
    }
    return 0;
}
