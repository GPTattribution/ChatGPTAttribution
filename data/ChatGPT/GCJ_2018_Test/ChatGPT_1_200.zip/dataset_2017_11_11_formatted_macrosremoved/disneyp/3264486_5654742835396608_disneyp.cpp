#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

#define REP(i, a, b) for (int i = int(a); i < int(b); i++)
#define dump(val) cerr << __LINE__ << ":\t" << #val << " = " << (val) << endl

using namespace std;

typedef long long int lli;

int main() {
    int T;
    cin >> T;
    REP(t, 0, T) {
        int A;
        cin >> A;
        if (A == 20) {
            vector<vector<bool>> mp(4, vector<bool>(5, false));
            int cnt = 0;
            while (cnt < A) {
                int x, y;
                int bx[2] = {1, 3};
                int by[2] = {1, 2};
                REP(k, 0, 4) {
                    int c = 0;
                    REP(a, -1, 2) {
                        REP(b, -1, 2) {
                            c += mp[by[k / 2] + a][bx[k % 2] + b];
                        }
                    }
                    if (c != 9) {
                        x = bx[k % 2];
                        y = by[k / 2];
                    }
                }
                cout << x + 1 << ' ' << y + 1 << endl;
                int nx, ny;
                cin >> nx >> ny;
                if (nx == -1 && ny == -1) {
                    return 0;
                }
                if (nx == 0 && ny == 0) {
                    break;
                }
                ny--;
                nx--;
                cnt += !mp[ny][nx];
                mp[ny][nx] = true;
            }

        } else {
            vector<vector<bool>> mp(18, vector<bool>(12, false));
            int cnt = 0;
            while (cnt < A) {
                int x, y;
                int bx[5] = {1, 4, 7, 10, 13};
                int by[6] = {1, 4, 7, 10, 13, 16};
                REP(k, 0, 30) {
                    int c = 0;
                    REP(a, -1, 2) {
                        REP(b, -1, 2) {
                            c += mp[by[k / 5] + a][bx[k % 5] + b];
                        }
                    }
                    if (c != 9) {
                        x = bx[k % 5];
                        y = by[k / 5];
                    }
                }
                cout << x + 1 << ' ' << y + 1 << endl;
                int nx, ny;
                cin >> nx >> ny;
                if (nx == -1 && ny == -1) {
                    return 0;
                }
                if (nx == 0 && ny == 0) {
                    break;
                }
                ny--;
                nx--;
                cnt += !mp[ny][nx];
                mp[ny][nx] = true;
            }
        }
    }
    return 0;
}
