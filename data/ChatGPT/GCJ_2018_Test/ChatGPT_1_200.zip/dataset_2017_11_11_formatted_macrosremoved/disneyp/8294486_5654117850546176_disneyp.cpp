#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

#define REP(i, a, b) for (int i = int(a); i < int(b); i++)
#define dump(val) cerr << __LINE__ << ":\t" << #val << " = " << (val) << endl

using namespace std;

typedef long long int lli;

int main() {
    int T;
    cin >> T;
    REP(t, 0, T) {
        int A, B, N;
        cin >> A >> B;
        cin >> N;
        A++;
        for (int i = 0; i < N && A <= B; i++) {
            int mid = (A + B) / 2;
            cout << mid << endl;
            string res;
            cin >> res;
            if (res == "CORRECT" || res == "WRONG_ANSWER") {
                break;
            } else if (res == "TOO_SMALL") {
                A = mid + 1;
            } else if (res == "TOO_BIG") {
                B = mid - 1;
            } else {
                break;
            }
        }
    }
    return 0;
}
