#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <iomanip>

#define REP(i, a, b) for (int i = int(a); i < int(b); i++)
#define dump(val) cerr << __LINE__ << ":\t" << #val << " = " << (val) << endl

using namespace std;

typedef long long int lli;

int main() {
    int T;
    cin >> T;
    REP(t, 0, T) {
        int D, N;
        cin >> D >> N;
        double ans = 0.0;
        REP(i, 0, N) {
            int K, S;
            cin >> K >> S;
            double tmp = (double)(D - K) / S;
            ans = max(ans, tmp);
        }
        cout << "Case #" << t + 1 << ": " << fixed << setprecision(10) << D / ans << endl;
    }
    return 0;
}
