#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <queue>
#include <map>

#define REP(i, a, b) for (int i = int(a); i < int(b); i++)
#define dump(val) cerr << __LINE__ << ":\t" << #val << " = " << (val) << endl

using namespace std;

typedef long long int lli;

int main() {
    int T;
    cin >> T;
    REP(t, 0, T) {
        lli N, K;
        cin >> N >> K;
        map<lli, lli> m;
        priority_queue<lli, vector<lli>> pq;
        m[N] = 1;
        pq.push(N);
        lli Ld, Rd;
        while (K > 0) {
            lli k = pq.top();
            pq.pop();
            lli c = m[k];
            m[k] = 0;
            K -= c;
            lli mid = k / 2;
            Ld = k / 2;
            Rd = (k + 1) / 2 - 1;
            pq.push(Ld);
            pq.push(Rd);
            m[Ld] += c;
            m[Rd] += c;
        }
        cout << "Case #" << t + 1 << ": " << max(Ld, Rd) << ' ' << min(Ld, Rd) << endl;
    }
    return 0;
}
