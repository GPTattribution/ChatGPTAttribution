#include <bits/stdc++.h>
using namespace std;
using ll = long long;
template<typename S, typename T>
void xmin(S&a, T const&b){if(b<a) a=b;}
template<typename S, typename T>
void xmax(S&a, T const&b){if(b>a) a=b;}

signed main()
{
    #ifdef LOCAL_RUN
    freopen("inB.txt", "r", stdin);
    //freopen("outX.txt", "w", stdout);
    #endif // LOCAL_RUN
    cin.tie(0); cout.tie(0); ios_base::sync_with_stdio(false);
    int TTT; cin >> TTT;
    for(int cas=1;cas<=TTT;++cas) {
    cout << "Case #" << cas << ": " ;

    int n;
    cin >> n;
    vector<pair<int, char> > v;
    for(int i=0;i<n;++i){
        char c = 'A' + i;
        int cnt; cin >> cnt;
        for(int j=1;j<=cnt;++j){
            v.emplace_back(j, c);
        }
    }
    sort(v.begin(), v.end());
    for(int i=v.size(), j;i>1;i=j){
        j = (i-1)>>1<<1;
        for(int k=j;k<i;++k){
            cout << v[k].second;
        }
        cout << " ";
    }
    cout << "\n";


    }
    return 0;
}
