#include <bits/stdc++.h>
using ll = long long;
template<typename S, typename T>
void xmin(S&a, T const&b){if(b<a) a=b;}
template<typename S, typename T>
void xmax(S&a, T const&b){if(b>a) a=b;}

using namespace std;


void solve(){

    array<vector<int>, 2> a;
    int n;
    cin >> n;
    for(int i=0;i<n;++i){
        int tmp; cin >> tmp;
        a[i%2].push_back(tmp);
    }
    for(auto &e:a) sort(e.begin(), e.end());
    vector<int> b(n);
    for(int i=0;i<n;++i){
        b[i] = a[i%2][i/2];
    }
    for(int i=0;i+1<n;++i){
        if(b[i] > b[i+1]){
            cout << i << "\n";
            return;
        }
    }
    cout << "OK\n";
}

int main()
{
    #ifdef LOCAL_RUN
    freopen("inB.txt", "r", stdin);
    //freopen("outX.txt", "w", stdout);
    #endif // LOCAL_RUN
    cin.tie(0); cout.tie(0);
    int TTT; cin >> TTT;
    for(int cas = 1;cas<=TTT;++cas){
        cout << "Case #" << cas << ": ";

        solve();

        cout << "\n";
    }
    return 0;
}
