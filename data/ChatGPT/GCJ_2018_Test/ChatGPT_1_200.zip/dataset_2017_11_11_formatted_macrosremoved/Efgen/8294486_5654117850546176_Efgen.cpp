#include <bits/stdc++.h>
using namespace std;
using ll = long long;
template<typename S, typename T>
void xmin(S&a, T const&b){if(b<a) a=b;}
template<typename S, typename T>
void xmax(S&a, T const&b){if(b>a) a=b;}

string make_query(ll const&x){
    cout << x << endl;
    string result;
    cin >> result;
    return result;
}

signed main()
{
    #ifdef LOCAL_RUN
    //freopen("inA.txt", "r", stdin);
    //freopen("outX.txt", "w", stdout);
    #endif // LOCAL_RUN
    cin.tie(0); cout.tie(0); ios_base::sync_with_stdio(false);
    int TTT; cin >> TTT; while(TTT--){


    ll a, b, n;
    cin >> a >> b >> n;

    bool done = false;

    while(!done){
        ll m = a + (b-a+1)/2;
        string result = make_query(m);
        if(result == "CORRECT"){
            done = true;
        } else if (result == "TOO_SMALL"){
            a = m;
        } else if (result == "TOO_BIG"){
            b = m-1;
        } else if (result == "WRONG_ANSWER"){
            cerr << "Failed\n";
            exit(0);
        } else {
            assert(0);
        }
    }



    }
    return 0;
}
