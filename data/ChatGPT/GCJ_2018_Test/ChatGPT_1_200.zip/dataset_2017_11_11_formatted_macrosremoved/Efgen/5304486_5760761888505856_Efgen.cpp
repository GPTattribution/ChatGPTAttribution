#include <bits/stdc++.h>
using namespace std;
using ll = long long;
template<typename S, typename T>
void xmin(S&a, T const&b){if(b<a) a=b;}
template<typename S, typename T>
void xmax(S&a, T const&b){if(b>a) a=b;}


map<ll, vector<pair<ll, ll> > > cache;

vector<pair<ll, ll> > get_inters(ll x){
    auto it = cache.find(x);
    if(it != cache.end()){
        return it->second;
    }

    if(x == 0){
        return vector<pair<ll, ll> >();
    }
    auto inters_l = get_inters((x-1)/2);
    auto inters_r = get_inters(x-1-(x-1)/2);
    vector<pair<ll, ll> > ret;
    merge(inters_l.begin(), inters_l.end(), inters_r.begin(), inters_r.end(), back_inserter(ret));
    ret.emplace_back(x, 1);
    for(unsigned int i=0;i+1<ret.size();++i){
        if(ret[i].first == ret[i+1].first){
            ret[i+1].second+=ret[i].second;
            ret[i].second = 0;
        }
    }
    ret.erase(remove_if(ret.begin(), ret.end(), [&](pair<ll, ll> const&val){return val.second == 0;}), ret.end());
    return cache[x] = ret;
}


signed main()
{
    #ifdef LOCAL_RUN
    freopen("inD.txt", "r", stdin);
    //freopen("outX.txt", "w", stdout);
    #endif // LOCAL_RUN
    cin.tie(0); cout.tie(0); ios_base::sync_with_stdio(false);
    int TTT; cin >> TTT;
    for(int cas=1;cas<=TTT;++cas) {
    cout << "Case #" << cas << ": " ;

    ll n, k;
    cin >> n >> k;

    auto inters = get_inters(n);
    reverse(inters.begin(), inters.end());
    int i = 0;
    while(k >inters[i].second){
        k-=inters[i].second;
        ++i;
    }
    ll l = inters[i].first;
    cout << (l-1-(l-1)/2) << " " << (l-1)/2 << "\n";



    }
    return 0;
}
