#include <bits/stdc++.h>
using ll = long long;
template<typename S, typename T>
void xmin(S&a, T const&b){if(b<a) a=b;}
template<typename S, typename T>
void xmax(S&a, T const&b){if(b>a) a=b;}

using namespace std;

int qs = 0, max_qs = 0;

pair<int, int> query(int i, int j){
    ++qs;
    assert(1<i && i<1000);
    assert(1<j && j<1000);
    cout << i << " " << j << endl;
    pair<int, int> ret;
    cin >> ret.first >> ret.second;
    return ret;
}

constexpr pair<int, int> done(0, 0);
constexpr pair<int, int> fail(-1, -1);


void solve(){
    int A;
    cin >> A;
    int x = llround(ceil(sqrtl(A+0.5)));
    if(x<4) x=4;
    constexpr int offset = 100;
    vector<vector<char> > b(x, vector<char>(x, 0));
    for(int i=0;i<x;++i){
        for(int j=0;j<x;++j){
            while(!b[i][j]){
                int qx = min(i+1, x-2);
                int qy = min(j+1, x-2);
                auto ans = query(offset+qx, offset+qy);
                if(ans == fail) return;
                if(ans == done) return;
                ans.first-=offset;
                ans.second-=offset;
                b[ans.first][ans.second]=1;
            }
        }
    }
    #ifdef LOCAL_RUN
    cerr << A << " => " << x << "\n";
    for(auto &e:b){
        for(auto &f:e) cerr << (char)(f+'0');
        cerr << "\n";
    }
    #endif
    assert(0);
}


int main()
{
    #ifdef LOCAL_RUN
    //freopen("inX.txt", "r", stdin);
    //freopen("outX.txt", "w", stdout);
    #endif // LOCAL_RUN
    cin.tie(0); cout.tie(0);
    int TTT; cin >> TTT;
    for(int cas = 1;cas<=TTT;++cas){
        //cerr << "Case #" << cas << ":\n";
        qs = 0;

        solve();

        #ifdef LOCAL_RUN
        if(qs > max_qs){
            cerr << " " << qs << "";
            max_qs = qs;
        }
        #endif

        //cout << "\n";
    }
    return 0;
}
