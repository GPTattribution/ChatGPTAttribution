#include <cstdint>
#include <iostream>
#include <map>

typedef int64_t num;

void set(std::map<num, num> & cnt, num const key, num const value) {
    if (value == 0) {
        cnt.erase(key);
    } else {
        cnt[key] = value;
    }
}

num get(std::map<num, num> & cnt, num const key) {
    auto it = cnt.find(key);
    if (it == cnt.end()) {
        return 0;
    } else {
        return it->second;
    }
}

int main() {
    using std::cin;
    using std::cout;
    using std::endl;
    using std::map;

    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        num n, k;
        cin >> n >> k;

        map<num, num> cnt;
        set(cnt, n, 1);

        while (k > 0) {
            num max_size = cnt.rbegin()->first;
            num max_cnt = get(cnt, max_size);

            //std::cout << "k = " << k << ", S = " << max_size << ", C = " << max_cnt << endl;

            num min, max;
            min = (max_size - 1) / 2; // 4 -> 1, 5 -> 2, 1 -> 0
            max = max_size / 2; // 4 -> 2, 5 -> 2, 1 -> 0

            if (k <= max_cnt) {
                cout << "Case #" << t << ": " << max << " " << min << endl;
                break; /* while() */
            } else {
                set(cnt, max_size, 0);
                set(cnt, min, get(cnt, min) + max_cnt);
                set(cnt, max, get(cnt, max) + max_cnt);
            }
            k -= max_cnt;
        }
    }
}
