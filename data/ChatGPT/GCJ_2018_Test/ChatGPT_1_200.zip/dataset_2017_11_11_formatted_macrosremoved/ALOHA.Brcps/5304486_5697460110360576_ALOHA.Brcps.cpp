#include <algorithm>
#include <iostream>
#include <string>

static int damage(std::string const& code) {
    int beam = 1;
    int total = 0;
    for (auto ins : code) {
        if ('S' == ins) {
            total += beam;
        }
        if ('C' == ins) {
            beam *= 2;
        }
    }
    return total;
}

static int lessen_damage(std::string *code) {
    std::string &cr = *code;
    for (int i = cr.size() - 1; i - 1 >= 0; i--) {
        if ('C' == cr[i - 1] && 'S' == cr[i]) {
            std::swap(cr[i - 1], cr[i]);
            break;
        }
    }
}

static int solve(int d, std::string const& code) {
    int s_count = std::count(code.begin(), code.end(), 'S');
    if (s_count > d) {
        return -1;
    }

    std::string cc = code;
    int cd = damage(cc);

    int steps = 0;
    while (cd > d) {
        lessen_damage(&cc);
        cd = damage(cc);
        steps += 1;
    }

    return steps;
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; t++) {
        int d;
        std::string code;
        std::cin >> d >> code;

        int answer = solve(d, code);

        std::cout << "Case #" << t << ": ";
        if (-1 == answer) {
            std::cout << "IMPOSSIBLE";
        } else {
            std::cout << answer;
        }
        std::cout << std::endl;
    }

    return 0;
}
