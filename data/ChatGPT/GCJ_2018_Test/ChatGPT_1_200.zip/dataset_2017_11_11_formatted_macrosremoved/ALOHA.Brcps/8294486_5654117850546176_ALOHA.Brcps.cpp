#include <iostream>
#include <string>

int main() {
    using std::cin;
    using std::cout;
    using std::endl;
    using std::string;

    int t;

    cin >> t;
    while (t--) {
        int a, b, n;
        cin >> a >> b >> n;

        bool got_correct = false;
        while (!got_correct) { // WA is for losers, so there is no check for WA
            int guess = (a + b + 1) / 2;
            cout << guess << endl;

            string answer;
            cin >> answer;

            if (answer == "CORRECT") {
                got_correct = true;
            } else if (answer == "TOO_SMALL") {
                a = guess;
            } else if (answer == "TOO_BIG") {
                b = guess - 1;
            }
        }
    }

    return 0;
}
