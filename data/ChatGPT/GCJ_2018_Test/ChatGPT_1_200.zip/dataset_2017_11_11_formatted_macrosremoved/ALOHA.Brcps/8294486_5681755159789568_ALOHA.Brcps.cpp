#include <algorithm>
#include <iostream>
#include <vector>

//#define VALIDATE

template<typename It>
static int max_i(It begin, It end) {
    return std::max_element(begin, end) - begin;
}

template<typename T>
static int max_i(std::vector<T> const& v) {
    return max_i(v.begin(), v.end());
}

void validate(std::vector<int> const& p) {
#ifdef VALIDATE
    int sum = 0;
    for (int p_i : p) {
        sum += p_i;
    }
    for (int p_i : p) {
        if (p_i > sum - p_i) {
            std::cout << "INVALID" << std::endl;
        }
    }
#endif
}

int main() {
    using std::cin;
    using std::cout;
    using std::endl;
    using std::vector;

    int T;

    cin >> T;
    for (int t = 1; t <= T; t++) {
        int n;
        cin >> n;

        vector<int> p(n);
        for (int i = 0; i < n; i++) {
            cin >> p[i];
        }

        int total = 0;
        for (int p_i : p) {
            total += p_i;
        }

        cout << "Case #" << t << ":";

        if (total % 2 == 1) {
            int first = max_i(p);
            p[first] -= 1;
            total -= 1;
            cout << " " << char('A' + first);
        }
        validate(p);

        while (total > 0) {
            int t1 = max_i(p);
            p[t1] -= 1;
            int t2 = max_i(p);
            p[t2] -= 1;
            total -= 2;
            cout << " " << char('A' + t1) << char('A' + t2);
            validate(p);
        }

        cout << endl;
    }

    return 0;
}
