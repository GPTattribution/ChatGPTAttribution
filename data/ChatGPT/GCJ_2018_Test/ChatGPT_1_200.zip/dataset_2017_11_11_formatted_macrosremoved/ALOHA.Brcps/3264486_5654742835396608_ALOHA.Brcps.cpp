#include <iostream>
#include <vector>

static void interact(int w, int h) {
    using std::vector;
    const int shift = 1;

    vector<vector<int>> field(w, vector<int>(h, 0));

    while (true) {
        int i, j;

        i = 1 + shift;
        j = 1 + shift;
        int best_count = 0;
        for (int pi = 1; pi + 1 < w; pi++) {
            for (int pj = 1; pj + 1 < h; pj++) {
                int free_count = 0;
                for (int di = -1; di <= +1; di++) {
                    for (int dj = -1; dj <= +1; dj++) {
                        if (0 == field[pi + di][pj + dj]) {
                            free_count += 1;
                        }
                    }
                }
                if (free_count > best_count) {
                    best_count = free_count;
                    i = pi;
                    j = pj;
                }
            }
        }

        std::cout << i + shift << " " << j + shift << std::endl;

        int ri, rj;
        std::cin >> ri >> rj;

        if ((-1 == ri && -1 == rj) || (0 == ri && 0 == rj)) {
            return;
        }

        field[ri - shift][rj - shift] = 1;
    }
}

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; t++) {
        int a;
        std::cin >> a;

        int w, h;
        if (20 == a) {
            w = 5;
            h = 4;
        } else if (200 == a) {
            w = 20;
            h = 10;
        } else {
            //std::cerr << "UNEXPECTED A = " << a << std::endl;
            //return 1;
            for (w = 1; w < 15; w++) {
                if (w * w >= a) {
                    h = w;
                    break;
                }
            }
            //std::cout << "w = " << w << ", h = " << h << std::endl;
        }

        interact(w, h);
    }

    return 0;
}
