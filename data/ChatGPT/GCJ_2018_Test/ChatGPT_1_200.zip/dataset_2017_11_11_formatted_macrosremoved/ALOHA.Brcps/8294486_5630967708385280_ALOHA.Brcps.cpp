#include <iostream>

int main() {
    using std::cin;
    using std::cout;
    using std::endl;

    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        int d, n;
        cin >> d >> n;

        double max_t = 0.0;
        for (int i = 0; i < n; i++) {
            int k, s;
            cin >> k >> s;

            double t = 1.0 * (d - k) / s;
            if (t > max_t) {
                max_t = t;
            }
        }

        cout.precision(12);
        cout << std::fixed;
        cout << "Case #" << t << ": " << d / max_t << endl;
    }

    return 0;
}
