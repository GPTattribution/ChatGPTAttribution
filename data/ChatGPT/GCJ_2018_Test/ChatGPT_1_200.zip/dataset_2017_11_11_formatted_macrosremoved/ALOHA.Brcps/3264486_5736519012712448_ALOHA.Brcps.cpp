#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    int T;
    std::cin >> T;

    for (int t = 1; t <= T; t++) {
        int n;
        std::cin >> n;

        std::vector<int> even;
        std::vector<int> odd;

        for (int i = 0; i < n; i++) {
            int v;
            std::cin >> v;

            if (0 == i % 2) {
                even.push_back(v);
            } else {
                odd.push_back(v);
            }
        }

        std::sort(even.begin(), even.end());
        std::sort(odd.begin(), odd.end());

        std::vector<int> all(n);
        for (int i = 0; i < n; i++) {
            if (0 == i % 2) {
                all[i] = even[i / 2];
            } else {
                all[i] = odd[(i - 1) / 2];
            }
        }

        int trouble = -1;
        for (int i = 0; i + 1 < n; i++) {
            if (all[i] > all[i + 1]) {
                trouble = i;
                break;
            }
        }

        std::cout << "Case #" << t << ": ";
        if (-1 == trouble) {
            std::cout << "OK";
        } else {
            std::cout << trouble;
        }
        std::cout << std::endl;
    }

    return 0;
}
