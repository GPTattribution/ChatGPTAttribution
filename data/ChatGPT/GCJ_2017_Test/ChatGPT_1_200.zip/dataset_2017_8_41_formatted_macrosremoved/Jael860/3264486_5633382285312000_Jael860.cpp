#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string s = to_string(n);
    int i = 1;
    while (i < s.length() && s[i] >= s[i-1]) {
        i++;
    }
    while (i > 0 && s[i-1] == '0') {
        i--;
    }
    s[i-1]--;
    for (int j = i; j < s.length(); j++) {
        s[j] = '9';
    }
    return stoll(s);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long n;
        cin >> n;
        cout << "Case #" << t << ": " << last_tidy(n) << endl;
    }
    return 0;
}
