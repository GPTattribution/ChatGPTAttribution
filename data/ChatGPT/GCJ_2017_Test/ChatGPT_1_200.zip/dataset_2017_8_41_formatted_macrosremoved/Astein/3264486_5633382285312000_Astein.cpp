#include <bits/stdc++.h>
using namespace std;

long long T, n, x;

long long solve(long long n) {
    string s = to_string(n);
    int len = s.length();
    vector<int> nums;
    for (int i = 0; i < len; i++) {
        nums.push_back(s[i] - '0');
    }
    for (int i = len - 2; i >= 0; i--) {
        if (nums[i] > nums[i + 1]) {
            nums[i]--;
            for (int j = i + 1; j < len; j++) {
                nums[j] = 9;
            }
        }
    }
    long long ans = 0;
    for (int i = 0; i < len; i++) {
        ans = ans * 10 + nums[i];
    }
    return ans;
}

int main() {
    cin >> T;
    for (int i = 1; i <= T; i++) {
        cin >> n;
        x = solve(n);
        cout << "Case #" << i << ": " << x << endl;
    }
    return 0;
}
