#include <iostream>
#include <string>

using namespace std;

bool is_tidy(string s) {
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

string decrement_tidy(string s) {
    int i = s.length() - 1;
    while (i > 0 && s[i] == '0') {
        s[i] = '9';
        i--;
    }
    s[i]--;
    return s;
}

string find_last_tidy(string s) {
    while (!is_tidy(s)) {
        s = decrement_tidy(s);
    }
    return s;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        string N;
        cin >> N;
        cout << "Case #" << t << ": " << find_last_tidy(N) << endl;
    }
    return 0;
}
