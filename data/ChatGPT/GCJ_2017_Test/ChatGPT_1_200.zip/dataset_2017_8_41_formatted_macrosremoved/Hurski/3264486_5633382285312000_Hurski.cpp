#include <iostream>
#include <string>

using namespace std;

bool is_tidy(string num) {
    for (int i = 1; i < num.size(); i++) {
        if (num[i] < num[i-1]) {
            return false;
        }
    }
    return true;
}

string make_tidy(string num) {
    for (int i = num.size()-1; i > 0; i--) {
        if (num[i] < num[i-1]) {
            num[i-1]--;
            for (int j = i; j < num.size(); j++) {
                num[j] = '9';
            }
        }
    }
    return num;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        while (!is_tidy(n)) {
            n = make_tidy(n);
        }
        cout << "Case #" << i << ": " << n << endl;
    }
    return 0;
}
