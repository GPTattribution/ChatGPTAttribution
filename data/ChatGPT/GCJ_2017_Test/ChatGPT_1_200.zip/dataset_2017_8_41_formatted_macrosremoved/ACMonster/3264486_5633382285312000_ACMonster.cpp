#include <iostream>
#include <string>

bool isTidy(long long n) {
    std::string num = std::to_string(n);
    for (int i = 0; i < num.length() - 1; i++) {
        if (num[i] > num[i + 1]) {
            return false;
        }
    }
    return true;
}

long long lastTidy(long long n) {
    while (!isTidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int t;
    std::cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        std::cin >> n;
        std::cout << "Case #" << i << ": " << lastTidy(n) << std::endl;
    }
    return 0;
}
