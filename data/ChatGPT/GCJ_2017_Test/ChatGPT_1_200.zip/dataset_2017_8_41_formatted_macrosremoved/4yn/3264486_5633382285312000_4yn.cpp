#include <iostream>
using namespace std;

bool isTidy(long long n) {
    int prev = n % 10;
    n /= 10;
    while (n > 0) {
        int digit = n % 10;
        if (digit > prev) {
            return false;
        }
        prev = digit;
        n /= 10;
    }
    return true;
}

long long findTidy(long long n) {
    while (!isTidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << findTidy(n) << endl;
    }
    return 0;
}
