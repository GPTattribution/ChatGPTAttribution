#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll n;
int t, tt;

ll makeTidy(ll x) {
    vector<int> digits;
    while (x > 0) {
        digits.push_back(x % 10);
        x /= 10;
    }
    reverse(digits.begin(), digits.end());
    int n = digits.size();
    for (int i = 0; i < n - 1; i++) {
        if (digits[i] > digits[i + 1]) {
            digits[i]--;
            for (int j = i + 1; j < n; j++) {
                digits[j] = 9;
            }
            i -= 2;
            if (i < -1) {
                i = -1;
            }
        }
    }
    ll tidy = 0;
    for (int i = n - 1; i >= 0; i--) {
        tidy = tidy * 10 + digits[i];
    }
    return tidy;
}

int main() {
    cin >> t;
    tt = t;
    while (t--) {
        cin >> n;
        cout << "Case #" << tt - t << ": " << makeTidy(n) << endl;
    }
    return 0;
}
