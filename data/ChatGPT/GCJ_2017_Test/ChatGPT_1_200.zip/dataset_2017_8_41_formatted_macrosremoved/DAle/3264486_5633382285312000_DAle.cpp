#include <bits/stdc++.h>
using namespace std;

string solve(string s) {
    int n = s.size();
    for (int i = n - 2; i >= 0; i--) {
        if (s[i] > s[i + 1]) {
            s[i]--;
            for (int j = i + 1; j < n; j++) {
                s[j] = '9';
            }
        }
    }
    if (s[0] == '0') {
        s = s.substr(1, n - 1);
    }
    return s;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        string s;
        cin >> s;
        cout << "Case #" << t << ": " << solve(s) << endl;
    }
    return 0;
}
