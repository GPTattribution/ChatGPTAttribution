#include <iostream>
#include <string>
using namespace std;

bool is_tidy(string s) {
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

string make_tidy(string s) {
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            s[i-1]--;
            for (int j = i; j < s.length(); j++) {
                s[j] = '9';
            }
        }
    }
    return s;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        while (!is_tidy(n)) {
            n = make_tidy(n);
        }
        cout << "Case #" << i << ": " << n << endl;
    }
    return 0;
}
