#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

string lastTidyNumber(string n) {
    int len = n.length();
    for (int i = len - 2; i >= 0; i--) {
        if (n[i] > n[i + 1]) {
            n[i]--;
            for (int j = i + 1; j < len; j++) {
                n[j] = '9';
            }
        }
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        cout << "Case #" << i << ": " << lastTidyNumber(n) << endl;
    }
    return 0;
}
