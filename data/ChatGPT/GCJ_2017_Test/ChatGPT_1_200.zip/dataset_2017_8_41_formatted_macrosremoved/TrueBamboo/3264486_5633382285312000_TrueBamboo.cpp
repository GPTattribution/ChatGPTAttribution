#include <bits/stdc++.h>
using namespace std;

bool is_tidy(long long n) {
    long long prev_digit = 10; 
    while (n > 0) {
        int curr_digit = n % 10;
        if (curr_digit > prev_digit) {
            return false;
        }
        prev_digit = curr_digit;
        n /= 10;
    }
    return true;
}

long long solve(long long n) {
    while (!is_tidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << solve(n) << endl;
    }
    return 0;
}
