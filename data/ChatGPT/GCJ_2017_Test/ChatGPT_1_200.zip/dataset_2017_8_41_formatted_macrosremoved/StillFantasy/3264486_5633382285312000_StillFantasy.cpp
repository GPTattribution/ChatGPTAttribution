#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string str = to_string(n);
    int len = str.length();
    for (int i = 0; i < len - 1; i++) {
        if (str[i] > str[i+1]) {
            return false;
        }
    }
    return true;
}

long long solve(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string str = to_string(n);
    int len = str.length();
    long long ans = 0;
    for (int i = 0; i < len - 1; i++) {
        if (str[i] > str[i+1]) {
            ans = stoll(str.substr(0, i+1)) - 1;
            break;
        }
    }
    if (ans == 0) {
        ans = n - 1;
    }
    while (!is_tidy(ans)) {
        string str = to_string(ans);
        int len = str.length();
        for (int i = 0; i < len - 1; i++) {
            if (str[i] > str[i+1]) {
                ans = stoll(str.substr(0, i+1)) - 1;
                break;
            }
        }
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << solve(n) << endl;
    }
    return 0;
}
