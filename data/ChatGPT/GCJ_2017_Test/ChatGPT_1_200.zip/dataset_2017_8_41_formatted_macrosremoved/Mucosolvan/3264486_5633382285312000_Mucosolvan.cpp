#include <iostream>
#include <string>

using namespace std;

string lastTidyNumber(string s) {
    int n = s.size();
    int k = n;
    for (int i = n - 1; i >= 1; i--) {
        if (s[i] < s[i - 1]) {
            k = i;
            s[i - 1]--;
        }
    }
    for (int i = k; i < n; i++) {
        s[i] = '9';
    }
    while (s.size() > 1 && s[0] == '0') {
        s.erase(0, 1);
    }
    return s;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        cout << "Case #" << i << ": " << lastTidyNumber(n) << endl;
    }
    return 0;
}
