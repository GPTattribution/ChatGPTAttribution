#include<bits/stdc++.h>
using namespace std;

string getTidyNumber(string n) {
    int len = n.length();
    for (int i = len - 1; i > 0; i--) {
        if (n[i] < n[i - 1]) {
            n[i - 1]--;
            for (int j = i; j < len; j++) {
                n[j] = '9';
            }
        }
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        cout << "Case #" << i << ": " << getTidyNumber(n) << endl;
    }
    return 0;
}
