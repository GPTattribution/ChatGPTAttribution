#include<bits/stdc++.h>
using namespace std;

string solve(string str) {
    int n = str.length();
    for (int i = n-1; i > 0; i--) {
        if (str[i] < str[i-1]) {
            str[i-1]--;
            for (int j = i; j < n; j++) {
                str[j] = '9';
            }
        }
    }
    if (str[0] == '0') return str.substr(1);
    return str;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        string str;
        cin >> str;
        cout << "Case #" << i << ": " << solve(str) << endl;
    }
    return 0;
}
