#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;

        long long lo = 1;
        long long hi = n;
        long long ans = 0;
        while (lo <= hi) {
            long long mid = (lo + hi) / 2;
            if (is_tidy(mid)) {
                ans = mid;
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
