#include<bits/stdc++.h>
using namespace std;

string getTidyNumber(string n) {
    int len = n.length();
    for (int i = len - 2; i >= 0; i--) {
        if (n[i] > n[i + 1]) {
            n[i]--;
            for (int j = i + 1; j < len; j++) {
                n[j] = '9';
            }
        }
    }
    int nonZeroIndex = 0;
    while (n[nonZeroIndex] == '0') nonZeroIndex++;
    return n.substr(nonZeroIndex);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        cout << "Case #" << i << ": " << getTidyNumber(n) << endl;
    }
    return 0;
}
