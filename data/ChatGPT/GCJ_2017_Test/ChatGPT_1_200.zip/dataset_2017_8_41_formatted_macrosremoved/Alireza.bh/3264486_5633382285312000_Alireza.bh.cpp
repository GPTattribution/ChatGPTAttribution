#include <iostream>
using namespace std;

long long getTidyNumber(long long n) {
    string s = to_string(n);
    int len = s.length();
    for (int i = 0; i < len - 1; i++) {
        if (s[i] > s[i + 1]) {
            while (i >= 0 && s[i] > s[i + 1]) {
                s[i]--;
                for (int j = i + 1; j < len; j++) {
                    s[j] = '9';
                }
                i--;
            }
            return stoi(s);
        }
    }
    return n;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << getTidyNumber(n) << endl;
    }
    return 0;
}
