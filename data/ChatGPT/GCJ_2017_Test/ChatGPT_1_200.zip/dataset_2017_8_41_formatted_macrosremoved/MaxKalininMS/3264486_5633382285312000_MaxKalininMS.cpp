#include <bits/stdc++.h>
using namespace std;

bool is_tidy(long long n) {
    long long last_digit = 9;
    while (n > 0) {
        long long digit = n % 10;
        if (digit > last_digit) {
            return false;
        }
        last_digit = digit;
        n /= 10;
    }
    return true;
}

long long solve(long long n) {
    while (!is_tidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << solve(n) << endl;
    }
    return 0;
}
