#include <iostream>
#include <string>

using namespace std;

string solve(string n) {
    int i = n.size() - 1;
    while (i > 0 && n[i - 1] <= n[i]) {
        i--;
    }
    if (i == 0) {
        return n;
    }
    while (i > 0 && n[i - 1] > n[i]) {
        n[i - 1]--;
        i--;
    }
    for (int j = i; j < n.size(); j++) {
        n[j] = '9';
    }
    if (n[0] == '0') {
        n = n.substr(1);
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        string answer = solve(n);
        cout << "Case #" << i << ": " << answer << endl;
    }
    return 0;
}
