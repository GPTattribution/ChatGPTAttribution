#include<bits/stdc++.h>
using namespace std;

int T, n, k, ans, len;
string str;

int main() {
    cin >> T;
    for (int t = 1; t <= T; t++) {
        cin >> str;
        len = str.size();
        ans = -1;
        for (int i = len - 1; i >= 1; i--) {
            if (str[i] < str[i - 1]) {
                str[i - 1]--;
                for (int j = i; j < len; j++) str[j] = '9';
            }
        }
        if (str[0] == '0') {
            str.erase(str.begin());
            len--;
        }
        cout << "Case #" << t << ": " << str << endl;
    }
    return 0;
}
