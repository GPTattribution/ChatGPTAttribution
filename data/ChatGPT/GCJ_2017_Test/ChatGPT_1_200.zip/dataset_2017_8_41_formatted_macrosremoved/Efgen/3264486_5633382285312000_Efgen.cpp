#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int t;
ll n;

ll make_tidy(ll x) {
    string s = to_string(x);
    int n = s.size();
    for (int i = 0; i < n - 1; i++) {
        if (s[i] > s[i + 1]) {
            s[i]--;
            for (int j = i + 1; j < n; j++) {
                s[j] = '9';
            }
        }
    }
    return stoll(s);
}

int main() {
    cin >> t;
    for (int i = 1; i <= t; i++) {
        cin >> n;
        cout << "Case #" << i << ": " << make_tidy(n) << endl;
    }
    return 0;
}
