#include <bits/stdc++.h>
using namespace std;

string decrement(string n) {
  int len = n.length();
  int i = len - 1;
  while (i > 0 && n[i] < n[i-1]) {
    n[i-1]--;
    i--;
  }
  for (int j = i+1; j < len; j++) {
    n[j] = '9';
  }
  if (n[0] == '0') {
    n.erase(0,1);
    len--;
  }
  return n;
}

int main() {
  int t;
  cin >> t;
  for (int i = 1; i <= t; i++) {
    string n;
    cin >> n;
    cout << "Case #" << i << ": " << decrement(n) << endl;
  }
  return 0;
}
