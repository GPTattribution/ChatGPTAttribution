#include <iostream>
#include <string>

using namespace std;

bool isTidy(long long num) {
    string str = to_string(num);
    for (int i = 1; i < str.length(); i++) {
        if (str[i] < str[i-1]) {
            return false;
        }
    }
    return true;
}

long long findLastTidyNumber(long long n) {
    long long lastTidyNumber = n;
    while (!isTidy(lastTidyNumber)) {
        lastTidyNumber--;
    }
    return lastTidyNumber;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long lastTidyNumber = findLastTidyNumber(n);
        cout << "Case #" << i << ": " << lastTidyNumber << endl;
    }
    return 0;
}
