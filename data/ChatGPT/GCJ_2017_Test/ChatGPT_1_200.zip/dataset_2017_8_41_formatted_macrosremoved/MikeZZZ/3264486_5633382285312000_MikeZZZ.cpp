#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    string str_n = to_string(n);
    int len = str_n.length();
    for (int i = len - 1; i >= 1; i--) {
        if (str_n[i] < str_n[i-1]) {
            str_n[i-1]--;
            for (int j = i; j < len; j++) {
                str_n[j] = '9';
            }
        }
    }
    return stoll(str_n);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long n;
        cin >> n;
        cout << "Case #" << t << ": " << solve(n) << endl;
    }
    return 0;
}
