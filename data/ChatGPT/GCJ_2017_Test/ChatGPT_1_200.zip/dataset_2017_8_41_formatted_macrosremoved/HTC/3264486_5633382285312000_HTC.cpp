#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

bool isTidy(ll n) {
    ll prev = n % 10;
    n /= 10;
    while (n > 0) {
        ll curr = n % 10;
        if (curr > prev) {
            return false;
        }
        prev = curr;
        n /= 10;
    }
    return true;
}

ll findLargestTidyNumber(ll n) {
    if (isTidy(n)) {
        return n;
    }
    ll ans = 0;
    while (n > 0) {
        ll curr = n % 10;
        n /= 10;
        if (n > 0 && curr < n % 10) {
            ans = n * pow(10, to_string(n).length()) - 1;
            n--;
        }
    }
    return ans;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        ll n;
        cin >> n;
        ll ans = findLargestTidyNumber(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
