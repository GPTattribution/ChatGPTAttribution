#include <iostream>
#include <string>

using namespace std;

string makeTidy(string num) {
    int n = num.length();
    int i = 0;
    while (i < n - 1 && num[i] <= num[i + 1]) i++;
    while (i > 0 && num[i - 1] == '0') i--;
    if (i == 0) return num;
    num[i - 1]--;
    i++;
    while (i < n) num[i++] = '9';
    return num;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        string n;
        cin >> n;
        cout << "Case #" << t << ": " << makeTidy(n) << endl;
    }
    return 0;
}
