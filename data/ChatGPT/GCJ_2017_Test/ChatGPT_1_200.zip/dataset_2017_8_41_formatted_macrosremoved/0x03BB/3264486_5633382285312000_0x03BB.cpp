#include<bits/stdc++.h>
using namespace std;
long long t, n, cnt;
string str;
bool flag;
int main() {
    cin >> t;
    for(int i = 1; i <= t; i++) {
        cin >> n;
        str = to_string(n);
        flag = false;
        for(int j = str.length() - 1; j > 0; j--) {
            if(str[j] < str[j - 1]) {
                flag = true;
                str[j - 1]--;
                for(int k = j; k < str.length(); k++) str[k] = '9';
            }
        }
        if(str[0] == '0') {
            str = str.substr(1, str.length() - 1);
        }
        cout << "Case #" << i << ": " << str << endl;
    }
    return 0;
}
