#include <bits/stdc++.h>
using namespace std;

bool is_tidy(long long n) {
    vector<int> digits;
    while (n > 0) {
        digits.push_back(n % 10);
        n /= 10;
    }
    reverse(digits.begin(), digits.end());
    for (int i = 1; i < digits.size(); i++) {
        if (digits[i] < digits[i - 1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy(long long n) {
    while (!is_tidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long result = last_tidy(N);
        cout << "Case #" << t << ": " << result << endl;
    }
    return 0;
}
