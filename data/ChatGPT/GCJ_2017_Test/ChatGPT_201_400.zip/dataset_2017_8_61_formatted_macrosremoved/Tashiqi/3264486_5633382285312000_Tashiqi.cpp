#include <bits/stdc++.h>
using namespace std;

#define ll long long

bool is_tidy(ll n) {
    string s = to_string(n);
    for (int i = 0; i < s.size() - 1; i++) {
        if (s[i] > s[i + 1]) {
            return false;
        }
    }
    return true;
}

ll solve(ll n) {
    while (!is_tidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        ll n;
        cin >> n;
        ll ans = solve(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
