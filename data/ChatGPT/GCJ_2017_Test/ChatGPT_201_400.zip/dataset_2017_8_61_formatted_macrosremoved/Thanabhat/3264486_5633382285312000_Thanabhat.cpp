#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long find_last_tidy(long long n) {
    long long lo = 1, hi = n;
    while (lo < hi) {
        long long mid = (lo + hi) / 2;
        if (is_tidy(mid)) {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    return lo - 1;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;
        long long ans = find_last_tidy(N);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
