#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

long long get_last_tidy(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string s = to_string(n);
    int i = 0;
    while (i < s.length() - 1 && s[i] <= s[i+1]) {
        i++;
    }
    while (i > 0 && s[i] == s[i-1]) {
        i--;
    }
    s[i]--;
    for (int j = i+1; j < s.length(); j++) {
        s[j] = '9';
    }
    return stoll(s);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long last_tidy = get_last_tidy(n);
        cout << "Case #" << i << ": " << last_tidy << endl;
    }
    return 0;
}
