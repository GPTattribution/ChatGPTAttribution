// UNNECESSARY
// #include
// <chrono>//std::chrono::/system_clock/steady_clock/high_resolution_clock/duration
// #include
// <cstdio>//printf/scanf/fopen/fclose/fprintf/fscanf/snprintf/putc/puts/getc/gets
// #include <fstream>//ifstream/ofstream

// DATA STRUCTURES
#include <array>
#include <bitset>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <tuple>
#include <valarray>
#include <vector>

// MISCELLANEOUS
#include <algorithm> //min/max/sort(rand-access it)/merge
#include <cassert>
#include <climits> //INT_MAX/INT_MIN/ULLONG_MAX
#include <cmath> //fmin/fmax/fabs/sin(h)/cos(h)/tan(h)/exp/log/pow/sqrt/cbrt/ceil/floor/round/trunc
#include <cstdlib> //abs/atof/atoi/atol/atoll/strtod/strtof/..., srand/rand, calloc/malloc, exit, qsort
#include <iomanip> //setfill/setw/setprecision/fixed/scientific
#include <iostream> //cin/cout/wcin/wcout/left/right/internal/dec/hex/oct/fixed/scientific
#include <iterator>
#include <limits> //numeric_limits<type>::max/min/lowest/epsilon/infinity/quiet_NaN/signaling_NaN
#include <new>
#include <string> //stoi/stol/stoul/stoll/stoull/stof/stod/stold/to_string/getline
#include <utility> //pair
typedef unsigned int ui;
typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int, int> pii;
typedef std::pair<ll, int> plli;
typedef std::pair<ull, int> puli;
typedef std::pair<double, int> pdi;
typedef std::pair<ll, ll> pllll;
typedef std::pair<ull, ull> pulul;
typedef std::pair<double, double> pdd;
typedef std::tuple<int, int, int> ti3;
typedef std::tuple<int, int, int, int> ti4;

const bool debug = true;

// --------------------------------------------------------------------------------------

using namespace std;

int main(void) {
  int t;
  cin >> t;
  for (int test = 0; test < t; ++test) {
    int n;
    // red, ora, yel, gre, blu, vio
    int colors[6];
    char colorchars[6] = {'R', 'O', 'Y', 'G', 'B', 'V'};
    cin >> n;
    for (int i = 0; i < 6; ++i) {
      cin >> colors[i];
    }
    int red, ora, yel, gre, blu, vio;
    red = colors[0];
    ora = colors[1];
    yel = colors[2];
    gre = colors[3];
    blu = colors[4];
    vio = colors[5];

    string s(n, '?');
    // int* indices = new int[n];

    if (ora == 0 && gre == 0 && vio == 0) {
      int countmax = max({red, yel, blu});
      size_t argmax = 0;
      for (int i = 0; i < 3; ++i) {
        if (countmax == colors[2 * i]) {
          argmax = 2 * i;
          break;
        }
      }
      for (size_t pos = 0; pos < n; ++pos) {
        s[pos] = colorchars[argmax];
        // indices[pos] = argmax;
        --colors[argmax];
        countmax = 0;
        if (pos < n - 1) {
          size_t next_argmax = 7;
          for (int i = 0; i < 3; ++i) {
            if (2 * i == argmax) {
              continue;
            } else {
              if (countmax < colors[2 * i]) {
                countmax = colors[2 * i];
                next_argmax = 2 * i;
              }
            }
          }
          argmax = next_argmax;
          if (argmax == 7) {
            break;
          }
        }
      }
      if (argmax == 7) {
        s = "IMPOSSIBLE";
      } else if (s[0] == s[n - 1]) {
        if (n <= 3 || s[0] == s[n - 2] || s[n - 1] == s[n - 3]) {
          s = "IMPOSSIBLE";
        } else {
          char last = s[n - 1];
          char seco = s[n - 2];
          s[n - 1] = seco;
          s[n - 2] = last;
        }
      }
      cout << "Case #" << (test + 1) << ": " << s << '\n';
      // delete[] indices;
    } else {
      cout << "Case #" << (test + 1) << ": UNDEFINED" << '\n';
    }
  }

  return 0;
}
