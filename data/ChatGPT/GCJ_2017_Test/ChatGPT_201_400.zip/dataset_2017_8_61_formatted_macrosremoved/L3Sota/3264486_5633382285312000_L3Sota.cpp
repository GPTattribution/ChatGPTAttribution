#include <iostream>
#include <string>
using namespace std;

bool isTidy(long long n) {
    string str = to_string(n);
    for (int i = 1; i < str.length(); i++) {
        if (str[i] < str[i-1]) {
            return false;
        }
    }
    return true;
}

long long lastTidyNumber(long long n) {
    while (!isTidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;
        cout << "Case #" << i << ": " << lastTidyNumber(N) << endl;
    }
    return 0;
}
