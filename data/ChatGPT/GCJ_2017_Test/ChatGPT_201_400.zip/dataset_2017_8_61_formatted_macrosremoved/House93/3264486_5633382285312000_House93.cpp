#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    int prev = -1;
    for (char c : s) {
        int digit = c - '0';
        if (digit < prev) {
            return false;
        }
        prev = digit;
    }
    return true;
}

long long find_last_tidy(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string s = to_string(n);
    int len = s.length();
    long long ans = 0;
    for (int i = 0; i < len; i++) {
        ans = ans * 10 + 9;
    }
    for (int i = len - 1; i >= 0; i--) {
        int digit = s[i] - '0';
        if (digit != 0) {
            long long num = 0;
            for (int j = 0; j < i; j++) {
                num = num * 10 + s[j] - '0';
            }
            num = num * 10 + digit - 1;
            ans = min(ans, find_last_tidy(num));
            break;
        }
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;
        long long ans = find_last_tidy(N);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
