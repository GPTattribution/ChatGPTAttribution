#include<bits/stdc++.h>
using namespace std;

long long tidy_number(long long n){
    string s=to_string(n);
    string temp=s;
    int len=s.length();
    for(int i=len-1;i>=1;i--){
        if(s[i]<s[i-1]){
            for(int j=i;j<len;j++) temp[j]='9';
            temp[i-1]=s[i-1]-1;
        }
    }
    return stoll(temp);
}

int main(){
    int t;
    cin>>t;
    for(int i=1;i<=t;i++){
        long long n;
        cin>>n;
        cout<<"Case #"<<i<<": "<<tidy_number(n)<<endl;
    }
    return 0;
}
