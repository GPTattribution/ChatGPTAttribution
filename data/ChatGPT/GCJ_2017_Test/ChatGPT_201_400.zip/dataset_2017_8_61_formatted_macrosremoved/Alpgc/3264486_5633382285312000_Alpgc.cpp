#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string str = to_string(n);
    for (int i = 1; i < str.size(); i++) {
        if (str[i] < str[i - 1]) {
            return false;
        }
    }
    return true;
}

long long solve(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string str = to_string(n);
    int pos = str.size() - 1;
    while (pos > 0 && str[pos] <= str[pos - 1]) {
        pos--;
    }
    if (pos == 0) {
        n--;
        str = to_string(n);
        pos = str.size() - 1;
        while (pos > 0 && str[pos] == '0') {
            pos--;
        }
    }
    str[pos]--;
    for (int i = pos + 1; i < str.size(); i++) {
        str[i] = '9';
    }
    return stoll(str);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << solve(n) << endl;
    }
    return 0;
}
