#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    int prev_digit = -1;
    for (char c : s) {
        int digit = c - '0';
        if (digit < prev_digit) {
            return false;
        }
        prev_digit = digit;
    }
    return true;
}

long long last_tidy_number(long long n) {
    for (long long i = n; i >= 1; i--) {
        if (is_tidy(i)) {
            return i;
        }
    }
    return -1;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long ans = last_tidy_number(N);
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
