#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    int len = s.length();
    for (int i = 0; i < len-1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

long long find_last_tidy(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string s = to_string(n);
    int len = s.length();
    int index = len-1;
    for (int i = len-2; i >= 0; i--) {
        if (s[i] > s[i+1]) {
            index = i;
        }
    }
    s[index]--;
    for (int i = index+1; i < len; i++) {
        s[i] = '9';
    }
    while (s[0] == '0') {
        s.erase(s.begin());
    }
    return stoll(s);
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;
        long long last_tidy = find_last_tidy(N);
        cout << "Case #" << i << ": " << last_tidy << endl;
    }
    return 0;
}
