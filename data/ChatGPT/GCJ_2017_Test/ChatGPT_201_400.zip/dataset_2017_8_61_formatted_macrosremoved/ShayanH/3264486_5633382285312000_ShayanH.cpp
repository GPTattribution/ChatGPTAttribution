#include <iostream>
#include <string>
using namespace std;

bool isTidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.size() - 1; i++) {
        if (s[i] > s[i + 1])
            return false;
    }
    return true;
}

long long lastTidy(long long n) {
    while (!isTidy(n))
        n--;
    return n;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;
        long long last = lastTidy(N);
        cout << "Case #" << i << ": " << last << endl;
    }
    return 0;
}
