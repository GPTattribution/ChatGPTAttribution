#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i + 1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string s = to_string(n);
    int i;
    for (i = s.length() - 1; i >= 1; i--) {
        if (s[i] < s[i - 1]) {
            break;
        }
    }
    for (int j = i; j < s.length(); j++) {
        s[j] = '9';
    }
    for (int j = i - 1; j >= 0; j--) {
        if (s[j] > '1') {
            s[j]--;
            for (int k = j + 1; k < s.length(); k++) {
                s[k] = '9';
            }
        }
    }
    return stoll(s);
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long n;
        cin >> n;
        long long ans = last_tidy(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
