#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string str = to_string(n);
    for (int i = 1; i < str.length(); i++) {
        if (str[i] < str[i-1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy(long long n) {
    long long res = n;
    while (!is_tidy(res)) {
        res--;
    }
    return res;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << last_tidy(n) << endl;
    }
    return 0;
}
