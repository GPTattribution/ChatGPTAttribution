#include <iostream>
#include <string>

using namespace std;

bool is_tidy(string num) {
    for (int i = 0; i < num.length() - 1; i++) {
        if (num[i] > num[i + 1]) {
            return false;
        }
    }
    return true;
}

string get_tidy_number(string num) {
    int i = num.length() - 1;
    while (i > 0 && num[i - 1] > num[i]) {
        num[i - 1]--;
        for (int j = i; j < num.length(); j++) {
            num[j] = '9';
        }
        i--;
    }
    return num;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        string N;
        cin >> N;
        while (!is_tidy(N)) {
            N = get_tidy_number(N);
        }
        cout << "Case #" << t << ": " << N << endl;
    }
    return 0;
}
