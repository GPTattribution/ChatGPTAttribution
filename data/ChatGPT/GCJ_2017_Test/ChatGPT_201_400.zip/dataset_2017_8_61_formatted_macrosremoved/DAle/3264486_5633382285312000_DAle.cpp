#include <iostream>
#include <string>

using namespace std;

long long getLargestTidyNumber(long long N) {
    string str = to_string(N);
    int len = str.length();
    int i = 0;
    while (i < len - 1 && str[i] <= str[i + 1]) {
        i++;
    }
    if (i == len - 1) {
        return N;
    }
    while (i >= 0 && str[i] > str[i + 1]) {
        str[i] = str[i] - 1;
        i--;
    }
    for (int j = i + 1; j < len; j++) {
        str[j] = '9';
    }
    return stoll(str);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long lastTidyNumber = getLargestTidyNumber(N);
        cout << "Case #" << t << ": " << lastTidyNumber << endl;
    }
    return 0;
}
