#include <iostream>
#include <string>
using namespace std;

bool is_tidy(string num) {
    for (int i = 1; i < num.length(); i++) {
        if (num[i] < num[i-1]) {
            return false;
        }
    }
    return true;
}

string get_last_tidy_number(string num) {
    int i = num.length()-1;
    while (i > 0 && num[i] < num[i-1]) {
        num[i-1]--;
        i--;
    }
    for (int j = i; j < num.length(); j++) {
        num[j] = '9';
    }
    while (num[0] == '0') {
        num.erase(0, 1);
    }
    return num;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        string num;
        cin >> num;
        while (!is_tidy(num)) {
            num = get_last_tidy_number(num);
        }
        cout << "Case #" << t << ": " << num << endl;
    }
    return 0;
}
