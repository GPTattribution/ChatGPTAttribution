#include <iostream>
#include <string>
using namespace std;

bool isTidy(long long n) {
    string s = to_string(n);
    int len = s.length();
    for (int i = 1; i < len; i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long findLargestTidy(long long n) {
    if (isTidy(n)) {
        return n;
    }
    string s = to_string(n);
    int len = s.length();
    int pos = -1;
    for (int i = 1; i < len; i++) {
        if (s[i] < s[i-1]) {
            pos = i-1;
            break;
        }
    }
    if (pos == -1) {
        return n;
    }
    while (pos > 0 && s[pos] == s[pos-1]) {
        pos--;
    }
    s[pos] = s[pos] - 1;
    for (int i = pos+1; i < len; i++) {
        s[i] = '9';
    }
    return stoll(s);
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long ans = findLargestTidy(N);
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
