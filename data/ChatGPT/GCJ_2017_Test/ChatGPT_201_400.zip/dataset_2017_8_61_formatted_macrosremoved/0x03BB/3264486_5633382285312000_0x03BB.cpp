#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    int len = s.length();
    for (int i = 1; i < len; i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

long long find_last_tidy(long long n) {
    while (!is_tidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;
        long long last_tidy = find_last_tidy(N);
        cout << "Case #" << i << ": " << last_tidy << endl;
    }
    return 0;
}
