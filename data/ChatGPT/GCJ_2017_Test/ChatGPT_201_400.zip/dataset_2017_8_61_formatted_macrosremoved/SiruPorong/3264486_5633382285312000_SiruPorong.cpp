#include <iostream>
#include <string>
using namespace std;

bool isTidy(string num) {
    for (int i = 1; i < num.length(); i++) {
        if (num[i] < num[i-1]) {
            return false;
        }
    }
    return true;
}

string makeTidy(string num) {
    int i = num.length()-1;
    while (i > 0 && num[i-1] > num[i]) {
        num[i-1]--;
        for (int j = i; j < num.length(); j++) {
            num[j] = '9';
        }
        i--;
    }
    return num;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        string N;
        cin >> N;

        while (!isTidy(N)) {
            N = makeTidy(N);
        }

        cout << "Case #" << t << ": " << N << endl;
    }

    return 0;
}
