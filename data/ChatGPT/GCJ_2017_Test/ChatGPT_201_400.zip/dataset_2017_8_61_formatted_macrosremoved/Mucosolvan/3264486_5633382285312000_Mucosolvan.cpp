#include <iostream>
#include <string>

using namespace std;

long long find_last_tidy_number(long long N) {
    string str = to_string(N);
    int n = str.size();
    int index = n;

    for (int i = n - 1; i > 0; i--) {
        if (str[i] < str[i - 1]) {
            index = i - 1;
            str[index]--;
        }
    }

    for (int i = index + 1; i < n; i++) {
        str[i] = '9';
    }

    int i = 0;
    while (str[i] == '0') {
        i++;
    }

    return stoll(str.substr(i));
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;

        long long last_tidy_number = find_last_tidy_number(N);

        cout << "Case #" << i << ": " << last_tidy_number << endl;
    }

    return 0;
}
