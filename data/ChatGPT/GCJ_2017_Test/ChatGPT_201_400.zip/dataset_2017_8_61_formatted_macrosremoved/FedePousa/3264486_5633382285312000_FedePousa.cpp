#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
  string s = to_string(n);
  for (int i = 0; i < s.size() - 1; i++) {
    if (s[i] > s[i+1]) {
      return false;
    }
  }
  return true;
}

long long find_last_tidy(long long n) {
  long long last_tidy = n;
  while (!is_tidy(last_tidy)) {
    last_tidy--;
  }
  return last_tidy;
}

int main() {
  int T;
  cin >> T;
  for (int t = 1; t <= T; t++) {
    long long N;
    cin >> N;
    long long last_tidy = find_last_tidy(N);
    cout << "Case #" << t << ": " << last_tidy << endl;
  }
  return 0;
}
