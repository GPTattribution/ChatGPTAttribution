#include <iostream>
#include <string>
using namespace std;

bool is_tidy(string n) {
    for (int i = 0; i < n.length() - 1; i++) {
        if (n[i] > n[i+1]) {
            return false;
        }
    }
    return true;
}

string get_tidy(string n) {
    int i = 0;
    while (i < n.length() - 1 && n[i] <= n[i+1]) {
        i++;
    }
    while (i > 0 && n[i] == n[i-1]) {
        i--;
    }
    if (i == n.length() - 1) {
        return n;
    } else {
        n[i]--;
        for (int j = i + 1; j < n.length(); j++) {
            n[j] = '9';
        }
        return get_tidy(n);
    }
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        while (!is_tidy(n)) {
            n = get_tidy(n);
        }
        cout << "Case #" << i << ": " << n << endl;
    }
    return 0;
}
