#include <iostream>
#include <string>

using namespace std;

long long get_last_tidy_number(long long N) {
    string s = to_string(N);
    int n = s.size();
    int last = n-1;

    for (int i = last; i > 0; i--) {
        if (s[i] < s[i-1]) {
            s[i-1]--;
            for (int j = i; j <= last; j++) {
                s[j] = '9';
            }
        }
    }

    return stoll(s);
}

int main() {
    int T;
    cin >> T;

    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;

        long long result = get_last_tidy_number(N);
        cout << "Case #" << i << ": " << result << endl;
    }

    return 0;
}
