#include <iostream>
#include <string>

using namespace std;

bool is_tidy(const string& num) {
    for (int i = 0; i < num.size() - 1; i++) {
        if (num[i] > num[i + 1]) {
            return false;
        }
    }
    return true;
}

string make_tidy(string num) {
    int i = num.size() - 1;
    while (i > 0 && num[i] < num[i - 1]) {
        num[i - 1] -= 1;
        for (int j = i; j < num.size(); j++) {
            num[j] = '9';
        }
        i--;
    }
    return num;
}

int main() {
    int t;
    cin >> t;
    for (int case_num = 1; case_num <= t; case_num++) {
        string n;
        cin >> n;
        while (!is_tidy(n)) {
            n = make_tidy(n);
        }
        cout << "Case #" << case_num << ": " << n << endl;
    }
    return 0;
}
