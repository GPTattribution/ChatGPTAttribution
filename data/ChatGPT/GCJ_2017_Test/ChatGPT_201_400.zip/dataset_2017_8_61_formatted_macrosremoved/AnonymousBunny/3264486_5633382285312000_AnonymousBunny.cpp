#include <bits/stdc++.h>
using namespace std;

long long solve(long long n) {
    string s = to_string(n);
    int len = s.length();
    int pos = -1;

    for (int i = len - 1; i > 0; i--) {
        if (s[i] < s[i - 1]) {
            pos = i - 1;
            break;
        }
    }

    if (pos == -1) {
        return n;
    }

    for (int i = pos + 1; i < len; i++) {
        s[i] = '9';
    }

    while (pos > 0 && s[pos - 1] > s[pos]) {
        s[pos - 1]--;
        s[pos] = '9';
        pos--;
    }

    return stoll(s);
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;

        long long ans = solve(n);

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
