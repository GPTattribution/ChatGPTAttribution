#include <bits/stdc++.h>
using namespace std;

long long int last_tidy_number(long long int n) {
    string s = to_string(n);
    int len = s.length();
    int pos = len - 1;

    for(int i = len - 2; i >= 0; i--) {
        if(s[i] > s[i + 1]) {
            pos = i;
            s[i]--;
        }
    }

    for(int i = pos + 1; i < len; i++) {
        s[i] = '9';
    }

    if(s[0] == '0') {
        s.erase(0, 1);
    }

    return stoll(s);
}

int main() {
    int t;
    cin >> t;

    for(int i = 1; i <= t; i++) {
        long long int n;
        cin >> n;

        long long int ans = last_tidy_number(n);

        cout << "Case #" << i << ": " << ans << endl;
    }

    return 0;
}
