#include <iostream>
#include <string>

using namespace std;

bool is_tidy(string num) {
    int prev_digit = -1;
    for (char c : num) {
        int digit = c - '0';
        if (digit < prev_digit) {
            return false;
        }
        prev_digit = digit;
    }
    return true;
}

string get_last_tidy_number(string num) {
    int i = num.length() - 1;
    while (i > 0 && num[i - 1] > num[i]) {
        num[i - 1]--;
        i--;
    }
    for (int j = i; j < num.length(); j++) {
        num[j] = '9';
    }
    return num;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        while (!is_tidy(n)) {
            n = get_last_tidy_number(n);
        }
        cout << "Case #" << i << ": " << n << endl;
    }
    return 0;
}
