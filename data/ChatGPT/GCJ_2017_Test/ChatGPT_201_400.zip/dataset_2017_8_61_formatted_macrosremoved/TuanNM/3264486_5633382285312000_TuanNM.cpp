#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.size() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

long long find_tidy(long long n) {
    long long left = 1, right = n, result = 0;
    while (left <= right) {
        long long mid = (left + right) / 2;
        if (is_tidy(mid)) {
            result = mid;
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return result;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;
        long long result = find_tidy(N);
        cout << "Case #" << i << ": " << result << endl;
    }
    return 0;
}
