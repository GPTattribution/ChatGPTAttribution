#include <iostream>
#include <string>

using namespace std;

bool is_tidy(const string& s) {
    for (int i = 1; i < s.length(); i++) {
        if (s[i] < s[i-1]) {
            return false;
        }
    }
    return true;
}

string make_tidy(string s) {
    for (int i = s.length()-1; i > 0; i--) {
        if (s[i] < s[i-1]) {
            s[i-1]--;
            for (int j = i; j < s.length(); j++) {
                s[j] = '9';
            }
        }
    }
    return s;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        string s;
        cin >> s;
        while (!is_tidy(s)) {
            s = make_tidy(s);
        }
        cout << "Case #" << t << ": " << s << endl;
    }
    return 0;
}
