#include <iostream>
#include <string>

using namespace std;

string findLastTidyNumber(string N) {
    int i = 0;
    while (i < N.length() - 1 && N[i] <= N[i+1]) {
        i++;
    }
    while (i > 0 && N[i] < N[i-1]) {
        N[i-1]--;
        i--;
    }
    for (int j = i+1; j < N.length(); j++) {
        N[j] = '9';
    }
    return N;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        string N;
        cin >> N;
        cout << "Case #" << i << ": " << findLastTidyNumber(N) << endl;
    }
    return 0;
}
