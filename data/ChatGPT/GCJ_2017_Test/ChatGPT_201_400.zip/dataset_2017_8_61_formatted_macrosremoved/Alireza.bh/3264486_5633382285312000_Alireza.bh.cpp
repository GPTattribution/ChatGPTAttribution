#include <iostream>
#include <string>
using namespace std;

string lastTidyNumber(string n) {
    int len = n.length();
    int index = len;
    for (int i = len - 1; i > 0; i--) {
        if (n[i] < n[i - 1]) {
            index = i;
            n[i - 1]--;
        }
    }
    for (int i = index; i < len; i++) {
        n[i] = '9';
    }
    int leadingZero = 0;
    while (n[leadingZero] == '0') {
        leadingZero++;
    }
    return n.substr(leadingZero);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        cout << "Case #" << i << ": " << lastTidyNumber(n) << endl;
    }
    return 0;
}
