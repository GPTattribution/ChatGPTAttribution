#include <iostream>
#include <string>
using namespace std;

long long findLastTidyNumber(long long n) {
    string s = to_string(n);
    int len = s.length();
    int lastNonDec = len - 1;
    for (int i = len - 2; i >= 0; i--) {
        if (s[i] > s[lastNonDec]) {
            for (int j = lastNonDec; j < len; j++) {
                s[j] = '9';
            }
            s[i] = s[i] - 1;
            lastNonDec = i + 1;
        } else {
            lastNonDec = i;
        }
    }
    return stoll(s);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long ans = findLastTidyNumber(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
