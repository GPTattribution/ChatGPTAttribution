#include <iostream>
#include <string>

using namespace std;

bool isTidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

long long findLastTidy(long long n) {
    while (!isTidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << findLastTidy(n) << endl;
    }
    return 0;
}
