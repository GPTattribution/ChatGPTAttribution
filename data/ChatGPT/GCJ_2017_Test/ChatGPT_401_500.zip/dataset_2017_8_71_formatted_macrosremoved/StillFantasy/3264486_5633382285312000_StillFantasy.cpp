#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    int len = s.length();
    for (int i = 1; i < len; i++) {
        if (s[i] < s[i - 1]) {
            return false;
        }
    }
    return true;
}

long long find_last_tidy(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string s = to_string(n);
    int len = s.length();
    for (int i = len - 1; i >= 1; i--) {
        if (s[i] < s[i - 1]) {
            s[i - 1] = s[i - 1] - 1;
            for (int j = i; j < len; j++) {
                s[j] = '9';
            }
        }
    }
    return stoll(s);
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long n;
        cin >> n;
        long long last_tidy = find_last_tidy(n);
        cout << "Case #" << i << ": " << last_tidy << endl;
    }
    return 0;
}
