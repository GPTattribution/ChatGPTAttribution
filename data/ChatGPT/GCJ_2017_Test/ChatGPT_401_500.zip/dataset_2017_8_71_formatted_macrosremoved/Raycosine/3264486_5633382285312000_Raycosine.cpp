#include <iostream>
#include <string>

using namespace std;

long long findTidyNumber(long long N) {
    string s = to_string(N);
    int n = s.length();

    int i = n-2;
    while (i >= 0 && s[i] <= s[i+1]) {
        i--;
    }

    if (i < 0) {
        return N;
    }

    for (int j = i+1; j < n; j++) {
        s[j] = '9';
    }

    while (i >= 0 && s[i] > s[i+1]) {
        s[i] = s[i] - 1;
        i--;
    }

    return stoll(s);
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;

        long long lastTidyNumber = findTidyNumber(N);
        cout << "Case #" << t << ": " << lastTidyNumber << endl;
    }

    return 0;
}
