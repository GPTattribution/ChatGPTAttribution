#include <iostream>
#include <string>

using namespace std;

long long get_last_tidy_number(long long n) {
    string s = to_string(n);
    int last_tidy_pos = s.size() - 1;
    for (int i = s.size() - 2; i >= 0; i--) {
        if (s[i] > s[last_tidy_pos]) {

            s[i]--;
            last_tidy_pos = i + 1;
            for (int j = last_tidy_pos; j < s.size(); j++) {
                s[j] = '9';
            }
        } else {
            last_tidy_pos = i;
        }
    }
    return stoll(s);
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;
        long long last_tidy = get_last_tidy_number(N);
        cout << "Case #" << i << ": " << last_tidy << endl;
    }
    return 0;
}
