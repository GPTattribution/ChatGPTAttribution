#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    int last_digit = 0;
    for (char c : s) {
        int digit = c - '0';
        if (digit < last_digit) {
            return false;
        }
        last_digit = digit;
    }
    return true;
}

long long last_tidy(long long n) {
    if (is_tidy(n)) {
        return n;
    }
    string s = to_string(n);
    int len = s.length();
    for (int i = len - 2; i >= 0; i--) {
        if (s[i] > '1') {
            s[i]--;
            for (int j = i + 1; j < len; j++) {
                s[j] = '9';
            }
        }
    }
    return stoll(s);
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << last_tidy(n) << endl;
    }
    return 0;
}
