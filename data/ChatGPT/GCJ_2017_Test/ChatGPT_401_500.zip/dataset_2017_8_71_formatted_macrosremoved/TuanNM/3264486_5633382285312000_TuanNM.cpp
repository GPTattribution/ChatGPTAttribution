#include<bits/stdc++.h>
using namespace std;

bool isTidy(long long n) {
    long long lastDigit = n % 10;
    while (n > 0) {
        n /= 10;
        if (n % 10 > lastDigit) {
            return false;
        }
        lastDigit = n % 10;
    }
    return true;
}

long long findLastTidyNumber(long long n) {
    while (!isTidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        cout << "Case #" << i << ": " << findLastTidyNumber(n) << endl;
    }
    return 0;
}
