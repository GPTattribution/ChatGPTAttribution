#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i + 1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy_number(long long n) {
    while (!is_tidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long ans = last_tidy_number(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
