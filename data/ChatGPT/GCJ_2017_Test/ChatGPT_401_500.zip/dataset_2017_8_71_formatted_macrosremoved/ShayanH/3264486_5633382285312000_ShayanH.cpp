#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i + 1]) {
            return false;
        }
    }
    return true;
}

long long get_last_tidy_number(long long n) {
    long long left = 1;
    long long right = n;
    long long last_tidy = 0;
    while (left <= right) {
        long long mid = (left + right) / 2;
        if (is_tidy(mid)) {
            last_tidy = mid;
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return last_tidy;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long last_tidy = get_last_tidy_number(n);
        cout << "Case #" << i << ": " << last_tidy << endl;
    }
    return 0;
}
