#include<bits/stdc++.h>
using namespace std;

bool isTidy(long long n) {
    long long prevDigit = 10;
    while(n > 0) {
        long long currDigit = n % 10;
        if(currDigit > prevDigit) {
            return false;
        }
        prevDigit = currDigit;
        n /= 10;
    }
    return true;
}

int main() {
    int T;
    cin >> T;
    for(int i = 1; i <= T; i++) {
        long long N;
        cin >> N;
        long long ans = N;
        while(!isTidy(ans)) {
            ans--;
        }
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
