#include <iostream>
#include <string>

using namespace std;

bool is_tidy(string n) {
    for (int i = 0; i < n.size() - 1; i++) {
        if (n[i] > n[i+1]) {
            return false;
        }
    }
    return true;
}

string make_tidy(string n) {
    int pos = n.size() - 1;
    for (int i = n.size() - 1; i > 0; i--) {
        if (n[i-1] > n[i]) {
            pos = i - 1;
            n[pos]--;
        }
    }
    for (int i = pos+1; i < n.size(); i++) {
        n[i] = '9';
    }
    while (n.size() > 1 && n[0] == '0') {
        n.erase(0, 1);
    }
    return n;
}

string solve(string n) {
    if (is_tidy(n)) {
        return n;
    } else {
        return solve(make_tidy(n));
    }
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        string n;
        cin >> n;
        cout << "Case #" << i << ": " << solve(n) << endl;
    }
    return 0;
}
