#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    int len = s.length();
    for (int i = 1; i < len; i++) {
        if (s[i] < s[i - 1]) {
            return false;
        }
    }
    return true;
}

long long get_last_tidy_number(long long n) {
    while (!is_tidy(n)) {
        n--;
    }
    return n;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;
        long long last_tidy_number = get_last_tidy_number(N);
        cout << "Case #" << t << ": " << last_tidy_number << endl;
    }
    return 0;
}
