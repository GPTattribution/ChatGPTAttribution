#include <iostream>
#include <string>

using namespace std;

string get_last_tidy_number(string s) {
    int n = s.length();
    int j = n - 1;

    while (j > 0 && s[j-1] > s[j]) {
        j--;
    }

    if (j == 0) {
        return s;
    }

    s[j-1]--;
    for (int i = j; i < n; i++) {
        s[i] = '9';
    }

    return get_last_tidy_number(s);
}

int main() {
    int t;
    cin >> t;

    for (int i = 1; i <= t; i++) {
        string s;
        cin >> s;
        cout << "Case #" << i << ": " << get_last_tidy_number(s) << endl;
    }

    return 0;
}
