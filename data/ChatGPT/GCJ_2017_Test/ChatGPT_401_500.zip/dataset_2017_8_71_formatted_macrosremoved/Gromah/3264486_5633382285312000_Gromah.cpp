#include <iostream>
#include <string>

using namespace std;

bool is_tidy(const string& number) {
    for (int i = 0; i < number.size() - 1; i++) {
        if (number[i] > number[i+1]) {
            return false;
        }
    }
    return true;
}

string make_tidy(const string& number) {
    string tidy_number = number;
    for (int i = 0; i < tidy_number.size() - 1; i++) {
        if (tidy_number[i] > tidy_number[i+1]) {
            tidy_number[i] = char(tidy_number[i] - 1);
            for (int j = i+1; j < tidy_number.size(); j++) {
                tidy_number[j] = '9';
            }
        }
    }
    return tidy_number;
}

string find_last_tidy_number(const string& n) {
    string last_tidy_number = n;
    while (!is_tidy(last_tidy_number)) {
        last_tidy_number = make_tidy(last_tidy_number);
    }
    return last_tidy_number;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        string last_tidy_number = find_last_tidy_number(n);
        cout << "Case #" << i << ": " << last_tidy_number << endl;
    }
    return 0;
}
