#include <iostream>
#include <string>

using namespace std;

bool isTidy(long long n) {
    string s = to_string(n);
    int len = s.length();
    for (int i = 1; i < len; i++) {
        if (s[i] < s[i-1])
            return false;
    }
    return true;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        while (!isTidy(n)) {
            n--;
        }
        cout << "Case #" << i << ": " << n << endl;
    }
    return 0;
}
