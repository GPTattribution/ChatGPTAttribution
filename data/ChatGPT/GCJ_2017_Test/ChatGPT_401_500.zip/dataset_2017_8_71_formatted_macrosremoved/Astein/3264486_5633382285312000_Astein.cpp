#include <iostream>
#include <string>

using namespace std;

string largestTidyNumber(string n) {
    int len = n.length();
    int lastNonNine = len - 1;
    for (int i = len - 2; i >= 0; i--) {
        if (n[i] > n[i + 1]) {
            lastNonNine = i;
            n[i]--;
        }
    }
    for (int i = lastNonNine + 1; i < len; i++) {
        n[i] = '9';
    }
    while (n[0] == '0') {
        n.erase(0, 1);
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        string n;
        cin >> n;
        cout << "Case #" << i << ": " << largestTidyNumber(n) << endl;
    }
    return 0;
}
