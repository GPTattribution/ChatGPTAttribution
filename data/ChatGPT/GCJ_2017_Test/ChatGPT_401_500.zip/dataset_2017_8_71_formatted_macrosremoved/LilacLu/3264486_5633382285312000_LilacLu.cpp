#include <iostream>
#include <string>

using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    int prev = -1;
    for (char c : s) {
        int digit = c - '0';
        if (digit < prev) {
            return false;
        }
        prev = digit;
    }
    return true;
}

long long find_last_tidy(long long n) {
    while (!is_tidy(n)) {
        int prev = -1;
        int scale = 1;
        while (n > 0) {
            int digit = n % 10;
            if (digit > prev) {
                prev = digit;
            } else {
                n = (n / 10 + 1) * scale;
                break;
            }
            prev = digit;
            n /= 10;
            scale *= 10;
        }
    }
    return n;
}

int main() {
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++) {
        long long n;
        cin >> n;
        long long ans = find_last_tidy(n);
        cout << "Case #" << i << ": " << ans << endl;
    }
    return 0;
}
