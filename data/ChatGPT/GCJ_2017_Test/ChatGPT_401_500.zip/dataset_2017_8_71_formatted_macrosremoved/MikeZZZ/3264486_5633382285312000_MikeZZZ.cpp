#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string str = to_string(n);
    int len = str.length();
    for (int i = 1; i < len; i++) {
        if (str[i] < str[i-1]) {
            return false;
        }
    }
    return true;
}

long long last_tidy_number(long long n) {
    while (!is_tidy(n)) {
        string str = to_string(n);
        int len = str.length();
        int i;
        for (i = len-1; i > 0; i--) {
            if (str[i] < str[i-1]) {
                break;
            }
        }
        str[i-1]--;
        for (int j = i; j < len; j++) {
            str[j] = '9';
        }
        n = stoll(str);
    }
    return n;
}

int main() {
    int T;
    cin >> T;
    for (int i = 1; i <= T; i++) {
        long long N;
        cin >> N;
        long long result = last_tidy_number(N);
        cout << "Case #" << i << ": " << result << endl;
    }
    return 0;
}
