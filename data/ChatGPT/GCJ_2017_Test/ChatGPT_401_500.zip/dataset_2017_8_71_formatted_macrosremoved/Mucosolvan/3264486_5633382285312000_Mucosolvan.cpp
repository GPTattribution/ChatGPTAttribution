#include <iostream>
#include <string>
using namespace std;

bool is_tidy(long long n) {
    string s = to_string(n);
    for (int i = 0; i < s.length() - 1; i++) {
        if (s[i] > s[i+1]) {
            return false;
        }
    }
    return true;
}

int main() {
    int T;
    cin >> T;

    for (int t = 1; t <= T; t++) {
        long long N;
        cin >> N;

        long long tidy = N;
        while (!is_tidy(tidy)) {
            tidy--;
        }

        cout << "Case #" << t << ": " << tidy << endl;
    }

    return 0;
}
